import express from "express";
import {
  getWorkOrderNosByClientName,
  getSubjectAndAmountByWorkOrderNo,
  createInvoice,
  getLatestBillNo, // <-- Import the new controller
} from "../controllers/InvoiceController.js";

const invoiceRouter = express.Router();

// Route to get Work Order numbers by client name
invoiceRouter.get("/reference-number", getWorkOrderNosByClientName);

// Route to get Subject and Total Amount by Work Order number
invoiceRouter.get("/work-order-details", getSubjectAndAmountByWorkOrderNo);
invoiceRouter.get("/create", createInvoice);
invoiceRouter.get("/get-latest-bill-no", getLatestBillNo);

export default invoiceRouter;
