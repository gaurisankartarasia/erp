// // import { Router } from 'express';

// // import {
// //   createJoiningLetter,
// //   getJoiningLetterById,
// //   updateJoiningLetter,
// //   deleteJoiningLetter,
// //   handleCreateValidation,
// //   handleUpdateValidation,
// //   handleParamValidation,
// // } from "../controllers/JoingLetterController.js"
// // import { protect } from '../middlewares/AuthMiddleware.js';

// // const router = Router();

// // // Apply authentication to all routes
// // router.use(protect);

// // // Route for creating a new letter
// // router.route('/create')
// //   .post(handleCreateValidation, createJoiningLetter);

// // router.route('/:id')
// //   .get(handleParamValidation, getJoiningLetterById)
// //   .put(handleUpdateValidation, updateJoiningLetter)
// //   .delete(handleParamValidation, deleteJoiningLetter);

// // export default router;

// import { Router } from 'express';
// import {
//   createJoiningLetter,
//   getJoiningLetterById,
//   updateJoiningLetter,
//   deleteJoiningLetter,
//   getAllJoiningLetters,
//   handleCreateValidation,
//   handleUpdateValidation,
//   handleParamValidation,
// } from "../controllers/JoingLetterController.js";
// import { protect } from '../middlewares/AuthMiddleware.js';

// const router = Router();

// // Apply authentication to all routes
// router.use(protect);

// // Route for getting all joining letters and creating a new one
// router.route('/')
//   .get(getAllJoiningLetters) 
//   // Route to fetch all joining letters
//   router.post("/create", handleCreateValidation, createJoiningLetter); // Corrected route to create joining letter

// // Route for handling CRUD operations on a specific joining letter by ID
// router.route('/:id')
//   .get(handleParamValidation, getJoiningLetterById)  // Route to get a joining letter by ID
//   .put(handleUpdateValidation, updateJoiningLetter)  // Route to update a joining letter
//   .delete(handleParamValidation, deleteJoiningLetter);  // Route to delete a joining letter

// export default router;




import { Router } from 'express';
import {
  createJoiningLetter,
  getJoiningLetterById,
  updateJoiningLetter,
  deleteJoiningLetter,
  getAllJoiningLetters,
  handleCreateValidation,
  handleUpdateValidation,
  handleParamValidation,
} from "../controllers/JoingLetterController.js";
import { protect } from '../middlewares/AuthMiddleware.js';

const router = Router();

// Apply authentication to all routes
router.use(protect);

// Route for getting all joining letters
router.get('/', getAllJoiningLetters);

// Route for creating a new joining letter
router.post('/create', handleCreateValidation, createJoiningLetter);

// Route for handling CRUD operations on a specific joining letter by ID
router.route('/:id')
  .get(handleParamValidation, getJoiningLetterById)
  .put(handleUpdateValidation, updateJoiningLetter)
  .delete(handleParamValidation, deleteJoiningLetter);

export default router;