import { Router } from 'express';
import {
  createSalaryAnnexure,
  getSalaryAnnexureById,
  updateSalaryAnnexure,
  deleteSalaryAnnexure,
  getAllSalaryAnnexures,
  handleCreateValidation,
  handleUpdateValidation,
  handleParamValidation,
} from "../controllers/SalaryAnnexureController.js";
import { protect } from '../middlewares/AuthMiddleware.js';

const router = Router();

// Apply authentication to all routes
router.use(protect);

// Route for getting all salary annexures
router.get('/', getAllSalaryAnnexures);

// Route for creating a new salary annexure
router.post('/create', handleCreateValidation, createSalaryAnnexure);

// Route for handling CRUD operations on a specific salary annexure by ID
router.route('/:id')
  .get(handleParamValidation, getSalaryAnnexureById)
  .put(handleUpdateValidation, updateSalaryAnnexure)
  .delete(handleParamValidation, deleteSalaryAnnexure);

export default router;