import { Router } from "express";
import {
  getAllStaffExpenses,
  getStaffExpenseById,
  addStaffExpense,
  editStaffExpense,
} from "../controllers/StaffExpenseController.js";
import upload from "../middlewares/UploadMiddleware.js";

const staffExpenseRouter = Router();

// Configure file upload for staff expense documents
const expenseDocumentUpload = upload({
  mode: "single",
  field: "document",
  uploadDir: "public/uploads/staff-expenses",
  allowedTypes: ["application/pdf"],
  prefix: "staff-expense",
  resize: false,
});

// Routes
staffExpenseRouter.get("/", getAllStaffExpenses);               // GET all staff expenses with pagination/search
staffExpenseRouter.get("/:id", getStaffExpenseById);            // GET single staff expense by ID
staffExpenseRouter.post("/add", expenseDocumentUpload, addStaffExpense);  // POST new staff expense
staffExpenseRouter.put("/edit/:id", expenseDocumentUpload, editStaffExpense); // PUT update staff expense

export default staffExpenseRouter;
