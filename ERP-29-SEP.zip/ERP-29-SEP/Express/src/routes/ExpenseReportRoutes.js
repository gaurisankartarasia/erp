import { Router } from "express";
import {
  getExpenseReport,
  exportExpenseReport,
} from "../controllers/ExpenseReportController.js";

const router = Router();

router.get("/", getExpenseReport);

router.get("/export", exportExpenseReport);

export default router;
