import { Router } from "express";
import {
  addDesignation,
  editDesignation,
  getAllDesignations,
  updateDesignationStatus,
  getDesignationById
} from "../controllers/DesignationController.js";

const router = Router();

router.get('/', getAllDesignations);
router.get('/:id', getDesignationById);
router.post("/create", addDesignation);
router.put("/edit/:id", editDesignation);
router.patch('/status/:id', updateDesignationStatus);


export default router;
