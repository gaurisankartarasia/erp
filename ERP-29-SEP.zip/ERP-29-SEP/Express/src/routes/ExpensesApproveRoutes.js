import { Router } from "express";
import {
  getPayers,
  searchExpenses,
  approveExpenses,
} from "../controllers/ExpensesApproveController.js";

const router = Router();

router.get("/payers", getPayers);

router.get("/search", searchExpenses);

router.patch("/approve", approveExpenses);

export default router;
