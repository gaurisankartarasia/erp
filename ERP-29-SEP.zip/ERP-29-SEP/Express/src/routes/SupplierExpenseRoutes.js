import { Router } from "express";
import {
    getAllSupplierExpenses,
  getAllSuppliers,
  addSupplierExpense,
  editSupplierExpense,
  getSupplierExpenseById
} from "../controllers/SupplierExpenseController.js";
import upload from "../middlewares/UploadMiddleware.js";

const router = Router();

const expenseDocumentUpload = upload({
  mode: "single",
  field: "document",
  uploadDir: "public/uploads/supplier-expenses",
  allowedTypes: ["application/pdf"],
  prefix: "supplier-expense",
  resize: false,
});

router.get("/", getAllSupplierExpenses);
router.get("/suppliers", getAllSuppliers);

router.get("/:id", getSupplierExpenseById);

router.post("/add", expenseDocumentUpload, addSupplierExpense);

router.put("/edit/:id", expenseDocumentUpload, editSupplierExpense);

export default router;
