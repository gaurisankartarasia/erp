import { models } from "../models/index.js";

// Destructure the models we need
const { State, District } = models;

// --- State Operations ---

/**
 * @desc    Get all active states
 * @route   GET /api/locations/states
 */
export const getAllStates = async (req, res) => {
  try {
    const states = await State.findAll({
      where: {
        is_active: true,
        is_delete: false,
      },
      order: [['state_name', 'ASC']],
    });
    res.status(200).json({ message: "States retrieved successfully.", data: states });
  } catch (error) {
    console.error("Error fetching states:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Get a single state by its ID, including its districts
 * @route   GET /api/locations/states/:id
 */
export const getStateWithDistricts = async (req, res) => {
  try {
    const { id } = req.params;
    const state = await State.findOne({
      where: { id, is_delete: false },
      include: [{
        model: District,
        where: { is_active: true, is_delete: false },
        required: false // Use false to return the state even if it has no districts
      }]
    });

    if (!state) {
      return res.status(404).json({ message: "State not found." });
    }

    res.status(200).json({ message: "State and its districts retrieved successfully.", data: state });
  } catch (error) {
    console.error("Error fetching state with districts:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Create a new state
 * @route   POST /api/locations/states
 */
export const createState = async (req, res) => {
    try {
        const { state_name } = req.body;
        if (!state_name) {
            return res.status(400).json({ message: "State name is required." });
        }
        const newState = await State.create({ state_name });
        res.status(201).json({ message: "State created successfully.", data: newState });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// --- District Operations ---

/**
 * @desc    Get all active districts, including their parent state's name
 * @route   GET /api/locations/districts
 */
export const getAllDistricts = async (req, res) => {
  try {
    const districts = await District.findAll({
      where: {
        is_active: true,
        is_delete: false,
      },
      include: [{
        model: State,
        attributes: ['id', 'state_name'] // Only get the ID and name from the State model
      }],
      order: [['district_name', 'ASC']],
    });
    res.status(200).json({ message: "Districts retrieved successfully.", data: districts });
  } catch (error) {
    console.error("Error fetching districts:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Get all districts that belong to a specific state
 * @route   GET /api/locations/states/:stateId/districts
 */
export const getDistrictsByState = async (req, res) => {
  try {
    const { stateId } = req.params;
    const districts = await District.findAll({
      where: {
        state_id: stateId,
        is_active: true,
        is_delete: false
      },
      order: [['district_name', 'ASC']]
    });
    res.status(200).json({ message: `Districts for state ID ${stateId} retrieved.`, data: districts });
  } catch (error) {
    console.error("Error fetching districts by state:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Create a new district
 * @route   POST /api/locations/districts
 */
export const createDistrict = async (req, res) => {
    try {
        const { district_name, state_id } = req.body;
        if (!district_name || !state_id) {
            return res.status(400).json({ message: "District name and State ID are required." });
        }
        const newDistrict = await District.create({ district_name, state_id });
        res.status(201).json({ message: "District created successfully.", data: newDistrict });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};