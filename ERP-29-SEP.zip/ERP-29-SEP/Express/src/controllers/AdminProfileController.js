import { models } from "../models/index.js";

// Get the AdminProfile model
const { AdminProfile } = models;

// We assume we are always working with the first (and only) record.
const PROFILE_ID = 1;

/**
 * @desc    Get the single admin profile/company settings
 * @route   GET /api/admin-profile
 * @access  Private (Admin)
 */
export const getAdminProfile = async (req, res) => {
  try {
    const profile = await AdminProfile.findByPk(PROFILE_ID);

    if (!profile) {
      // This might happen if the database is empty.
      // You could choose to create a default one here, or send an error.
      return res.status(404).json({ message: "Admin profile not found. Please initialize settings." });
    }

    // We don't want to send the hashed password to the frontend
    const profileData = profile.toJSON();
    delete profileData.password;

    res.status(200).json({ message: "Profile retrieved successfully.", data: profileData });
  } catch (error) {
    console.error("Error fetching admin profile:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Update the single admin profile/company settings
 * @route   PUT /api/admin-profile
 * @access  Private (Admin)
 */
export const updateAdminProfile = async (req, res) => {
  try {
    const profile = await AdminProfile.findByPk(PROFILE_ID);

    if (!profile) {
      return res.status(404).json({ message: "Admin profile not found." });
    }
    
    // If the password field is sent and is empty, don't update it.
    // This prevents accidentally wiping the password.
    if (req.body.password !== undefined && req.body.password === '') {
        delete req.body.password;
    }

    // Update the profile with the new data from the request body.
    // The 'beforeUpdate' hook in the model will handle password hashing automatically.
    const updatedProfile = await profile.update(req.body);

    // Prepare data to send back, excluding the password
    const profileData = updatedProfile.toJSON();
    delete profileData.password;

    res.status(200).json({ message: "Profile updated successfully.", data: profileData });
  } catch (error)
 {
    console.error("Error updating admin profile:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};