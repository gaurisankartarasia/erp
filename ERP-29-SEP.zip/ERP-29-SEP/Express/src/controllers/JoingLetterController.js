
// import { body, param, validationResult } from 'express-validator';
// import { sequelize } from '../models/index.js';
// const { JoiningLetter } = sequelize.models;


// const bodyValidationRules = [
//   body('name').trim().notEmpty().withMessage('Name is required.'),
//   body('designation').trim().notEmpty().withMessage('Designation is required.'),
//   body('date').isISO8601().withMessage('A valid date in YYYY-MM-DD format is required.'),
//   body('date_of_joining').isISO8601().withMessage('A valid date of joining in YYYY-MM-DD format is required.'),
//   body('cost_to_company').isDecimal().withMessage('Cost to Company must be a valid number.'),
//   body('phone_number').trim().notEmpty().withMessage('Contact/Phone No is required.'),
//   body('address').trim().notEmpty().withMessage('Address is required.'),
// ];

// // Validation rule for the URL parameter (used for get by ID, update, delete)
// const paramValidationRules = [
//   param('id').isInt().withMessage('A valid ID is required in the URL.'),
// ];

// // Middleware function to check and handle validation errors
// const checkValidation = (req, res, next) => {
//   const errors = validationResult(req);
//   if (!errors.isEmpty()) {
//     return res.status(400).json({ errors: errors.array() });
//   }
//   next();
// };

// // We export these as arrays to be used in the router
// export const handleCreateValidation = [...bodyValidationRules, checkValidation];
// export const handleUpdateValidation = [...paramValidationRules, ...bodyValidationRules, checkValidation];
// export const handleParamValidation = [...paramValidationRules, checkValidation];


// /**
//  * ===================================================================
//  * CONTROLLER LOGIC (FULL CRUD)
//  * ===================================================================
//  */
// export const getAllJoiningLetters = async (req, res) => {
//   try {
//     const joiningLetters = await JoiningLetter.findAll({
//       order: [['createdAt', 'DESC']]
//     });

//     res.status(200).json({
//       message: 'Joining Letters fetched successfully.',
//       data: joiningLetters,
//     });
//   } catch (error) {
//     console.error('Error fetching joining letters:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

// /**
//  * CREATE a new Joining Letter
//  */
// export const createJoiningLetter = async (req, res) => {
//   const {
//     name, designation, date, date_of_joining,
//     cost_to_company, phone_number, address,
//   } = req.body;

//   try {
//     // Get the current year and generate the year range (e.g., 2025-26)
//     const currentYear = new Date().getFullYear();
//     const nextYear = currentYear + 1;

//     // Get the last two digits of the current year and next year
//     const yearRange = `${currentYear.toString().slice(-2)}${nextYear.toString().slice(-2)}`; // e.g., 2526

//     // Get the next available ID for the reference number
//     const lastJoiningLetter = await JoiningLetter.findOne({
//       order: [['id', 'DESC']], // Get the latest entry
//     });

//     const nextId = lastJoiningLetter ? lastJoiningLetter.id + 1 : 1; // Increment the ID for the reference number

//     // Construct the reference number (e.g., MTPL/2526/OL-1)
//     const referenceNumber = `MTPL/${yearRange}/OL-${nextId}`;

//     // Default the 'date' field to the current date if not provided
//     const currentDate = date || new Date().toISOString().split('T')[0]; // Get current date in YYYY-MM-DD format

//     // Create the new joining letter with the reference number and the current date
//     const letterData = {
//       name,
//       designation,
//       date: currentDate, // Set the default value as current date if not provided
//       date_of_joining,
//       cost_to_company,
//       phone_number,
//       address,
//       reference_number: referenceNumber, // Store the generated reference number
//     };

//     const newJoiningLetter = await JoiningLetter.create(letterData);

//     res.status(201).json({
//       message: 'Joining Letter created successfully!',
//       data: newJoiningLetter,
//     });
//   } catch (error) {
//     console.error('Error creating joining letter:', error);
//     if (error.name === 'SequelizeUniqueConstraintError') {
//       return res.status(409).json({ message: 'This joining letter might already exist.' });
//     }
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };


// /**
//  * GET a single Joining Letter by ID
//  */
// export const getJoiningLetterById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const joiningLetter = await JoiningLetter.findByPk(id);

//     if (!joiningLetter) {
//       return res.status(404).json({ message: 'Joining Letter not found.' });
//     }

//     res.status(200).json({
//       message: 'Joining Letter fetched successfully.',
//       data: joiningLetter,
//     });
//   } catch (error) {
//     console.error('Error fetching joining letter by ID:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

// /**
//  * UPDATE an existing Joining Letter by ID
//  */
// export const updateJoiningLetter = async (req, res) => {
//   const { id } = req.params;
//   const {
//     name, designation, date, date_of_joining,
//     cost_to_company, phone_number, address,
//   } = req.body;

//   try {
//     const joiningLetter = await JoiningLetter.findByPk(id);
//     if (!joiningLetter) {
//       return res.status(404).json({ message: 'Joining Letter not found.' });
//     }

//     const updatedData = {
//       name, designation, date,
//       date_of_joining, cost_to_company, phone_number, address,
//     };

//     await joiningLetter.update(updatedData);

//     res.status(200).json({
//       message: 'Joining Letter updated successfully!',
//       data: joiningLetter,
//     });
//   } catch (error) {
//     console.error('Error updating joining letter:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

// /**
//  * DELETE a Joining Letter by ID
//  */
// export const deleteJoiningLetter = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const joiningLetter = await JoiningLetter.findByPk(id);

//     if (!joiningLetter) {
//       return res.status(404).json({ message: 'Joining Letter not found.' });
//     }

//     await joiningLetter.destroy();

//     res.status(200).json({ message: 'Joining Letter deleted successfully.' });
//   } catch (error) {
//     console.error('Error deleting joining letter:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };









import { body, param, validationResult } from 'express-validator';
import { sequelize } from '../models/index.js';
const { JoiningLetter } = sequelize.models;

const bodyValidationRules = [
  body('name').trim().notEmpty().withMessage('Name is required.'),
  body('designation').trim().notEmpty().withMessage('Designation is required.'),
  body('date').isISO8601().withMessage('A valid date in YYYY-MM-DD format is required.'),
  body('date_of_joining').isISO8601().withMessage('A valid date of joining in YYYY-MM-DD format is required.'),
  body('cost_to_company').isDecimal().withMessage('Cost to Company must be a valid number.'),
  body('phone_number').trim().notEmpty().withMessage('Contact/Phone No is required.'),
  body('address').trim().notEmpty().withMessage('Address is required.'),
];

const paramValidationRules = [
  param('id').isInt().withMessage('A valid ID is required in the URL.'),
];

const checkValidation = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

export const handleCreateValidation = [...bodyValidationRules, checkValidation];
export const handleUpdateValidation = [...paramValidationRules, ...bodyValidationRules, checkValidation];
export const handleParamValidation = [...paramValidationRules, checkValidation];

/**
 * ===================================================================
 * CONTROLLER LOGIC (FULL CRUD)
 * ===================================================================
 */
export const getAllJoiningLetters = async (req, res) => {
  try {
    const joiningLetters = await JoiningLetter.findAll({
      order: [['createdAt', 'DESC']]
    });

    res.status(200).json({
      message: 'Joining Letters fetched successfully.',
      data: joiningLetters,
    });
  } catch (error) {
    console.error('Error fetching joining letters:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * CREATE a new Joining Letter
 */
export const createJoiningLetter = async (req, res) => {
  const {
    name, designation, date, date_of_joining,
    cost_to_company, phone_number, address,
  } = req.body;

  try {
    // Get the current year and generate the year range (e.g., 2025-26)
    const currentYear = new Date().getFullYear();
    const nextYear = currentYear + 1;

    // Get the last two digits of the current year and next year
    const yearRange = `${currentYear.toString().slice(-2)}${nextYear.toString().slice(-2)}`; // e.g., 2526

    // Get the next available ID for the reference number
    const lastJoiningLetter = await JoiningLetter.findOne({
      order: [['id', 'DESC']],
    });

    const nextId = lastJoiningLetter ? lastJoiningLetter.id + 1 : 1;

    // Construct the reference number (e.g., MTPL/2526/OL-1)
    const referenceNumber = `MTPL/${yearRange}/OL-${nextId}`;

    // Default the 'date' field to the current date if not provided
    const currentDate = date || new Date().toISOString().split('T')[0];

    const letterData = {
      name,
      designation,
      date: currentDate,
      date_of_joining,
      cost_to_company,
      phone_number,
      address,
      reference_number: referenceNumber,
    };

    const newJoiningLetter = await JoiningLetter.create(letterData);

    res.status(201).json({
      message: 'Joining Letter created successfully!',
      data: newJoiningLetter,
    });
  } catch (error) {
    console.error('Error creating joining letter:', error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({ message: 'This joining letter might already exist.' });
    }
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * GET a single Joining Letter by ID
 */
export const getJoiningLetterById = async (req, res) => {
  try {
    const { id } = req.params;
    const joiningLetter = await JoiningLetter.findByPk(id);

    if (!joiningLetter) {
      return res.status(404).json({ message: 'Joining Letter not found.' });
    }

    res.status(200).json({
      message: 'Joining Letter fetched successfully.',
      data: joiningLetter,
    });
  } catch (error) {
    console.error('Error fetching joining letter by ID:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * UPDATE an existing Joining Letter by ID
 */
export const updateJoiningLetter = async (req, res) => {
  const { id } = req.params;
  const {
    name, designation, date, date_of_joining,
    cost_to_company, phone_number, address,
  } = req.body;

  try {
    const joiningLetter = await JoiningLetter.findByPk(id);
    if (!joiningLetter) {
      return res.status(404).json({ message: 'Joining Letter not found.' });
    }

    const updatedData = {
      name, 
      designation, 
      date,
      date_of_joining, 
      cost_to_company, 
      phone_number, 
      address,
    };

    await joiningLetter.update(updatedData);

    res.status(200).json({
      message: 'Joining Letter updated successfully!',
      data: joiningLetter,
    });
  } catch (error) {
    console.error('Error updating joining letter:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * DELETE a Joining Letter by ID
 */
export const deleteJoiningLetter = async (req, res) => {
  try {
    const { id } = req.params;
    const joiningLetter = await JoiningLetter.findByPk(id);

    if (!joiningLetter) {
      return res.status(404).json({ message: 'Joining Letter not found.' });
    }

    await joiningLetter.destroy();

    res.status(200).json({ message: 'Joining Letter deleted successfully.' });
  } catch (error) {
    console.error('Error deleting joining letter:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};