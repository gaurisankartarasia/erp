import bcrypt from "bcryptjs";
import { sequelize } from "../models/index.js";
import { Op } from "sequelize";
import { log } from "../services/LogService.js";

const { Employee, Designation, Client, State, District } = sequelize.models;

const employeeAssociations = [
  {
    model: Designation,
    as: "designation_info",
    attributes: ["designation_name"],
  },
  {
    model: Client,
    as: "client_info",
    attributes: ["projNm"],
  },
  {
    model: State,
    as: "permanent_state_info",
    attributes: ["state_name"],
  },
  {
    model: District,
    as: "permanent_district_info",
    attributes: ["district_name"],
  },
  {
    model: State,
    as: "present_state_info",
    attributes: ["state_name"],
  },
  {
    model: District,
    as: "present_district_info",
    attributes: ["district_name"],
  },
];

// reusable func to geerate employee code same as the suffix of table id.
const generateNextEmpCode = async () => {
  const lastEmployee = await Employee.findOne({
    order: [["id", "DESC"]],
    raw: true,
  });

  if (!lastEmployee) {
    return "MTPLEMP001";
  }

  const numericPart = parseInt(lastEmployee.id);
  const nextNumericPart = numericPart + 1;
  return `MTPLEMP${String(nextNumericPart).padStart(3, "0")}`;
};

export const registerEmployee = async (req, res) => {
  try {
    const emp_code = await generateNextEmpCode();
    const data = { ...req.body, emp_code };

    if (req.files?.upload_image) {
      data.upload_image = req.files.upload_image[0].path;
    }
    if (req.files?.upload_resume) {
      data.upload_resume = req.files.upload_resume[0].path;
    }


    const phoneDigits = data.mobile_no.replace(/\D/g, "");
    const lastFiveDigits = phoneDigits.slice(-5);

    const rawPassword = `${emp_code}@${lastFiveDigits}`;

    const saltRounds = 10;
    data.password = await bcrypt.hash(rawPassword, saltRounds);

    const newEmployee = await Employee.create(data);

    res.status(201).json({
      message: "Employee registeration successful.",
      employee: newEmployee,
    });
  } catch (error) {
    console.error("Registration Error:", error);
    res
      .status(500)
      .json({ message: "Failed to register employee", error: error.message });
  }
};

export const editEmployee = async (req, res) => {
  const { id } = req.params;
  try {
    const employee = await Employee.findByPk(id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found." });
    }

    const data = { ...req.body };

    if (req.files?.upload_image) {
      data.upload_image = req.files.upload_image[0].path;
    }
    if (req.files?.upload_resume) {
      data.upload_resume = req.files.upload_resume[0].path;
    }

    await employee.update(data);

    res.status(200).json({
      message: "Employee updated successfully!",
      employee,
    });
  } catch (error) {
    console.error("Update Error:", error);
    res
      .status(500)
      .json({ message: "Failed to update employee", error: error.message });
  }
};

export const getAllEmployees = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = "createdAt",
      order = "DESC",
      search = "",
    } = req.query;

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const whereCondition = {
      is_delete: false,
      [Op.or]: [
        { name: { [Op.like]: `%${search}%` } },
        { mobile_no: { [Op.like]: `%${search}%` } },
        { "$designation_info.designation_name$": { [Op.like]: `%${search}%` } },
      ],
    };

    const { rows: employees, count: totalEmployees } =
      await Employee.findAndCountAll({
        where: search ? whereCondition : { is_delete: false },
        include: employeeAssociations,
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [[sortBy, order.toUpperCase()]],
        attributes: {
          exclude: [
            "password",
            "activation_token",
            "activation_token_expires_at",
            "is_master",
          ],
        },
        distinct: true,
      });

    return res.status(200).json({
      message: "Employees fetched successfully",
      data: employees,
      total: totalEmployees,
      page: parseInt(page),
      pages: Math.ceil(totalEmployees / limit),
    });
  } catch (err) {
    console.error("Error fetching employees:", err);
    return res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

export const getEmployeeById = async (req, res) => {
  const { id } = req.params;

  try {
    const employee = await Employee.findByPk(id, {
      include: employeeAssociations,
      attributes: {
        exclude: [
          "password",
          "activation_token",
          "activation_token_expires_at",
          "is_master",
        ],
      },
    });

    if (!employee) {
      return res.status(404).json({
        message: "Employee Not Found",
      });
    }

    res.status(200).json(employee);
  } catch (err) {
    console.error("Error fetching employee by ID:", err);
    return res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

export const updateEmployee = async (req, res) => {
  const { id } = req.params;
  const updateFields = req.body;

  try {
    const employee = await Employee.findByPk(id);

    if (!employee) {
      return res.status(400).json({
        message: "Employee Not Found",
      });
    }

    if (updateFields.email && updateFields.email !== employee.email) {
      const existingEmail = await Employee.findOne({
        where: { email: updateFields.email },
      });
      if (existingEmail) {
        return res.status(409).json({
          message: "Email already in use",
        });
      }
    }

    if (updateFields.phone && updateFields.phone !== employee.phone) {
      const existingPhone = await Employee.findOne({
        where: { phone: updateFields.phone },
      });
      if (existingPhone) {
        return res.status(409).json({
          message: "Phone already in use.",
        });
      }
    }

    if (req.file) {
      updateFields.upload_image = req.file.path;
    }

    await log({
      req,
      action: "UPDATE",
      page_name: "EMPLOYEE FORM PAGE",
      target: employee.id,
    });

    await employee.update(updateFields);

    res.status(200).json({
      message: "Employee updated successfully.",
      data: employee,
    });
  } catch (err) {
    console.error("Error updating employee:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

export const toggleEmployeeStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const employee = await Employee.findByPk(id);

    if (!employee) {
      return res.status(404).json({ message: "Employee not found." });
    }

    employee.is_active = !employee.is_active;
    await employee.save();

    res.status(200).json({
      message: `Employee has been ${
        employee.is_active ? "activated" : "deactivated"
      }.`,
      data: employee,
    });
  } catch (error) {
    console.error("Error toggling employee status:", error);
    res.status(500).json({ message: "Server error while toggling status." });
  }
};

export const getAccountById = async (req, res) => {
  const { id } = req.user;

  try {
    const employee = await Employee.findByPk(id);

    if (!employee) {
      return res.status(400).json({
        message: "Employee Not Found",
      });
    }



    res.status(200).json(employee);
  } catch (err) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

export const updateAccount = async (req, res) => {
  const { id } = req.user;
  const updateFields = req.body;

  try {
    const employee = await Employee.findByPk(id);

    if (!employee) {
      return res.status(400).json({
        message: "Employee Not Found",
      });
    }

    if (updateFields.email && updateFields.email !== employee.email) {
      const existingEmail = await Employee.findOne({
        where: { email: updateFields.email },
      });
      if (existingEmail) {
        return res.status(409).json({
          message: "Email already in use",
        });
      }
    }

    if (updateFields.phone && updateFields.phone !== employee.phone) {
      const existingPhone = await Employee.findOne({
        where: { phone: updateFields.phone },
      });
      if (existingPhone) {
        return res.status(409).json({
          message: "Phone already in use.",
        });
      }
    }

    if (req.file) {
      updateFields.upload_image = req.file.path;
    }

    await log({
      req,
      action: "UPDATE",
      page_name: "EMPLOYEE FORM PAGE",
      target: employee.id,
    });

    await employee.update(updateFields);

    res.status(200).json({
      message: "Employee updated successfully.",
      data: employee,
    });
  } catch (err) {
    console.error("Error updating employee:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};
