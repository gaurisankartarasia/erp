// import { body, param, validationResult } from 'express-validator';
// import { sequelize } from '../models/index.js';
// const { SalaryAnnexure } = sequelize.models;

// const bodyValidationRules = [
//   body('basic').isDecimal().withMessage('Basic must be a valid number.'),
//   body('hra').isDecimal().withMessage('HRA must be a valid number.'),
//   body('otherAllowance').isDecimal().withMessage('Other Allowance must be a valid number.'),
//   body('yourContributionPf').isDecimal().withMessage('Your Contribution PF must be a valid number.'),
//   body('yourContributionEsi').isDecimal().withMessage('Your Contribution ESI must be a valid number.'),
//   body('professionalTax').isDecimal().withMessage('Professional Tax must be a valid number.'),
//   body('companySharePf').isDecimal().withMessage('Company Share PF must be a valid number.'),
//   body('pfAdminCharges').isDecimal().withMessage('PF Admin Charges must be a valid number.'),
//   body('companyShareEsi').isDecimal().withMessage('Company Share ESI must be a valid number.'),
//   body('overTime').isDecimal().withMessage('Over Time must be a valid number.'),
// ];

// const paramValidationRules = [
//   param('id').isInt().withMessage('A valid ID is required in the URL.'),
// ];

// const checkValidation = (req, res, next) => {
//   const errors = validationResult(req);
//   if (!errors.isEmpty()) {
//     return res.status(400).json({ errors: errors.array() });
//   }
//   next();
// };

// export const handleCreateValidation = [...bodyValidationRules, checkValidation];
// export const handleUpdateValidation = [...paramValidationRules, ...bodyValidationRules, checkValidation];
// export const handleParamValidation = [...paramValidationRules, checkValidation];

// /**
//  * ===================================================================
//  * CONTROLLER LOGIC (FULL CRUD)
//  * ===================================================================
//  */

// export const getAllSalaryAnnexures = async (req, res) => {
//   try {
//     const salaryAnnexures = await SalaryAnnexure.findAll({
//       order: [['createdAt', 'DESC']]
//     });

//     res.status(200).json({
//       message: 'Salary Annexures fetched successfully.',
//       data: salaryAnnexures,
//     });
//   } catch (error) {
//     console.error('Error fetching salary annexures:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

// export const getSalaryAnnexureById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const salaryAnnexure = await SalaryAnnexure.findByPk(id);

//     if (!salaryAnnexure) {
//       return res.status(404).json({ message: 'Salary Annexure not found.' });
//     }

//     res.status(200).json({
//       message: 'Salary Annexure fetched successfully.',
//       data: salaryAnnexure,
//     });
//   } catch (error) {
//     console.error('Error fetching salary annexure by ID:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

// export const createSalaryAnnexure = async (req, res) => {
//   const {
//     basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
//     professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime
//   } = req.body;

//   try {
//     // Calculate the values
//     const salaryComponent = parseFloat(basic) + parseFloat(hra) + parseFloat(otherAllowance);
//     const totalDeductions = parseFloat(yourContributionPf) + parseFloat(yourContributionEsi) + parseFloat(professionalTax);
//     const net = salaryComponent - totalDeductions;
//     const companyContributions = parseFloat(companySharePf) + parseFloat(pfAdminCharges) + parseFloat(companyShareEsi) + parseFloat(overTime);
//     const totalCTC = salaryComponent + companyContributions;

//     const annexureData = {
//       basic: parseFloat(basic) || 0,
//       hra: parseFloat(hra) || 0,
//       otherAllowance: parseFloat(otherAllowance) || 0,
//       yourContributionPf: parseFloat(yourContributionPf) || 0,
//       yourContributionEsi: parseFloat(yourContributionEsi) || 0,
//       professionalTax: parseFloat(professionalTax) || 0,
//       companySharePf: parseFloat(companySharePf) || 0,
//       pfAdminCharges: parseFloat(pfAdminCharges) || 0,
//       companyShareEsi: parseFloat(companyShareEsi) || 0,
//       overTime: parseFloat(overTime) || 0,
//       salaryComponent,
//       net,
//       totalCTC,
//       employee_id: req.user?.id || 1, // Assuming you have user authentication
//     };

//     const newSalaryAnnexure = await SalaryAnnexure.create(annexureData);

//     res.status(201).json({
//       message: 'Salary Annexure created successfully!',
//       data: newSalaryAnnexure,
//     });
//   } catch (error) {
//     console.error('Error creating salary annexure:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

// // export const updateSalaryAnnexure = async (req, res) => {
// //   const { id } = req.params;
// //   const {
// //     basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
// //     professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime
// //   } = req.body;

// //   try {
// //     const salaryAnnexure = await SalaryAnnexure.findByPk(id);
// //     if (!salaryAnnexure) {
// //       return res.status(404).json({ message: 'Salary Annexure not found.' });
// //     }

// //     // Recalculate the values
// //     const salaryComponent = parseFloat(basic) + parseFloat(hra) + parseFloat(otherAllowance);
// //     const totalDeductions = parseFloat(yourContributionPf) + parseFloat(yourContributionEsi) + parseFloat(professionalTax);
// //     const net = salaryComponent - totalDeductions;
// //     const companyContributions = parseFloat(companySharePf) + parseFloat(pfAdminCharges) + parseFloat(companyShareEsi) + parseFloat(overTime);
// //     const totalCTC = salaryComponent + companyContributions;

// //     const updatedData = {
// //       basic: parseFloat(basic) || 0,
// //       hra: parseFloat(hra) || 0,
// //       otherAllowance: parseFloat(otherAllowance) || 0,
// //       yourContributionPf: parseFloat(yourContributionPf) || 0,
// //       yourContributionEsi: parseFloat(yourContributionEsi) || 0,
// //       professionalTax: parseFloat(professionalTax) || 0,
// //       companySharePf: parseFloat(companySharePf) || 0,
// //       pfAdminCharges: parseFloat(pfAdminCharges) || 0,
// //       companyShareEsi: parseFloat(companyShareEsi) || 0,
// //       overTime: parseFloat(overTime) || 0,
// //       salaryComponent,
// //       net,
// //       totalCTC,
// //     };

// //     await salaryAnnexure.update(updatedData);

// //     res.status(200).json({
// //       message: 'Salary Annexure updated successfully!',
// //       data: salaryAnnexure,
// //     });
// //   } catch (error) {
// //     console.error('Error updating salary annexure:', error);
// //     res.status(500).json({ message: 'Internal Server Error' });
// //   }
// // };

// // controllers/salaryAnnexureController.js

// export const updateSalaryAnnexure = async (req, res) => {
//   const { id } = req.params;
//   const {
//     basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
//     professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime
//   } = req.body;

//   try {
//     const salaryAnnexure = await SalaryAnnexure.findByPk(id);
//     if (!salaryAnnexure) {
//       return res.status(404).json({ message: 'Salary Annexure not found.' });
//     }

//     // Recalculate the values
//     const salaryComponent = parseFloat(basic) + parseFloat(hra) + parseFloat(otherAllowance);
//     const totalDeductions = parseFloat(yourContributionPf) + parseFloat(yourContributionEsi) + parseFloat(professionalTax);
//     const net = salaryComponent - totalDeductions;
//     const companyContributions = parseFloat(companySharePf) + parseFloat(pfAdminCharges) + parseFloat(companyShareEsi) + parseFloat(overTime);
//     const totalCTC = salaryComponent + companyContributions;

//     const updatedData = {
//       basic: parseFloat(basic) || 0,
//       hra: parseFloat(hra) || 0,
//       otherAllowance: parseFloat(otherAllowance) || 0,
//       yourContributionPf: parseFloat(yourContributionPf) || 0,
//       yourContributionEsi: parseFloat(yourContributionEsi) || 0,
//       professionalTax: parseFloat(professionalTax) || 0,
//       companySharePf: parseFloat(companySharePf) || 0,
//       pfAdminCharges: parseFloat(pfAdminCharges) || 0,
//       companyShareEsi: parseFloat(companyShareEsi) || 0,
//       overTime: parseFloat(overTime) || 0,
//       salaryComponent,
//       net,
//       totalCTC,
//     };

//     await salaryAnnexure.update(updatedData);

//     // Refresh the data to get the latest from database
//     const updatedAnnexure = await SalaryAnnexure.findByPk(id);

//     res.status(200).json({
//       message: 'Salary Annexure updated successfully!',
//       data: updatedAnnexure, // Return the updated data
//     });
//   } catch (error) {
//     console.error('Error updating salary annexure:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };



// export const deleteSalaryAnnexure = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const salaryAnnexure = await SalaryAnnexure.findByPk(id);

//     if (!salaryAnnexure) {
//       return res.status(404).json({ message: 'Salary Annexure not found.' });
//     }

//     await salaryAnnexure.destroy();

//     res.status(200).json({ message: 'Salary Annexure deleted successfully.' });
//   } catch (error) {
//     console.error('Error deleting salary annexure:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };



import { body, param, validationResult } from 'express-validator';
import { sequelize } from '../models/index.js';
const { SalaryAnnexure } = sequelize.models;

// --- VALIDATION MIDDLEWARE (No changes needed) ---
const bodyValidationRules = [
  body('basic').isDecimal().withMessage('Basic must be a valid number.'),
  body('hra').isDecimal().withMessage('HRA must be a valid number.'),
  body('otherAllowance').isDecimal().withMessage('Other Allowance must be a valid number.'),
  body('yourContributionPf').isDecimal().withMessage('Your Contribution PF must be a valid number.'),
  body('yourContributionEsi').isDecimal().withMessage('Your Contribution ESI must be a valid number.'),
  body('professionalTax').isDecimal().withMessage('Professional Tax must be a valid number.'),
  body('companySharePf').isDecimal().withMessage('Company Share PF must be a valid number.'),
  body('pfAdminCharges').isDecimal().withMessage('PF Admin Charges must be a valid number.'),
  body('companyShareEsi').isDecimal().withMessage('Company Share ESI must be a valid number.'),
  body('overTime').isDecimal().withMessage('Over Time must be a valid number.'),
];

const paramValidationRules = [
  param('id').isInt().withMessage('A valid ID is required in the URL.'),
];

const checkValidation = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};

export const handleCreateValidation = [...bodyValidationRules, checkValidation];
export const handleUpdateValidation = [...paramValidationRules, ...bodyValidationRules, checkValidation];
export const handleParamValidation = [...paramValidationRules, checkValidation];

/**
 * ===================================================================
 * CONTROLLER LOGIC (FULL CRUD) - FIXED & COMPLETE
 * ===================================================================
 */

/**
 * Get the annexure for the currently logged-in user.
 */
export const getAllSalaryAnnexures = async (req, res) => {
  try {
    const userId = req.user?.id; // Assumes 'protect' middleware adds user to req
    if (!userId) {
      return res.status(401).json({ success: false, message: 'User not authenticated.' });
    }

    const annexure = await SalaryAnnexure.findOne({ where: { employee_id: userId } });
    
    // The frontend expects an array, so wrap the result in an array if it exists.
    const dataToSend = annexure ? [annexure] : [];

    res.status(200).json({
      success: true,
      message: 'Salary Annexure fetched successfully.',
      data: dataToSend,
    });
  } catch (error) {
    console.error('Error fetching salary annexure:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

/**
 * Get a single salary annexure by its ID.
 */
export const getSalaryAnnexureById = async (req, res) => {
  try {
    const { id } = req.params;
    const salaryAnnexure = await SalaryAnnexure.findByPk(id);

    if (!salaryAnnexure) {
      return res.status(404).json({ success: false, message: 'Salary Annexure not found.' });
    }

    res.status(200).json({
      success: true,
      message: 'Salary Annexure fetched successfully.',
      data: salaryAnnexure,
    });
  } catch (error) {
    console.error('Error fetching salary annexure by ID:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

/**
 * Create a new salary annexure for the logged-in user.
 * Prevents creation if one already exists.
 */
export const createSalaryAnnexure = async (req, res) => {
  const userId = req.user?.id;
  
  // Prevent duplicate records for the same user
  const existingAnnexure = await SalaryAnnexure.findOne({ where: { employee_id: userId } });
  if (existingAnnexure) {
    return res.status(400).json({
      success: false,
      message: 'Salary Annexure already exists for this user. Please update the existing one.',
    });
  }
  
  const {
    basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
    professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime
  } = req.body;

  try {
    // Backend calculates totals to ensure data integrity
    const salaryComponent = parseFloat(basic) + parseFloat(hra) + parseFloat(otherAllowance);
    const totalDeductions = parseFloat(yourContributionPf) + parseFloat(yourContributionEsi) + parseFloat(professionalTax);
    const net = salaryComponent - totalDeductions;
    const companyContributions = parseFloat(companySharePf) + parseFloat(pfAdminCharges) + parseFloat(companyShareEsi) + parseFloat(overTime);
    const totalCTC = salaryComponent + companyContributions;

    const newSalaryAnnexure = await SalaryAnnexure.create({
      basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
      professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime,
      salaryComponent, net, totalCTC,
      employee_id: userId,
    });

    res.status(201).json({
      success: true,
      message: 'Salary Annexure created successfully!',
      data: newSalaryAnnexure,
    });
  } catch (error) {
    console.error('Error creating salary annexure:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

/**
 * Update an existing salary annexure.
 */
export const updateSalaryAnnexure = async (req, res) => {
  const { id } = req.params;
  const userId = req.user?.id;
  const {
    basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
    professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime
  } = req.body;

  try {
    const salaryAnnexure = await SalaryAnnexure.findByPk(id);
    if (!salaryAnnexure) {
      return res.status(404).json({ success: false, message: 'Salary Annexure not found.' });
    }

    // Authorization check: Ensure the user owns this annexure
    if (salaryAnnexure.employee_id !== userId) {
        return res.status(403).json({ success: false, message: 'User not authorized to update this record.' });
    }

    // Recalculate values on the backend
    const salaryComponent = parseFloat(basic) + parseFloat(hra) + parseFloat(otherAllowance);
    const totalDeductions = parseFloat(yourContributionPf) + parseFloat(yourContributionEsi) + parseFloat(professionalTax);
    const net = salaryComponent - totalDeductions;
    const companyContributions = parseFloat(companySharePf) + parseFloat(pfAdminCharges) + parseFloat(companyShareEsi) + parseFloat(overTime);
    const totalCTC = salaryComponent + companyContributions;

    const updatedData = {
      basic, hra, otherAllowance, yourContributionPf, yourContributionEsi,
      professionalTax, companySharePf, pfAdminCharges, companyShareEsi, overTime,
      salaryComponent, net, totalCTC,
    };

    await salaryAnnexure.update(updatedData);
    
    res.status(200).json({
      success: true,
      message: 'Salary Annexure updated successfully!',
      data: salaryAnnexure, // Return the updated record
    });
  } catch (error) {
    console.error('Error updating salary annexure:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

/**
 * Delete a salary annexure.
 */
export const deleteSalaryAnnexure = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;
    const salaryAnnexure = await SalaryAnnexure.findByPk(id);

    if (!salaryAnnexure) {
      return res.status(404).json({ success: false, message: 'Salary Annexure not found.' });
    }

    // Authorization check
    if (salaryAnnexure.employee_id !== userId) {
        return res.status(403).json({ success: false, message: 'User not authorized to delete this record.' });
    }

    await salaryAnnexure.destroy();

    res.status(200).json({ success: true, message: 'Salary Annexure deleted successfully.' });
  } catch (error) {
    console.error('Error deleting salary annexure:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};
