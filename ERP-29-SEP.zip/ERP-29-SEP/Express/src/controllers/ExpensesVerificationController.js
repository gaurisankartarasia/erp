import { Op } from "sequelize";
import { sequelize } from "../models/index.js";

const {Employee, Vendor, Expense} = sequelize.models

export const getPayers = async (req, res) => {
  const { type } = req.query;

  if (!["staff", "supplier"].includes(type)) {
    return res.status(400).json({ message: "Invalid payer type specified." });
  }

  try {
    let payers;
    if (type === "staff") {
      payers = await Employee.findAll({
        attributes: [
          ["id", "value"],
          ["name", "label"],
        ],
        where: { is_active: true, is_delete: false },
        order: [["name", "ASC"]],
      });
    } else {
      payers = await Vendor.findAll({
        attributes: [
          ["id", "value"],
          ["name", "label"],
        ],
        where: { is_active: true },
        order: [["name", "ASC"]],
      });
    }
    res.status(200).json({ data: payers });
  } catch (error) {
    console.error(`Error fetching ${type}:`, error);
    res.status(500).json({ message: `Failed to fetch ${type}.` });
  }
};


export const searchExpenses = async (req, res) => {
  const { payer_type, payer_id, from_date, to_date } = req.query;

  if (!payer_type || !payer_id || !from_date || !to_date) {
    return res.status(400).json({ message: "All search fields are required." });
  }

  try {
    const expenses = await Expense.findAll({
      where: {
        payer_type,
        payer_id,
        date: {
          [Op.between]: [from_date, to_date],
        },
        status: "pending",
        is_delete: false,
      },
      order: [["date", "ASC"]],
    });
    res.status(200).json({ data: expenses });
  } catch (error) {
    console.error("Error searching expenses:", error);
    res.status(500).json({ message: "Failed to search for expenses." });
  }
};


export const verifyExpenses = async (req, res) => {
  const { expenseIds } = req.body;

  if (!expenseIds || !Array.isArray(expenseIds) || expenseIds.length === 0) {
    return res
      .status(400)
      .json({ message: "An array of expense IDs is required." });
  }

  try {
    const [updateCount] = await Expense.update(
      { status: "verified" },
      {
        where: {
          id: {
            [Op.in]: expenseIds,
          },
          status: "pending",
        },
      }
    );

    if (updateCount === 0) {
      return res
        .status(404)
        .json({
          message: "No pending expenses found with the provided IDs to verify.",
        });
    }

    res
      .status(200)
      .json({
        message: `${updateCount} expense(s) have been successfully verified.`,
      });
  } catch (error) {
    console.error("Error verifying expenses:", error);
    res.status(500).json({ message: "Failed to verify expenses." });
  }
};
