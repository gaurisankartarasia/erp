import { models } from "../models/index.js";
const { Tax } = models;

// Helper function to generate next Tax ID
const generateNextTaxId = async () => {
  const lastTax = await Tax.findOne({
    order: [["id", "DESC"]], // safer
    raw: true,
  });

  if (!lastTax || !lastTax.taxId) {
    return "TAX00001";
  }

  const numPart = lastTax.taxId.replace("TAX", "");
  const lastNumeric = parseInt(numPart, 10);

  if (isNaN(lastNumeric)) {
    throw new Error(`Invalid taxId format: ${lastTax.taxId}`);
  }

  const nextNumeric = lastNumeric + 1;
  return `TAX${String(nextNumeric).padStart(5, "0")}`;
};

// Add a new Tax entry with auto-generated taxId
export const addTax = async (req, res) => {
    try {
        const { month, year, date, epf, esi, gst, tds } = req.body;

        if (!month || !year || !date) {
            return res.status(400).json({ error: "Month, year, and date are required" });
        }

        const formattedTaxId = await generateNextTaxId();

        const taxEntry = await Tax.create({
            taxId: formattedTaxId,
            month,
            year,
            date,
            epf: epf || 0,
            esi: esi || 0,
            gst: gst || 0,
            tds: tds || 0,
        });

        res.status(201).json({ message: "Tax entry added", data: taxEntry.toJSON() });
    } catch (err) {
        console.error("Server error:", err);
        res.status(500).json({ error: "Server error", details: err.message });
    }
};

// Get all Tax entries
export const getAllTaxes = async (req, res) => {
    try {
        const taxes = await Tax.findAll({
            order: [["createdAt", "DESC"]],
            raw: true,
        });
        res.status(200).json(taxes);
    } catch (err) {
        console.error("Server error:", err);
        res.status(500).json({ error: "Server error", details: err.message });
    }
};

// Get a single Tax entry by taxId
export const getTaxById = async (req, res) => {
    try {
        const tax = await Tax.findOne({
            where: { taxId: req.params.taxId },
            raw: true,
        });

        if (!tax) {
            return res.status(404).json({ error: "Tax entry not found" });
        }

        res.status(200).json(tax);
    } catch (err) {
        console.error("Server error:", err);
        res.status(500).json({ error: "Server error", details: err.message });
    }
};

// Update a Tax entry (taxId cannot be changed)
export const updateTax = async (req, res) => {
    try {
        const tax = await Tax.findOne({ where: { taxId: req.params.taxId } });
        if (!tax) return res.status(404).json({ error: "Tax entry not found" });

        const { taxId, ...updateData } = req.body; // Prevent taxId update

        await tax.update(updateData);
        res.status(200).json({ message: "Tax entry updated", data: tax.toJSON() });
    } catch (err) {
        console.error("Server error:", err);
        res.status(500).json({ error: "Server error", details: err.message });
    }
};

// Delete a Tax entry
export const deleteTax = async (req, res) => {
    try {
        const tax = await Tax.findOne({ where: { taxId: req.params.taxId } });
        if (!tax) return res.status(404).json({ error: "Tax entry not found" });

        await tax.destroy();
        res.status(200).json({ message: "Tax entry deleted" });
    } catch (err) {
        console.error("Server error:", err);
        res.status(500).json({ error: "Server error", details: err.message });
    }
};
