import { DataTypes } from 'sequelize';

export default (sequelize) => {
  sequelize.define('Item', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    item_id: {
      type: DataTypes.STRING(10), // e.g. ITEM001
      allowNull: false,
      unique: true,
    },
    item_name: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    model_name: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    unit: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    is_active: {
      type: DataTypes.TINYINT(1),
      defaultValue: 1,
    },
    is_delete: {
      type: DataTypes.TINYINT(1),
      defaultValue: 0,
    }
   
  }, {
    tableName: 'items',
    timestamps: true,
    underscored:true
  });
};