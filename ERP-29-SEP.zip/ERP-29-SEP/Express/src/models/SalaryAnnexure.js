import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "SalaryAnnexure",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      employee_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      basic: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      hra: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      otherAllowance: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      yourContributionPf: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      yourContributionEsi: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      professionalTax: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      companySharePf: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      pfAdminCharges: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      companyShareEsi: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      overTime: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      salaryComponent: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      net: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      totalCTC: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
    },
    {
      tableName: "salary_annexures",
      timestamps: true,
      underscored: true,
    }
  );
};