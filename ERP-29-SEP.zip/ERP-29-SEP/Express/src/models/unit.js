// // // models/unit.js

// // import { DataTypes } from 'sequelize';

// // export default (sequelize) => {
// //   sequelize.define('Unit', {
// //     id: {
// //       type: DataTypes.STRING,
// //       primaryKey: true,
// //       allowNull: false,
// //     },
// //     name: {
// //       type: DataTypes.STRING,
// //       allowNull: false,
// //     },
// //     description: {
// //       type: DataTypes.TEXT,
// //       allowNull: false,
// //     },
// //     status: {
// //       type: DataTypes.ENUM('Active', 'Inactive'),
// //       defaultValue: 'Active',
// //     },
// //   }, {
// //     tableName: 'units',
// //     timestamps: true,
// //     createdAt: 'created_at',
// //     updatedAt: 'updated_at',
// //   });
// // };




// import { DataTypes } from 'sequelize';
// export default (sequelize) => {
//   sequelize.define('Unit', {
//     id: {
//       type: DataTypes.BIGINT.UNSIGNED,
//       autoIncrement: true,
//       primaryKey: true,
//     },
//     unit_id: {
//       type: DataTypes.STRING(10), // 'UM001' will go here
//       allowNull: false,
//       unique: true,
//     },
//     unit_name: {
//       type: DataTypes.STRING(150),
//     },
//     description: {
//       type: DataTypes.TEXT,
//     },
//     is_active: {
//       type: DataTypes.TINYINT(1),
//       defaultValue: 1,
//     },
//     is_delete: {
//       type: DataTypes.TINYINT(1),
//       defaultValue: 0,
//     },
//     updated_at: {
//       type: DataTypes.DATE,
//     },
//     created_at: {
//       type: DataTypes.DATE,
//     }
//   }, {
//     tableName: 'units',
//     timestamps: false
//   });
// };


import { DataTypes } from 'sequelize';
export default (sequelize) => {
  sequelize.define('Unit', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    unit_id: {
      type: DataTypes.STRING(10),
      allowNull: false,
      unique: true,
    },
    unit_name: {
      type: DataTypes.STRING(150),
    },
    description: {
      type: DataTypes.TEXT,
    },
    is_active: {
      type: DataTypes.TINYINT(1),
      defaultValue: 1,
    },
    is_delete: {
      type: DataTypes.TINYINT(1),
      defaultValue: 0,
    }
  }, {
    tableName: 'units',
        timestamps: true,
    underscored:true
  });
};