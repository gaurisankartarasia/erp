import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "Expense",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      payer_type: {
        type: DataTypes.ENUM("staff", "supplier"),
        allowNull: false,
      },
      payer_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
      },
      date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      expense_type: {
        type: DataTypes.STRING,
        allowNull: true, 
      },
      matter: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      approx_km: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      invoice_no: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      invoice_date: {
        type: DataTypes.DATEONLY,
        allowNull: true,
      },
      taxable_amt: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: true,
      },
      tax: {
        type: DataTypes.DECIMAL(5, 2),
        allowNull: true,
      },
      tax_amt: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: true,
      },
      discount: {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.0,
      },
      total_amt: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
      },
      document: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      status: {
        type: DataTypes.ENUM("pending", "verified", "approved", "rejected"),
        defaultValue: "pending",
      },
      is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      is_delete: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      tableName: "expenses",
      timestamps: true,
      underscored: true,
    }
  );
};
