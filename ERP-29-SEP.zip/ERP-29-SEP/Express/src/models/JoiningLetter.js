import { DataTypes } from "sequelize";
export default (sequelize) => {
  sequelize.define(
    "JoiningLetter",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
    //   // It's crucial to know which employee this letter is for
    //   employee_id: {
    //     type: DataTypes.INTEGER,
    //     allowNull: false,
    //     references: {
    //       model: "employees", // Links to your existing employees table
    //       key: "id",
    //     },
    //   },
     reference_number: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true, // Make it unique
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      designation: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      date_of_joining: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      cost_to_company: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
      },
      phone_number: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      address: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
    },
    {
      tableName: "joining_letters",
      timestamps: true,
      underscored: true,
    }
  );
};
