import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

import { MdInfo, MdCheckCircle, MdWarning, MdError } from "react-icons/md";

export default function MessageModal({
  isOpen,
  onClose,
  message,
  variant = "info",
}) {
  const variantConfig = {
    info: {
      color: "text-blue-600",
      icon: <MdInfo className="w-10 h-auto" />,
    },
    success: {
      color: "text-green-600",
      icon: <MdCheckCircle className="w-10 h-auto" />,
    },
    warning: {
      color: "text-yellow-600",
      icon: <MdWarning className="w-18" />,
    },
    danger: {
      color: "text-red-600",
      icon: <MdError className="w-10 h-auto" />,
    },
  };

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(open) => !open && onClose && onClose()}
    >
      <DialogContent className="[&>button]:hidden">
        <DialogHeader>
          <DialogTitle
            className={cn(
              "font-semibold text-center flex flex-col items-center gap-6",
              variantConfig[variant].color
            )}
          >
            {variantConfig[variant].icon}
            <span>{message}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="mt-6 flex justify-center">
          <Button onClick={onClose} aria-label="Close" variant={"outline"} >
            Ok
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
