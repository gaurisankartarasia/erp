import React, { useState, useEffect, useMemo } from "react";
import { useForm, FormProvider, useFieldArray } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";


const AttendanceUpdateByIdPage = () => {
  const methods = useForm({
    defaultValues: {
      attendanceGroup: "",
      employees: [],
    },
  });
  const { handleSubmit, control, reset } = methods;

  const { fields, replace, update } = useFieldArray({ control, name: "employees" });

  const [attendanceGroups, setAttendanceGroups] = useState([]);
  const [isSearched, setIsSearched] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const message = useMessageModal();

  const getMonthName = (monthNumber) =>
    new Date(0, monthNumber - 1).toLocaleString("default", { month: "long" });

  useEffect(() => {
    const fetchAttendanceGroups = async () => {
      setIsLoading(true);
      try {
        const res = await apiClient.get("/attendance/list-groups");
        const options = res.data.data.map((group) => ({
          value: JSON.stringify({
            year: group.year,
            month: group.month,
            attendance_id: group.attendance_id,
          }),
          label: group.attendance_id,
        }));
        setAttendanceGroups(options);
      } catch (error) {
        message.error("Failed to load attendance records.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchAttendanceGroups();
  }, [message]);

  const onSearch = async (data) => {
    setIsLoading(true);
    replace([]);
    try {
      const searchParams = JSON.parse(data.attendanceGroup);
      const res = await apiClient.get("/attendance/details-by-group", {
        params: searchParams,
      });

      if (res.data.data.length > 0) {
        const formattedData = res.data.data.map((att) => ({
          db_id: att.id,
          emp_code: att.Employee.emp_code,
          name: att.Employee.name,
          absentday: att.absentday || "0",
               designation: att.Employee.designation_info?.designation_name || 'N/A', 
            client: att.Employee.client_info?.projNm || 'N/A',
        }));
        console.log(formattedData)
        replace(formattedData);
        setIsSearched(true);
      } else {
        message.info("No attendance details found for the selected record.");
        setIsSearched(false);
      }
    } catch (error) {
      message.error("Failed to search for attendance records.");
    } finally {
      setIsLoading(false);
    }
  };

  const onUpdate = async (data) => {
    setIsSubmitting(true);
    const payload = {
      employees: data.employees.map((emp) => ({
        id: emp.id,
        absentday: emp.absentday,
      })),
    };

    try {
      await apiClient.patch("/attendance/update", payload);
      message.success("Attendance updated successfully!");
      handleReset();
    } catch (error) {
      message.error("Failed to update attendance.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    replace([]);
    setIsSearched(false);
  };

  
const AbsentDayInput = ({ field, index }) => {
  const [absentDay, setAbsentDay] = useState(field.absentday || "0");
  const [isUpdating, setIsUpdating] = useState(false);
const [isEditable, setIsEditable] = useState(false);

  const handleUpdate = async () => {
    if (isUpdating) return;
    setIsUpdating(true);
    try {
      await apiClient.patch(`/attendance/update-single/${field.db_id}`, {
        absentday: absentDay,
      });
         update(field.index, { ...field, absentday: absentDay });
      message.success(`Updated attendance for ${field.name}`);
    } catch (error) {
      message.error("Update failed.");
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Input
        type="number"
        value={absentDay}
        onChange={(e) => setAbsentDay(e.target.value)}
        className="w-24"
      />
      <Button onClick={handleUpdate} disabled={isUpdating} size="sm">
        {isUpdating ? "..." : "Update"}
      </Button>
    </div>
  );
};


  return (
    <FormProvider {...methods}>
      <FormLayout
        title="Attendance List"
        onSubmit={isSearched ? handleSubmit(onUpdate) : handleSubmit(onSearch)}
        onReset={handleReset}
        isSubmitting={isLoading || isSubmitting}
        submitText={isSearched ? "Submit" : "Search"}
        onCancel={isSearched ? () => setIsSearched(false) : undefined}
        backPath={"/attendance"}
      >
        <div className="grid grid-cols-2 gap-6">
          <FormSelect
            name="attendanceGroup"
            label="Attendance ID"
            options={attendanceGroups}
            rules={{ required: "An attendance record is required" }}
            disabled={isSearched}
          />
        </div>
        <div className="col-span-2" >
            
      {isSearched && fields.length > 0 && (
        <div className="mt-6">
          <div>
            <Table>
              <TableHeader>
                <TableRow>
                        <TableHead>SL No</TableHead>
                  <TableHead>Emp Code</TableHead>
                  <TableHead>Name</TableHead>
                    <TableHead>Location</TableHead>
                                    <TableHead>Designation</TableHead>
                  <TableHead>Absent Days</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fields.map((field, index) => (
                  <TableRow key={field.id}>
                     <TableCell>{index + 1}</TableCell>
                    <TableCell>{field.emp_code}</TableCell>
                    <TableCell>{field.name}</TableCell>
                       <TableCell>{field.client}</TableCell>
                    <TableCell>{field.designation}</TableCell>
                 
                    <TableCell className="w-48">
                      {/* <FormInput
                        name={`employees.${index}.absentday`}
                        type="number"
                        rules={{ min: 0 }}
                      /> */} <AbsentDayInput key={field.id} field={field} index={index} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
        </div>
      </FormLayout>

    </FormProvider>
  );
};

export default AttendanceUpdateByIdPage;
