import React, { useState, useEffect, useMemo } from "react";
import { useForm, FormProvider, useFieldArray } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import FormInput from "@/pages/employee/custom/FormInput";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Eye } from "lucide-react";

const AttendanceGeneratePage = () => {
  const methods = useForm({
    defaultValues: {
      year: new Date().getFullYear().toString(),
      month: "",
      client: "",
      employees: [],
    },
  });
  const { handleSubmit, control, watch, reset } = methods;

  const { fields, replace } = useFieldArray({ control, name: "employees" });

  const [clientOptions, setClientOptions] = useState([]);
  const [isSearched, setIsSearched] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const message = useMessageModal();

  const [year, month] = watch(["year", "month"]);
  const workingDays = useMemo(() => {
    if (!year || !month) return 30;
    return new Date(parseInt(year), parseInt(month), 0).getDate();
  }, [year, month]);

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const res = await apiClient.get("master/clients");
        const options = res.data.data.map(c => ({ value: String(c.id), label: c.projNm }));
        setClientOptions(options);
      } catch (error) {
        message.error("Failed to load clients.");
      }
    };
    fetchClients();
  }, [message]);

  const onSearch = async (data) => {
    setIsLoading(true);
    replace([]); 
    try {
      const res = await apiClient.get("/attendance/search-employees", { params: data });
      if (res.data.data.length > 0) {
        replace(res.data.data.map(emp => ({ ...emp, absentday: "0" })));
        setIsSearched(true);
      } else {
        message.info("No employees found for this client, or attendance is already generated.");
        setIsSearched(false);
      }
    } catch (error) {
      message.error("Failed to search employees.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const onSubmit = async (data) => {
    setIsSubmitting(true);
    const clientLabel = clientOptions.find(c => c.value === data.client)?.label;
    
    const payload = {
        year: data.year,
        month: data.month,
        client: data.client,
        client_projNm: clientLabel, 
        employees: data.employees,
    };

    try {
        await apiClient.post("/attendance/generate", payload);
        message.success("Attendance generated successfully!");
        handleReset();
    } catch (error) {
        message.error("Failed to submit attendance.");
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    replace([]);
    setIsSearched(false);
  };

  const yearOptions = Array.from({ length: 10 }, (_, i) => {
    const year = new Date().getFullYear() - 5 + i;
    return { value: String(year), label: String(year) };
  });

  const monthOptions = Array.from({ length: 12 }, (_, i) => ({
    value: String(i + 1),
    label: new Date(0, i).toLocaleString('default', { month: 'long' }),
  }));

  return (
    <FormProvider {...methods}>
      <FormLayout
        title="Attendance List"
        onSubmit={isSearched ? handleSubmit(onSubmit) : handleSubmit(onSearch)}
        onReset={handleReset}
        isSubmitting={isLoading || isSubmitting}
        submitText={isSearched ? "Submit" : "Search"}
        onCancel={isSearched ? () => setIsSearched(false) : undefined}
        isLoading={isLoading}
   topButtons={[
  { text: "View", path: "view" , icon: Eye}
]}

      >
        <div className="grid grid-cols-3 gap-6">
          <FormSelect name="year" label="Year" options={yearOptions} rules={{ required: "Year is required" }} />
          <FormSelect name="month" label="Month" options={monthOptions} rules={{ required: "Month is required" }} />
          <FormSelect name="client" label="Client / Project" options={clientOptions} rules={{ required: "Client is required" }} showSearch />
        </div>
<div className="col-span-2" >
   {isSearched && fields.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-2">Client location: {clientOptions.find(c => c.value === watch("client"))?.label}</h3>
          <div>
            <Table>
              <TableHeader>
                <TableRow>
                   <TableHead>SL No</TableHead>
                  <TableHead>Emp Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Designation</TableHead>
                  {/* <TableHead>Working Days</TableHead> */}
                  <TableHead>Absent Days</TableHead>
                  {/* <TableHead>Present Days</TableHead> */}
                </TableRow>
              </TableHeader>
              <TableBody>
                {fields.map((field, index) => {
                  const absentDays = watch(`employees.${index}.absentday`) || 0;
                  // const presentDays = workingDays - absentDays;
                  return (
                    <TableRow key={field.id}>
                      <TableCell>{index+1}</TableCell>
                      <TableCell>{field.emp_code}</TableCell>
                      <TableCell>{field.name}</TableCell>
                       <TableCell>{field.client_info.projNm}</TableCell>
                        <TableCell>{field.designation_info.designation_name}</TableCell>
                      {/* <TableCell>{workingDays}</TableCell> */}
                      <TableCell className="w-40">
                        <FormInput name={`employees.${index}.absentday`} type="number" rules={{ max: { value: workingDays, message: `Max ${workingDays}`}, min: 0 }} />
                      </TableCell>
                      {/* <TableCell>{presentDays}</TableCell> */}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}


</div>


               </FormLayout>

    
    </FormProvider>
  );
};

export default AttendanceGeneratePage;