import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useServerSideTable } from "../../hooks/useServerSideTable";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Edit, FileText } from "lucide-react";

const StatusBadge = ({ status }) => {
  const config = {
    Pending: { text: "Pending", classes: "bg-red-100 text-red-700" },
    Approved: { text: "Approved", classes: "bg-green-100 text-green-700" },
    Rejected: { text: "Rejected", classes: "bg-gray-100 text-gray-700" },
  };

  const badge = config[status] || config["Pending"];

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${badge.classes}`}
    >
      {badge.text}
    </span>
  );
};

const StaffExpenseList = () => {
  const {
    data: expenses,
    tableState,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/staff-expenses`
  );

const columns = useMemo(
  () => [
    {
      header: "Sl#",
      cell: ({ row }) =>
        (tableState.currentPage - 1) * tableState.entriesPerPage +
        row.index +
        1,
    },
    {
      header: "ID",
      accessorKey: "id",
      enableSorting: true,
    },
    {
      header: "Name",
      accessorKey: "staffName",
      enableSorting: true,
    },
    {
      header: "Date",
      accessorKey: "date",
      enableSorting: true,
      cell: ({ row }) =>
        row.original.date
          ? new Date(row.original.date).toLocaleDateString("en-GB")
          : "N/A",
    },
    {
      header: "Matter",
      accessorKey: "matter",
      enableSorting: false,
    },
    {
      header: "Soft Copy",
      accessorKey: "documentUrl",
      enableSorting: false,
      cell: ({ row }) => {
        let url = row.original.documentUrl;

        // Fix: prepend protocol if missing
        if (url && !url.startsWith("http://") && !url.startsWith("https://")) {
          url = `http://${url}`;
        }

        return url ? (
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-red-600"
          >
            <FileText className="w-5 h-5" />
          </a>
        ) : (
          <span className="text-gray-400">N/A</span>
        );
      },
    },
    {
      header: "Amount",
      accessorKey: "total_amt",
      enableSorting: true,
      cell: ({ row }) =>
        row.original.total_amt
          ? parseFloat(row.original.total_amt).toFixed(2)
          : "0.00",
    },
    {
      header: "Status",
      accessorKey: "status",
      enableSorting: true,
      cell: ({ row }) => <StatusBadge status={row.original.status} />,
    },
    {
      header: "Actions",
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button asChild size="sm" variant="ghost">
            <Link to={`/staff-expenses/edit/${row.original.id}`}>
              <Edit className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      ),
    },
  ],
  [tableState.currentPage, tableState.entriesPerPage]
);



  return (
    <PageLayout
      title="Staff Expenses List"
      addPath={"add"}
      addText="Add Staff Expense"
    >
      <ShadcnDataTable
        Ltext="Staff Expense List"
        Rtext="Add Expense"
        addPath="add"
        data={expenses}
        columns={columns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default StaffExpenseList;
