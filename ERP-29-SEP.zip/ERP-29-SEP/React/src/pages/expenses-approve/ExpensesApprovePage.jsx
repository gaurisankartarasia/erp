import React, { useState, useEffect } from "react";
import { useForm, FormProvider } from "react-hook-form";
import PageLayout from "@/components/layouts/PageLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import FormInput from "@/pages/employee/custom/FormInput";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Button } from "@/components/ui/button";

const ExpensesApprovePage = () => {
  const methods = useForm({
    defaultValues: {
      payer_type: "",
      payer_id: "",
      from_date: "",
      to_date: "",
    },
  });
  const { handleSubmit, watch, reset } = methods;

  const [payers, setPayers] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const message = useMessageModal();

  const payerType = watch("payer_type");

  useEffect(() => {
    const fetchPayers = async () => {
      if (!payerType) {
        setPayers([]);
        return;
      }
      try {
        const res = await apiClient.get(
          `/expense-approve/payers?type=${payerType}`
        );
        setPayers(res.data.data);
      } catch (error) {
        message.error(`Failed to load ${payerType}.`);
      }
    };
    fetchPayers();
    methods.setValue("payer_id", ""); // Reset payer when type changes
  }, [payerType, message, methods]);

  const onSearch = async (data) => {
    setIsLoading(true);
    setExpenses([]);
    setSelectedIds(new Set());
    try {
      const res = await apiClient.get("/expense-approve/search", {
        params: data,
      });
      setExpenses(res.data.data);
      if (res.data.data.length === 0) {
        message.info("No pending expenses found for the selected criteria.");
      }
    } catch (error) {
      message.error("Failed to fetch expenses.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelect = (id) => {
    setSelectedIds((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedIds(new Set(expenses.map((exp) => exp.id)));
    } else {
      setSelectedIds(new Set());
    }
  };

  const onVerify = async () => {
    if (selectedIds.size === 0) {
      message.error("Please select at least one expense to verify.");
      return;
    }
    setIsSubmitting(true);
    try {
      await apiClient.patch("/expense-approve/approve", {
        expenseIds: Array.from(selectedIds),
      });
      message.success("Selected expenses have been verified.");
      // Refetch the data to show the updated list
      handleSubmit(onSearch)();
    } catch (error) {
      message.error("Verification failed.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    setPayers([]);
    setExpenses([]);
    setSelectedIds(new Set());
  };

  const payerTypeOptions = [
    { value: "staff", label: "Staff" },
    { value: "supplier", label: "Supplier" },
  ];

  return (
    <FormProvider {...methods}>
      <PageLayout title="Verify Expenses">
        <div className="grid grid-cols-4 gap-6">
          <FormSelect
            name="payer_type"
            label="Select Type"
            options={payerTypeOptions}
            rules={{ required: "Type is required" }}
          />
          <FormSelect
            name="payer_id"
            label="Select Name"
            options={payers}
            disabled={!payerType}
            rules={{ required: "Name is required" }}
          />
          <FormInput
            name="from_date"
            label="From Date"
            type="date"
            rules={{ required: "Start date is required" }}
          />
          <FormInput
            name="to_date"
            label="To Date"
            type="date"
            rules={{ required: "End date is required" }}
          />
        </div>
        <div className="flex items-center gap-2 my-4" >
          <Button onClick={handleSubmit(onSearch)}>Search</Button>
          <Button onClick={handleReset} variant={"outline"} >Reset</Button>
          {selectedIds.size !== 0
          &&  
  <Button
            onClick={onVerify}
            disabled={isSubmitting || selectedIds.size === 0}
          >
            {isSubmitting
              ? "Approving..."
              : `Approve (${selectedIds.size})`}
          </Button>

          }
        
        </div>

        <div className="col-span-2">
          {expenses.length > 0 && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-2">Verified or Pending Expenses</h3>
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">
                        <Checkbox
                          onCheckedChange={handleSelectAll}
                          checked={
                            selectedIds.size === expenses.length &&
                            expenses.length > 0
                          }
                        />
                      </TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Matter / Expense Type</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {expenses.map((expense) => (
                      <TableRow key={expense.id}>
                        <TableCell>
                          <Checkbox
                            onCheckedChange={() => handleSelect(expense.id)}
                            checked={selectedIds.has(expense.id)}
                          />
                        </TableCell>
                        <TableCell>{expense.date}</TableCell>
                        <TableCell>
                          {expense.matter || expense.expense_type}
                        </TableCell>
                        <TableCell className="text-right">
                          {parseFloat(expense.total_amt).toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <div className="flex justify-end mt-4"></div>
            </div>
          )}
        </div>
      </PageLayout>
    </FormProvider>
  );
};

export default ExpensesApprovePage;
