import { DataTypes } from 'sequelize';

export default (sequelize) => {
  const VendorExpense = sequelize.define('SupplierExpense', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    supplier: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      references: {
        model: 'vendors',
        key: 'id',
      },
    },
    matter: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    invoice_no: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    invoice_date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    taxable_amt: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    tax: {
      type: DataTypes.DECIMAL(5, 2),
      allowNull: false,
    },
    tax_amt: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    discount: {
      type: DataTypes.DECIMAL(12, 2),
      defaultValue: 0.00,
    },
    total_amt: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    status: {
  type: DataTypes.ENUM("pending", "verified", "approved"),
  allowNull: false,
  defaultValue: "pending",
},

    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    is_delete: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  }, {
    tableName: 'erp_supplier_expenses',
    timestamps: true,
    underscored: true,
  });

  return VendorExpense;
};