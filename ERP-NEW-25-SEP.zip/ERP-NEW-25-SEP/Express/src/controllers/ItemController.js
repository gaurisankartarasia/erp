// import { models } from '../models/index.js';
// import { Op } from 'sequelize';

// // Generate custom item_id like ITEM001, ITEM002, etc.
// const generateItemId = async () => {
//   try {
//     const lastItem = await models.Item.findOne({
//       order: [['created_at', 'DESC']]
//     });
//     if (!lastItem) return 'ITEM001';
//     const lastId = lastItem.item_id;
//     const number = parseInt(lastId.replace('ITEM', '')) + 1;
//     return `ITEM${number.toString().padStart(3, '0')}`;
//   } catch (error) {
//     return `ITEM${Date.now().toString().slice(-3)}`;
//   }
// };

// // Get all items (with search, pagination, sorting)
// export const getAllItems = async (req, res) => {
//   try {
//     const { search = '', page = 1, limit = 10, sort, order } = req.query;
//     const offset = (page - 1) * limit;
//     const whereCondition = {
//       is_delete: 0,
//       ...(search ? {
//         [Op.or]: [
//           { item_id: { [Op.like]: `%${search}%` } },
//           { item_name: { [Op.like]: `%${search}%` } },
//           { model_name: { [Op.like]: `%${search}%` } },
//           { unit: { [Op.like]: `%${search}%` } }
//         ]
//       } : {})
//     };
//     let orderArray = [['created_at', 'DESC']];
//     if (sort) {
//       const allowedSortFields = ['item_id', 'item_name', 'model_name', 'unit', 'created_at', 'updated_at'];
//       if (allowedSortFields.includes(sort)) {
//         orderArray = [[sort, order && order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC']];
//       }
//     }
//     const { count, rows: items } = await models.Item.findAndCountAll({
//       where: whereCondition,
//       order: orderArray,
//       limit: parseInt(limit),
//       offset: offset
//     });
//     res.json({
//       success: true,
//       data: items,
//       total: count,
//       currentPage: parseInt(page),
//       totalPages: Math.ceil(count / limit)
//     });
//   } catch (error) {
//     res.status(500).json({
//       success: false,
//       message: 'Error fetching items',
//       error: error.message
//     });
//   }
// };

// // Get item by ID
// export const getItemById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const item = await models.Item.findOne({ where: { item_id: id, is_delete: 0 } });
//     if (!item) {
//       return res.status(404).json({ success: false, message: 'Item not found' });
//     }
//     res.json({ success: true, data: item });
//   } catch (error) {
//     res.status(500).json({ success: false, message: 'Error fetching item', error: error.message });
//   }
// };

// // Create new item
// export const createItem = async (req, res) => {
//   try {
//     const { item_name, model_name, unit } = req.body;
//     if (!item_name || !model_name || !unit) {
//       return res.status(400).json({ success: false, message: 'All fields are required' });
//     }
//     const itemId = await generateItemId();
//     const newItem = await models.Item.create({
//       item_id: itemId,
//       item_name,
//       model_name,
//       unit,
//       is_active: 1,
//       is_delete: 0,
//       created_at: new Date(),
//       updated_at: new Date()
//     });
//     res.status(201).json({ success: true, message: 'Item created successfully', data: newItem });
//   } catch (error) {
//     res.status(500).json({ success: false, message: 'Error creating item', error: error.message });
//   }
// };

// // Update item
// export const updateItem = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { item_name, model_name, unit } = req.body;
//     const item = await models.Item.findOne({ where: { item_id: id, is_delete: 0 } });
//     if (!item) {
//       return res.status(404).json({ success: false, message: 'Item not found' });
//     }
//     await item.update({
//       item_name: item_name || item.item_name,
//       model_name: model_name || item.model_name,
//       unit: unit || item.unit,
//       updated_at: new Date()
//     });
//     res.json({ success: true, message: 'Item updated successfully', data: item });
//   } catch (error) {
//     res.status(500).json({ success: false, message: 'Error updating item', error: error.message });
//   }
// };

// // Get all active units for dropdown
// export const getActiveUnits = async (req, res) => {
//   try {
//     const units = await models.Unit.findAll({
//       where: { is_active: 1, is_delete: 0 },
//       order: [['unit_name', 'ASC']]
//     });
//     res.json({ success: true, data: units });
//   } catch (error) {
//     res.status(500).json({ success: false, message: 'Error fetching units', error: error.message });
//   }
// };

import { models } from '../models/index.js';
import { Op } from 'sequelize';

// Generate custom item_id like ITEM001, ITEM002, etc.
const generateItemId = async () => {
  try {
    const lastItem = await models.Item.findOne({
      order: [['created_at', 'DESC']]
    });
    if (!lastItem) return 'ITEM001';
    const lastId = lastItem.item_id;
    const number = parseInt(lastId.replace('ITEM', '')) + 1;
    return `ITEM${number.toString().padStart(3, '0')}`;
  } catch (error) {
    return `ITEM${Date.now().toString().slice(-3)}`;
  }
};

// Get all items (with search, pagination, sorting)
export const getAllItems = async (req, res) => {
  try {
    const { search = '', page = 1, limit = 10, sort, order } = req.query;
    const offset = (page - 1) * limit;
    const whereCondition = {
      is_delete: 0,
      ...(search ? {
        [Op.or]: [
          { item_id: { [Op.like]: `%${search}%` } },
          { item_name: { [Op.like]: `%${search}%` } },
          { model_name: { [Op.like]: `%${search}%` } },
          { unit: { [Op.like]: `%${search}%` } }
        ]
      } : {})
    };
    let orderArray = [['created_at', 'DESC']];
    if (sort) {
      const allowedSortFields = ['item_id', 'item_name', 'model_name', 'unit', 'created_at', 'updated_at'];
      if (allowedSortFields.includes(sort)) {
        orderArray = [[sort, order && order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC']];
      }
    }
    const { count, rows: items } = await models.Item.findAndCountAll({
      where: whereCondition,
      order: orderArray,
      limit: parseInt(limit),
      offset: offset
    });
    
    // Map items to include status text
    const itemsWithStatus = items.map(item => ({
      ...item.toJSON(),
      status: item.is_active ? 'Active' : 'Inactive'
    }));
    
    res.json({
      success: true,
      data: itemsWithStatus,
      total: count,
      currentPage: parseInt(page),
      totalPages: Math.ceil(count / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching items',
      error: error.message
    });
  }
};

// Get item by ID
export const getItemById = async (req, res) => {
  try {
    const { id } = req.params;
    const item = await models.Item.findByPk(id);
    if (!item) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    const itemWithStatus = {
      ...item.toJSON(),
      status: item.is_active ? 'Active' : 'Inactive'
    };
    
    res.json({ success: true, data: itemWithStatus });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching item', error: error.message });
  }
};

// Create new item
export const createItem = async (req, res) => {
  try {
    const { item_name, model_name, unit } = req.body;
    if (!item_name || !model_name || !unit) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }
    const itemId = await generateItemId();
    const newItem = await models.Item.create({
      item_id: itemId,
      item_name,
      model_name,
      unit,
      is_active: 1,
      is_delete: 0,
      created_at: new Date(),
      updated_at: new Date()
    });
    res.status(201).json({ success: true, message: 'Item created successfully', data: newItem });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error creating item', error: error.message });
  }
};

// Update item (including status toggle)
export const updateItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { item_name, model_name, unit, status } = req.body;
    
    const item = await models.Item.findOne({ where: { item_id: id, is_delete: 0 } });
    if (!item) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    // Handle status toggle
    if (status) {
      const is_active = status === 'Active' ? 1 : 0;
      await item.update({
        is_active,
        updated_at: new Date()
      });
    } else {
      // Regular update
      await item.update({
        item_name: item_name || item.item_name,
        model_name: model_name || item.model_name,
        unit: unit || item.unit,
        updated_at: new Date()
      });
    }
    
    const updatedItem = {
      ...item.toJSON(),
      status: item.is_active ? 'Active' : 'Inactive'
    };
    
    res.json({ success: true, message: 'Item updated successfully', data: updatedItem });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating item', error: error.message });
  }
};

// Get all active units for dropdown
export const getActiveUnits = async (req, res) => {
  try {
    const units = await models.Unit.findAll({
      where: { is_active: 1, is_delete: 0 },
      order: [['unit_name', 'ASC']]
    });
    res.json({ success: true, data: units });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching units', error: error.message });
  }
};