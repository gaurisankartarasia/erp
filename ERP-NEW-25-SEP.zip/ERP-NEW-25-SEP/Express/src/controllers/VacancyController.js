import { models, sequelize } from "../models/index.js";
import { Op } from "sequelize";
import { log } from "../services/LogService.js";

const Vacancy = sequelize.models.Vacancy;

/**
 * Create a new Vacancy
 */
export const createVacancy = async (req, res) => {
  const { post_name, date, description } = req.body;

  if (!post_name || !date || !description) {
    return res.status(400).json({
      message: "Post Name, Date, and Description are required",
    });
  }

  try {
    const vacancy = await Vacancy.create({
      post_name,
      date,
      description,
    });

    await log({
      req,
      action: "CREATE",
      page_name: "VACANCY FORM PAGE",
      target: `Vacancy ID: ${vacancy.id}`,
    });

    res.status(201).json({
      message: "Vacancy Created Successfully",
      data: vacancy,
    });

  } catch (err) {
    res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

/**
 * Get all Vacancies with pagination, sorting and search
 */
export const getAllVacancies = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = "createdAt",
      order = "DESC",
      search = "",
    } = req.query;

    const offset = (page - 1) * limit;

    const whereCondition = {
      [Op.or]: [
        { post_name: { [Op.like]: `%${search}%` } },
        { description: { [Op.like]: `%${search}%` } },
      ],
    };

    const { rows: vacancies, count: totalVacancies } = await Vacancy.findAndCountAll({
      where: search ? whereCondition : {},
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, order.toUpperCase()]],
      attributes: { exclude: ["createdAt", "updatedAt"] },
    });

    res.status(200).json({
      message: "Vacancies fetched successfully",
      data: vacancies,
      total: totalVacancies,
      page: parseInt(page),
      pages: Math.ceil(totalVacancies / limit),
    });

  } catch (err) {
    console.error("Error fetching vacancies:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

/**
 * Get Vacancy by ID
 */
export const getVacancyById = async (req, res) => {
  const { id } = req.params;

  try {
    const vacancy = await Vacancy.findByPk(id);

    if (!vacancy) {
      return res.status(404).json({
        message: "Vacancy Not Found",
      });
    }

    await log({
      req,
      action: "READ",
      page_name: "VACANCY FORM PAGE",
      target: `Vacancy ID: ${vacancy.id}`,
    });

    res.status(200).json(vacancy);

  } catch (err) {
    res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

/**
 * Update Vacancy by ID
 */
export const updateVacancy = async (req, res) => {
  const { id } = req.params;
  const updateFields = req.body;

  try {
    const vacancy = await Vacancy.findByPk(id);

    if (!vacancy) {
      return res.status(404).json({
        message: "Vacancy Not Found",
      });
    }

    await vacancy.update(updateFields);

    await log({
      req,
      action: "UPDATE",
      page_name: "VACANCY FORM PAGE",
      target: `Vacancy ID: ${vacancy.id}`,
    });

    res.status(200).json({
      message: "Vacancy updated successfully",
      data: vacancy,
    });

  } catch (err) {
    console.error("Error updating vacancy:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

/**
 * Delete Vacancy by ID
 */
export const deleteVacancy = async (req, res) => {
  const { id } = req.params;

  try {
    const vacancy = await Vacancy.findByPk(id);

    if (!vacancy) {
      return res.status(404).json({
        message: "Vacancy Not Found",
      });
    }

    await vacancy.destroy();

    await log({
      req,
      action: "DELETE",
      page_name: "VACANCY FORM PAGE",
      target: `Vacancy ID: ${vacancy.id}`,
    });

    res.status(200).json({
      message: "Vacancy deleted successfully",
    });

  } catch (err) {
    console.error("Error deleting vacancy:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

/**
 * Toggle Vacancy status (if applicable)
 * Assuming Vacancy model has an `is_active` boolean field.
 */
export const toggleVacancyStatus = async (req, res) => {
  const { id } = req.params;

  try {
    const vacancy = await Vacancy.findByPk(id);

    if (!vacancy) {
      return res.status(404).json({
        message: "Vacancy Not Found",
      });
    }

    vacancy.is_active = !vacancy.is_active;
    await vacancy.save();

    res.status(200).json({
      message: `Vacancy has been ${vacancy.is_active ? "activated" : "deactivated"}.`,
      data: vacancy,
    });

  } catch (err) {
    console.error("Error toggling vacancy status:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};


// http://localhost:5000/api/vacancies/add
// http://localhost:5000/api/vacancies/
// http://localhost:5000/api/vacancies/:id
// http://localhost:5000/api/vacancies/edit/:id
// http://localhost:5000/api/vacancies/delete/:id



// http://localhost:5000/api/vacancies/toggle-status/:id
// http://localhost:5000/api/vacancies/edit/:id

