

import express from "express";
import { createVacancy, deleteVacancy, getAllVacancies, getVacancyById, toggleVacancyStatus, updateVacancy } from "../controllers/VacancyController.js";


const router = express.Router();

// Create a new vacancy
router.post("/add", createVacancy);

// Get all vacancies with pagination, search, sorting
router.get("/" , getAllVacancies);

// Get vacancy by ID
router.get("/:id", getVacancyById);

// Update vacancy by ID
router.put("/edit/:id", updateVacancy);

// Delete vacancy by ID
router.delete("/delete/:id", deleteVacancy);

// Toggle vacancy is_active status by ID
router.patch("/toggle-status/:id", toggleVacancyStatus);

export default router;
