import React, { useMemo, useState } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "../../hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Edit, FileText } from "lucide-react";
import apiClient from "@/api/axiosConfig";

const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const VendorExpensesListPage = () => {
  const {
    data: employees,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/supplier-expenses`
  );
  const confirm = useConfirmModal();

  const handleToggleStatus = async (employee) => {
    const ok = await confirm({
      title: "Change Status",
      description: `Are you sure you want to ${
        employee.is_active ? "deactivate" : "activate"
      } this employee?`,
    });

    if (!ok) return;

    try {
      await apiClient.patch(`/employee/${employee.id}/status`);
      refreshData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const employeeColumns = useMemo(
    () => [
      {
        id: "sl_no",
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        id: "supplier_name",
        header: "Supplier Name",
        accessorFn: (row) => row.supplier_info.name || "-",
        enableSorting: true,
      },
      {
        id: "matter",
        header: "Matter",
        accessorFn: (row) => row.matter || "-",
        enableSorting: true,
      },
      {
        id: "date",
        header: "Date",
        accessorFn: (row) => row.date || "-",
        enableSorting: true,
      },
      {
        id: "invoice_no",
        header: "Invoice No",
        accessorFn: (row) => row.invoice_no || "-",
        enableSorting: true,
      },
      {
        id: "invoice_date",
        header: "Invoice Date",
        accessorFn: (row) => row.invoice_date || "-",
        enableSorting: true,
      },
      {
        id: "total_amt",
        header: "Total Amount",
        accessorFn: (row) => row.total_amt || "-",
        enableSorting: true,
      },
      {
        id: "document",
        header: "Document",
        cell: () => {
          return (
             <Button asChild size="sm" variant="ghost">
                <FileText />
              </Button>
          );
        },
      },
      {
        id: "status",
        header: "Status",
        accessorFn: (row) => row.status,
        enableSorting: true,
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          const employee = row.original;
          return (
            <div className="flex items-center">
              <Button asChild size="sm" variant="ghost">
                <Link to={`/supplierexpenses/edit/${employee.id}`}>
                  <Edit />
                </Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage]
  );

  return (
    <PageLayout
      title="Employee List"
      addPath={"add"}
      addText="Add Vendor Expense"
    >
      <ShadcnDataTable
        addPath="add"
        data={employees}
        columns={employeeColumns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default VendorExpensesListPage;
