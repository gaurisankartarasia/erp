import React, { useEffect, useCallback, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, FormProvider } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/pages/employee/custom/FormInput";
import FormSelect from "@/pages/employee/custom/FormSelect";
import DocumentUploader from "@/components/common/forms/FormDocumentUpload";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const SupplierExpensesFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      supplier: "",
      matter: "",
      date: "",
      invoice_no: "",
      invoice_date: "",
      taxable_amt: "",
      tax: "0",
      tax_amt: "0.00",
      discount: "",
      total_amt: "0.00",
      document: null,
    },
  });

  const { handleSubmit, reset, watch, setValue } = methods;

  const [clientOptions, setClientOptions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);

  const [taxableAmount, taxPercentage, discount] = watch([
    "taxable_amt",
    "tax",
    "discount",
  ]);

  useEffect(() => {
    const parsedTaxable = parseFloat(taxableAmount) || 0;
    const parsedTax = parseFloat(taxPercentage) || 0;
    const parsedDiscount = parseFloat(discount) || 0;

    const calculatedTaxAmount = (parsedTaxable * parsedTax) / 100;
    const calculatedTotal =
      parsedTaxable + calculatedTaxAmount - parsedDiscount;

    setValue("tax_amt", calculatedTaxAmount.toFixed(2));
    setValue("total_amt", calculatedTotal.toFixed(2));
  }, [taxableAmount, taxPercentage, discount, setValue]);

  const fetchData = useCallback(
    async (endpoint, valueKey, labelKey) => {
      try {
        const response = await apiClient.get(endpoint);
        if (!Array.isArray(response.data.data)) return [];
        return response.data.data
          .filter((item) => item && item[valueKey] != null)
          .map((item) => ({
            value: String(item[valueKey]),
            label: item[labelKey],
          }));
      } catch {
        message.error(`Failed to fetch options from ${endpoint}`);
        return [];
      }
    },
    [message]
  );

  useEffect(() => {
    const fetchInitialOptions = async () => {
      const clients = await fetchData("supplier-expenses/suppliers", "id", "name");
      setClientOptions(clients);
    };
    fetchInitialOptions();
  }, [fetchData]);

  useEffect(() => {
    if (id) {
      const fetchExpense = async () => {
        setIsLoading(true);
        try {
          const res = await apiClient.get(`/supplier-expenses/${id}`);
          reset(res.data);
        } catch (e) {
          message.error("Failed to fetch expense data.");
        } finally {
          setIsLoading(false);
        }
      };
      fetchExpense();
    }
  }, [id, reset, message]);

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    const payload = new FormData();

    Object.keys(data).forEach((key) => {
      const value = data[key];

      // **THE FIX IS HERE**
      // Only append the document field if it's a new FileList with a file.
      // Otherwise, skip it, so the backend doesn't try to update the existing file path with an object.
      if (key === 'document') {
        if (value instanceof FileList && value.length > 0) {
          payload.append(key, value[0]);
        }
      } else if (value !== null && value !== undefined) {
        payload.append(key, value);
      }
    });

    try {
      if (id) {
        await apiClient.put(`/supplier-expenses/edit/${id}`, payload);
        message.success("Expense updated successfully.");
      } else {
        await apiClient.post("/supplier-expenses/add", payload);
        message.success("Expense added successfully.");
      }
      navigate("/supplierexpenses");
    } catch (err) {
      message.error(
        err.response?.data?.message || "An unexpected error occurred."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const taxOptions = [
    { value: "0", label: "0%" },
    { value: "5", label: "5%" },
    { value: "12", label: "12%" },
    { value: "18", label: "18%" },
    { value: "28", label: "28%" },
  ];
console.log(clientOptions)
  return (
    <FormProvider {...methods}>
      <FormLayout
        title={id ? "Edit Vendor Expense" : "Add Vendor Expense"}
        backPath="/supplierexpenses"
        onSubmit={handleSubmit(onSubmit)}
        isSubmitting={isSubmitting}
        submitText={id ? "Update" : "Submit"}
        onCancel={() => navigate("/supplierexpenses")}
        onReset={() => reset()}
        isLoading={isLoading}
      >
        <div className="col-span-2">
          <div className="grid grid-cols-4 gap-6">
            <FormSelect
              name="supplier"
              label="Vendor Name"
              options={clientOptions}
              rules={{ required: "Vendor Name is required" }}
              showSearch
            />
            <FormInput
              name="matter"
              label="Matter"
              rules={{ required: "Matter is required" }}
            />
            <FormInput
              name="date"
              label="Date"
              type="date"
              rules={{ required: "Date is required" }}
            />
            <FormInput
              name="invoice_no"
              label="Invoice No"
              rules={{ required: "Invoice No is required" }}
            />
            <FormInput
              name="invoice_date"
              label="Invoice Date"
              type="date"
              rules={{ required: "Invoice date is required" }}
            />
            <FormInput
              name="taxable_amt"
              label="Taxable Amount"
              type="number"
              rules={{
                required: "Taxable amount is required",
                min: { value: 0, message: "Amount must be positive" },
              }}
            />
            <FormSelect
              name="tax"
              label="Tax %"
              options={taxOptions}
              rules={{ required: "Tax percentage is required" }}
            />
            <FormInput
              name="tax_amt"
              label="Tax Amount"
              type="number"
              disabled
            />
            <FormInput
              name="discount"
              label="Discount"
              type="number"
              placeholder="0.00"
              rules={{
                min: { value: 0, message: "Discount must be positive" },
              }}
            />
            <FormInput
              name="total_amt"
              label="Total Amount"
              type="number"
              disabled
            />

            <div className="col-span-2">
              <DocumentUploader
                name="document"
                label="Upload Support Documents"
                allowedTypes={["application/pdf"]}
                maxSizeMB={2}
                rules={{ required: "Document is required" }}
              />
            </div>
          </div>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default SupplierExpensesFormPage;
