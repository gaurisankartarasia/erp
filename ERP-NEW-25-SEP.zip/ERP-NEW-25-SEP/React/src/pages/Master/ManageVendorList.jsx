import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check } from "lucide-react";
import apiClient from "@/api/axiosConfig";

const TaxStatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const ManageVendorList = () => {
  const {
    data: vendors,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/vendors/`
  );

  const confirm = useConfirmModal();

  const handleToggleStatus = async (vendor) => {
    const ok = await confirm({
      title: "Change Vendor Status",
      description: `Are you sure you want to ${
        vendor.is_active ? "deactivate" : "activate"
      } this vendor?`,
    });

    if (!ok) return;

    try {
      await apiClient.patch(`/vendors/toggle-status/${vendor.id}`);
      refreshData();
    } catch (error) {
      console.error("Error updating vendor status:", error);
    }
  };

  const vendorColumns = useMemo(
    () => [
      {
        header: "Sl#",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "ID",
        accessorKey: "vendor_code",
        enableSorting: true,
      },
      {
        header: "Name",
        accessorKey: "name",
        enableSorting: true,
      },
      {
        header: "Mobile No",
        accessorKey: "mobile_no",
        enableSorting: false,
        cell: ({ row }) => row.original.mobile_no || "NA",
      },
      {
        header: "Email Id",
        accessorKey: "email_id",
        enableSorting: false,
        cell: ({ row }) => row.original.email_id || "NA",
      },
      {
        header: "Tax Type",
        accessorKey: "tax_type",
        enableSorting: true,
      },
      {
        header: "Tax Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <TaxStatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const vendor = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(vendor)}
                aria-label={
                  vendor.is_active ? "Deactivate vendor" : "Activate vendor"
                }
              >
                {vendor.is_active ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>

              <Button asChild size="sm" variant="ghost">
                <Link to={`/master/vendors/edit/${vendor.id}`}>
                  <Edit className="text-indigo-600" />
                </Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage, confirm]
  );

  return (
    <PageLayout
      title="Manage Vendor"
      rightButton={{ text: "Add Vendor", path: "add" }}
    >
      <ShadcnDataTable
        Ltext="Manage Vendor"
        Rtext="+ Add Vendor"
        addPath="add"
        data={vendors}
        columns={vendorColumns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default ManageVendorList;
