import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import PageLayout from "@/components/layouts/PageLayout";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import { Button } from "@/components/ui/button";
import { X, Check, Edit } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { useConfirmModal } from "@/hooks/useConfirmModal";

export default function DesignationListPage() {
  const { data, tableState, refreshData } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/designations`
  );
  const message = useMessageModal();
  const confirm = useConfirmModal();

  const handleStatusToggle = async (designation) => {
    const confirmed = await confirm({
      description: `Do you really want to ${
        designation.is_active ? "deactivate" : "activate"
      } this record?

`,
    });
    if (!confirmed) return;
    try {
      const newStatus = !designation.is_active;
      await apiClient.patch(`/designations/status/${designation.id}`, {
        is_active: newStatus,
      });
      refreshData();
    } catch (error) {
      console.error("Failed to update status:", error);
      alert("Failed to update designation status.");
    }
  };

  const columns = useMemo(
    () => [
             {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        accessorKey: "designation_id",
        header: "ID",
        enableSorting: true,
      },
      {
        accessorKey: "designation_name",
        header: "Designation Name",
        enableSorting: true,
      },
      {
        accessorKey: "description",
        header: "Description",
        enableSorting: false,
      },
      {
        accessorKey: "is_active",
        header: "Status",
        enableSorting: true,
        cell: ({ row }) => {
          const isActive = row.original.is_active;
          return (
            <Badge variant={isActive ? "default" : "destructive"}>
              {isActive ? "Active" : "Inactive"}
            </Badge>
          );
        },
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const designation = row.original;
          return (
            <>
              <Button
                variant={"ghost"}
                onClick={() => handleStatusToggle(designation)}
              >
                {designation.is_active ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>
              <Button variant={"ghost"} asChild>
                <Link to={`/designations/edit/${designation.id}`}>
                  <Edit className="text-blue-500" />
                </Link>
              </Button>
            </>
          );
        },
      },
    ],
    []
  );

  return (
    <PageLayout
      title="Designations"
      rightButton={{ text: "Add Designation", path: "create" }}
    >
      <ShadcnDataTable columns={columns} data={data} tableState={tableState} />
    </PageLayout>
  );
}
