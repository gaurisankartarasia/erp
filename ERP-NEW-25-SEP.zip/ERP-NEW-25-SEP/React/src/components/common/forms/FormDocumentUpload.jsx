// import React, { useRef, useMemo } from "react";
// import { FaEye, FaTrash } from "react-icons/fa";
// import { Input } from "@/components/ui/input";

// const DocumentUploader = ({
//   label = "Upload Document",
//   file,
//   existingFileName,
//   existingFileUrl,
//   required = false,

//   onFileChange,
//   onRemove,

//   allowedTypes = ["application/pdf", "image/jpeg", "image/png"],
//   maxSizeMB = 5,

//   error,
// }) => {
//   const fileInputRef = useRef(null);

//   const handleFileSelection = (e) => {
//     const selectedFile = e.target.files[0];
//     if (!selectedFile) {
//       onFileChange(null, null);
//       return;
//     }

//     const maxSizeInBytes = maxSizeMB * 1024 * 1024;
//     if (selectedFile.size > maxSizeInBytes) {
//       const errorMessage = `File is too large. Max size is ${maxSizeMB}MB.`;
//       onFileChange(null, errorMessage);
//       if (fileInputRef.current) fileInputRef.current.value = "";
//       return;
//     }

//     if (!allowedTypes.includes(selectedFile.type)) {    
//       const errorMessage = "Invalid file type.";
//       onFileChange(null, errorMessage);
//       if (fileInputRef.current) fileInputRef.current.value = "";
//       return;
//     }

//     onFileChange(selectedFile, null);
//   };

//   const acceptString = useMemo(() => allowedTypes.join(","), [allowedTypes]);

//   const allowedExtensions = useMemo(
//     () =>
//       [
//         ...new Set(
//           allowedTypes.map((type) => type.split("/")[1].toUpperCase())
//         ),
//       ].join(", "),
//     [allowedTypes]
//   );

//   return (
//     <div>
//       <div className="flex items-center gap-2 mb-1">
//         <label className="text-sm font-medium">
//           {label}     {required && (
//             <span className="text-sm font-medium text-red-500">*</span>
//           )}
//         </label>
//         <p className="text-xs text-primary">
//           Accepts: {allowedExtensions}. Max size: {maxSizeMB}MB.
      
//         </p>
//       </div>
//       <Input
//         type="file"
//         ref={fileInputRef}
//         onChange={handleFileSelection}
//         accept={acceptString}
//         className={` w-full cursor-pointer  ${
//           error ? "border-red-500" : "border-none"
//         } 
// `}
//       />

//       {error && <p className="text-xs text-red-600 mt-1">{error}</p>}


//       {!file && existingFileName && (
//         <div className="mt-2 p-2 bg-gray-50 rounded-md border flex items-center justify-between">
//           <span className="text-sm text-gray-700 truncate">
//             {existingFileName}
//           </span>
//           <div className="flex items-center gap-3 flex-shrink-0">
//             {existingFileUrl && (
//               <a
//                 href={existingFileUrl}
//                 target="_blank"
//                 rel="noopener noreferrer"
//                 className="flex items-center gap-2 text-blue-600 hover:text-blue-800"
//                 title="View File"
//               >
//                 View <FaEye />
//               </a>
//             )}
//             {onRemove && (
//               <button
//                 type="button"
//                 onClick={onRemove}
//                 className="text-red-600 hover:text-red-800"
//                 title="Remove File"
//               >
//                 <FaTrash />
//               </button>
//             )}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default DocumentUploader;



import React from "react";
import { useFormContext, Controller } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const FormDocumentUploader = ({
  name,
  label,
  required = false,
  rules = {},
  allowedTypes = ["application/pdf"],
  maxSizeMB = 5,
}) => {
  const { control, formState: { errors }, watch } = useFormContext();
  const file = watch(name);
  const error = errors[name]?.message;

  const acceptString = allowedTypes.join(",");
  const allowedExtensions = [...new Set(allowedTypes.map(type => type.split('/')[1].toUpperCase()))].join(', ');

  return (
    <div className="grid gap-2">
      <Label htmlFor={name}>
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <Controller
        name={name}
        control={control}
        rules={{
          ...rules,
          validate: {
            maxSize: (fileList) => {
              if (!fileList || fileList.length === 0) return true;
              return fileList[0].size <= maxSizeMB * 1024 * 1024 || `File size must be less than ${maxSizeMB}MB`;
            },
            allowedType: (fileList) => {
              if (!fileList || fileList.length === 0) return true;
              return allowedTypes.includes(fileList[0].type) || `Invalid file type. Accepts: ${allowedExtensions}`;
            },
          },
        }}
        render={({ field }) => (
          <Input
            id={name}
            type="file"
            accept={acceptString}
            className={cn(error && "border-destructive")}
            onChange={(e) => field.onChange(e.target.files)}
          />
        )}
      />
      {file?.[0]?.name && !error && (
        <div className="mt-2 text-sm text-muted-foreground">Selected file: {file[0].name}</div>
      )}
      {error && <p className="text-sm text-destructive">{error}</p>}
      <p className="text-xs text-muted-foreground">
        Accepts: {allowedExtensions}. Max size: {maxSizeMB}MB.
      </p>
    </div>
  );
};

export default FormDocumentUploader;