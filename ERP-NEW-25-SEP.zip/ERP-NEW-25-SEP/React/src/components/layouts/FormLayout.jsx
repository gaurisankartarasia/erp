import React from "react";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";

export default function FormLayout({
  title,
  children,
  onSubmit,
  onReset,
  onCancel,
  submitText = "Submit",
  showSubmit = true,
  topButtons = [],
  backPath,
  onBack,
  isLoading = false,
}) {
  const navigate = useNavigate();

  return (
    <div className="relative bg-white shadow-2xl border p-6">
      {isLoading && (
        <div className="absolute inset-0 bg-white/70 flex items-center justify-center z-10">
          <Spinner className="w-12 h-12 animate-spin" />
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">{title}</h2>

        <div className="flex gap-3">
          {(backPath || onBack) && (
            <Button
              type="button"
              variant="warning"
              onClick={() => (onBack ? onBack() : navigate(backPath))}
              disabled={isLoading}
            >
              <ArrowLeft />
              Back
            </Button>
          )}

          {topButtons.map((btn, idx) => {
            const Icon = btn.icon;
            const content = (
              <Button
                variant={btn.variant || "default"}
                onClick={btn.onClick}
                disabled={isLoading}
              >
                {Icon && <Icon className="w-4 h-4 mr-2" />}
                {btn.text}
              </Button>
            );
            return btn.path ? (
              <Link key={idx} to={btn.path}>
                {content}
              </Link>
            ) : (
              <div key={idx}>{content}</div>
            );
          })}
        </div>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit && onSubmit();
        }}
      >
        <div className="grid grid-cols-2 gap-6">{children}</div>

        <div className="mt-6 flex gap-3 justify-start">
          {showSubmit && (
            <Button type="submit" variant="success" disabled={isLoading}>
              {submitText}
            </Button>
          )}
          {onReset && (
            <Button
              type="button"
              variant="outline"
              onClick={() => onReset && onReset()}
              disabled={isLoading}
            >
              Reset
            </Button>
          )}
          {onCancel && (
            <Button
              type="button"
              variant="destructive"
              onClick={() => onCancel && onCancel()}
              disabled={isLoading}
            >
              Cancel
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}
