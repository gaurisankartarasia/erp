import { DataTypes } from 'sequelize';

export default (sequelize) => {
  sequelize.define('Contribution', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    cont_id: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    epf_employee_share: {
      type: DataTypes.DECIMAL(18, 2),
      allowNull: false,
    },
    epf_employer_share: {
      type: DataTypes.DECIMAL(18, 2),
      allowNull: false,
    },
    esi_employee_share: {
      type: DataTypes.DECIMAL(18, 2),
      allowNull: false,
    },
    esi_employer_share: {
      type: DataTypes.DECIMAL(18, 2),
      allowNull: false,
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    is_delete: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  }, {
    tableName: 'erp_contributions',
    timestamps: true,
    underscored: true,
  });
};
