import sequelize from "../../configs/db.js";
import defineEmployeeModel from "./Employees.js";
import definePermissionModel from "./Permission.js";
import defineTaskModel from "./Task.js";
import defineLogModel from "./LogRecords.js";
import defineLeaveTypeModel from "./leave-type.model.js";
import defineSalarySlipModel from "./salary-slip.model.js";
import defineSalaryComponentModel from "./salary-component.model.js";
import defineEmployeeSalaryStructureModel from "./employee-salary-structure.model.js";

import defineRulesModel from "./Rules.js";
import definePayrollReportModel from "./payroll-report.model.js";
import defineLeaveRequestModel from "./leave-request.model.js";
import defineAttendanceModel from "./attendance.modal.js";
import defineIncrementSchemeModel from "./IncrementScheme.js";

import defineStateModel from "./State.js";
import defineDistrictModel from "./District.js";
import defineClientModel from "./Client.js";
import defineAdminProfileModel from "./AdminProfile.js";
import defineDesignationModel from "./Designation.js";
import defineContributionModel from "./Contribution.js";
import defineUnitModel from "./unit.js";
import defineItemModel from "./Item.js";
import defineVacancyModel from "./Vacancy.js";
import defineVendorModel from "./Vendor.js";

defineEmployeeModel(sequelize);
definePermissionModel(sequelize);
defineTaskModel(sequelize);
defineSalarySlipModel(sequelize);
defineSalaryComponentModel(sequelize);
defineEmployeeSalaryStructureModel(sequelize);
defineLeaveTypeModel(sequelize);
defineLeaveRequestModel(sequelize);
defineRulesModel(sequelize);
definePayrollReportModel(sequelize);
defineAttendanceModel(sequelize);
defineLogModel(sequelize);
defineIncrementSchemeModel(sequelize);
defineStateModel(sequelize);
defineDistrictModel(sequelize);
defineClientModel(sequelize);
defineAdminProfileModel(sequelize);
defineDesignationModel(sequelize);
defineContributionModel(sequelize);
defineUnitModel(sequelize);
defineItemModel(sequelize);
defineVacancyModel(sequelize);
defineVendorModel(sequelize);

const {
  Employee,
  Permission,
  Task,
  SalaryComponent,
  EmployeeSalaryStructure,
  LeaveType,
  LeaveRequest,
  IncrementScheme,
  State,
  District,
  Client,
  AdminProfile,
  Designation,
  Contribution,
  Unit,
  Item,
  vacancy,
  Vendor,
  Log,
  Attendance,
  PayrollReport,
  SalarySlip,
} = sequelize.models;

District.belongsTo(State, { foreignKey: "state_id" });
State.hasMany(District, { foreignKey: "state_id" });

Employee.belongsToMany(Permission, { through: "employee_permissions" });
Permission.belongsToMany(Employee, { through: "employee_permissions" });

Employee.hasMany(EmployeeSalaryStructure, { foreignKey: "employee_id" });
EmployeeSalaryStructure.belongsTo(Employee, { foreignKey: "employee_id" });

LeaveRequest.belongsTo(Employee, {
  as: "Employee",
  foreignKey: "employee_id",
});

LeaveRequest.belongsTo(Employee, {
  as: "CreatedByAdmin",
  foreignKey: "created_by_admin_id",
});

LeaveType.hasMany(LeaveRequest, { foreignKey: "leave_type_id" });
LeaveRequest.belongsTo(LeaveType, { foreignKey: "leave_type_id" });

LeaveType.belongsTo(LeaveType, {
  as: "FallbackType",
  foreignKey: "fallback_leave_type_id",
});

Employee.hasMany(PayrollReport, { foreignKey: "generated_by_id" });
PayrollReport.belongsTo(Employee, { foreignKey: "generated_by_id" });

Employee.hasMany(Attendance, { foreignKey: "employee_id" });
Attendance.belongsTo(Employee, { foreignKey: "employee_id" });

Employee.hasMany(LeaveRequest, { foreignKey: "employee_id" });
LeaveRequest.belongsTo(Employee, { foreignKey: "employee_id" });
PayrollReport.hasMany(SalarySlip, { foreignKey: "report_id" });
SalarySlip.belongsTo(PayrollReport, { foreignKey: "report_id" });

SalaryComponent.hasMany(EmployeeSalaryStructure, {
  foreignKey: "component_id",
});
EmployeeSalaryStructure.belongsTo(SalaryComponent, {
  as: "component",
  foreignKey: "component_id",
});

Employee.hasMany(Task);
Task.belongsTo(Employee);



Employee.belongsTo(Designation, { foreignKey: "designation", as: "designation_info" });
Designation.hasMany(Employee, { foreignKey: "designation" });
Employee.belongsTo(Client, { foreignKey: "client", as: "client_info" });
Client.hasMany(Employee, { foreignKey: "client" });
Employee.belongsTo(State, { foreignKey: "permanent_state", as: "permanent_state_info" });
Employee.belongsTo(State, { foreignKey: "present_state", as: "present_state_info" });
Employee.belongsTo(District, { foreignKey: "permanent_district", as: "permanent_district_info" });
Employee.belongsTo(District, { foreignKey: "present_district", as: "present_district_info" });



console.log("Models and Associations defined");

export { sequelize };
export const models = sequelize.models;
