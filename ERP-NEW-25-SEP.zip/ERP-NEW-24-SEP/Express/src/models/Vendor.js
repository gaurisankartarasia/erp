import { DataTypes } from 'sequelize';

export default (sequelize) => {
    sequelize.define('Vendor', {
        vendor_code: {
            type: DataTypes.STRING,
            allowNull: true,
            unique: true,
            comment: 'Special unique string ID for the vendor',
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        mobile_no: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email_id: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                isEmail: true,
            },
        },
        tax_type: {
            type: DataTypes.ENUM('Inner State ','Intra State '),
            defaultValue: 'Inner State'



        },
        is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
        gst_no: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        pan_no: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        address: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        state: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        district: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        pin_code: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        bank_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        branch_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        ifsc_code: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        bank_ac_no: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        beneficiary_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        remarks: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
    }, {
        tableName: 'vendors',
        timestamps: true,
        underscored: true,
        // Sequelize will still expect a primary key 'id' by default, so ensure DB has it or configure accordingly
    });
};
