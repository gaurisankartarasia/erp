import { DataTypes } from 'sequelize';

export default (sequelize) => {
  sequelize.define('Designation', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    designation_id: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    designation_name: {
      type: DataTypes.STRING,
      allowNull: false,
         unique: true
    },
    description: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    is_delete: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  }, {
    tableName: 'erp_designations',
    timestamps: true,
    underscored: true,
  });
};
