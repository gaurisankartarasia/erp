import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "Employee",
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      emp_code: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      user_type: {
        type: DataTypes.ENUM("user", "admin", "master"),
        allowNull: true,
      },
      name: {
        type: DataTypes.STRING(200),
        allowNull: true,
      },
        email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
      mobile_no: {
        type: DataTypes.STRING(15),
        allowNull: false,
      },
      dob: {
        type: DataTypes.DATEONLY,
        allowNull: true,
      },
      doj: {
        type: DataTypes.DATEONLY,
        allowNull: true,
      },
      designation: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true,
      },
      client: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true,
      },
      guardian_contact: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      gender: {
        type: DataTypes.ENUM("male", "female", "others"),
        allowNull: true,
      },
      religion: {
        type: DataTypes.ENUM("Hindu", "Muslim", "Christian"),
        allowNull: true,
      },
      father_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      mother_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      marital_status: {
        type: DataTypes.ENUM("single", "married", "divorced", "widowed"),
        allowNull: true,
      },
      spouse_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      qualification: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      extra_qualification: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      pan_no: {
        type: DataTypes.STRING(50),
        allowNull: true,
        unique: true,
      },
      bank_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      aadhar_no: {
        type: DataTypes.STRING(20),
        allowNull: true,
        unique: true,
      },
      branch_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      esi_ip_no: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      ifsc_code: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      epf_uan_no: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      bank_ac_no: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      blood_group: {
        type: DataTypes.ENUM("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"),
        allowNull: true,
      },
      branch_id: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      permanent_address: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      present_address: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      permanent_district: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      present_district: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      permanent_state: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      present_state: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      permanent_pin_code: {
        type: DataTypes.STRING(10),
        allowNull: true,
      },
      present_pin_code: {
        type: DataTypes.STRING(10),
        allowNull: true,
      },
      gross_salary: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
      },
      dor: {
        type: DataTypes.DATEONLY,
        allowNull: true,
      },
      upload_image: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      upload_resume: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      password: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      is_delete: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      is_master: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      last_login: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      activation_token: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      activation_token_expires_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    },
    {
      tableName: "employees",
      timestamps: true,
      underscored: true,
    }
  );
};
