import { models, sequelize } from "../models/index.js";
import { Op } from "sequelize";
import { log } from "../services/LogService.js";

const Vendor = sequelize.models.Vendor;

/**
 * Helper function to generate vendor_code from id
 * e.g. id = 1 => VC001
 */
const generateVendorCode = (id) => {
  return `VC${String(id).padStart(3, "0")}`;
};

/**
 * Create a new Vendor
 */
export const createVendor = async (req, res) => {
  const {
    name,
    mobile_no,
    email_id,
    tax_type,
    gst_no,
    pan_no,
    address,
    state,
    district,
    pin_code,
    bank_name,
    branch_name,
    ifsc_code,
    bank_ac_no,
    beneficiary_name,
    remarks,
  } = req.body;

  // Validate required fields
  if (
    !name ||
    !mobile_no ||
    !email_id ||
    !tax_type ||
    !gst_no ||
    !pan_no ||
    !address ||
    !state ||
    !district ||
    !pin_code ||
    !bank_name ||
    !branch_name ||
    !ifsc_code ||
    !bank_ac_no ||
    !beneficiary_name
  ) {
    return res.status(400).json({
      message: "Please provide all required fields.",
    });
  }

  try {
    // Create vendor without vendor_code initially
    let vendor = await Vendor.create({
      name,
      mobile_no,
      email_id,
      tax_type,
      gst_no,
      pan_no,
      address,
      state,
      district,
      pin_code,
      bank_name,
      branch_name,
      ifsc_code,
      bank_ac_no,
      beneficiary_name,
      remarks,
      is_active: false, // default inactive
    });

    // Generate vendor_code based on ID and update
    const vendor_code = generateVendorCode(vendor.id);
    await vendor.update({ vendor_code });

    await log({
      req,
      action: "CREATE",
      page_name: "VENDOR FORM PAGE",
      target: `Vendor ID: ${vendor.id} Vendor Code: ${vendor.vendor_code}`,
    });

    res.status(201).json({
      message: "Vendor Created Successfully",
      data: vendor,
    });
  } catch (err) {
    console.error("Error creating vendor:", err);
    res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

/**
 * Get all Vendors with pagination, sorting and search
 */
export const getAllVendors = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = "createdAt",
      order = "DESC",
      search = "",
    } = req.query;

    const offset = (page - 1) * limit;

    const whereCondition = search
      ? {
          [Op.or]: [
            { name: { [Op.like]: `%${search}%` } },
            { email_id: { [Op.like]: `%${search}%` } },
            { vendor_code: { [Op.like]: `%${search}%` } },
          ],
        }
      : {};

    const { rows: vendors, count: totalVendors } = await Vendor.findAndCountAll({
      where: whereCondition,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, order.toUpperCase()]],
      attributes: { exclude: ["createdAt", "updatedAt"] },
    });

    res.status(200).json({
      message: "Vendors fetched successfully",
      data: vendors,
      total: totalVendors,
      page: parseInt(page),
      pages: Math.ceil(totalVendors / limit),
    });
  } catch (err) {
    console.error("Error fetching vendors:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

/**
 * Get Vendor by ID
 */
export const getVendorById = async (req, res) => {
  const { id } = req.params;

  try {
    const vendor = await Vendor.findByPk(id);

    if (!vendor) {
      return res.status(404).json({
        message: "Vendor Not Found",
      });
    }

    await log({
      req,
      action: "READ",
      page_name: "VENDOR FORM PAGE",
      target: `Vendor ID: ${vendor.id} Vendor Code: ${vendor.vendor_code}`,
    });

    res.status(200).json(vendor);
  } catch (err) {
    res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

/**
 * Update Vendor by ID
 */
export const updateVendor = async (req, res) => {
  const { id } = req.params;
  const updateFields = req.body;

  try {
    const vendor = await Vendor.findByPk(id);

    if (!vendor) {
      return res.status(404).json({
        message: "Vendor Not Found",
      });
    }

    await vendor.update(updateFields);

    await log({
      req,
      action: "UPDATE",
      page_name: "VENDOR FORM PAGE",
      target: `Vendor ID: ${vendor.id} Vendor Code: ${vendor.vendor_code}`,
    });

    res.status(200).json({
      message: "Vendor updated successfully",
      data: vendor,
    });
  } catch (err) {
    console.error("Error updating vendor:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

/**
 * Delete Vendor by ID
 */
export const deleteVendor = async (req, res) => {
  const { id } = req.params;

  try {
    const vendor = await Vendor.findByPk(id);

    if (!vendor) {
      return res.status(404).json({
        message: "Vendor Not Found",
      });
    }

    await vendor.destroy();

    await log({
      req,
      action: "DELETE",
      page_name: "VENDOR FORM PAGE",
      target: `Vendor ID: ${vendor.id} Vendor Code: ${vendor.vendor_code}`,
    });

    res.status(200).json({
      message: "Vendor deleted successfully",
    });
  } catch (err) {
    console.error("Error deleting vendor:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

/**
 * Toggle Vendor status (is_active)
 */
export const toggleVendorStatus = async (req, res) => {
  const { id } = req.params;

  try {
    const vendor = await Vendor.findByPk(id);

    if (!vendor) {
      return res.status(404).json({
        message: "Vendor Not Found",
      });
    }

    vendor.is_active = !vendor.is_active;
    await vendor.save();

    res.status(200).json({
      message: `Vendor has been ${vendor.is_active ? "activated" : "deactivated"}.`,
      data: vendor,
    });
  } catch (err) {
    console.error("Error toggling vendor status:", err);
    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};



// * `http://localhost:5000/api/vendors/add`
// * `http://localhost:5000/api/vendors/`
// * `http://localhost:5000/api/vendors/:id`
// * `http://localhost:5000/api/vendors/edit/:id`
// * `http://localhost:5000/api/vendors/delete/:id`
// * `http://localhost:5000/api/vendors/toggle-status/:id`
