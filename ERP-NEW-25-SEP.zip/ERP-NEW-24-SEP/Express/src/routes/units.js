// // import express from 'express';
// // import {
// //     getAllUnits,
// //     getUnitById,
// //     createUnit,
// //     updateUnit,
// //     deleteUnit
// // } from '../controllers/unitController.js';

// // const router = express.Router();

// // // Unit Routes
// // router.route('/')
// //     .get(getAllUnits)
// //     .post(createUnit);

// // router.route('/:id')
// //     .get(getUnitById)
// //     .put(updateUnit)
// //     .delete(deleteUnit);

// // export default router;


// import express from 'express';
// import {
//     getAllUnits,
//     getUnitById,
//     createUnit,
//     updateUnit,
//     deleteUnit
// } from '../controllers/unitController.js';

// const router = express.Router();

// // Unit Routes
// router.route('/')
//     .get(getAllUnits)
//     .post(createUnit);

// router.route('/:id')
//     .get(getUnitById)
//     .put(updateUnit)
//     .delete(deleteUnit);

// export default router;



import express from 'express';
import {
    getAllUnits,
    getUnitById,
    createUnit,
    updateUnit
} from '../controllers/unitController.js';

const router = express.Router();

// Unit Routes
router.route('/')
    .get(getAllUnits)
    .post(createUnit);

router.route('/:id')
    .get(getUnitById)
    .put(updateUnit);

export default router;