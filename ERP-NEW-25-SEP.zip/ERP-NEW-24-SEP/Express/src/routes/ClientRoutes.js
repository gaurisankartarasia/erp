import { Router } from 'express';
import {
  createClient,
  getAllClients,
  getClientById,
  updateClient,
  deleteClient,
  toggleClientStatus,
} from '../controllers/ClientController.js';

const router = Router();

// Route to get all clients and create a new client
router.route('/')
  .get(getAllClients)
  .post(createClient);
  router.patch('/:id/status', toggleClientStatus);

// Route to get, update, and delete a specific client by its ID
router.route('/:id')
  .get(getClientById)
  .put(updateClient)
  .delete(deleteClient);

export default router;