import express from "express";
import {
  editEmployee,
  getAccountById,
  getAllEmployees,
  getEmployeeById,
  registerEmployee,
  toggleEmployeeStatus,
  updateAccount,
  updateEmployee,
} from "../controllers/EmployeeController.js";
import { protect } from "../middlewares/AuthMiddleware.js";
import upload from "../middlewares/UploadMiddleware.js";

const router = express.Router();
router.use(protect);

router.get("/employees", getAllEmployees);
router.get("/employees/:id", getEmployeeById);

router.post(
  "/register",
  upload({
    field: "upload_image",
    prefix: "employee",
    uploadDir: "public/uploads/employees",
  }),
  registerEmployee
);

router.put(
  "/edit/:id",
  upload({
    field: "upload_image",
    prefix: "employee",
    resize: true,
    uploadDir: "public/uploads/employees",
  }),
  editEmployee
);

//account related croutes
router.get("/employee/account", getAccountById);
router.put(
  "/employee/account/edit",
  upload({
    field: "upload_image",
    prefix: "employee",
    resize: true,
    uploadDir: "public/uploads/employees",
  }),
  updateAccount
);

router.patch("/:id/status", toggleEmployeeStatus);

export default router;
