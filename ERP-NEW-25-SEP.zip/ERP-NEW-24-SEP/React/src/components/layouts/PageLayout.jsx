import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function PageLayout({
  title,
  rightButton,
  topButtons = [],
  addPath,
  onAdd,
  addText = "Add",
  children,
}) {
  const normalizedButtons = [
    ...topButtons,
    ...(rightButton
      ? [{ text: rightButton.text, path: rightButton.path }]
      : []),
  ];

  return (
    <div className="shadow-2xl border bg-white p-6">
      <div className="flex justify-between items-center mb-6">
        {title && <h1 className="text-xl font-semibold">{title}</h1>}

        <div className="flex gap-3">
          {addPath ? (
            <Link to={addPath}>
              <Button variant="default">
                <Plus/>
                {addText}
              </Button>
            </Link>
          ) : onAdd ? (
            <Button variant="default" onClick={onAdd}>
              <Plus className="w-4 h-4 mr-2" />
              {addText}
            </Button>
          ) : null}

          {normalizedButtons.map((btn, idx) =>
            btn.path ? (
              <Link key={idx} to={btn.path}>
                <Button>{btn.text}</Button>
              </Link>
            ) : (
              <Button key={idx} onClick={btn.onClick}>
                {btn.text}
              </Button>
            )
          )}
        </div>
      </div>

      <div>{children}</div>
    </div>
  );
}
