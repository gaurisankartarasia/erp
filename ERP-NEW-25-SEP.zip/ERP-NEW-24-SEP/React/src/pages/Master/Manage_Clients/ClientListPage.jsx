import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "../../../hooks/useServerSideTable"; // Assuming hook is in the same folder
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirm } from "@/contexts/ConfirmModalProvider"; // Using the correct confirm hook
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check } from "lucide-react";
import apiClient from "@/api/axiosConfig"; // Assuming a pre-configured axios instance

// Reusable StatusBadge component (can be moved to a common folder)
const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};


const ClientListPage = () => {
  // 1. Use the hook to fetch client data from the correct API endpoint
  const {
    data: clients,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/clients`
  );
  
  // 2. Get the confirmation function from the context
  const confirm = useConfirm();

  // 3. Handle toggling the active/inactive status for a client
  const handleToggleStatus = async (client) => {
    const ok = await confirm({
      title: "Change Client Status",
      description: `Are you sure you want to ${
        client.is_active ? "deactivate" : "activate"
      } the client "${client.clientNm}"?`,
    });

    if (!ok) return;

    try {
      // NOTE: Assumes an API endpoint exists to toggle status.
      // You might need to create this in your backend.
      await apiClient.patch(`/clients/${client.id}/status`);
      refreshData(); // Refresh the table data on success
    } catch (error) {
      console.error("Error updating client status:", error);
      // Here you would show an error modal or toast notification
    }
  };

  // 4. Define the columns for the client data table
  const clientColumns = useMemo(
    () => [
      {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "Client Name",
        accessorKey: "clientNm",
        enableSorting: true,
      },
      {
        header: "Project Name",
        accessorKey: "projNm",
        enableSorting: true,
      },
      {
        header: "Email",
        accessorKey: "email",
        enableSorting: true,
      },
      {
        header: "Mobile No.",
        accessorKey: "mob",
        enableSorting: false,
      },
      {
        header: "Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const client = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(client)}
                title={client.is_active ? "Deactivate Client" : "Activate Client"}
              >
                {client.is_active ? <X className="text-red-500" /> : <Check className="text-green-500" />}
              </Button>

              <Button asChild size="sm" variant="ghost" title="Edit Client">
                <Link to={`/clients/${client.id}/edit`}>
                  <Edit />
                </Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage, confirm] // Added confirm to dependency array
  );

  // 5. Render the final page layout and data table
  return (
    <PageLayout
      title="Client List"
      rightButton={{ text: "Add Client", path: "add" }}
    >
      <ShadcnDataTable
        // These props might be specific to your DataTable component
        Ltext="Client List"
        Rtext="Add Client"
        addPath="add"
        
        // Core props
        data={clients}
        columns={clientColumns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default ClientListPage;