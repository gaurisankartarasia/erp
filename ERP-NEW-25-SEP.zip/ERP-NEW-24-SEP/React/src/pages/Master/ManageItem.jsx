
// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";

// const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

// const ManageItem = () => {
//   const [items, setItems] = useState([]);
//   const [search, setSearch] = useState("");
//   const [showEntries, setShowEntries] = useState(10);
//   const [loading, setLoading] = useState(false);
//   const navigate = useNavigate();

//   // Fetch items from backend
//   const fetchItems = async () => {
//     setLoading(true);
//     try {
//       const res = await axios.get(`${API_BASE_URL}/items`);
//       if (res.data.success) {
//         setItems(res.data.data);
//       } else {
//         setItems([]);
//       }
//     } catch (error) {
//       setItems([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchItems();
//   }, []);

//   // Toggle item status
//   const toggleItemStatus = async (itemId, currentStatus) => {
//     try {
//       const newStatus = currentStatus === "Active" ? "Inactive" : "Active";
//       const res = await axios.put(`${API_BASE_URL}/items/${itemId}`, { status: newStatus });
//       if (res.data.success) {
//         fetchItems();
//       } else {
//         alert("Error updating status: " + res.data.message);
//       }
//     } catch (error) {
//       alert("Error updating status");
//     }
//   };

//   // Edit item function
//   const editItem = (itemId) => {
//     navigate(`/manage-item/edit/${itemId}`);
//   };

//   // Delete item function
//   const deleteItem = async (itemId) => {
//     if (window.confirm("Are you sure you want to delete this item?")) {
//       try {
//         const res = await axios.put(`${API_BASE_URL}/items/${itemId}`, { status: "delete" });
//         if (res.data.success) {
//           fetchItems();
//         } else {
//           alert("Error deleting item: " + res.data.message);
//         }
//       } catch (error) {
//         alert("Error deleting item");
//       }
//     }
//   };

//   // Filter items based on search
//   const filteredItems = items.filter((item) => {
//     if (!item) return false;
//     const searchLower = search.toLowerCase();
//     return (
//       (item.item_id && item.item_id.toLowerCase().includes(searchLower)) ||
//       (item.item_name && item.item_name.toLowerCase().includes(searchLower)) ||
//       (item.model_name && item.model_name.toLowerCase().includes(searchLower)) ||
//       (item.unit && item.unit.toLowerCase().includes(searchLower))
//     );
//   });

//   // Add new item
//   const addNewItem = () => {
//     navigate("/manage-item/add");
//   };

//   return (
//     <div style={{ padding: 20, fontFamily: "Arial, sans-serif" }}>
//       <h2>Manage Item</h2>
//       <div style={{ 
//         display: "flex", 
//         justifyContent: "space-between", 
//         marginBottom: 15, 
//         alignItems: "center" 
//       }}>
//         <div>
//           Show{" "}
//           <select 
//             value={showEntries} 
//             onChange={(e) => setShowEntries(parseInt(e.target.value))}
//             style={{ padding: 5 }}
//           >
//             <option value={10}>10</option>
//             <option value={25}>25</option>
//             <option value={50}>50</option>
//             <option value={100}>100</option>
//           </select>{" "}
//           entries
//         </div>
//         <div>
//           Search:{" "}
//           <input
//             type="text"
//             placeholder="Search"
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             style={{ padding: 5, width: 200 }}
//           />
//         </div>
//         <button
//           style={{
//             backgroundColor: "#ff5722",
//             border: "none",
//             color: "white",
//             padding: "8px 15px",
//             borderRadius: 4,
//             cursor: "pointer",
//             fontWeight: "bold"
//           }}
//           onClick={addNewItem}
//         >
//           + Add Item
//         </button>
//       </div>
//       <table style={{ 
//         width: "100%", 
//         borderCollapse: "collapse", 
//         textAlign: "left", 
//         fontSize: 14,
//         boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
//       }}>
//         <thead>
//           <tr style={{ 
//             backgroundColor: "#333", 
//             color: "white",
//             fontSize: 15
//           }}>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Sl#</th>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Item Code</th>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Item Name</th>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Model Name</th>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Unit</th>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Status</th>
//             <th style={{ padding: "12px 10px", border: "1px solid #ddd" }}>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {loading ? (
//             <tr>
//               <td colSpan={7} style={{ padding: 20, textAlign: "center" }}>Loading...</td>
//             </tr>
//           ) : filteredItems.length === 0 ? (
//             <tr>
//               <td colSpan={7} style={{ 
//                 padding: 15, 
//                 textAlign: "center",
//                 border: "1px solid #ddd"
//               }}>
//                 No entries found
//               </td>
//             </tr>
//           ) : (
//             filteredItems.slice(0, showEntries).map((item, index) => (
//               <tr key={item.item_id} style={{ 
//                 borderBottom: "1px solid #ddd",
//                 backgroundColor: index % 2 === 0 ? "#f9f9f9" : "white"
//               }}>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd",
//                   fontWeight: "bold"
//                 }}>
//                   {index + 1}
//                 </td>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd",
//                   color: "#0066cc",
//                   fontWeight: "bold"
//                 }}>
//                   {item.item_id}
//                 </td>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd" 
//                 }}>
//                   {item.item_name}
//                 </td>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd" 
//                 }}>
//                   {item.model_name}
//                 </td>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd" 
//                 }}>
//                   {item.unit}
//                 </td>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd",
//                   color: item.status === 'Active' ? "green" : "red",
//                   fontWeight: "bold"
//                 }}>
//                   {item.status}
//                 </td>
//                 <td style={{ 
//                   padding: "10px", 
//                   border: "1px solid #ddd" 
//                 }}>
//                   {item.status === "Active" ? (
//                     <button
//                       style={{
//                         backgroundColor: "transparent",
//                         border: "none",
//                         cursor: "pointer",
//                         color: "red",
//                         marginRight: 10,
//                         fontWeight: "bold",
//                         fontSize: 16,
//                       }}
//                       title="Set Inactive"
//                       onClick={() => toggleItemStatus(item.item_id, item.status)}
//                     >
//                       ✗
//                     </button>
//                   ) : (
//                     <button
//                       style={{
//                         backgroundColor: "transparent",
//                         border: "none",
//                         cursor: "pointer",
//                         color: "green",
//                         marginRight: 10,
//                         fontWeight: "bold",
//                         fontSize: 16,
//                       }}
//                       title="Set Active"
//                       onClick={() => toggleItemStatus(item.item_id, item.status)}
//                     >
//                       ✔
//                     </button>
//                   )}
//                   <button
//                     style={{
//                       backgroundColor: "transparent",
//                       border: "none",
//                       cursor: "pointer",
//                       color: "blue",
//                       fontSize: 16,
//                       marginRight: 10,
//                     }}
//                     title="Edit"
//                     onClick={() => editItem(item.item_id)}
//                   >
//                     ✎
//                   </button>
//                   <button
//                     style={{
//                       backgroundColor: "transparent",
//                       border: "none",
//                       cursor: "pointer",
//                       color: "#ff5722",
//                       fontSize: 16,
//                     }}
//                     title="Delete"
//                     onClick={() => deleteItem(item.item_id)}
//                   >
//                     🗑️
//                   </button>
//                 </td>
//               </tr>
//             ))
//           )}
//         </tbody>
//       </table>
//       <div style={{ 
//         marginTop: 10, 
//         fontSize: 14,
//         color: "#666",
//         display: "flex",
//         justifyContent: "space-between",
//         alignItems: "center"
//       }}>
//         <div>
//           Showing {Math.min(filteredItems.length, showEntries)} of {filteredItems.length} entries
//         </div>
//         <div>
//           {filteredItems.length > showEntries && (
//             <span style={{ marginLeft: 10 }}>
//               <button style={{ padding: "5px 10px", marginRight: 5 }}>Previous</button>
//               <button style={{ padding: "5px 10px" }}>Next</button>
//             </span>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ManageItem;




import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "../../hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check } from "lucide-react";
import apiClient from "@/api/axiosConfig";

const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };
  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const ManageItem = () => {
  const {
    data: items,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/items`
  );
  const confirm = useConfirmModal();
  const handleToggleStatus = async (item) => {
    const ok = await confirm({
      title: "Change Status",
      description: `Are you sure you want to ${
        item.is_active ? "deactivate" : "activate"
      } this item?`,
    });
    if (!ok) return;
    try {
      await apiClient.put(`/items/${item.item_id}`, {
        status: item.is_active ? "Inactive" : "Active",
      });
      refreshData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const itemColumns = useMemo(
    () => [
      {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "Item Code",
        accessorKey: "item_id",
        enableSorting: true,
      },
      {
        header: "Item Name",
        accessorKey: "item_name",
        enableSorting: true,
      },
      {
        header: "Model Name",
        accessorKey: "model_name",
        enableSorting: true,
      },
      {
        header: "Unit",
        accessorKey: "unit",
        enableSorting: true,
      },
      {
        header: "Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const item = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(item)}
              >
                {item.is_active ? <X className="text-red-500" /> : <Check className="text-green-500" />}
              </Button>
              <Button asChild size="sm" variant="ghost">
                <Link to={`/manage-item/edit/${item.id}`}><Edit /></Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage]
  );

  return (
    <PageLayout
      title="Item List"
      rightButton={{ text: "Add Item", path: "add" }}
    >
      <ShadcnDataTable
        Ltext="Item List"
        Rtext="Add Item"
        addPath="add"
        data={items}
        columns={itemColumns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default ManageItem;