

import React, { useEffect, useCallback, useState, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, FormProvider } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import FormSelect from "@/components/common/forms/FormSelect";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const SectionHeader = ({ title }) => (
  <div className="col-span-4 mt-4 border-b pb-2">
    <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
  </div>
);

const AddressFields = ({ type, stateOptions, districtOptions, isDisabled }) => (
  <>
    <SectionHeader title={`${type.charAt(0).toUpperCase() + type.slice(1)} Address`} />
    <FormInput name={`${type}_address`} label="Address" rules={{ required: "Address is required" }} disabled={isDisabled} />
    <FormInput name={`${type}_pin_code`} label="Pincode" rules={{ required: "Pincode is required" }} disabled={isDisabled} />
    <FormSelect name={`${type}_state`} label="State" options={stateOptions} disabled={isDisabled} rules={{ required: "State is required" }} />
    <FormSelect name={`${type}_district`} label="District" options={districtOptions} disabled={isDisabled} placeholder={!isDisabled ? "Select a state first" : undefined} rules={{ required: "District is required" }} />
  </>
);

const EmployeeFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      user_type: "", name: "", email: "", mobile_no: "", dob: "", doj: "",
      designation: "", client: "", guardian_contact: "", gender: "", religion: "",
      father_name: "", mother_name: "", marital_status: "", spouse_name: "",
      qualification: "", extra_qualification: "", pan_no: "", bank_name: "",
      aadhar_no: "", branch_name: "", branch_id: "", esi_ip_no: "", ifsc_code: "",
      epf_uan_no: "", bank_ac_no: "", blood_group: "", gross_salary: "", dor: "",
      upload_image: null, upload_resume: null, present_address: "", present_district: "",
      present_state: "", present_pin_code: "", permanent_address: "",
      permanent_district: "", permanent_state: "", permanent_pin_code: "",
    },
  });

  const { handleSubmit, reset,  watch, setValue, getValues } = methods;

  const [options, setOptions] = useState({ designations: [], clients: [], states: [] });
  const [districts, setDistricts] = useState({ present: [], permanent: [] });
  const [isSameAddress, setIsSameAddress] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);
  const renderCount = useRef(0);
   renderCount.current = renderCount.current + 1;
   console.log(`Input component has rerendered ${renderCount.current} times.`);

  const presentStateId = watch("present_state");
  const permanentStateId = watch("permanent_state");
  const maritalStatus = watch("marital_status");

  const formatOptionsForSelect = (data, valueKey, labelKey) => {
    if (!Array.isArray(data)) return [];
    return data
      .filter((item) => item && item[valueKey] != null)
      .map((item) => ({ value: String(item[valueKey]), label: item[labelKey] }));
  };

  const fetchData = useCallback(async (endpoint, valueKey, labelKey) => {
    try {
      const response = await apiClient.get(endpoint);
      return formatOptionsForSelect(response.data.data, valueKey, labelKey);
    } catch {
      message.error(`Failed to fetch options from ${endpoint}`);
      return [];
    }
  }, [message]);

  const fetchDistricts = useCallback(async (stateId) => {
    if (!stateId) return [];
    return await fetchData(`/locations/states/${stateId}/districts`, "id", "district_name");
  }, [fetchData]);

  useEffect(() => {
    const fetchInitialOptions = async () => {
      const [designations, clients, states] = await Promise.all([
        fetchData("master/designations", "id", "designation_name"),
        fetchData("master/clients", "id", "projNm"),
        fetchData("/locations/states", "id", "state_name"),
      ]);
      setOptions({ designations, clients, states });
    };
    fetchInitialOptions();
  }, [fetchData]);

  useEffect(() => {
    if (id) {
      const fetchEmployee = async () => {
        setIsLoading(true);
        try {
          const res = await apiClient.get(`/employee/employees/${id}`);
          reset(res.data);
        } catch (e) {
          message.error("Something went wrong.");
        } finally {
          setIsLoading(false);
        }
      };
      fetchEmployee();
    }
  }, [id, reset, message]);

  useEffect(() => {
    if (presentStateId) {
      fetchDistricts(presentStateId).then((d) => setDistricts((prev) => ({ ...prev, present: d })));
    }
  }, [presentStateId, fetchDistricts]);

  useEffect(() => {
    if (permanentStateId && !isSameAddress) {
      fetchDistricts(permanentStateId).then((d) => setDistricts((prev) => ({ ...prev, permanent: d })));
    }
  }, [permanentStateId, isSameAddress, fetchDistricts]);

  useEffect(() => {
    if (isSameAddress) {
      const presentValues = getValues(["present_address", "present_pin_code", "present_state", "present_district"]);
      setValue("permanent_address", presentValues[0]);
      setValue("permanent_pin_code", presentValues[1]);
      setValue("permanent_state", presentValues[2]);
      setValue("permanent_district", presentValues[3]);
      setDistricts(prev => ({ ...prev, permanent: prev.present }));
    }
  }, [isSameAddress, presentStateId, getValues, setValue]);

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    const payload = new FormData();
    Object.keys(data).forEach((key) => {
      if (data[key] !== null && data[key] !== undefined) {
        payload.append(key, data[key]);
      }
    });

    try {
      if (id) {
        await apiClient.put(`/employee/edit/${id}`, payload);
        message.success("Employee updated successfully.");
      } else {
        const res = await apiClient.post("/employee/register", payload);
        message.success("Employee registered successfully.");
        if (res.data.generatedPassword) {
          message.info(`Generated Password: ${res.data.generatedPassword}`);
        }
      }
      navigate("/employees");
    } catch (err) {
      message.error(err.response?.data?.message || "An unexpected error occurred.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectOptions = {
    user_type: [{ value: "user", label: "User" }, { value: "admin", label: "Admin" }, { value: "master", label: "Master" }],
    gender: [{ value: "male", label: "Male" }, { value: "female", label: "Female" }, { value: "others", label: "Others" }],
    religion: [{ value: "Hindu", label: "Hindu" }, { value: "Muslim", label: "Muslim" }, { value: "Christian", label: "Christian" }],
    marital_status: [{ value: "single", label: "Single" }, { value: "married", label: "Married" }, { value: "divorced", label: "Divorced" }, { value: "widowed", label: "Widowed" }],
    blood_group: ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map((bg) => ({ value: bg, label: bg })),
  };

  return (
    <FormProvider {...methods}>
      <FormLayout
        title={id ? "Edit Employee" : "Register Employee"}
        backPath="/employees"
        onSubmit={handleSubmit(onSubmit)}
        isSubmitting={isSubmitting}
        submitText={id ? "Update" : "Submit"}
        onCancel={() => navigate("/employees")}
        onReset={() => reset()}
        isLoading={isLoading}
      >
        <div className="col-span-2">
          <div className="grid grid-cols-4 gap-6">
            <FormSelect name="user_type" label="User Type" options={selectOptions.user_type} rules={{ required: "User type is required" }} />
            <FormInput name="name" label="Name" rules={{ required: "Name is required" }} />
            <FormInput name="mobile_no" label="Mobile No" maxLength={10} rules={{ required: "Mobile No is required", minLength: 10, maxLength: 10 }} />
            <FormInput name="dob" label="DOB" type="date" rules={{ required: "Date of Birth is required" }} />
            <FormInput name="doj" label="DOJ" type="date" rules={{ required: "Date of Joining is required" }} />
            <FormSelect name="designation" label="Designation" options={options.designations} rules={{ required: "Designation is required" }} />
            <FormSelect name="client" label="Client Location" options={options.clients} rules={{ required: "Client Location is required" }} />
            <FormInput name="email" label="Email Id" rules={{ required: "Email is required", pattern: { value: /^\S+@\S+$/i, message: "Invalid email address" } }} />
            <FormInput name="father_name" label="Father's Name" rules={{ required: "Father's Name is required" }} />
            <FormInput name="mother_name" label="Mother's Name" />
            <FormInput name="guardian_contact" label="Guardian Contact" rules={{ required: "Guardian Contact is required" }} />
            <FormSelect name="gender" label="Gender" options={selectOptions.gender} rules={{ required: "Gender is required" }} />
            <FormSelect name="religion" label="Religion" options={selectOptions.religion} />
            <FormSelect name="marital_status" label="Marital Status" options={selectOptions.marital_status} rules={{ required: "Marital Status is required" }} />
            {maritalStatus === "married" && <FormInput name="spouse_name" label="Spouse's Name" rules={{ required: "Spouse's name is required" }} />}
            <FormSelect name="blood_group" label="Blood Group" options={selectOptions.blood_group} />
            <FormInput name="qualification" label="Qualification" />
            <FormInput name="extra_qualification" label="Extra Qualification" />
            <FormInput name="pan_no" label="PAN Number" rules={{ required: "PAN is required" }} />
            <FormInput name="aadhar_no" label="Aadhar Number" rules={{ required: "Aadhar is required" }} />
            <FormInput name="epf_uan_no" label="EPF UAN Number" />
            <FormInput name="esi_ip_no" label="ESI IP Number" />
            <FormInput name="bank_name" label="Bank Name" rules={{ required: "Bank name is required" }} />
            <FormInput name="bank_ac_no" label="Bank Account Number" rules={{ required: "Account no. is required" }} />
            <FormInput name="branch_name" label="Branch Name" rules={{ required: "Branch name is required" }} />
            <FormInput name="ifsc_code" label="IFSC Code" rules={{ required: "IFSC code is required" }} />
            <FormInput name="branch_id" label="Branch Id" rules={{ required: "Branch Id is required" }} />
            <AddressFields type="present" stateOptions={options.states} districtOptions={districts.present} />
            <div className="col-span-4 flex items-center gap-2">
              <input type="checkbox" id="sameAddress" checked={isSameAddress} onChange={(e) => setIsSameAddress(e.target.checked)} className="h-4 w-4 rounded" />
              <label htmlFor="sameAddress" className="text-sm font-medium">Permanent Address is same as Present Address</label>
            </div>
            <AddressFields type="permanent" stateOptions={options.states} districtOptions={isSameAddress ? districts.present : districts.permanent} isDisabled={isSameAddress} />
            <FormInput name="gross_salary" label="Gross Salary" type="number" />
            <FormInput name="dor" label="Date of Resignation" type="date" />
            <FormInput name="upload_image" label="Upload Image" type="file" accept="image/*" />
            <FormInput name="upload_resume" label="Upload Resume" type="file" accept=".pdf,.doc,.docx" />
          </div>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default EmployeeFormPage;
