import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "BankGuarantee",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      work_order_id: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: false,
        references: {
          model: "mtpl_work_orders",
          key: "id",
        },
      },
      bg_no: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      bg_date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      bg_validity: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      bg_amount: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
      },
      document: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      tableName: "mtpl_bank_guarantees",
      timestamps: true,
      underscored: true,
    }
  );
};
