import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "Invoice",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
      },
      bill_no: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      date: {
        type: DataTypes.STRING(200),
        allowNull: true,
      },
      client_name: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true,
      },
      client_code: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      subject: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      reference: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      gst: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: false,
        defaultValue: 0,
      },
      cgst: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: false,
        defaultValue: 0,
      },
      sgst: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: false,
        defaultValue: 0,
      },
      igst: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: false,
        defaultValue: 0,
      },
      total: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      grand_total: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: false,
      },
      is_active: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 1,
      },
      is_delete: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 0,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    },
    {
      tableName: "mtpl_invoices",
      timestamps: false,
    }
  );
};
