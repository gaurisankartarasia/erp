import { models } from '../models/index.js';
import { Op } from 'sequelize';

const {Contribution} = models

const generateNextContId = async () => {
  const lastContribution = await Contribution.findOne({
    order: [['id', 'DESC']],
  });

  if (!lastContribution) {
    return 'EE001';
  }

  const numericPart = parseInt(lastContribution.cont_id.substring(4), 10);
  const nextNumericPart = numericPart + 1;
  return `EE${String(nextNumericPart).padStart(3, '0')}`;
};

export const addContribution = async (req, res) => {
  try {
    const {
      epf_employee_share,
      epf_employer_share,
      esi_employee_share,
      esi_employer_share,
    } = req.body;

    const cont_id = await generateNextContId();

    const newContribution = await Contribution.create({
      cont_id,
      epf_employee_share,
      epf_employer_share,
      esi_employee_share,
      esi_employer_share,
      date :  new Date()
    });

    res.status(201).json({
      message: 'Contribution added successfully.',
      contribution: newContribution,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error adding contribution.' });
  }
};

export const editContribution = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      epf_employee_share,
      epf_employer_share,
      esi_employee_share,
      esi_employer_share,
    } = req.body;

    const contribution = await Contribution.findByPk(id);

    if (!contribution) {
      return res.status(404).json({ message: 'Contribution not found.' });
    }

    await contribution.update({
      epf_employee_share,
      epf_employer_share,
      esi_employee_share,
      esi_employer_share,
      date :  new Date(),
    });

    res.status(200).json({
      message: 'Contribution updated successfully.',
      contribution,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating contribution.' });
  }
};

export const getAllContributions = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = '',
      sort = 'createdAt',
      order = 'desc',
    } = req.query;

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const whereClause = {
      is_delete: false,
      [Op.or]: [
        { cont_id: { [Op.like]: `%${search}%` } },
        { date: { [Op.like]: `%${search}%` } },
        { epf_employee_share: { [Op.like]: `%${search}%` } },
        { epf_employer_share: { [Op.like]: `%${search}%` } },
        { esi_employee_share: { [Op.like]: `%${search}%` } },
        { esi_employer_share: { [Op.like]: `%${search}%` } },
      ],
    };

    const { count, rows } = await Contribution.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit, 10),
      offset,
      order: [[sort, order.toUpperCase()]],
    });

    res.status(200).json({
      data: rows,
      total: count,
    });
  } catch (error) {
    console.error("Error fetching contributions:", error);
    res.status(500).json({ message: "Failed to fetch contributions" });
  }
};

export const getContributionById = async (req, res) => {
  try {
    const { id } = req.params;
    const contribution = await Contribution.findByPk(id);
    if (!contribution) {
      return res.status(404).json({ message: 'Contribution not found.' });
    }
    res.status(200).json(contribution);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching contribution data.' });
  }
};

export const updateContributionStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { is_active } = req.body;

    if (typeof is_active !== 'boolean') {
      return res.status(400).json({ message: 'Invalid status value provided.' });
    }

    const contribution = await Contribution.findByPk(id);

    if (!contribution) {
      return res.status(404).json({ message: 'Contribution not found.' });
    }

    await contribution.update({ is_active });

    res.status(200).json({ message: 'Contribution status updated successfully.' });
  } catch (error) {
    console.error('Error updating contribution status:', error);
    res.status(500).json({ message: 'Failed to update contribution status.' });
  }
};