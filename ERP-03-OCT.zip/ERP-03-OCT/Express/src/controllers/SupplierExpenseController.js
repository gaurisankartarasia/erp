import { sequelize } from "../models/index.js";
import { Op } from "sequelize";

const { Vendor, SupplierExpense, Expense } = sequelize.models;

export const getAllSupplierExpenses = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      sort = "createdAt",
      order = "desc",
    } = req.query;

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const whereClause = {
      is_delete: false,
      payer_type: "supplier",
      [Op.or]: [
        { invoice_no: { [Op.like]: `%${search}%` } },
        { matter: { [Op.like]: `%${search}%` } },
      ],
    };

    const { count, rows } = await Expense.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit, 10),
      offset,
      order: [[sort, order.toUpperCase()]],
      include: [
        {
          model: Vendor,
          as: "supplier",
          attributes: ["name"],
          required: false,
        },
      ],
    });

    res.status(200).json({
      data: rows,
      total: count,
    });
  } catch (error) {
    console.error("Error fetching supplier expenses:", error);
    res
      .status(500)
      .json({
        message: "Failed to fetch supplier expenses",
        error: error.message,
      });
  }
};

export const getAllSuppliers = async (req, res) => {
  try {
    const suppliers = await Vendor.findAll({
      where: { is_active: true },
      attributes: [
        ["id", "id"],
        ["name", "name"],
      ],
      order: [["id", "ASC"]],
    });
    res.status(200).json({ data: suppliers });
  } catch (error) {
    console.error("Error fetching vendors:", error);
    res.status(500).json({ message: "Failed to fetch vendors" });
  }
};

export const getSupplierExpenseById = async (req, res) => {
  const { id } = req.params;

  try {
    const supplier_expenses = await Expense.findByPk(id);

    if (!supplier_expenses) {
      return res.status(400).json({
        message: "Not Found",
      });
    }

    res.status(200).json(supplier_expenses);
  } catch (err) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: err.message,
    });
  }
};

export const addSupplierExpense = async (req, res) => {
  try {
    const data = { ...req.body };
    data.payer_type = "supplier";
    data.payer_id = data.payer_id;

    if (req.file) {
      data.document = req.file.path;
    }

    const newExpense = await Expense.create(data);

    res.status(201).json({
      message: "Vendor expense added successfully.",
      expense: newExpense,
    });
  } catch (error) {
    console.error("Add Expense Error:", error);
    res
      .status(500)
      .json({ message: "Failed to add expense", error: error.message });
  }
};

/**
 * @description Edit an existing vendor expense record
 */
export const editSupplierExpense = async (req, res) => {
  const { id } = req.params;
  try {
    const expense = await Expense.findByPk(id);
    if (!expense) {
      return res.status(404).json({ message: "Expense record not found." });
    }

    const data = { ...req.body };
    data.payer_id = data.payer_id;

    if (typeof data.document !== "string") {
      delete data.document;
    }

    if (req.file) {
      data.document = req.file.path;
    }

    await expense.update(data);

    res.status(200).json({
      message: "Vendor expense updated successfully.",
      expense,
    });
  } catch (error) {
    console.error("Update Expense Error:", error);
    res
      .status(500)
      .json({ message: "Failed to update expense", error: error.message });
  }
};
