import { Router } from "express";
import {
  getPayers,
  searchExpenses,
  verifyExpenses,
} from "../controllers/ExpensesVerificationController.js";

const router = Router();

router.get("/payers", getPayers);

router.get("/search", searchExpenses);

router.patch("/verify", verifyExpenses);

export default router;
