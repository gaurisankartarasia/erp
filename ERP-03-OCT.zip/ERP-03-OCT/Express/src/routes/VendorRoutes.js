import express from "express";
import {
  createVendor,
  deleteVendor,
  getAllVendors,
  getVendorById,
  toggleVendorStatus,
  updateVendor,
} from "../controllers/VendorController.js";

const router = express.Router();

// Create a new vendor
router.post("/add", createVendor);

// Get all vendors with pagination, search, sorting
router.get("/", getAllVendors);

// Get vendor by ID
router.get("/:id", getVendorById);

// Update vendor by ID
router.put("/edit/:id", updateVendor);

// Delete vendor by ID
router.delete("/delete/:id", deleteVendor);

// Toggle vendor is_active status by ID
router.patch("/toggle-status/:id", toggleVendorStatus);

export default router;
