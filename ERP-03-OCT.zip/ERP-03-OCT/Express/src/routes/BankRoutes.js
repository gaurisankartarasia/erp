import { Router } from 'express';
import { body } from 'express-validator';
import {
  getAllBGsForWorkOrder,
  createBG,
  deleteBG,
} from "../controllers/BankController.js"
import upload from "../middlewares/UploadMiddleware.js"
import { protect } from "../middlewares/AuthMiddleware.js"; // Assuming you have this

const router = Router();

// Configure upload middleware for Bank Guarantees
const bgUploadOptions = {
  field: 'document',
  uploadDir: 'public/uploads/bank-guarantees',
  allowedTypes: ['application/pdf', 'image/jpeg', 'image/jpg'],
  prefix: 'bg-doc',
  resize: false, 
};

const isDDMMYYYY = (value) => {
  if (!value) return false;
  const regex = /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-\d{4}$/;
  if (!regex.test(value)) {
    throw new Error('Date must be in DD-MM-YYYY format.');
  }
  return true;
};

const validationRules = [
  body('work_order_id').isInt({ min: 1 }).withMessage('A valid Work Order ID is required.'),
  body('bg_no').trim().notEmpty().withMessage('BG No is required.'),
  // Use the custom validator for date fields
  body('bg_date').custom(isDDMMYYYY),
  body('bg_validity').custom(isDDMMYYYY),
  body('bg_amount').isDecimal().withMessage('A valid BG Amount is required.'),
];
// Apply auth middleware to all routes
router.use(protect);




router.get('/work-order/:workOrderId', getAllBGsForWorkOrder);


router.post('/', ...upload(bgUploadOptions), validationRules, createBG);

router.delete('/:id', deleteBG);

export default router;