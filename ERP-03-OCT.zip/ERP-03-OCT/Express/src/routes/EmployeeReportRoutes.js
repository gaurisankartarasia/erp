import { Router } from 'express';
import { getEmployeesByClientPaginated, exportEmployeesByClient } from '../controllers/EmployeeReportController.js';

const router = Router();

router.get('/by-client', getEmployeesByClientPaginated);
router.get('/by-client/export', exportEmployeesByClient);

export default router;