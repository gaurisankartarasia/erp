import express from "express";
import { getAllTaxes, addTax, updateTax, deleteTax, getTaxById } from "../controllers/TaxController.js";

const router = express.Router();

router.get("/", getAllTaxes);
router.get("/:id", getTaxById);
router.post("/", addTax);
router.put("/:id", updateTax);
router.delete("/:id", deleteTax);

export default router;
