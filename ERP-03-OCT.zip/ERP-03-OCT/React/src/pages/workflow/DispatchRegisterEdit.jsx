import FormLayout from '@/components/layouts/FormLayout';
import FormInput from '@/components/common/forms/FormInput';
import apiClient from '@/api/axiosConfig';
import { toast } from 'sonner';
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditDispatchForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [formData, setFormData] = useState({
    date: '',
    sendTo: '',
    subject: '',
    softCopy: null,
  });
  const [letterNo, setLetterNo] = useState('');
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [existingFile, setExistingFile] = useState(null);

  // Store initial data for reset
  const [initialData, setInitialData] = useState(null);

  // Fetch dispatch data by id
  useEffect(() => {
    const fetchDispatch = async () => {
      try {
        const res = await apiClient.get(`/dispatches/${id}`);
        if (res.data) {
          const data = {
            date: res.data.date || '',
            sendTo: res.data.sendTo || '',
            subject: res.data.subject || '',
            softCopy: null,
          };
          setFormData(data);
          setInitialData(data); // Save for reset
          setLetterNo(res.data.letterNo || '');
          setExistingFile(res.data.softCopy || null);
        }
      } catch {
        toast.error('Failed to fetch dispatch data');
        navigate('/workflow/dispatch-register');
      }
    };
    fetchDispatch();
  }, [id, navigate]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'softCopy') {
      setFormData((prev) => ({ ...prev, [name]: files[0] }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const validateForm = () => {
  const newErrors = {};
  if (!formData.date) newErrors.date = 'Date is required.';
  if (!formData.sendTo.trim()) newErrors.sendTo = 'Send To is required.';
  if (!formData.subject.trim()) newErrors.subject = 'Subject is required.';
  // Only require softCopy if neither a new file nor an existing file is present
  if (!formData.softCopy && !existingFile) newErrors.softCopy = 'Soft copy file is required.';
  setErrors(newErrors);
  return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    if (e && typeof e.preventDefault === 'function') {
      e.preventDefault();
    }
    if (!validateForm()) return;
    setIsSubmitting(true);
    try {
      const submitData = new FormData();
      submitData.append('date', formData.date);
      submitData.append('sendTo', formData.sendTo);
      submitData.append('subject', formData.subject);
      if (formData.softCopy) submitData.append('softCopy', formData.softCopy);
      const res = await apiClient.put(`/dispatches/${id}`, submitData);
      if (res.data && res.data.id) {
        toast.success('Dispatch updated successfully!');
        navigate('/workflow/dispatch-register');
      } else {
        toast.error(res.data?.error || 'Failed to update dispatch');
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Something went wrong');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate('/workflow/dispatch-register');
  };

  // Reset handler for Edit page
  const handleReset = () => {
    if (initialData) {
      setFormData({ ...initialData });
      setErrors({});
    }
  };

  return (
    <FormLayout
      title="Edit Dispatch"
      backPath="/workflow/dispatch-register"
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText="Update"
      showCancel={true}
      onCancel={handleCancel}
      onReset={handleReset}
    >
      <FormInput
        name="letterNo"
        label="Letter No"
        value={letterNo}
        readOnly
      />
      <FormInput
        name="date"
        label="Date"
        type="date"
        value={formData.date}
        onChange={handleChange}
        required
        error={errors.date}
      />
      <FormInput
        name="sendTo"
        label="Send To"
        value={formData.sendTo}
        onChange={handleChange}
        required
        error={errors.sendTo}
      />
      <FormInput
        name="subject"
        label="Subject"
        value={formData.subject}
        onChange={handleChange}
        required
        error={errors.subject}
      />
      <div className="form-group mt-4">
        <label htmlFor="softCopy" className="block font-medium mb-1">
          Soft Copy
          <span className="text-red-500 text-xs ml-2">
            Only accept pdf, doc, docx, jpg, jpeg, png docs format, max size= 2048 kb
          </span>
        </label>
        <input
          type="file"
          name="softCopy"
          id="softCopy"
          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
          onChange={handleChange}
          className={`border rounded px-2 py-1 w-full ${errors.softCopy ? 'border-red-500' : ''}`}
        />
        {errors.softCopy && (
          <p className="text-red-500 text-sm mt-1">{errors.softCopy}</p>
        )}
        {existingFile && (
          <div className="mt-2">
            <a
              href={`${import.meta.env.VITE_API_BASE_URL.replace(/\/api$/, '')}/uploads/dispatches/${existingFile}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 underline text-sm"
            >
              View Existing File
            </a>
          </div>
        )}
      </div>
    </FormLayout>
  );
};

export default EditDispatchForm;
