import React from 'react'

const InvoiceListPage = () => {
  return (
    <div>
      <h1>InvoiceListPage</h1>
    </div>
  )
}

export default InvoiceListPage
