import React, { useState, useEffect, useMemo } from "react";
import PageLayout from "../../components/layouts/PageLayout";
import FormInput from "../../components/common/forms/FormInput";
import FormSelect from "../../components/common/forms/FormSelect";
import ShadcnDataTable from "@/components/common/DataTable";

const BASE_URL = "http://localhost:5000/api/tax_entry";

export default function TaxEntryPage() {
  const months = [
    { value: "1", label: "January" },
    { value: "2", label: "February" },
    { value: "3", label: "March" },
    { value: "4", label: "April" },
    { value: "5", label: "May" },
    { value: "6", label: "June" },
    { value: "7", label: "July" },
    { value: "8", label: "August" },
    { value: "9", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" },
  ];

  const years = [
    { value: "2024", label: "2024" },
    { value: "2025", label: "2025" },
  ];

  const [formData, setFormData] = useState({
    
    month: "",
    year: "",
    date: "",
    epf: "",
    esi: "",
    gst: "",
    tds: "",
  });

  const [errors, setErrors] = useState({});
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalItems, setTotalItems] = useState(0);

  // Pagination & sorting
  const [currentPage, setCurrentPage] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [sortBy, setSortBy] = useState("id");
  const [sortOrder, setSortOrder] = useState("asc");
  const [searchTerm, setSearchTerm] = useState("");

  const fetchData = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        page: currentPage,
        limit: entriesPerPage,
        sortBy,
        sortOrder,
        search: searchTerm,
      });
      const res = await fetch(`${BASE_URL}?${query.toString()}`);
      const json = await res.json();
      setData(json.data || json);
      setTotalItems(json.total || (json.data ? json.data.length : 0));
    } catch (err) {
      console.error("Failed to fetch tax entries:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentPage, entriesPerPage, sortBy, sortOrder, searchTerm]);

  // Validation function
  const validateForm = () => {
    let newErrors = {};

    if (!formData.month) newErrors.month = "Month is required";
    if (!formData.year) newErrors.year = "Year is required";
    if (!formData.date) newErrors.date = "Date is required";

    ["epf", "esi", "gst", "tds"].forEach((field) => {
      if (formData[field] === "") {
        newErrors[field] = `${field.toUpperCase()} is required`;
      } else if (isNaN(formData[field]) || Number(formData[field]) < 0) {
        newErrors[field] = `${field.toUpperCase()} must be a positive number`;
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      const payload = {
        
        month: formData.month,
        year: formData.year,
        date: formData.date,
        epf: Number(formData.epf),
        esi: Number(formData.esi),
        gst: Number(formData.gst),
        tds: Number(formData.tds),
      };
      await fetch(BASE_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      setFormData({taxid:"", month: "", year: "", date: "", epf: "", esi: "", gst: "", tds: "" });
      setErrors({});
      fetchData();
    } catch (err) {
      console.error("Error submitting form:", err);
      alert("Failed to submit tax entry");
    }
  };

  const handleReset = () => {
    setFormData({ month: "", year: "", date: "", epf: "", esi: "", gst: "", tds: "" });
    setErrors({});
  };

  // ✅ Enable sorting for all fields except Sl. No.
  const columns = useMemo(
    () => [
      {
        id: "slNo",
        header: "Sl. No.",
        cell: ({ row }) => (currentPage - 1) * entriesPerPage + row.index + 1,
        enableSorting: false, // no sorting for serial number
      },
       { accessorKey: "taxId", header: "Tax ID", enableSorting: true }, // ✅ use taxId
    { accessorKey: "month", header: "Month", enableSorting: true },
    { accessorKey: "year", header: "Year", enableSorting: true },
    { accessorKey: "date", header: "Date", enableSorting: true },
    { accessorKey: "epf", header: "EPF", enableSorting: true },
    { accessorKey: "esi", header: "ESI", enableSorting: true },
    { accessorKey: "gst", header: "GST", enableSorting: true },
    { accessorKey: "tds", header: "TDS", enableSorting: true },
  ],
  [currentPage, entriesPerPage]
);

  const tableState = {
    loading,
    totalItems,
    currentPage,
    setCurrentPage,
    entriesPerPage,
    setEntriesPerPage,
    searchTerm,
    setSearchTerm,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
  };

  return (
    <PageLayout title="Tax Entry">
      <div className="bg-white p-4 shadow rounded-md mb-10">
        <h2 className="text-lg font-bold mb-4">Tax Entry</h2>
        <form onSubmit={handleSubmit} onReset={handleReset} className="grid grid-cols-6 gap-4">
          <div className="col-span-2">
            <FormSelect
              name="month"
              label="Month"
              placeholder="--Select Month--"
              value={formData.month}
              options={months}
              onValueChange={(val) => setFormData({ ...formData, month: val })}
              required
            />
            {errors.month && <p className="text-red-500 text-sm">{errors.month}</p>}
          </div>

          <div className="col-span-2">
            <FormSelect
              name="year"
              label="Year"
              placeholder="--Select Year--"
              value={formData.year}
              options={years}
              onValueChange={(val) => setFormData({ ...formData, year: val })}
              required
            />
            {errors.year && <p className="text-red-500 text-sm">{errors.year}</p>}
          </div>

          <div className="col-span-2">
            <FormInput
              name="date"
              label="Date Of Entry"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              required
            />
            {errors.date && <p className="text-red-500 text-sm">{errors.date}</p>}
          </div>

          {["epf", "esi", "gst", "tds"].map((field) => (
            <div key={field}>
              <FormInput
                name={field}
                label={field.toUpperCase()}
                type="number"
                value={formData[field]}
                onChange={(e) => setFormData({ ...formData, [field]: e.target.value })}
                required
              />
              {errors[field] && <p className="text-red-500 text-sm">{errors[field]}</p>}
            </div>
          ))}

          <div className="col-span-6 flex gap-2 mt-2">
            <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">Submit</button>
            <button type="reset" className="bg-gray-500 text-white px-4 py-2 rounded">Reset</button>
          </div>
        </form>
      </div>

      <ShadcnDataTable columns={columns} data={data} tableState={tableState} />
    </PageLayout>
  );
}
