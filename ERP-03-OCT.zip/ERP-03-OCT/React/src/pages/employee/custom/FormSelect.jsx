

import React, { useState, useMemo } from "react";
import { useFormContext, Controller } from "react-hook-form";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const FormSelect = ({
  name,
  label,
  placeholder = "--Select an option--",
  options,
  required = false,
  showSearch = false,
  ...props
}) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();
  const error = errors[name]?.message 

  const [search, setSearch] = useState("");
  const filteredOptions = useMemo(
    () =>
      options.filter((opt) =>
        opt.label.toLowerCase().includes(search.toLowerCase())
      ),
    [search, options]
  );

  return (
    <div className="grid gap-2">
      <Label htmlFor={name}>
        {label}
        {required && <span className="text-destructive">*</span>}
      </Label>

      <Controller
        name={name}
        control={control}
        rules={props.rules}
        render={({ field }) => (
          <Select value={field.value} onValueChange={field.onChange}>
            <SelectTrigger
              className={cn(error && "border-destructive")}
              id={name}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {showSearch && (
                <div className="p-2">
                  <Input
                    placeholder="Search..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="mb-2"
                  />
                </div>
              )}

{filteredOptions.map((option) => (
  <SelectItem key={option.value} value={String(option.value)}>
    {option.label}
  </SelectItem>
))}
              {filteredOptions.length === 0 && (
                <div className="px-2 py-1 text-sm text-muted-foreground">
                  No results found
                </div>
              )}
            </SelectContent>
          </Select>
        )}
      />

    </div>
  );
};

export default React.memo(FormSelect);







// --------------- native select 



// import React from "react";
// import { useFormContext } from "react-hook-form";
// import { Label } from "@/components/ui/label";
// import { cn } from "@/lib/utils";

// const FormSelect = ({
//   name,
//   label,
//   placeholder = "--Select an option--",
//   options = [],
//   required = false,
//   ...props
// }) => {
//   const {
//     register,
//     formState: { errors },
//   } = useFormContext();

//   const error = errors[name]?.message;

//   return (
//     <div className="grid gap-2">
//       <Label htmlFor={name}>
//         {label}
//         {required && <span className="text-destructive">*</span>}
//       </Label>

//       <select
//         id={name}
//         {...register(name, props.rules)}
//         className={cn(
//           "border bg-input rounded px-2 py-1 w-full",
//           error && "border-destructive"
//         )}
//         defaultValue=""
//       >
//         <option value="" disabled>
//           {placeholder}
//         </option>
//         {options.map((option) => (
//           <option key={option.value} value={String(option.value)}>
//             {option.label}
//           </option>
//         ))}
//       </select>

//       {/* {error && <p className="text-sm text-destructive">{error}</p>} */}
//     </div>
//   );
// };

// export default React.memo(FormSelect);

