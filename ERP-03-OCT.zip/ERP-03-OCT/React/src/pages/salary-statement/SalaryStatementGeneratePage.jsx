import React, { useState, useEffect, useMemo } from "react";
import {
  useForm,
  FormProvider,
  useFieldArray,
  useWatch,
  useFormContext,
} from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import FormInput from "@/pages/employee/custom/FormInput";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const SalaryStatementRow = ({ index, control, workingDays }) => {
  const { setValue } = useFormContext();

  const [grossSalary, absentDay, otherAllowance, tds, contributionRates] =
    useWatch({
      control,
      name: [
        `employees.${index}.Gross_Salary`,
        `employees.${index}.Absent_Day`,
        `employees.${index}.other_allowence`,
        `employees.${index}.Tds`,
        `employees.${index}.contributionRates`,
      ],
    });

  const [net_amt, EPF_Employee_Share, EPF_Employer_Share,  ESI_Employee_Share, ESI_Employer_Share, paid_amt] = useWatch({
    control,
    name: [
      `employees.${index}.net_amt`,
      `employees.${index}.EPF_Employee_Share`,
       `employees.${index}.EPF_Employer_Share`,
      `employees.${index}.ESI_Employee_Share`,
       `employees.${index}.ESI_Employer_Share`,
      `employees.${index}.paid_amt`,
    ],
  });

  useEffect(() => {
    const gs = parseFloat(grossSalary) || 0;
    const ad = parseInt(absentDay) || 0;
    const oa = parseFloat(otherAllowance) || 0;
    const tdsVal = parseFloat(tds) || 0;
    const wd = workingDays > 0 ? workingDays : 30;

    const netAmount = gs - ad * (gs / wd) + oa;
    const epfEmployeeDeduction =
      (netAmount * parseFloat(contributionRates?.epf_employee || 0)) / 100;
    const esiEmployeeDeduction =
      (netAmount * parseFloat(contributionRates?.esi_employee || 0)) / 100;
    const paidAmount =
      netAmount - epfEmployeeDeduction - esiEmployeeDeduction - tdsVal;

    setValue(`employees.${index}.net_amt`, netAmount.toFixed(2));
    setValue(
      `employees.${index}.EPF_Employee_Share`,
      epfEmployeeDeduction.toFixed(2)
    );
     setValue(
      `employees.${index}.EPF_Employer_Share`,
      epfEmployeeDeduction.toFixed(2)
    );
    setValue(
      `employees.${index}.ESI_Employee_Share`,
      esiEmployeeDeduction.toFixed(2)
    );
        setValue(
      `employees.${index}.ESI_Employer_Share`,
      esiEmployeeDeduction.toFixed(2)
    );
    setValue(`employees.${index}.paid_amt`, paidAmount.toFixed(2));
  }, [
    grossSalary,
    absentDay,
    otherAllowance,
    tds,
    workingDays,
    contributionRates,
    index,
    setValue,
  ]);

  const field = useWatch({ control, name: `employees` })[index];

  return (
    <TableRow>
      <TableCell>{field.emp_code}</TableCell>
      <TableCell>{field.name}</TableCell>
      <TableCell>{field.client}</TableCell>
      <TableCell>{field.Gross_Salary}</TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.Absent_Day`}
          type="number"
          rules={{ min: 0, max: workingDays }}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.other_allowence`}
          type="number"
          rules={{ min: 0 }}
        />
      </TableCell>
      <TableCell>{net_amt}</TableCell>
      <TableCell>{EPF_Employee_Share}</TableCell>
          <TableCell>{EPF_Employer_Share}</TableCell>
      <TableCell>{ESI_Employee_Share}</TableCell>
      <TableCell>{ESI_Employer_Share}</TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.Tds`}
          type="number"
          rules={{ min: 0 }}
        />
      </TableCell>
      <TableCell>{paid_amt}</TableCell>
    </TableRow>
  );
};

const SalaryStatementPage = () => {
  const methods = useForm({
    defaultValues: {
      year: new Date().getFullYear().toString(),
      month: "",
      employees: [],
    },
  });
  const { handleSubmit, control, watch, reset } = methods;
  const { fields, replace } = useFieldArray({ control, name: "employees" });
  const [isSearched, setIsSearched] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const message = useMessageModal();

  const [year, month] = watch(["year", "month"]);
  const workingDays = useMemo(
    () =>
      year && month
        ? new Date(parseInt(year), parseInt(month), 0).getDate()
        : 30,
    [year, month]
  );

  const onSearch = async (data) => {
    setIsLoading(true);
    replace([]);
    try {
      const res = await apiClient.get("/salary-statement/preview", {
        params: data,
      });
      replace(res.data.data);
      setIsSearched(true);
    } catch (error) {
      message.error(
        error.response?.data?.message || "Failed to preview salary data."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    try {
      await apiClient.post("/salary-statement/generate", data);
      message.success("Salary statement generated successfully!");
      handleReset();
    } catch (error) {
      message.error(
        error.response?.data?.message || "Failed to generate salary statement."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    replace([]);
    setIsSearched(false);
  };

  const yearOptions = Array.from({ length: 10 }, (_, i) => ({
    value: String(new Date().getFullYear() - 5 + i),
    label: String(new Date().getFullYear() - 5 + i),
  }));
  const monthOptions = Array.from({ length: 12 }, (_, i) => ({
    value: String(i + 1),
    label: new Date(0, i).toLocaleString("default", { month: "long" }),
  }));

  return (
    <FormProvider {...methods}>
      <FormLayout
        title="Generate Salary Statement"
        onSubmit={isSearched ? handleSubmit(onSubmit) : handleSubmit(onSearch)}
        onReset={handleReset}
        isSubmitting={isLoading || isSubmitting}
        submitText={isSearched ? "Generate" : "Search"}
        onCancel={isSearched ? () => setIsSearched(false) : undefined}
        topButtons={[
          {text:"View",path:"update" }
        ]}
        
      >
        <div className="grid grid-cols-3 gap-6">
          <FormSelect
            name="year"
            label="Year"
            options={yearOptions}
            rules={{ required: true }}
          />
          <FormSelect
            name="month"
            label="Month"
            options={monthOptions}
            rules={{ required: true }}
          />
        </div>
        <div className="col-span-2" >
                {isSearched && fields.length > 0 && (
        <div className="mt-6">
          <div className="border rounded-md overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                    <TableHead>Sl No</TableHead>
                  <TableHead>Emp Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Gross Salary</TableHead>
                  <TableHead>Absent Days</TableHead>
                  <TableHead>Other Allowance</TableHead>
                  <TableHead>Net Salary</TableHead>
                  <TableHead>EPF EMP</TableHead>
                  <TableHead>EPF EMPR</TableHead>
                  <TableHead>ESI EMP</TableHead>
                  <TableHead>ESI EMPR</TableHead>
                  <TableHead>ESI</TableHead>
                  <TableHead>TDS</TableHead>
                  <TableHead>Payable Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fields.map((field, index) => (
                  <SalaryStatementRow
                    key={field.id}
                    index={index}
                    control={control}
                    workingDays={workingDays}
                  />
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
        </div>
      </FormLayout>


    </FormProvider>
  );
};

export default SalaryStatementPage;
