import React, { useState, useEffect, useRef } from "react";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import apiClient from "@/api/axiosConfig";
import { toast } from "sonner";

const AdminProfilePage = () => {
  const [formData, setFormData] = useState({
    admin_name: "",
    email: "",
    mobile_no: "",
    address: "",
    bank_name: "",
    branch_code: "",
    account_no: "",
    ifsc_code: "",
    invoice_bank_name: "",
    invoice_account_no: "",
    invoice_ifsc_code: "",
    pan_no: "",
    tan_no: "",
    gst_no: "",
    cin_no: "",
  });


const renderCount = useRef(0);
 renderCount.current = renderCount.current + 1;
 console.log(`component rerendered ${renderCount.current} times.`);
  const [passwordData, setPasswordData] = useState({
    new_password: "",
    confirm_password: "",
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const fetchProfile = async () => {
    setIsLoading(true);
    try {
      const res = await apiClient.get("/admin-profile");
      const profileData = res.data.data;

      setFormData({
        admin_name: profileData.admin_name || "",
        email: profileData.email || "",
        mobile_no: profileData.mobile_no || "",
        address: profileData.address || "",
        bank_name: profileData.bank_name || "",
        branch_code: profileData.branch_code || "",
        account_no: profileData.account_no || "",
        ifsc_code: profileData.ifsc_code || "",
        invoice_bank_name: profileData.invoice_bank_name || "",
        invoice_account_no: profileData.invoice_account_no || "",
        invoice_ifsc_code: profileData.invoice_ifsc_code || "",
        pan_no: profileData.pan_no || "",
        tan_no: profileData.tan_no || "",
        gst_no: profileData.gst_no || "",
        cin_no: profileData.cin_no || "",
      });
    } catch (err) {
      toast.error("Failed to load company profile data.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.admin_name.trim())
      newErrors.admin_name = "Company/Admin Name is required.";
    if (!formData.email.trim()) newErrors.email = "Email is required.";
    if (!formData.mobile_no.trim())
      newErrors.mobile_no = "Mobile Number is required.";

    if (passwordData.new_password && passwordData.new_password.length < 6) {
      newErrors.new_password = "Password must be at least 6 characters.";
    }
    if (passwordData.new_password !== passwordData.confirm_password) {
      newErrors.confirm_password = "Passwords do not match.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      toast.error("Please fix the errors before submitting.");
      return;
    }
    setIsSubmitting(true);

    const payload = { ...formData };

    if (passwordData.new_password) {
      payload.password = passwordData.new_password;
    }

    try {
      await apiClient.put("/admin-profile", payload);
      toast.success("Profile updated successfully!");

      setPasswordData({ new_password: "", confirm_password: "" });

      fetchProfile();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to update profile.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p>Loading Company Profile...</p>
      </div>
    );
  }

  return (
    <FormLayout
      title="Company Profile & Settings"
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText="Save Changes"
    >
      {/* Grouping related fields using comments for clarity */}
      {/* --- Basic Information --- */}
      <FormInput
        name="admin_name"
        label="Company / Admin Name"
        value={formData.admin_name}
        onChange={handleChange}
        required
        error={errors.admin_name}
        className="lg:col-span-2"
      />
      <FormInput
        name="email"
        label="Email Address"
        type="email"
        value={formData.email}
        onChange={handleChange}
        required
        error={errors.email}
      />
      <FormInput
        name="mobile_no"
        label="Mobile Number"
        type="tel"
        value={formData.mobile_no}
        onChange={handleChange}
        required
        error={errors.mobile_no}
      />
      <FormInput
        name="address"
        label="Address"
        type="textarea"
        value={formData.address}
        onChange={handleChange}
        className="lg:col-span-4"
      />
      {/* --- Statutory Details --- */}
      <FormInput
        name="pan_no"
        label="PAN Number"
        value={formData.pan_no}
        onChange={handleChange}
      />
      <FormInput
        name="tan_no"
        label="TAN Number"
        value={formData.tan_no}
        onChange={handleChange}
      />
      <FormInput
        name="gst_no"
        label="GST Number"
        value={formData.gst_no}
        onChange={handleChange}
      />
      <FormInput
        name="cin_no"
        label="CIN Number"
        value={formData.cin_no}
        onChange={handleChange}
      />
      {/* --- Primary Bank Details --- */}
      <FormInput
        name="bank_name"
        label="Bank Name"
        value={formData.bank_name}
        onChange={handleChange}
      />
      <FormInput
        name="branch_code"
        label="Branch Code"
        value={formData.branch_code}
        onChange={handleChange}
      />
      <FormInput
        name="account_no"
        label="Account Number"
        value={formData.account_no}
        onChange={handleChange}
      />
      <FormInput
        name="ifsc_code"
        label="IFSC Code"
        value={formData.ifsc_code}
        onChange={handleChange}
      />
      {/* --- Invoice Bank Details --- */}
      <FormInput
        name="invoice_bank_name"
        label="Invoice Bank Name"
        value={formData.invoice_bank_name}
        onChange={handleChange}
      />
      <FormInput
        name="invoice_account_no"
        label="Invoice Account No."
        value={formData.invoice_account_no}
        onChange={handleChange}
      />
      <FormInput
        name="invoice_ifsc_code"
        label="Invoice IFSC Code"
        value={formData.invoice_ifsc_code}
        onChange={handleChange}
      />
      <div className="lg:col-span-1"></div> {/* Empty div for alignment */}
      {/* --- Password Update Section --- */}
      <div className="lg:col-span-4 mt-4 border-t pt-4">
        <h3 className="font-semibold text-lg mb-2">Change Password</h3>
        <p className="text-sm text-gray-500 mb-4">
          Leave these fields blank to keep the current password.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormInput
            name="new_password"
            label="New Password"
            type="password"
            value={passwordData.new_password}
            onChange={handlePasswordChange}
            error={errors.new_password}
          />
          <FormInput
            name="confirm_password"
            label="Confirm New Password"
            type="password"
            value={passwordData.confirm_password}
            onChange={handlePasswordChange}
            error={errors.confirm_password}
          />
        </div>
      </div>
    </FormLayout>
  );
};

export default AdminProfilePage;
