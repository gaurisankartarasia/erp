import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import FormSelect from "@/components/common/forms/FormSelect";
import apiClient from "@/api/axiosConfig";
import { toast } from "sonner";

const ClientFormPage = () => {
  const navigate = useNavigate();
  const { clientId } = useParams();
  const isEditMode = !!clientId;
    const renderCount = useRef(0);
     renderCount.current = renderCount.current + 1;
     console.log(`Input component has rerendered ${renderCount.current} times.`);

  const [formData, setFormData] = useState({
    clientNm: "",
    projNm: "",
    person: "",
    email: "",
    mob: "",
    phone: "",
    gstno: "",
    pan: "",
    location: "",
    state_id: "",
    district_id: "",
    pin: "",
    taxtype: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(isEditMode);

  const [states, setStates] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [isDistrictLoading, setIsDistrictLoading] = useState(false);

  useEffect(() => {
    const fetchStates = async () => {
      try {
        const res = await apiClient.get("/locations/states");
        const formattedStates = res.data.data.map(state => ({
          value: String(state.id), 
          label: state.state_name
        }));
        setStates(formattedStates);
      } catch (err) {
        toast.error("Failed to load states. Please try again later.");
      }
    };
    fetchStates();
  }, []);

  useEffect(() => {
    const selectedStateId = formData.state_id;
    if (!selectedStateId) {
      setDistricts([]);
      return;
    }

    const fetchDistricts = async () => {
      setIsDistrictLoading(true);
      try {
        const res = await apiClient.get(`/locations/states/${selectedStateId}/districts`);
        const formattedDistricts = res.data.data.map(district => ({
          // FIX #1: The Select component requires a STRING value
          value: String(district.id), 
          label: district.district_name
        }));
        setDistricts(formattedDistricts);
      } catch (err) {
        toast.error("Failed to load districts for the selected state.");
        setDistricts([]);
      } finally {
        setIsDistrictLoading(false);
      }
    };

    fetchDistricts();
  }, [formData.state_id]);

  useEffect(() => {
    if (!isEditMode) return;
    const fetchClient = async () => {
      setIsLoading(true);
      try {
        const res = await apiClient.get(`/clients/${clientId}`);
        const clientData = res.data.data;
        setFormData({
          clientNm: clientData.clientNm || "",
          projNm: clientData.projNm || "",
          person: clientData.person || "",
          email: clientData.email || "",
          mob: clientData.mob || "",
          phone: clientData.phone || "",
          gstno: clientData.gstno || "",
          pan: clientData.pan || "",
          location: clientData.location || "",
          // FIX #1: Convert fetched IDs to STRING for the initial value
          state_id: clientData.state_id ? String(clientData.state_id) : "",
          district_id: clientData.district_id ? String(clientData.district_id) : "",
          pin: clientData.pin || "",
          taxtype: clientData.taxtype || "",
        });
      } catch (err) {
        toast.error("Failed to load client data.");
        navigate("/clients");
      } finally {
        setIsLoading(false);
      }
    };
    fetchClient();
  }, [clientId, isEditMode, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleValueChange = (name, value) => {
    setFormData(prev => {
        const newState = { ...prev, [name]: value };
        if (name === 'state_id') {
            newState.district_id = '';
        }
        return newState;
    });
  };

  const validateForm = () => { /* ...your validation... */ return true; };
  const handleSubmit = async () => { /* ...your submission logic... */ };
  const handleCancel = () => navigate("/clients");

  

  return (
    <FormLayout
      title={isEditMode ? "Edit Client" : "Create New Client"}
      onSubmit={handleSubmit}
      onCancel={handleCancel}
      isSubmitting={isSubmitting}
      submitText={isEditMode ? "Update" : "Submit"}
      // FIX #2: Control the grid layout from here
      gridClass="grid-cols-1 md:grid-cols-2 lg:grid-cols-4"
      isLoading={isLoading}
    >
      {/* FIX #2: REMOVED the extra wrapper divs. These are now direct children of FormLayout */}
      
      <FormInput name="clientNm" label="Client Name" value={formData.clientNm} onChange={handleChange} required error={errors.clientNm} />
      <FormInput name="projNm" label="Project Name" value={formData.projNm} onChange={handleChange} />
      <FormInput name="person" label="Contact Person" value={formData.person} onChange={handleChange} required error={errors.person} />
      <FormInput name="email" label="Email Address" type="email" value={formData.email} onChange={handleChange} required error={errors.email} />
      <FormInput name="mob" label="Mobile Number" type="tel" value={formData.mob} onChange={handleChange} required error={errors.mob} />
      <FormInput name="phone" label="Alternate Phone" type="tel" value={formData.phone} onChange={handleChange} />
      
      <FormInput name="location" label="Location / Address" type="text" value={formData.location} onChange={handleChange} required error={errors.location} className="lg:col-span-2"/>

      <FormSelect
        name="state_id"
        label="State"
        placeholder="Select a state..."
        value={formData.state_id}
        onValueChange={(value) => handleValueChange('state_id', value)}
        options={states}
        required
        error={errors.state_id}
      />

      <FormSelect
        name="district_id"
        label="District"
        placeholder={isDistrictLoading ? "Loading..." : (!formData.state_id ? "Select a state first" : "Select a district...")}
        value={formData.district_id}
        onValueChange={(value) => handleValueChange('district_id', value)}
        options={districts}
        required
        error={errors.district_id}
        disabled={!formData.state_id || isDistrictLoading}
      />
      
      <FormInput name="pin" label="PIN Code" type="number" value={formData.pin} onChange={handleChange} />
      <FormInput name="gstno" label="GST Number" value={formData.gstno} onChange={handleChange} />
      <FormInput name="pan" label="PAN Number" value={formData.pan} onChange={handleChange} />
      <FormInput name="taxtype" label="Tax Type" value={formData.taxtype} onChange={handleChange} />
    </FormLayout>
  );
};

export default ClientFormPage;