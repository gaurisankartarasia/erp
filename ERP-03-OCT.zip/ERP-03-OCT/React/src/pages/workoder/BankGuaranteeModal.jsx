import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";

import apiClient from "@/api/axiosConfig";
import FormInput from "@/components/common/forms/FormInput";
import MessageModal from "@/components/common/modals/MessageModal";
import ConfirmModal from "@/components/common/modals/ConfirmationModal";
const BankGuaranteeModal = ({ isOpen, onClose, workOrderId }) => {
  const [formData, setFormData] = useState({
    bg_no: "",
    bg_date: "",
    bg_validity: "",
    bg_amount: "",
    document: null,
  });
  const [errors, setErrors] = useState({});
  const [guarantees, setGuarantees] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [messageModal, setMessageModal] = useState({
    isOpen: false,
    message: "",
    variant: "info",
  });

  const fetchGuarantees = async () => {
    if (!workOrderId) return;
    try {
      const response = await apiClient.get(
        `/bank-guarantees/work-order/${workOrderId}`
      );
      setGuarantees(response.data.data);
    } catch (error) {
      toast.error("Failed to fetch existing bank guarantees.");
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchGuarantees();
      // Also clear form and errors when the modal opens
      setFormData({
        bg_no: "",
        bg_date: "",
        bg_validity: "",
        bg_amount: "",
        document: null,
      });
      setErrors({});
    }
  }, [isOpen, workOrderId]);

  // This handler now also clears errors on input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  // This handler now also clears the document error on file selection
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowedTypes = ["application/pdf", "image/jpeg"];
    const maxSize = 10 * 1024 * 1024;
    if (!allowedTypes.includes(file.type) || file.size > maxSize) {
      toast.error("Invalid file: Must be PDF/JPG and under 10MB.");
      e.target.value = null;
      return;
    }
    setFormData((prev) => ({ ...prev, document: file }));
    if (errors.document) {
      setErrors((prev) => ({ ...prev, document: null }));
    }
  };

  const toDMY = (dateStr) => {
    if (!dateStr) return "";
    const [y, m, d] = dateStr.split("-");
    if (!y || !m || !d) return "";
    return `${d}-${m}-${y}`;
  };

  // This function is now simplified to just return the errors object
  const validateForm = () => {
    const newErrors = {};
    if (!formData.bg_no.trim()) newErrors.bg_no = "BG No is required.";
    if (!formData.bg_date) newErrors.bg_date = "BG Date is required.";
    if (!formData.bg_validity)
      newErrors.bg_validity = "BG Validity is required.";
    if (!formData.bg_amount || isNaN(formData.bg_amount))
      newErrors.bg_amount = "BG Amount is required.";
    if (!formData.document) newErrors.document = "Soft Copy is required.";
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!workOrderId) {
      toast.error("Cannot save: Work Order ID is missing.");
      return;
    }

    // --- VALIDATION FIX ---
    // 1. Run validation to get any errors
    const formErrors = validateForm();

    // 2. Set the errors state to update the UI
    setErrors(formErrors);

    // 3. Check if the errors object is empty. If not, stop the submission.
    if (Object.keys(formErrors).length > 0) {
      toast.error("Please fill all required fields.");
      return;
    }

    // Your existing date conversion logic remains unchanged
    const bgDateDMY = toDMY(formData.bg_date);
    const bgValidityDMY = toDMY(formData.bg_validity);

    setIsSubmitting(true);

    const payload = new FormData();
    payload.append("bg_no", formData.bg_no);
    payload.append("bg_date", bgDateDMY);
    payload.append("bg_validity", bgValidityDMY);
    payload.append("bg_amount", formData.bg_amount);
    if (formData.document) payload.append("document", formData.document);
    payload.append("work_order_id", workOrderId);

    try {
      await apiClient.post("/bank-guarantees", payload, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMessageModal({
        isOpen: true,
        message: "Bank Guarantee saved successfully!",
        variant: "success",
      });
      fetchGuarantees();
      setFormData({
        bg_no: "",
        bg_date: "",
        bg_validity: "",
        bg_amount: "",
        document: null,
      });
      setErrors({});
      const fileInput = document.getElementById("bg-document-upload");
      if (fileInput) fileInput.value = null;
    } catch (error) {
      let msg =
        error.response?.data?.message ||
        error.response?.data?.errors?.map((e) => e.msg).join(" | ") ||
        "Failed to save bank guarantee.";
      setMessageModal({ isOpen: true, message: msg, variant: "danger" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = async (bgId) => {
    try {
      await apiClient.delete(`/bank-guarantees/${bgId}`);
      toast.success("Bank Guarantee deleted successfully!");
      fetchGuarantees();
    } catch (error) {
      toast.error("Failed to delete bank guarantee.");
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
        <div className="bg-white rounded-lg shadow-lg p-6 w-[700px] relative max-h-[90vh] overflow-y-auto">
          <button
            className="absolute top-2 right-2 text-gray-500 hover:text-gray-800"
            onClick={onClose}
            aria-label="Close"
          >
            &times;
          </button>
          <h2 className="text-lg font-semibold mb-4 border-b pb-2">
            {" "}
            Bank Guarantee
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <FormInput
                  name="bg_no"
                  label="BG No"
                  value={formData.bg_no}
                  placeholder="BG NO"
                  onChange={handleChange}
                  required
                  error={errors.bg_no}
                />
              </div>
              <div>
                <FormInput
                  name="bg_date"
                  label="BG Date"
                  type="date"
                  value={formData.bg_date}
                  onChange={handleChange}
                  required
                  error={errors.bg_date}
                />
              </div>
              <div>
                <FormInput
                  name="bg_validity"
                  label="BG Validity"
                  type="date"
                  value={formData.bg_validity}
                  onChange={handleChange}
                  required
                  error={errors.bg_validity}
                />
              </div>
              <div>
                <FormInput
                  name="bg_amount"
                  label="BG Amount"
                  type="number"
                  placeholder="BG Amount"
                  value={formData.bg_amount}
                  onChange={handleChange}
                  required
                  error={errors.bg_amount}
                />
              </div>
              <div className="md:col-span-1">
                <label className="block text-sm font-medium mb-1">
                  Soft Copy<span className="text-red-500">   *</span>
                </label>

                <div
                  className={`flex items-center border rounded-md overflow-hidden ${
                    errors.document ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <span className="px-3 text-gray-500 truncate text-sm">
                    {formData.document
                      ? formData.document.name
                      : "Upload Letter Soft Copy"}
                  </span>
                  <label
                    htmlFor="bg-document-upload"
                    className="cursor-pointer bg-blue-500 text-white py-2 px-4 hover:bg-blue-600 text-sm"
                  >
                    Upload
                    <input
                      id="bg-document-upload"
                      name="document"
                      type="file"
                      className="sr-only"
                      accept=".pdf,.jpg,.jpeg"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
                {errors.document && (
                  <p className="text-red-500 text-xs mt-1">{errors.document}</p>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border rounded-md text-sm"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 text-sm"
              >
                {isSubmitting ? "Submitting..." : "Submit"}
              </button>
            </div>
          </form>
          <div className="mt-6 border-t pt-4">
            <h3 className="text-md font-semibold mb-2">Existing Guarantees</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border">
                <thead>
                  <tr className="bg-gray-100 text-left">
                    <th className="px-2 py-1 border">BG No</th>
                    <th className="px-2 py-1 border">BG Date</th>
                    <th className="px-2 py-1 border">BG Validity</th>
                    <th className="px-2 py-1 border">BG Amount</th>
                    <th className="px-2 py-1 border">Soft Copy</th>
                    <th className="px-2 py-1 border text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {guarantees.length > 0 ? (
                    guarantees.map((bg) => (
                      <tr key={bg.id}>
                        <td className="border px-2 py-1">{bg.bg_no}</td>
                        <td className="border px-2 py-1">
                          {toDMY(bg.bg_date)}
                        </td>
                        <td className="border px-2 py-1">
                          {toDMY(bg.bg_validity)}
                        </td>
                        <td className="border px-2 py-1">{bg.bg_amount}</td>
                        <td className="border px-2 py-1">
                          <a
                            href={`${import.meta.env.VITE_API_BASE_URL.replace(
                              /\/api$/,
                              ""
                            )}/uploads/bank-guarantees/${bg.document}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            View
                          </a>
                        </td>

                        <td className="border px-2 py-1 text-center">
                          <button
                            onClick={() => handleDeleteClick(bg.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan="6"
                        className="text-center py-4 text-gray-500"
                      >
                        No bank guarantees found for this work order.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <MessageModal
        isOpen={messageModal.isOpen}
        onClose={() =>
          setMessageModal({ isOpen: false, message: "", variant: "info" })
        }
        message={messageModal.message}
        variant={messageModal.variant}
      />
    </>
  );
};

export default BankGuaranteeModal;
