import { Router } from "express";
import {
  searchEmployeesForAttendance,
  generateAttendance,
  listAttendanceGroups,
  getAttendanceDetailsByGroup,
  updateAttendanceRecords,
  updateSingleAttendanceRecord
} from "../controllers/AttendanceController.js";
import {protect} from "../middlewares/AuthMiddleware.js"

const router = Router();
router.use(protect)

router.get("/search-employees", searchEmployeesForAttendance);
router.get("/list-groups", listAttendanceGroups);
router.get("/details-by-group", getAttendanceDetailsByGroup);
router.post("/generate", generateAttendance);
router.patch('/update', updateAttendanceRecords); 
router.patch('/update-single/:id', updateSingleAttendanceRecord);

export default router;
