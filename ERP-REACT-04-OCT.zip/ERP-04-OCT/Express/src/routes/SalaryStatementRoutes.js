import { Router } from "express";
import {
  previewSalaryStatement,
  generateSalaryStatement,
  listSalaryStatements,
  getSalaryStatementDetails,
  updateSalaryRecord,
} from "../controllers/SalaryStatementController.js";

const router = Router();

router.get("/preview", previewSalaryStatement);
router.post("/generate", generateSalaryStatement);
router.get('/list-statements', listSalaryStatements);
router.get('/details', getSalaryStatementDetails);
router.patch('/update-record/:id', updateSalaryRecord);

export default router;
