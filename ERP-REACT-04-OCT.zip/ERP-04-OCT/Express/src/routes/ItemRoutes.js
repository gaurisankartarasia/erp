import express from 'express';
import {
  getAllItems,
  getItemById,
  createItem,
  updateItem,
  getActiveUnits
} from '../controllers/ItemController.js';

const router = express.Router();

router.get('/units', getActiveUnits); // For dropdown
router.get('/', getAllItems);
router.post('/', createItem);
router.get('/:id', getItemById);
router.put('/:id', updateItem);

export default router;