import express from 'express'
import { createReminder, deleteReminder, getAllReminders, getReminderById, toggleReminderStatus, updateReminder } from '../controllers/ReminderSchedulerController.js'

const  reminderSchedulerRouter=express.Router()
reminderSchedulerRouter.post('/create',createReminder)
reminderSchedulerRouter.get('/',getAllReminders)
reminderSchedulerRouter.get('/:id',getReminderById)
reminderSchedulerRouter.put('/edit/:id',updateReminder)
reminderSchedulerRouter.delete('/delete/:id',deleteReminder)
reminderSchedulerRouter.patch('/toggle-status/:id',toggleReminderStatus)

export default reminderSchedulerRouter