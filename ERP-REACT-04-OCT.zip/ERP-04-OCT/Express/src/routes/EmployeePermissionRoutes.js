import express from "express";
import { getEmployeePermissions } from "../controllers/EmployeePermissionsController.js";
import { protect } from "../middlewares/AuthMiddleware.js";

const router = express.Router();

router.use(protect)

router.get("/", getEmployeePermissions);

export default router;
