import express from "express";
import { createPaymentReceive, deletePaymentReceive, getAllBillNumbers, getAllPaymentReceives, getInvoicesByBillNo, getPaymentReceiveById, getPaymentsByBillNo, updatePaymentReceive } from "../controllers/PaymentReceiveController.js";


const paymentReceiveRoutes = express.Router();

/**
 * @route   POST /api/payment-receive
 * @desc    Create a new payment record
 */
paymentReceiveRoutes.post("/add", createPaymentReceive);

/**
 * @route   GET /api/payment-receive
 * @desc    Get all payment records (with pagination, search, sorting)
 */
paymentReceiveRoutes.get("/allpayments", getAllPaymentReceives);

/**
 * @route   GET /api/payment-receive/:id
 * @desc    Get a single payment record by ID
 */
paymentReceiveRoutes.get("/payment/:id", getPaymentReceiveById);

/**
 * @route   PUT /api/payment-receive/:id
 * @desc    Update a payment record by ID
 */
paymentReceiveRoutes.put("/edit/:id", updatePaymentReceive);

/**
 * @route   DELETE /api/payment-receive/:id
 * @desc    Soft delete a payment record
 */
paymentReceiveRoutes.delete("/delete/:id", deletePaymentReceive);

paymentReceiveRoutes.get("/bill-numbers",getAllBillNumbers)
paymentReceiveRoutes.get('/get-data-by-bill/',getInvoicesByBillNo)
paymentReceiveRoutes.get('/payment-receives/by-bill', getPaymentsByBillNo);
export default paymentReceiveRoutes;
 