import express from "express";
import { getAllClientNamesByBillNumber, getAllPaymentBillNumbersIncludingDeleted, searchPaymentReceives } from "../controllers/PaymentReceiveReportController.js";


const paymentReceiveReportRoutes = express.Router();

paymentReceiveReportRoutes.get("/all-bill-numbers",getAllPaymentBillNumbersIncludingDeleted)
paymentReceiveReportRoutes.get("/clients-by-bill-numbers",getAllClientNamesByBillNumber)
paymentReceiveReportRoutes.get("/history", searchPaymentReceives);
export default paymentReceiveReportRoutes;
 