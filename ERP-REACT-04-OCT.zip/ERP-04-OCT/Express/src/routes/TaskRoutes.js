import express from "express";
import {
  createTask,
  getTaskById,
  updateTask,
  deleteTask,
  updateTaskStatus,
  getTaskHistories,
  getAvailableTasks,
  getMyActiveTasks,
} from "../controllers/TaskController.js";
import { protect, hasPermission } from "../middlewares/AuthMiddleware.js";
import { permissions } from "../utils/permissions.js";

const router = express.Router();

router.use(protect).use(hasPermission(permissions.TASKS))

router.route("/").post(createTask);

router.route("/active-tasks").get(getMyActiveTasks);
router.route("/all-employees").get(getAvailableTasks);

router.route("/histories").get(getTaskHistories);

router.route("/:id").get(getTaskById).put(updateTask).delete(deleteTask);

router.route("/:id/status").patch(updateTaskStatus);

export default router;
