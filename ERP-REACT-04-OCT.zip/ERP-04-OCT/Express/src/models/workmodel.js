import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "WorkOrder",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
      },

      client_id: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: false,
        references: {
          model: "mtpl_clients",
          key: "id",
        },
      },

      created_by_client_id: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: false,
        references: {
          model: "mtpl_clients",
          key: "id",
        },
      },

      work_order_no: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      start_date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      expiry_date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      subject: {
        type: DataTypes.STRING(1000),
        allowNull: false,
      },
      taxable_price: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
      },
      tax_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      tax_amount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
      },
      total_amount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
      },
      document: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
    },
    {
      tableName: "mtpl_work_orders",
      timestamps: true,
      underscored: true,
    }
  );
};
