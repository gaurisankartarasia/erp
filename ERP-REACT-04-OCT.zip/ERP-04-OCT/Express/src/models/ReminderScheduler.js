import { DataTypes } from "sequelize";
import { Op } from "sequelize";
export default (sequelize) => {
  sequelize.define('ReminderScheduler', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    reminder_matter: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email_id: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    mobile_no: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    due_date: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // optional: set default to true
    }
  }, {
    tableName: 'mtpl_reminder_schedulers',
    timestamps: true,
    underscored: true
  });
};
