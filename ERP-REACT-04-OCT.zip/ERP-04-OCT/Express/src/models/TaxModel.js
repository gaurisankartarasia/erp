
import { DataTypes } from "sequelize";

const defineTaxModel = (sequelize) => {
  return sequelize.define("Tax", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    taxId: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
    },
    month: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    year: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    epf: {
      type: DataTypes.FLOAT,
      defaultValue: 0,
    },
    esi: {
      type: DataTypes.FLOAT,
      defaultValue: 0,
    },
    gst: {
      type: DataTypes.FLOAT,
      defaultValue: 0,
    },
    tds: {
      type: DataTypes.FLOAT,
      defaultValue: 0,
    },
  }, {
    tableName: "mtpl_tax_entry",
    timestamps: true,
    underscored:true
  });
};

export default defineTaxModel;
