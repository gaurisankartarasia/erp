import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "PaymentReceive",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
      },
      recvlid: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      bill_no: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      release_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      release_amount: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      tax_deduct: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      pending_amount: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      remarks: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      is_active: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 1,
      },
      is_delete: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 0,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    },
    {
      tableName: "payment_receive",
      timestamps: true,
      underscored:true
    }
  );
};
