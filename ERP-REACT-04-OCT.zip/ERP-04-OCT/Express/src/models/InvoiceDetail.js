import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "InvoiceDetail",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
      },
      invoice_id: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: false,
      },
      invoice_code: {
        type: DataTypes.STRING(200),
        allowNull: true,
      },
      desc: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      sac: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      qty: {
        type: DataTypes.DECIMAL(18, 0),
        allowNull: true,
      },
      uom: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      unit_price: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      amnt: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      gstp: {
        type: DataTypes.DECIMAL(18, 2),
        allowNull: true,
      },
      gst_amt: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
      },
      is_active: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 1,
      },
      is_delete: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 0,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    },
    {
      tableName: "invoice_details",
      timestamps: false,
    }
  );
};
