import { sequelize } from '../models/index.js';
import { Op } from 'sequelize';
import { stringify } from 'csv-stringify';
import * as XLSX from 'xlsx';

const {Employee, Client, Designation} = sequelize.models

const getEmployeeQueryOptions = (clientId, search = '') => {
  const whereClause = {
    client: clientId,
    is_active: true,
    is_delete: false,
  };

  if (search) {
    whereClause[Op.or] = [
      { name: { [Op.like]: `%${search}%` } },
      { emp_code: { [Op.like]: `%${search}%` } },
      { '$designation_info.designation_name$': { [Op.like]: `%${search}%` } },
    ];
  }

return {
  where: whereClause,
  attributes: { exclude: ['createdAt', 'updatedAt', 'password'] }, 
  include: [
    { model: Client, as: 'client_info', attributes: ['projNm', 'location'], required: true },
    { model: Designation, as: 'designation_info', attributes: ['designation_name'] },
  ],
  order: [['name', 'ASC']],
  raw: true,
  nest: true,
};
};

export const getEmployeesByClientPaginated = async (req, res) => {
  const { clientId, page = 1, limit = 10, search = '' } = req.query;

  if (!clientId) {
    return res.status(400).json({ message: 'A client ID is required.' });
  }

  const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

  try {
    const { rows: employees, count: totalItems } = await Employee.findAndCountAll({
      ...getEmployeeQueryOptions(clientId, search),
      limit: parseInt(limit),
      offset,
      distinct: true,
    });

    res.status(200).json({
      data: employees,
      total: totalItems,
    });
  } catch (error) {
    console.error("Error fetching paginated employee data:", error);
    res.status(500).json({ message: "Failed to fetch employee data." });
  }
};

export const exportEmployeesByClient = async (req, res) => {
  const { clientId, format = 'csv' } = req.query;

  if (!clientId) {
    return res.status(400).json({ message: 'A client ID is required.' });
  }

  try {
    const employees = await Employee.findAll(getEmployeeQueryOptions(clientId));
    
    const dataToExport = employees.map(emp => ({
      "Employee Code": emp.emp_code,
      "Name": emp.name,
      "Email": emp.email,
      "Mobile No": emp.mobile_no,
      "Designation": emp.designation_info?.designation_name || 'N/A',
      "Client Project": emp.client_info?.projNm || 'N/A',
      "Date of Joining": emp.doj,
    }));

    const filename = `employee-report-${Date.now()}`;

    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}.csv"`);
      stringify(dataToExport, { header: true }).pipe(res);
    } else if (format === 'excel') {
      const ws = XLSX.utils.json_to_sheet(dataToExport);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Employees");
      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}.xlsx"`);
      res.send(buffer);
    } else {
      res.status(400).json({ message: 'Invalid export format specified.' });
    }
  } catch (error) {
    console.error("Error exporting employee data:", error);
    res.status(500).json({ message: "Failed to export data." });
  }
};