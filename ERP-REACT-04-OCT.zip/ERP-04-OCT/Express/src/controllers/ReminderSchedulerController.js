import { models } from "../models/index.js";
import { Op } from "sequelize";
const { ReminderScheduler } = models;

export const createReminder = async (req, res) => {
    try {
        const { reminder_matter, email_id, mobile_no, due_date } = req.body;

        if (!reminder_matter || !email_id || !mobile_no || !due_date) {
            return res.status(400).json({
                message: "All fields are required"
            });
        }

        const reminder = await ReminderScheduler.create({
            reminder_matter,
            email_id,
            mobile_no,
            due_date
        })


        return res.status(201).json({
            message: "Reminder created successfully",
            data: reminder
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({
            message: "Internal Server Error"
        });
    }
};

export const getAllReminders = async (req, res) => {
  try {
    // Pagination params
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    // Search param - searching on reminder_matter, email_id, mobile_no
    const searchTerm = req.query.search || "";

    // Base where clause - no deletion flag here, but you can add if needed
    const where = {};

    if (searchTerm) {
      where[Op.or] = [
        { reminder_matter: { [Op.like]: `%${searchTerm}%` } },
        { email_id: { [Op.like]: `%${searchTerm}%` } },
        { mobile_no: { [Op.like]: `%${searchTerm}%` } }
      ];
    }

    // Sorting params
    const sortBy = req.query.sort || "created_at";
    const sortOrder = req.query.order || "DESC";
    if (!["ASC", "DESC"].includes(sortOrder.toUpperCase())) {
      return res.status(400).json({ message: "Invalid sort order." });
    }
    const order = [[sortBy, sortOrder]];

    // Query database with pagination, searching, and sorting
    const { count, rows } = await ReminderScheduler.findAndCountAll({
      where,
      order,
      limit,
      offset
    });

    return res.status(200).json({
      message: "Reminders retrieved successfully",
      data: rows,
      total: count,
      meta: {
        totalPages: Math.ceil(count / limit),
        currentPage: page,
      },
    });
  } catch (err) {
    console.error("Error fetching reminders:", err);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
};


export const getReminderById = async (req, res) => {
    const { id } = req.params;

    try {
        const reminder = await ReminderScheduler.findByPk(id)
        if (!reminder) {
            return res.status(404).json({
                message: "Reminder not found"
            })
        }

        return res.status(200).json(reminder)
    } catch (err) {
        return res.status(500).json({
            message: "Internal Server Error"
        })
    }
}
export const updateReminder = async (req, res) => {
    try {
        const { id } = await req.params
        const reminder = await ReminderScheduler.findByPk(id)
        if (!reminder) {
            return res.status(400).json({
                message: "Reminder Not Found"
            })
        }

        await reminder.update(req.body)
        res.status(200).json({
            message: "Reminder Scheduler  updated successfully",
            data: reminder,
        });
    } catch (err) {
        return res.status(500).json({
            message: "Internal Server Error"
        })
    }
}
// Delete reminder
export const deleteReminder = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await ReminderScheduler.destroy({
      where: { id }
    });

    if (deleted === 0) {
      return res.status(404).json({ message: "Reminder not found" });
    }

    return res.status(200).json({ message: "Reminder deleted successfully" });
  } catch (err) {
    console.error("Delete Error:", err);
    return res.status(500).json({ message: "Failed to delete reminder" });
  }
};
export const toggleReminderStatus = async (req, res) => {
  const { id } = req.params;

  try {
    const reminder = await ReminderScheduler.findByPk(id);

    if (!reminder) {
      return res.status(404).json({ message: "Reminder not found" });
    }

    // Toggle the is_active field
    const updatedReminder = await reminder.update({
      is_active: !reminder.is_active,
    });

    return res.status(200).json({
      message: `Reminder status updated to ${updatedReminder.is_active ? "Active" : "Inactive"}`,
      data: updatedReminder,
    });
  } catch (err) {
    console.error("Toggle Status Error:", err);
    return res.status(500).json({
      message: "Failed to toggle reminder status",
    });
  }
};
