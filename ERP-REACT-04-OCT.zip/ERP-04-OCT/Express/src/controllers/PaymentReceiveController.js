import { Op } from "sequelize";
import { models } from "../models/index.js";

const { PaymentReceive, Invoice } = models;

export const createPaymentReceive = async (req, res) => {
  try {
    const {
      recvlid,
      bill_no,
      release_date,
      release_amount,
      tax_deduct,
      pending_amount,
      remarks,
      is_active,
      is_delete,
    } = req.body;

    // Check required fields
    if (!bill_no) {
      return res.status(400).json({ message: "Bill number (bill_no) is required." });
    }
    if (!release_date) {
      return res.status(400).json({ message: "Release date (release_date) is required." });
    }
    if (release_amount === undefined || release_amount === null) {
      return res.status(400).json({ message: "Release amount (release_amount) is required." });
    }

    // Prepare data object explicitly
    const paymentData = {
      recvlid: recvlid || null,
      bill_no,
      release_date,
      release_amount,
      tax_deduct: tax_deduct || null,
      pending_amount: pending_amount || null,
      remarks: remarks || null,
      is_active: is_active !== undefined ? is_active : 1,
      is_delete: is_delete !== undefined ? is_delete : 0,
    };

    const newPayment = await PaymentReceive.create(paymentData);
    if (Number(pending_amount) === 0) {
      await Invoice.update(
        { is_delete: 1 },
        {
          where: {
            bill_no: bill_no
          },
        }
      );
    }

    return res.status(201).json({ message: "Payment record created successfully.", data: newPayment });
  } catch (error) {
    console.error("Error creating payment record:", error);
    return res.status(500).json({ message: "Server error", error: error.message });
  }
};

export const getAllPaymentReceives = async (req, res) => {
    try {
        const page = parseInt(req.query.page, 10) || 1;
        const limit = parseInt(req.query.limit, 10) || 10;
        const offset = (page - 1) * limit;
        const searchTerm = req.query.search || '';

        const where = {
            is_delete: false,
        };

        if (searchTerm) {
            where[Op.or] = [
                { bill_no: { [Op.like]: `%${searchTerm}%` } },
                { recvlid: { [Op.like]: `%${searchTerm}%` } },
                { remarks: { [Op.like]: `%${searchTerm}%` } },
            ];
        }

        const sortBy = req.query.sort || 'release_date';
        const sortOrder = req.query.order?.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
        const order = [[sortBy, sortOrder]];

        const { count, rows } = await PaymentReceive.findAndCountAll({
            where,
            order,
            limit,
            offset,
        });

        res.status(200).json({
            message: "Payment records retrieved successfully.",
            data: rows,
            total: count,
            meta: {
                totalPages: Math.ceil(count / limit),
                currentPage: page,
            },
        });
    } catch (error) {
        console.error("Error fetching payments:", error);
        if (error.name === 'SequelizeDatabaseError') {
            return res.status(400).json({ message: "Invalid sort or search column provided." });
        }
        res.status(500).json({ message: "Server error", error: error.message });
    }
};
export const getPaymentReceiveById = async (req, res) => {
    try {
        const { id } = req.params;

        const payment = await PaymentReceive.findOne({
            where: {
                id: id,
                is_delete: false,
            },
        });

        if (!payment) {
            return res.status(404).json({ message: "Payment record not found." });
        }

        res.status(200).json({ message: "Payment record retrieved successfully.", data: payment });
    } catch (error) {
        console.error("Error fetching payment by ID:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};
export const updatePaymentReceive = async (req, res) => {
    try {
        const { id } = req.params;

        const payment = await PaymentReceive.findOne({
            where: {
                id: id,
                is_delete: false,
            },
        });

        if (!payment) {
            return res.status(404).json({ message: "Payment record not found." });
        }

        const updatedPayment = await payment.update(req.body);

        res.status(200).json({ message: "Payment record updated successfully.", data: updatedPayment });
    } catch (error) {
        console.error("Error updating payment record:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};
export const deletePaymentReceive = async (req, res) => {
    try {
        const { id } = req.params;

        const payment = await PaymentReceive.findOne({
            where: {
                id: id,
                is_delete: false,
            },
        });

        if (!payment) {
            return res.status(404).json({ message: "Payment record not found." });
        }

        payment.is_delete = true;
        await payment.save();

        res.status(200).json({ message: "Payment record deleted successfully." });
    } catch (error) {
        console.error("Error deleting payment record:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};
export const getAllBillNumbers = async (req, res) => {
    try {
        const invoices = await Invoice.findAll({
            attributes: ["bill_no"],
            where: {
                is_delete: 0
            },
            order: [["bill_no", "ASC"]]

        })

        const billNumbers = invoices.map((data) => data.bill_no)
        res.json({
            success: true,
            billNumbers
        })

    } catch (err) {
        return res.status(500).json({
            "message": "Internal Server Error"
        })
    }
}
// export const getInvoicesByBillNo = async (req, res) => {
//   const { bill_no } = req.query; // ✅ Use query instead of params

//   try {
//     const invoices = await Invoice.findAll({
//       where: {
//         bill_no,
//         is_delete: 0,
//       },
//       order: [["date", "DESC"]],
//     });

//     if (invoices.length === 0) {
//       return res
//         .status(404)
//         .json({ success: false, message: "No invoices found" });
//     }

//     return res.json({ success: true, invoices });
//   } catch (err) {
//     console.error("Error fetching invoices by bill_no:", err); // Optional for debugging
//     return res.status(500).json("Internal Server Error");
//   }
// };



export const getInvoicesByBillNo = async (req, res) => {
  const { bill_no } = req.query;

  try {
    // Step 1: Fetch invoices
    const invoices = await Invoice.findAll({
      where: {
        bill_no,
        is_delete: 0,
      },
      order: [["date", "DESC"]],
    });

    if (invoices.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "No invoices found" });
    }

    // Step 2: Fetch pending_amount for this bill_no from PaymentReceive
    const payment = await PaymentReceive.findOne({
      where: { bill_no },
    });

    const pending_amount = payment?.pending_amount || 0;

    // Step 3: Return both in response
    return res.json({
      success: true,
      invoices,
      pending_amount: parseFloat(pending_amount),
    });

  } catch (err) {
    console.error("Error fetching invoices by bill_no:", err);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};


// controllers/paymentReceiveController.js

export const getPaymentsByBillNo = async (req, res) => {
  const { bill_no } = req.query; // ✅ query param

  try {
    if (!bill_no) {
      return res.status(400).json({ message: "Query parameter 'bill_no' is required." });
    }

    const payments = await PaymentReceive.findAll({
      where: {
        bill_no,
        is_active: 1,
        is_delete: 0,
      },
      order: [['release_date', 'ASC']],
    });

    if (payments.length === 0) {
      return res.status(404).json({ message: "No payment records found for this bill number." });
    }

    res.status(200).json({
      success: true,
      message: "Payment records fetched successfully.",
      data: payments,
    });

  } catch (error) {
    console.error("Error fetching payment records by bill_no:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
