import { Op } from "sequelize";
import { models, sequelize } from "../models/index.js";
const { WorkOrder, Client, Invoice, InvoiceDetail } = sequelize.models;

export const getWorkOrderNosByClientName = async (req, res) => {
  try {
    const clientName = req.query.clientName || "";

    if (!clientName.trim()) {
      return res.status(400).json({ message: "clientName query parameter is required" });
    }

    const workOrders = await WorkOrder.findAll({
      include: [
        {
          model: Client,
          as: "Client",
          where: {
            clientNm: {
              [Op.like]: `%${clientName}%`,
            },
            is_active: true,
            is_delete: false,
          },
          attributes: [],
        },
      ],
      attributes: ["id", "work_order_no"],
      where: {
        is_active: true,
      },
      order: [["work_order_no", "ASC"]],
      limit: 50,
    });

    res.status(200).json({
      message: `Work orders filtered by client name: ${clientName}`,
      data: workOrders,
    });
  } catch (error) {
    console.error("Error fetching work orders by client name:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const getSubjectAndAmountByWorkOrderNo = async (req, res) => {
  try {
    const workOrderNo = req.query.workOrderNo || "";

    if (!workOrderNo.trim()) {
      return res.status(400).json({
        message: "workOrderNo query parameter is required",
      });
    }

    const workOrder = await WorkOrder.findOne({
      where: {
        work_order_no: {
          [Op.like]: `%${workOrderNo}%`,
        },
        is_active: true,
      },
      attributes: ["id", "subject", "total_amount"],
    });

    if (!workOrder) {
      return res.status(404).json({
        message: `No work order found for number: ${workOrderNo}`,
      });
    }

    res.status(200).json({
      message: "Work order details retrieved successfully.",
      data: {
        id: workOrder.id,
        subject: workOrder.subject,
        total_amount: workOrder.total_amount,
      },
    });
  } catch (error) {
    console.error("Error fetching subject and total amount:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// =========== Invoice Controllers ===========


//fetch invoices 
export const getInvoices = async (req, res) => {
  try {
    // Pagination params
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;

    // Sorting
    const sortBy = req.query.sortBy || "date"; // e.g. "client_name", "bill_no"
    const sortOrder = req.query.sortOrder === "asc" ? "ASC" : "DESC";

    // Search (optional)
    const search = req.query.search || "";

    const offset = (page - 1) * pageSize;

    // Build where clause for search
    const whereConditions = {
      is_active: 1,
      is_delete: 0,
    };

    if (search.trim()) {
      whereConditions[Op.or] = [
        { client_name: { [Op.like]: `%${search}%` } },
        { bill_no: { [Op.like]: `%${search}%` } },
      ];
    }

    // Count total records for pagination
    const totalInvoices = await Invoice.count({
      where: whereConditions,
    });

    // Fetch invoices with pagination, search, sort, and details
    const invoices = await Invoice.findAll({
      where: whereConditions,
      include: [
        {
          model: InvoiceDetail,
          as: "details",
          where: { is_active: 1, is_delete: 0 },
          required: false,
        },
      ],
      order: [[sortBy, sortOrder]],
      offset,
      limit: pageSize,
    });

    // Return paginated result
    res.status(200).json({
      message: "Invoices retrieved successfully.",
      pagination: {
        total: totalInvoices,
        page,
        pageSize,
        totalPages: Math.ceil(totalInvoices / pageSize),
      },
      data: invoices,
    });
  } catch (error) {
    console.error("Error fetching invoices:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


// Fetch invoice details by invoice ID
export const getInvoiceDetails = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({ message: "id parameter is required" });
    }

    const invoice = await Invoice.findByPk(id, {
      include: [
        {
          model: InvoiceDetail,
          as: "details",
          where: { is_active: 1, is_delete: 0 },
          required: false,
        },
      ],
    });

    if (!invoice) {
      return res.status(404).json({ message: "Invoice not found" });
    }

    res.status(200).json({
      message: "Invoice details retrieved successfully",
      data: invoice,
    });
  } catch (error) {
    console.error("Error fetching invoice details:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// Create a new invoice with details
export const createInvoice = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const {
      date,
      client_name,
      client_code,
      subject,
      reference,
      gst,
      cgst,
      sgst,
      igst,
      total,
      grand_total,
      details,
    } = req.body;

    if (!grand_total) {
      return res.status(400).json({ message: "grand_total is required" });
    }

    // Define your fixed prefix for bill_no:
    const BILL_PREFIX = "MTPL/2526/I-";

    // Find the latest bill_no starting with the prefix
    const latestInvoice = await Invoice.findOne({
      where: {
        bill_no: {
          [Op.like]: `${BILL_PREFIX}%`,
        },
      },
      order: [["bill_no", "DESC"]],
      transaction: t,
    });

    // Extract the last number suffix from the latest bill_no, default to 0 if none
    let lastNumber = 0;
    if (latestInvoice && latestInvoice.bill_no) {
      const match = latestInvoice.bill_no.match(/(\d+)$/);
      if (match) {
        lastNumber = parseInt(match[1], 10);
      }
    }

    // Increment by 1 and pad with zeros to length 3
    const newNumber = String(lastNumber + 1).padStart(3, "0");

    // Construct new bill_no
    const newBillNo = BILL_PREFIX + newNumber;

    // Create the invoice with the new bill_no
    const invoice = await Invoice.create(
      {
        bill_no: newBillNo,
        date,
        client_name,
        client_code,
        subject,
        reference,
        gst: gst || 0,
        cgst: cgst || 0,
        sgst: sgst || 0,
        igst: igst || 0,
        total,
        grand_total,
        is_active: 1,
        is_delete: 0,
      },
      { transaction: t }
    );

    // Insert invoice details if any
    if (Array.isArray(details) && details.length > 0) {
      const invoiceDetails = details.map((detail) => ({
        invoice_id: invoice.id,
        invoice_code: detail.invoice_code,
        desc: detail.desc,
        sac: detail.sac,
        qty: detail.qty,
        uom: detail.uom,
        unit_price: detail.unit_price,
        amnt: detail.amnt,
        gstp: detail.gstp,
        gst_amt: detail.gst_amt,
        is_active: 1,
        is_delete: 0,
      }));

      await InvoiceDetail.bulkCreate(invoiceDetails, { transaction: t });
    }

    await t.commit();

    res.status(201).json({
      message: "Invoice created successfully",
      data: { id: invoice.id, bill_no: newBillNo },
    });
  } catch (error) {
    await t.rollback();
    console.error("Error creating invoice:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


export const getLatestBillNo = async (req, res) => {
  try {
    const BILL_PREFIX = "MTPL/2526/I-";

    // Find latest bill_no starting with the prefix
    const latestInvoice = await Invoice.findOne({
      where: {
        bill_no: {
          [Op.like]: `${BILL_PREFIX}%`,
        },
      },
      order: [["bill_no", "DESC"]],
    });

    let lastNumber = 0;
    if (latestInvoice && latestInvoice.bill_no) {
      const match = latestInvoice.bill_no.match(/(\d+)$/);
      if (match) {
        lastNumber = parseInt(match[1], 10);
      }
    }

    // Increment for the next number
    const nextNumber = String(lastNumber + 1).padStart(3, "0");
    const nextBillNo = BILL_PREFIX + nextNumber;

    res.json({
      success: true,
      data: {
        latestBillNo: latestInvoice ? latestInvoice.bill_no : null,
        nextBillNo,
      },
    });
  } catch (error) {
    console.error("Error fetching latest bill no:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch latest bill no",
    });
  }
};
