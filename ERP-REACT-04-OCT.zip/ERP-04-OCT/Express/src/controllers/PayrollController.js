import { models } from "../models/index.js";
import { Op } from "sequelize";
import { calculateSalaryBreakdown } from "./SalaryController.js";

const {
  Employee,
  Attendance,
  Attendance2,
  LeaveRequest,
  LeaveType,
  PayrollReport,
  SalarySlip,
} = models;

export const getPayrollPreviewData = async (req, res) => {
  const { month, year } = req.body;

    const existingReport = await PayrollReport.findOne({
      where: { month, year, status: ["completed", "processing"] },
    });
    if (existingReport) {
      return res.status(409).json({
        message: `A report for ${month}/${year} is already generated.`,
        reportId: existingReport.id,
      });
    }

  try {

    const [activeEmployees, allAttendanceForMonth] = await Promise.all([
      Employee.findAll({
        where: { is_active: true },
        attributes: ["id", "name", "emp_code"],
      }),
      Attendance.findAll({
        where: {
          year: year.toString(),
          month: month.toString(),
        },
      }),
    ]);

    const previewData = [];

    for (const employee of activeEmployees) {
      const baseStructureResult = await calculateSalaryBreakdown(employee.id);

      if (baseStructureResult.error) {
        previewData.push({
          employee_id: employee.id,
          employee_name: employee.name,
          error: "No salary structure defined.",
        });
        continue;
      }
const attendanceRecord = allAttendanceForMonth.find(
  (a) => a.employee_id === employee.id
);

if (!attendanceRecord) {
  previewData.push({
    employee_id: employee.id,
    employee_name: employee.name,
    error: "No attendance record found.",
  });
  continue;
}

const presentDays = Number(attendanceRecord.presentday) || 0;
const absentDays = Number(attendanceRecord.absentday) || 0;

      const totalDaysInMonth = 26;

      let paidLeaveDays = 0;


      const totalPayableDays = totalDaysInMonth - absentDays;

      const finalEarnings = [];
      const finalDeductions = [];
      let totalFinalEarnings = 0;
      let totalFinalDeductions = 0;

      for (const component of baseStructureResult.breakdown) {
        let finalAmount = component.amount;
        if (component.is_days) {
          finalAmount =
            (component.amount / totalDaysInMonth) * totalPayableDays;
        }
        finalAmount = parseFloat(finalAmount.toFixed(2));

        const detail = { name: component.name, amount: finalAmount };

        if (component.type === "Earning") {
          finalEarnings.push(detail);
          totalFinalEarnings += finalAmount;
        } else {
          finalDeductions.push(detail);
          totalFinalDeductions += finalAmount;
        }
      }

      const finalNetSalary = totalFinalEarnings - totalFinalDeductions;

      previewData.push({
        employee_id: employee.emp_code,
        employee_name: employee.name,

        attendance_summary: {
          totalDaysInMonth,
          present_days: presentDays,
          paid_leave_days: paidLeaveDays,
          unpaid_leave_days: totalDaysInMonth - totalPayableDays,
        },
        base_earnings: finalEarnings,
        base_deductions: finalDeductions,
        total_base_earnings: parseFloat(totalFinalEarnings.toFixed(2)),
        total_base_deductions: parseFloat(totalFinalDeductions.toFixed(2)),
        base_net_salary: parseFloat(finalNetSalary.toFixed(2)),
      });
    }

    res.status(200).json(previewData);
  } catch (error) {
    res.status(500).json({
      message: "Error fetching payroll preview data.",
      error: error.message,
    });
  }
};

const runPayrollGeneration = async (reportId, month, year) => {

  try {
    const totalDaysInMonth = 26;

    const [activeEmployees, allAttendanceForMonth] =
      await Promise.all([
        Employee.findAll({
          where: { is_active: true },
          attributes: ["id", "name", "emp_code"],
        }),
     
        Attendance.findAll({
        where: {
          year: year.toString(),
          month: month.toString(),
        },
      })
       
      ]);

    const salarySlipsToCreate = [];
    for (const employee of activeEmployees) {
      const baseStructureResult = await calculateSalaryBreakdown(employee.id);

      if (baseStructureResult.error) {
        console.log(
          `Skipping employee ID ${employee.id} (${employee.name}): ${baseStructureResult.error}`
        );
        continue;
      }

const employeeAttendance = allAttendanceForMonth.find(
  (a) => a.employee_id === employee.id
);
const absentDays = Number(employeeAttendance.absentday) || 0;

      const totalPayableDays = totalDaysInMonth - absentDays;

      const finalBreakdown = [];
      let totalFinalEarnings = 0;
      let totalFinalDeductions = 0;

      for (const component of baseStructureResult.breakdown) {
        let finalAmount = component.amount;

        if (component.is_days) {
          finalAmount =
            (component.amount / totalDaysInMonth) * totalPayableDays;
        }

        finalAmount = parseFloat(finalAmount.toFixed(2));

        if (component.type === "Earning") {
          totalFinalEarnings += finalAmount;
        } else if (component.type === "Deduction") {
          totalFinalDeductions += finalAmount;
        }

        finalBreakdown.push({
          name: component.name,
          type: component.type,
          amount: finalAmount,
        });
      }

      const netSalary = totalFinalEarnings - totalFinalDeductions;

      salarySlipsToCreate.push({
        report_id: reportId,
        employee_id: employee.id,
        employee_name: employee.name,
        employee_code: employee.emp_code,
        gross_earnings: parseFloat(totalFinalEarnings.toFixed(2)),
        total_payable_days: totalPayableDays,
        total_deductions: parseFloat(totalFinalDeductions.toFixed(2)),
        net_salary: parseFloat(netSalary.toFixed(2)),
        structure_breakdown: {
          breakdown: finalBreakdown,
          summary: {
            totalEarnings: parseFloat(totalFinalEarnings.toFixed(2)),
            totalDeductions: parseFloat(totalFinalDeductions.toFixed(2)),
            netSalary: parseFloat(netSalary.toFixed(2)),
          },
        },
        attendance_breakdown: {
          unpaidDays: totalDaysInMonth - totalPayableDays,
        },
      });
    }

    if (salarySlipsToCreate.length > 0) {
      await SalarySlip.bulkCreate(salarySlipsToCreate);
    }

    await PayrollReport.update(
      { status: "completed", generated_at: new Date() },
      { where: { id: reportId } }
    );
    console.log(
      `Successfully completed payroll generation for report ID: ${reportId}`
    );
  } catch (error) {
    console.error(
      `Payroll generation FAILED for report ID: ${reportId}. Error: ${error.message}`
    );
    await PayrollReport.update(
      { status: "failed", error_log: error.message },
      { where: { id: reportId } }
    );
  }
};

export const initiatePayrollGeneration = async (req, res) => {
  const { month, year } = req.body;
  const { id: userId } = req.user;

  try {
    const existingReport = await PayrollReport.findOne({
      where: { month, year, status: ["completed", "processing"] },
    });
    if (existingReport) {
      return res.status(409).json({
        message: `A report for ${month}/${year} is already completed or currently processing.`,
        reportId: existingReport.id,
      });
    }

    const newReport = await PayrollReport.create({
      month,
      year,
      generated_by_id: userId,
      status: "processing",
    });

    res.status(202).json({
      message: "Payroll generation initiated.",
      reportId: newReport.id,
    });

    runPayrollGeneration(newReport.id, month, year);
  } catch (error) {
    res.status(500).json({
      message: "Failed to initiate payroll generation.",
      error: error.message,
    });
  }
};

export const getReportStatus = async (req, res) => {
  const { reportId } = req.params;
  try {
    const report = await PayrollReport.findByPk(reportId, {
      attributes: ["id", "status", "error_log"],
    });
    if (!report) return res.status(404).json({ message: "Report not found." });
    res.status(200).json(report);
  } catch (error) {
    res.status(500).json({ message: "Error fetching report status." });
  }
};

export const getPayrollReport = async (req, res) => {
  const { reportId } = req.params;
  try {
    const report = await PayrollReport.findByPk(reportId, {
      include: [
        { model: SalarySlip, as: "SalarySlips" },
      ],
    });
    if (!report) return res.status(404).json({ message: "Report not found." });
    if (report.status !== "completed")
      return res
        .status(400)
        .json({ message: "Report is still processing or has failed." });

    const reportJSON = report.toJSON();

    reportJSON.SalarySlips = reportJSON.SalarySlips.map((slip) => {
      return {
        ...slip,
        month: report.month,
        year: report.year,
        generated_at: report.generated_at,
      };
    });

    res.status(200).json(reportJSON);
  } catch (error) {
    res.status(500).json({
      message: "Error fetching payroll report.",
      error: error.message,
    });
  }
};

export const getRecentReports = async (req, res) => {
  try {
    const reports = await PayrollReport.findAll({
      order: [
        ["year", "DESC"],
        ["month", "DESC"],
      ],
      limit: 5,
    });
    res.status(200).json(reports);
  } catch (error) {
    res.status(500).json({ message: "Error fetching recent reports." });
  }
};
