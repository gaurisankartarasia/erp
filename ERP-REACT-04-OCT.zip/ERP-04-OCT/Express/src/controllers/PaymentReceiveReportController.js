import { Op } from "sequelize";
import { models } from "../models/index.js";

const { PaymentReceive, Invoice } = models;


export const getAllPaymentBillNumbersIncludingDeleted = async (req, res) => {
    try {
        const invoices = await Invoice.findAll({
            attributes: ["bill_no"],
           
            order: [["bill_no", "ASC"]]

        })

        const billNumbers = invoices.map((data) => data.bill_no)
        res.json({
            success: true,
            billNumbers
        })

    } catch (err) {
        return res.status(500).json({
            "message": "Internal Server Error"
        })
    }
}

export const getAllClientNamesByBillNumber = async (req, res) => {
  try {
    const { bill_no } = req.query;

    if (!bill_no) {
      return res.status(400).json({
        success: false,
        message: "bill_no query parameter is required",
      });
    }

    const invoices = await Invoice.findAll({
      where: {
        bill_no,
        is_active: 1,
        is_delete: 0,
      },
      attributes: ["client_name"], // Only fetch client_name
      raw: true,
    });

    const clientNames = [
      ...new Set(invoices.map((invoice) => invoice.client_name)),
    ];

    return res.status(200).json({
      success: true,
      bill_no,
      clientNames,
    });
  } catch (error) {
    console.error("Error fetching client names:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

export const searchPaymentReceives = async (req, res) => {
  try {
    const {
      bill_no,
      from_date,
      to_date,
      page = 1,
      limit = 10,
      sortBy = "release_date",
      order = "ASC",
      search = "",
    } = req.query;

    if (!bill_no) {
      return res.status(400).json({
        success: false,
        message: "Bill number is required",
      });
    }

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    // Build base where clause
    const whereClause = {
      bill_no,
      is_delete: 0,
    };

    // Add date range filter if both dates are provided
    if (from_date && to_date) {
      whereClause.release_date = {
        [Op.between]: [new Date(from_date), new Date(to_date)],
      };
    }

    // Add search condition on selected fields if search string is present
    if (search) {
      whereClause[Op.or] = [
        { recvlid: { [Op.like]: `%${search}%` } },
        { bill_no: { [Op.like]: `%${search}%` } },
        { remarks: { [Op.like]: `%${search}%` } },
      ];
    }

    const { rows: payments, count: totalPayments } = await PaymentReceive.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit, 10),
      offset,
      order: [[sortBy, order.toUpperCase()]],
      distinct: true, // just in case
    });

    return res.status(200).json({
      success: true,
      data: payments,
      total: totalPayments,
      page: parseInt(page, 10),
      pages: Math.ceil(totalPayments / limit),
    });
  } catch (error) {
    console.error("Error fetching payment receive history:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};
