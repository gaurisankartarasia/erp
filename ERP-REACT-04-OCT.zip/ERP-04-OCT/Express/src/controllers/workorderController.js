
import { validationResult } from 'express-validator';
import { sequelize } from "../models/index.js";
import { Op } from 'sequelize';
import fs from 'fs';
import path from 'path';

import { log } from "../services/LogService.js";
const { WorkOrder, Client } = sequelize.models;

/**
 * GET all Clients (with out pagination, search, sorting)
 */
export const getAllClients = async (req, res) => {
  try {
    const page = req.query.page ? parseInt(req.query.page, 10) : null;
    const limit = req.query.limit ? parseInt(req.query.limit, 10) : null;
    const offset = page && limit ? (page - 1) * limit : null;

    const searchTerm = req.query.search || '';
    const where = { is_delete: false };

    if (searchTerm) {
      where[Op.or] = [
        { clientNm: { [Op.like]: `%${searchTerm}%` } },
        { projNm: { [Op.like]: `%${searchTerm}%` } },
        { email: { [Op.like]: `%${searchTerm}%` } },
        { mob: { [Op.like]: `%${searchTerm}%` } },
      ];
    }

    const sortBy = req.query.sort || 'created_at';
    const sortOrder = req.query.order || 'DESC';
    if (!['ASC', 'DESC'].includes(sortOrder.toUpperCase())) {
      return res.status(400).json({ message: "Invalid sort order." });
    }

    const queryOptions = {
      where,
      order: [[sortBy, sortOrder.toUpperCase()]],
    };

    if (limit && offset !== null) {
      queryOptions.limit = limit;
      queryOptions.offset = offset;
    }

    const { count, rows } = await Client.findAndCountAll(queryOptions);
    await log({
      req,
      action: "READ",
      page_name: "ALL CLIENT NAME ",
      // target: `Employee ID: ${employee.id}`,
    });

    res.status(200).json({
      message: "Clients retrieved successfully.",
      data: rows,
      total: count,
      meta: page && limit ? {
        totalPages: Math.ceil(count / limit),
        currentPage: page,
      } : null
    });
  } catch (error) {
    console.error("Error fetching clients:", error);
    if (error.name === 'SequelizeDatabaseError') {
      return res.status(400).json({ message: "Invalid sort or search column provided." });
    }
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * CREATE a new Work Order
 */
export const createWorkOrder = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const {
    client_id, work_order_no, start_date, expiry_date,
    subject, taxable_price, tax_id, tax_amount, total_amount,
  } = req.body;

  const created_by_client_id = req.user?.id;
  if (!created_by_client_id) {
    return res.status(401).json({ message: 'Unauthorized: Creator client not found.' });
  }

  try {
    const existingOrder = await WorkOrder.findOne({ where: { work_order_no } });
    if (existingOrder) return res.status(409).json({ message: 'Work Order number already exists.' });

    let file = req.file;
   
    if (!file && req.files && Object.values(req.files).length > 0) {
      file = Object.values(req.files).flat()[0];
    }

    const workOrderData = {
      client_id,
      created_by_client_id,
      work_order_no,
      start_date,
      expiry_date,
      subject,
      taxable_price,
      tax_id,
      tax_amount,
      total_amount,
      document: file ? file.path || file.originalname : null,
    };

    const newWorkOrder = await WorkOrder.create(workOrderData);
    await log({
      req,
      action: "CREATE",
      page_name: "CREATE WORKORDER PAGE",
  target: `WorkOrder ID: ${newWorkOrder.id}`,
    });

    res.status(201).json({
      message: 'Work Order created successfully!',
      data: newWorkOrder,
    });
  } catch (error) {
    console.error('Error creating work order:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * GET all Work Orders (with pagination, search, sorting)
 */
export const getAllWorkOrders = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'created_at',
      order = 'DESC',
      search = '',
    } = req.query;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const whereCondition = search ? {
      [Op.or]: [
        { subject: { [Op.like]: `%${search}%` } },
        { work_order_no: { [Op.like]: `%${search}%` } },
        { '$Client.clientNm$': { [Op.like]: `%${search}%` } },
        { '$Client.projNm$': { [Op.like]: `%${search}%` } },
      ],
    } : {};

    const { rows: workOrders, count: totalWorkOrders } = await WorkOrder.findAndCountAll({
      where: whereCondition,
      limit: parseInt(limit),
      offset,
      order: [[sortBy, order.toUpperCase()]],
      include: [
        { model: Client, as: 'Client', attributes: ['id', 'clientNm', 'projNm', 'email'] }
      ],
      distinct: true,
    });
   await log({
      req,
      action: "READ",
      page_name: "ALL WORKORDERS PAGE",
      // target: `Employee ID: ${employee.id}`,
    });
    res.status(200).json({
      message: 'Work Orders fetched successfully',
      data: workOrders,
      total: totalWorkOrders,
      page: parseInt(page),
      pages: Math.ceil(totalWorkOrders / limit),
    });
  } catch (err) {
    console.error('Error fetching work orders:', err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * GET Work Order by ID
 */
export const getWorkOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    const workOrder = await WorkOrder.findByPk(id, {
      include: [
        { model: Client, as: 'Client', attributes: ['id', 'clientNm', 'projNm', 'email'] },
      ]
    });

    if (!workOrder) return res.status(404).json({ message: 'Work Order not found.' });

    res.status(200).json({
      message: 'Work Order fetched successfully',
      data: workOrder,
    });
  } catch (error) {
    console.error('Error fetching work order by ID:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * UPDATE Work Order
 */
// export const updateWorkOrder = async (req, res) => {
//   // Check validation errors
//   const errors = validationResult(req);
//   if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

//   const { id } = req.params;

//   try {
//     const workOrder = await WorkOrder.findByPk(id);
//     if (!workOrder) return res.status(404).json({ message: 'Work Order not found.' });

//     // Handle file upload
//     let file = req.file;
//     if (!file && req.files && Object.values(req.files).length > 0) {
//       file = Object.values(req.files).flat()[0];
//     }

//     if (file) {
//       // Delete old file if exists
//       if (workOrder.document) {
//         const oldFilePath = path.join('public', 'uploads', 'work-orders', workOrder.document);
//         if (fs.existsSync(oldFilePath)) fs.unlinkSync(oldFilePath);
//       }

//       // Save new file path in request body
//       req.body.document = file.path || file.originalname;
//     }

//     // Update the work order
//     await workOrder.update({
//       ...req.body,
//     });

//     res.status(200).json({
//       message: 'Work Order updated successfully!',
//       data: workOrder,
//     });
//   } catch (error) {
//     console.error('Error updating work order:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// };

export const updateWorkOrder = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { id } = req.params;

  try {
    const workOrder = await WorkOrder.findByPk(id);
    if (!workOrder) return res.status(404).json({ message: 'Work Order not found.' });

    // The data to update, starting with the body
    const updateData = { ...req.body };

    let file = req.file;
    if (!file && req.files && Object.values(req.files).length > 0) {
      file = Object.values(req.files).flat()[0];
    }

    // --- FIX #5: ONLY UPDATE DOCUMENT IF A NEW FILE IS UPLOADED ---
    if (file) {
      // 1. Delete the old file if it exists
      if (workOrder.document) {
        const oldFilePath = path.join('public', 'uploads', 'work-orders', workOrder.document);
        if (fs.existsSync(oldFilePath)) fs.unlinkSync(oldFilePath);
      }
      
      // 2. Add the new document filename to our update data
      updateData.document = file.path || file.originalname; // Use the unique name from your middleware
    } else {
      // 3. IMPORTANT: If no new file is sent, remove 'document' from the update data
      // This prevents overwriting the existing path with null or "[object Object]".
      delete updateData.document;
    }

    // Update the work order with the final, clean data
    await workOrder.update(updateData);
   await log({
      req,
      action: "UPDATE",
      page_name: "UPDATE WORKORDER PAGE",
      target: `Updated ID: ${workOrder.id}`,
    });
    res.status(200).json({
      message: 'Work Order updated successfully!',
      data: workOrder,
    });
  } catch (error) {
    console.error('Error updating work order:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};
/**
 * DELETE Work Order
 */
export const deleteWorkOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const workOrder = await WorkOrder.findByPk(id);

    if (!workOrder) return res.status(404).json({ message: 'Work Order not found.' });

    if (workOrder.document) {
      const filePath = path.join('public', 'uploads', 'work-orders', workOrder.document);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    await workOrder.destroy();

    res.status(200).json({ message: 'Work Order deleted successfully.' });
  } catch (error) {
    console.error('Error deleting work order:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * TOGGLE Work Order Status (is_active)
 */
export const toggleWorkOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const workOrder = await WorkOrder.findByPk(id);

    if (!workOrder) return res.status(404).json({ message: 'Work Order not found.' });

    workOrder.is_active = !workOrder.is_active;
    await workOrder.save();

    res.status(200).json({
      message: `Work Order has been ${workOrder.is_active ? 'activated' : 'deactivated'}.`,
      data: workOrder,
    });
  } catch (error) {
    console.error('Error toggling work order status:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};
