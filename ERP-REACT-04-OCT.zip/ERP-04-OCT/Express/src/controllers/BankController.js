import { validationResult } from 'express-validator';
import { sequelize } from '../models/index.js';
import fs from 'fs';
import path from 'path';

const { BankGuarantee } = sequelize.models;
import { log } from "../services/LogService.js";
function toYMD(dateStr) {
  if (!dateStr) return null;
  const [d, m, y] = dateStr.split("-");
  if (!d || !m || !y) return null;
  return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
}
export const getAllBGsForWorkOrder = async (req, res) => {
  try {
    const { workOrderId } = req.params;
    const bankGuarantees = await BankGuarantee.findAll({
      where: { work_order_id: workOrderId },
      order: [['bg_date', 'DESC']],
    });
    await log({
      req,
      action: "READ",
      page_name: "ALL Bank WORKORDER PAGE",
    //   target: `Employee ID: ${employee.id}`,
    });
    res.status(200).json({
      message: 'Bank Guarantees fetched successfully.',
      data: bankGuarantees,
    });
  } catch (error) {
    console.error('Error fetching bank guarantees:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};
/**
 * CREATE a new Bank Guarantee
 */

export const createBG = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { work_order_id, bg_no, bg_date, bg_validity, bg_amount } = req.body;

  try {
   
    // Prepare data for creation, converting dates to the required YYYY-MM-DD format.
    const bgData = {
      work_order_id,
      bg_no,
      bg_date: toYMD(bg_date), // Convert the date
      bg_validity: toYMD(bg_validity), // Convert the date
      bg_amount,
    };

    // This file handling logic is correct.
    if (req.file && req.file.path) {
      bgData.document = req.file.path
    } else {
      return res.status(400).json({ message: "Document file is required." });
    }

    const newBG = await BankGuarantee.create(bgData);
        await log({
          req,
          action: "CREATE",
          page_name: "CREATE Bank Guarantee PAGE",
          target: ` ID: ${newBG.id}`,
        });
    res.status(201).json({ message: 'Bank Guarantee created successfully!', data: newBG });
  } catch (error) {
    console.error('Error creating bank guarantee:', error);
    // Provide a more specific error message if possible
    if (error.name === 'SequelizeDatabaseError') {
      return res.status(400).json({ message: 'Invalid data provided, please check date formats and other fields.' });
    }
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
};
/**
 * DELETE a Bank Guarantee
 */
export const deleteBG = async (req, res) => {
  try {
    const { id } = req.params;
    const bankGuarantee = await BankGuarantee.findByPk(id);

    if (!bankGuarantee) {
      return res.status(404).json({ message: 'Bank Guarantee not found.' });
    }

    // Delete the associated file from the server
    if (bankGuarantee.document) {
      const filePath = path.join('public', bankGuarantee.document);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    await bankGuarantee.destroy();
        await log({
          req,
          action: "DELETE",
          page_name: "DELETE BANK GURANTEE PAGE",
        target: `BankGuarantee ID: ${bankGuarantee.id}, WorkOrder ID: ${bankGuarantee.work_order_id}`,
        });
    res.status(200).json({ message: 'Bank Guarantee deleted successfully.' });
  } catch (error) {
    console.error('Error deleting bank guarantee:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
}