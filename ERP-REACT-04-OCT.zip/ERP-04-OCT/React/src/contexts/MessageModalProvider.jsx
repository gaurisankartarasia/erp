import React, { createContext, useContext, useState, useCallback } from "react";
import MessageModal from "@/components/common/modals/MessageModal";

const MessageContext = createContext(null);

export function MessageProvider({ children }) {
  const [modalState, setModalState] = useState({
    isOpen: false,
    message: "",
    variant: "info",
  });

  const showMessage = useCallback(({ message, variant = "info" }) => {
    setModalState({
      isOpen: true,
      message,
      variant,
    });
  }, []);

  const handleClose = useCallback(() => {
    setModalState((prev) => ({
      ...prev,
      isOpen: false,
    }));
  }, []);

  const api = {
    info: (message) => showMessage({ message, variant: "info" }),
    success: (message) => showMessage({ message, variant: "success" }),
    warning: (message) => showMessage({ message, variant: "warning" }),
    error: (message) => showMessage({ message, variant: "danger" }),
  };

  return (
    <MessageContext.Provider value={api}>
      {children}
      <MessageModal
        isOpen={modalState.isOpen}
        onClose={handleClose}
        message={modalState.message}
        variant={modalState.variant}
      />
    </MessageContext.Provider>
  );
}

export function useMessage() {
  const ctx = useContext(MessageContext);
  if (!ctx) {
    throw new Error("useMessage must be used within a MessageProvider");
  }
  return ctx;
}
