import {
  MdOutlineDashboard,
  MdOutlineTune,
  MdOutlineBusiness,
  MdOutlineApartment,
  MdOutlineBadge,
  MdOutlineAccountBalanceWallet,
  MdOutlineLayers,
  MdOutlineCategory,
  MdOutlinePersonAddAlt,
  MdOutlineStorefront,
  MdOutlineTrendingUp,
  MdOutlineSchema,
  MdOutlineSummarize,
  MdOutlineTaskAlt,
  MdOutlineFormatListBulleted,
  MdOutlineHistory,
  MdOutlineAssignmentInd,
  MdOutlinePayments,
  MdOutlinePolicy,
  MdOutlineAccountTree,
  MdOutlineCurrencyRupee,
  MdOutlineEventBusy,
  MdOutlineClass,
  MdOutlineDateRange,
  MdOutlineSend,
  MdOutlineReceiptLong,
  MdOutlineGroup,
  MdOutlineAdminPanelSettings,
  MdAccountTree,
  MdReceiptLong,
  MdFactCheck,
  MdApproval,
  MdPostAdd,
} from "react-icons/md";
import { permissions } from "@/utils/permissions";

export const navItems = [
  {
    href: "/",
    icon: MdOutlineDashboard,
    label: "Dashboard",
  },
  {
    href: "/page-permissions",
    icon: MdOutlineAdminPanelSettings,
    label: "Page Permissions",
    permission: permissions.PAGE_PERMISSIONS,
  },

  {
    label: "Master",
    icon: MdOutlineTune,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/clients",
        icon: MdOutlineBusiness,
        label: "Manage Client",
        permission: permissions.MANAGE_CLIENT,
      },
      {
        href: "/company-profile",
        icon: MdOutlineApartment,
        label: "Company Profile",
        permission: permissions.COMPANY_PROFILE,
      },
      {
        href: "/designations",
        icon: MdOutlineBadge,
        label: "Manage Designations",
        permission: permissions.MANAGE_DESIGNATIONS,
      },
      {
        href: "/contributions",
        icon: MdOutlineAccountBalanceWallet,
        label: "Manage EPF/ESI",
        permission: permissions.MANAGE_EPF_ESI,
      },
      {
        href: "/manage-unit",
        icon: MdOutlineLayers,
        label: "Manage Unit",
        permission: permissions.MANAGE_UNIT,
      },
      {
        href: "/manage-item",
        icon: MdOutlineCategory,
        label: "Manage Item",
        permission: permissions.MANAGE_ITEM,
      },
      {
        href: "/master/vacancies",
        icon: MdOutlinePersonAddAlt,
        label: "Manage Vacancy",
        permission: permissions.MANAGE_VACANCY,
      },
      {
        href: "/master/vendors",
        icon: MdOutlineStorefront,
        label: "Manage Vendor",
        permission: permissions.MANAGE_VENDOR,
      },
      {
        href: "/employees",
        icon: MdOutlineGroup,
        label: "Manage Employees",
        permission: permissions.MANAGE_EMPLOYEES,
      },
    ],
  },
  {
    icon: MdAccountTree,
    label: "Workflow",
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/attendance",
        icon: MdOutlineGroup,
        label: "Attendance Entry",
        permission: permissions.ATTENDANCE_ENTRY,
      },
      {
        href: "/workorders",
        icon: MdOutlineGroup,
        label: "Work Orders",
        permission: permissions.WORK_ORDERS,
      },
      {
        href: "/staff-expenses",
        icon: MdOutlineGroup,
        label: "Staff Expenses Entry",
        permission: permissions.STAFF_EXPENSES_ENTRY,
      },
      {
        href: "/supplierexpenses",
        icon: MdReceiptLong,
        label: "Vendor Expenses Entry",
        permission: permissions.SUPPLIER_EXPENSES_ENTRY,
      },
      {
        href: "/expenses-verification",
        icon: MdFactCheck,
        label: "Expenses Verification",
        permission: permissions.EXPENSES_VERIFICATION,
      },
      {
        href: "/expenses-approve",
        icon: MdApproval,
        label: "Expenses Approval",
        permission: permissions.EXPENSES_APPROVAL,
      },
        {
        href: "/salary-statement",
        icon: MdOutlineGroup,
        label: "Salary Statement",
        permission: permissions.SALARY_STATEMENT,
      },
      {
        href: "/invoice",
        icon: MdApproval,
        label: "Invoice Register",
        permission: permissions.INVOICE_REGISTER,
      },
     
      {
        href: "/workflow/dispatch-register",
        icon: MdApproval,
        label: "Working Dispatch ",
        permission: permissions.WORKING_DISPATCH,
      },
         {
      href: "/payment-receive",
      icon: MdPostAdd, 
      label: "Payment Receive",
      permission: null,
     },

     {
      href: "/payment-receive-reports",
      icon: MdPostAdd, 
      label: "Payment Receive Reports",
      permission: null,
     },
      {
        href: "/tax-entry",
        icon: MdApproval,
        label: "Tax Entry ",
        permission: permissions.TAX_ENTRY,
      },
    ],
  },
    {
    label: "Reports",
    icon: MdOutlineTrendingUp,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/employee-details",
        icon: MdOutlineSchema,
        label: "Employee Details",
        permission: permissions.EMPLOYEE_REPORTS,
      },
    {
        href: "/expense-report",
        icon: MdOutlineSchema,
        label: "Expense Reports",
        permission: permissions.EXPENSE_REPORTS,
      },
      
       {
        href: "/leave-reports",
        icon: MdOutlineSchema,
        label: "Leave Reports",
        permission: permissions.EXPENSE_REPORTS,
      },
      
    ],
  },
   {
    label: "Tools",
    icon: MdOutlineTrendingUp,
    permission: null,
    isSubmenu: true,
    subItems: [
     
      {
        href: "/reminderschedulers",
        icon: MdOutlineSchema,
        label: "Reminder Schedulers",
        permission: permissions.EXPENSE_REPORTS,
      },
      
    ],
  },
  {
    label: "Increments",
    icon: MdOutlineTrendingUp,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/incrementschemes",
        icon: MdOutlineSchema,
        label: "Increment Schemes",
        permission: permissions.INCREMENT_SCHEMES,
      },
      {
        href: "/increment-reports",
        icon: MdOutlineSummarize,
        label: "Increment Reports",
        permission: permissions.INCREMENT_REPORTS,
      },
    ],
  },
  {
    label: "Tasks",
    icon: MdOutlineTaskAlt,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/tasks",
        icon: MdOutlineFormatListBulleted,
        label: "Tasks",
        permission: permissions.TASKS,
      },
      {
        href: "/tasks/history",
        icon: MdOutlineHistory,
        label: "Tasks History",
        permission: permissions.TASKS_HISTORY,
      },
      {
        href: "/tasks/all-employees",
        icon: MdOutlineAssignmentInd,
        label: "All Employee Tasks",
        permission: permissions.ALL_EMPLOYEE_TASKS,
      },
    ],
  },
  {
    label: "Payroll",
    icon: MdOutlinePayments,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/salary-components",
        icon: MdOutlinePolicy,
        label: "Salary Components",
        permission: permissions.SALARY_COMPONENTS,
      },
      {
        href: "/salary-stucture",
        icon: MdOutlineAccountTree,
        label: "Salary Structure",
        permission: permissions.SALARY_STRUCTURE,
      },
      {
        href: "/salary-payroll",
        icon: MdOutlineCurrencyRupee,
        label: "Generate Salary",
        permission: permissions.GENERATE_SALARY,
      },
    ],
  },
  {
    label: "Leaves",
    icon: MdOutlineEventBusy,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/leave-types",
        icon: MdOutlineClass,
        label: "Leave Types",
        permission: permissions.LEAVE_TYPES,
      },
      {
        href: "/manage-leaves",
        icon: MdOutlineDateRange,
        label: "Manage Leaves",
        permission: permissions.MANAGE_LEAVES,
      },
      {
        href: "/request-leave",
        icon: MdOutlineSend,
        label: "Request Leave",
        permission: permissions.REQUEST_LEAVE,
      },

      {
        href: "/tax-entry",
        icon: MdPostAdd,
        label: "Tax Entry",
        permission: permissions.TAX_ENTRY,
      },
    ],
  },
  {
    href: "/log",
    icon: MdOutlineReceiptLong,
    label: "Activity Log",
    permission: permissions.ACTIVITY_LOG,
  },
];
