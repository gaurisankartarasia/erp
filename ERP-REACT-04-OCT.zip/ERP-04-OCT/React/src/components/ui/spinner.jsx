import React from "react";
import "./spinner.css";

export function Spinner({ color = "#808080", size = 34 }) {
  const bars = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <div
      className="loader"
      style={{
        width: size,
        height: size,
      }}
    >
      {bars.map((bar) => (
        <div
          key={bar}
          className={`bar${bar}`}
          style={{ background: color }}
        ></div>
      ))}
    </div>
  );
}
