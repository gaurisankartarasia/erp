import React, { useState, useEffect } from "react";
import apiClient from "@/api/axiosConfig";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/spinner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const PermissionSelector = ({ selectedPermissions, onSelectionChange }) => {
  const [permissions, setPermissions] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchPermissions = async () => {
      try {
        const response = await apiClient.get("/page-permissions/permissions");
        const grouped = response.data.reduce((acc, permission) => {
          const page = permission.page_name || "General";
          if (!acc[page]) {
            acc[page] = [];
          }
          acc[page].push(permission);
          return acc;
        }, {});
        setPermissions(grouped);
      } catch (err) {
        setError("Failed to load permissions.");
      } finally {
        setLoading(false);
      }
    };
    fetchPermissions();
  }, []);

  const handleCheckboxChange = (permissionId) => {
    const newSelection = new Set(selectedPermissions);
    if (newSelection.has(permissionId)) {
      newSelection.delete(permissionId);
    } else {
      newSelection.add(permissionId);
    }
    onSelectionChange(Array.from(newSelection));
  };

  if (loading)
    return (
      <div className="flex justify-center p-4">
        <Spinner />
      </div>
    );
  if (error)
    return (
      <Alert variant="destructive">
        <Terminal className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  const allPermissions = Object.values(permissions).flat();
  return (
    <div className="space-y-6">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>SL No</TableHead>
            <TableHead>Page Name</TableHead>
            <TableHead>Short Code</TableHead>
            <TableHead className="text-center">
              <div className="flex items-center justify-center space-x-2">
                <span>Permission</span>
                <Checkbox
                className={"bg-white"}
                  checked={selectedPermissions.length === allPermissions.length}
                  indeterminate={
                    selectedPermissions.length > 0 &&
                    selectedPermissions.length < allPermissions.length
                  }
                  onCheckedChange={(checked) => {
                    if (checked) {
                      onSelectionChange(allPermissions.map((p) => p.id));
                    } else {
                      onSelectionChange([]);
                    }
                  }}
                />
                
              </div>
            </TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          {allPermissions.map((permission, i) => (
            <TableRow key={permission.id}>
              <TableCell>{i + 1}</TableCell>
              <TableCell>{permission.page_name}</TableCell>
              <TableCell>{permission.code_name}</TableCell>
              <TableCell className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Checkbox
                    id={`perm-${permission.id}`}
                    checked={selectedPermissions.includes(permission.id)}
                    onCheckedChange={() => handleCheckboxChange(permission.id)}
                  />
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default PermissionSelector;
