import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import clsx from "clsx";

const colorMap = {
  blue: "bg-blue-700 hover:bg-blue-600",
  orange: "bg-orange-700 hover:bg-orange-600",
  red: "bg-red-700 hover:bg-red-600",
  green: "bg-green-700 hover:bg-green-600",
};

export const DashboardCard = ({ title, value, icon: Icon, color = "blue" }) => {

  return (
    <Card
      className={clsx(
        "text-white",
        colorMap[color] || colorMap.blue
      )}
      
    >
     
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {Icon && <Icon className="h-4 w-4" />}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
};
