import React, { useEffect, useState } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/pages/employee/custom/FormInput";
import FormSelect from "@/pages/employee/custom/FormSelect";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Button } from "@/components/ui/button";
import ShadcnDataTable from "@/components/common/DataTable";
// import ShadcnDataTable from "./DataTable";  // adjust path as necessary

const PaymentReceiveReport = () => {
  const navigate = useNavigate();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      bill_no: "",
      client_name: "",
      from_date: "",
      to_date: "",
    },
  });

  const { handleSubmit, setValue, watch, reset } = methods;
  const selectedBillNo = watch("bill_no");

  const [billOptions, setBillOptions] = useState([]);
  const [clientOptions, setClientOptions] = useState([]);
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [loadingBills, setLoadingBills] = useState(false);
  const [loadingClients, setLoadingClients] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Table state needed for ShadcnDataTable
  const [currentPage, setCurrentPage] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");

  // Fetch all bill numbers
  useEffect(() => {
    const fetchBillNumbers = async () => {
      setLoadingBills(true);
      try {
        const res = await apiClient.get("/payment-receive-report/all-bill-numbers");
        if (res.data.success && Array.isArray(res.data.billNumbers)) {
          const options = res.data.billNumbers.map((bn) => ({
            label: bn,
            value: bn,
          }));
          setBillOptions(options);
        } else {
          message.error("Failed to load bill numbers.");
        }
      } catch (error) {
        console.error("Error fetching bill numbers:", error);
        message.error("Error loading bill numbers.");
      } finally {
        setLoadingBills(false);
      }
    };

    fetchBillNumbers();
  }, [message]);

  // Fetch client names when bill_no is selected
  useEffect(() => {
    if (!selectedBillNo) {
      setClientOptions([]);
      setValue("client_name", "");
      return;
    }

    const fetchClientNames = async () => {
      setLoadingClients(true);
      try {
        const res = await apiClient.get("/payment-receive-report/clients-by-bill-numbers", {
          params: { bill_no: selectedBillNo },
        });
        if (res.data.success && Array.isArray(res.data.clientNames)) {
          const options = res.data.clientNames.map((name) => ({
            label: name,
            value: name,
          }));
          setClientOptions(options);
        } else {
          message.warning("No client names found for this bill.");
        }
      } catch (error) {
        console.error("Error fetching client names:", error);
        message.error("Error loading client names.");
      } finally {
        setLoadingClients(false);
      }
    };

    fetchClientNames();
  }, [selectedBillNo, setValue, message]);

  // Search handler
  const onSubmit = async (formData) => {
    if (!formData.bill_no) {
      message.error("Bill number is required.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await apiClient.get("/payment-receive-report/history", {
        params: {
          bill_no: formData.bill_no,
          from_date: formData.from_date || undefined,
          to_date: formData.to_date || undefined,
        },
      });

      if (res.data.success && Array.isArray(res.data.data)) {
        setPaymentHistory(res.data.data);
        setCurrentPage(1);  // reset pagination on new search
      } else {
        message.warning("No payment history found.");
        setPaymentHistory([]);
      }
    } catch (error) {
      console.error("Error fetching payment history:", error);
      message.error("Failed to load payment history.");
      setPaymentHistory([]);
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    setPaymentHistory([]);
    setCurrentPage(1);
    setSearchTerm("");
    setSortBy(null);
    setSortOrder("asc");
  };

  // Define columns for data table
  const columns = [
    {
      header: "Sl#",
      accessorKey: "id",
      cell: (info) => paymentHistory.indexOf(info.row.original) + 1,
      enableSorting: false,
    },
    {
      header: "Invoice Number",
      accessorKey: "bill_no",
      enableSorting: true,
    },
    {
      header: "Client Name",
      accessorKey: "client_name",
      enableSorting: true,
    },
    {
      header: "Receive Date",
      accessorKey: "release_date",
      enableSorting: true,
    },
    {
      header: "Receive Amount",
      accessorKey: "release_amount",
      enableSorting: true,
      cell: (info) => Number(info.getValue()).toFixed(2),
    },
    {
      header: "Deduct Amount",
      accessorKey: "tax_deduct",
      enableSorting: true,
      cell: (info) => Number(info.getValue()).toFixed(2),
    },
    {
      header: "Pending Amount",
      accessorKey: "pending_amount",
      enableSorting: true,
      cell: (info) => Number(info.getValue()).toFixed(2),
    },
    {
      header: "Remarks",
      accessorKey: "remarks",
      enableSorting: false,
    },
  ];

  // Build the tableState object to pass to DataTable
  const tableState = {
    loading: submitting,
    totalItems: paymentHistory.length,
    currentPage,
    setCurrentPage,
    entriesPerPage,
    setEntriesPerPage,
    searchTerm,
    setSearchTerm,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
  };

  return (
    <FormProvider {...methods}>
      <FormLayout
        title="Payment Receive Report"
        backPath="/payment-receive"
        isSubmitting={submitting}
        submitText="Show"
        isLoading={loadingBills || loadingClients}
      >
        <div className="col-span-2">
          <div className="grid grid-cols-4 gap-6">
            <FormSelect
              name="bill_no"
              label="Bill No"
              options={billOptions}
              rules={{ required: "Bill No is required" }}
              disabled={loadingBills}
            />
            <FormSelect
              name="client_name"
              label="Client Name"
              options={clientOptions}
              disabled={!selectedBillNo || loadingClients}
              rules={{ required: "Client Name is required" }}
            />
            <FormInput name="from_date" label="From Date" type="date" />
            <FormInput name="to_date" label="To Date" type="date" />
            <div className="mt-6 flex gap-3 col-span-4">
              <Button
                type="button"
                variant="success"
                onClick={handleSubmit(onSubmit)}
                disabled={submitting}
              >
                SHOW
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleReset}
                disabled={submitting}
              >
                RESET
              </Button>
            </div>
          </div>
        </div>

        {/* Payment History Table */}
        <div className="mt-8 col-span-2">
          <h3 className="text-lg font-semibold mb-2">
            Payment History for Bill: {selectedBillNo || "N/A"}
          </h3>
          {paymentHistory.length === 0 ? (
            <div className="text-center py-4 text-gray-500">
              {selectedBillNo
                ? "No payment history found for this bill."
                : "Select a Bill No and click SHOW."}
            </div>
          ) : (
            <ShadcnDataTable
              columns={columns}
              data={paymentHistory}
              tableState={tableState}
            />
          )}
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default PaymentReceiveReport;
