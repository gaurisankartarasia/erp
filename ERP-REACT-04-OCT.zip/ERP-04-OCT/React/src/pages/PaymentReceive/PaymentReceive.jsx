// // import React, { useEffect, useState } from "react";
// // import { useForm, FormProvider } from "react-hook-form";
// // import { useNavigate, useParams } from "react-router-dom";
// // import FormLayout from "@/components/layouts/FormLayout";
// // import FormInput from "@/pages/employee/custom/FormInput";
// // import FormSelect from "@/pages/employee/custom/FormSelect";
// // import apiClient from "@/api/axiosConfig";
// // import { useMessageModal } from "@/hooks/useMessageModal";
// // import { Button } from "@/components/ui/button";

// // const PaymentReceive = () => {
// //   const { id } = useParams();
// //   const navigate = useNavigate();
// //   const message = useMessageModal();

// //   const methods = useForm({
// //     defaultValues: {
// //       bill_no: "",
// //       bill_date: "",
// //       client_name: "",
// //       bill_amount: "",
// //       subject: "",
// //       release_date: "",
// //       release_amount: "",
// //       tax_deduct: "",
// //       pending_amount: "",
// //       remarks: "",
// //     }
// //     ,
// //   });

// //   const { handleSubmit, reset, setValue, watch } = methods;

// //   const [billOptions, setBillOptions] = useState([]);
// //   const [isSubmitting, setIsSubmitting] = useState(false);
// //   const [isLoading, setIsLoading] = useState(!!id);
// //   const [fetchingBillData, setFetchingBillData] = useState(false);


// //   const [billAmount, releaseAmount, taxDeduct] = watch([
// //     "bill_amount",
// //     "release_amount",
// //     "tax_deduct",
// //   ]);


// //   const selectedBillNo = watch("bill_no");




// //   useEffect(() => {
// //     const bill = parseFloat(billAmount) || 0;
// //     const release = parseFloat(releaseAmount) || 0;
// //     const tax = parseFloat(taxDeduct) || 0;
// //     const pending = bill - (release + tax);
// //     setValue("pending_amount", pending.toFixed(2));
// //   }, [billAmount, releaseAmount, taxDeduct, setValue]);


// //   // Fetch bill numbers for dropdown on mount
// //   useEffect(() => {
// //     const fetchBillNumbers = async () => {
// //       try {
// //         const res = await apiClient.get("/payment-receive/bill-numbers");
// //         if (res.data.success && Array.isArray(res.data.billNumbers)) {
// //           const formatted = res.data.billNumbers.map((billNo) => ({
// //             value: billNo,
// //             label: billNo,
// //           }));
// //           setBillOptions(formatted);
// //         } else {
// //           message.error("Failed to fetch bill numbers.");
// //         }
// //       } catch (error) {
// //         message.error("Failed to fetch bill numbers.");
// //       }
// //     };

// //     fetchBillNumbers();
// //   }, [message]);

// //   // If editing existing payment by id, fetch data on mount
// //   useEffect(() => {
// //     if (id) {
// //       const fetchData = async () => {
// //         setIsLoading(true);
// //         try {
// //           const res = await apiClient.get(`/payment-receive/${id}`);
// //           reset(res.data);
// //         } catch {
// //           message.error("Failed to fetch payment data.");
// //         } finally {
// //           setIsLoading(false);
// //         }
// //       };
// //       fetchData();
// //     }
// //   }, [id, reset, message]);



// //   useEffect(() => {
// //     if (!selectedBillNo) {
// //       // Clear fields if no bill is selected
// //       setValue("bill_date", "");
// //       setValue("client_name", "");
// //       setValue("bill_amount", "");
// //       setValue("subject", "");
// //       setValue("release_date", "");
// //       setValue("release_amount", "");
// //       setValue("tax_deduct", "");
// //       setValue("pending_amount", "");
// //       setValue("remarks", "");
// //       return;
// //     }

// //     const fetchBillDetails = async () => {
// //       setFetchingBillData(true);
// //       try {
// //         const res = await apiClient.get('/payment-receive/get-data-by-bill', {
// //           params: { bill_no: selectedBillNo }
// //         });

// //         if (res.data.success && res.data.invoices.length > 0) {
// //           const invoice = res.data.invoices[0];

// //           setValue("bill_date", invoice.date || "");
// //           setValue("client_name", invoice.client_name || "");
// //           setValue("bill_amount", invoice.grand_total || "");
// //           setValue("subject", invoice.subject || "");
// //           setValue("release_date", "");
// //           setValue("release_amount", "");
// //           setValue("tax_deduct", "");
// //           setValue("remarks", "");

// //           // ✅ Set initial pending amount from backend response
// //           setValue("pending_amount", res.data.pending_amount || "");
// //         } else {
// //           message.error("No invoices found for selected Bill No.");
// //         }
// //       } catch (error) {
// //         message.error("Failed to fetch details for selected Bill No.");
// //       } finally {
// //         setFetchingBillData(false);
// //       }
// //     };

// //     fetchBillDetails();
// //   }, [selectedBillNo, setValue, message]);



// //   const onSubmit = async (data) => {
// //     setIsSubmitting(true);
// //     try {
// //       if (id) {
// //         await apiClient.put(`/payment-receive/edit/${id}`, data);
// //         message.success("Payment updated successfully.");
// //       } else {
// //         await apiClient.post("/payment-receive/add", data);
// //         message.success("Payment added successfully.");
// //       }
// //       navigate("/payment-receive");
// //     } catch (err) {
// //       message.error(err.response?.data?.message || "Something went wrong.");
// //     } finally {
// //       setIsSubmitting(false);
// //     }
// //   };

// //   return (
// //     <FormProvider {...methods}>
// //       <FormLayout
// //         title={id ? "Edit Payment Receive" : "Add Payment Receive"}
// //         backPath="/payment-receive"
// //         // onSubmit={handleSubmit(onSubmit)}
// //         isSubmitting={isSubmitting}
// //         submitText={id ? "Update" : "Submit"}
// //         // onCancel={() => navigate("/payment-receive")}
// //         // onReset={() => reset()}
// //         isLoading={isLoading || fetchingBillData}
// //       >
// //         <div className="col-span-2">
// //           {/* Top Section */}
// //           <div className="grid grid-cols-2 gap-6">
// //             <FormSelect
// //               name="bill_no"
// //               label="Bill No"
// //               options={billOptions}
// //               rules={{ required: "Bill No is required" }}
// //             />
// //             <FormInput
// //               name="bill_date"
// //               label="Bill Date"
// //               type="date"
// //               rules={{ required: "Bill Date is required" }}
// //               readOnly
// //             />
// //             <FormInput
// //               name="client_name"
// //               label="Client Name"
// //               rules={{ required: "Client Name is required" }}
// //               readOnly
// //             />
// //             <FormInput
// //               name="bill_amount"
// //               label="Bill Amount"
// //               type="number"
// //               rules={{ required: "Bill Amount is required" }}
// //               readOnly
// //             />
// //             <div className="col-span-4">
// //               <FormInput
// //                 name="subject"
// //                 label="Subject"
// //                 type="textarea"
// //                 rules={{ required: "Subject is required" }}
// //                 readOnly
// //               />
// //             </div>
// //           </div>
// //         </div>

// //         {/* Middle Row Input Section Styled like Table */}
// //         <div className="mt-8 border border-gray-300 p-4 bg-gray-50 col-span-2">
// //           <div className="grid grid-cols-5 gap-4 items-end">


// //             <FormInput
// //               name="release_date"
// //               label="Release Date"
// //               type="date"
// //               rules={{ required: "Release Date is required" }}
// //             />
// //             <FormInput
// //               name="release_amount"
// //               label="Release Amount"
// //               type="number"
// //               rules={{ required: "Release Amount is required" }}
// //             />

// //             <FormInput
// //               name="tax_deduct"
// //               label="Tax Deduct"
// //               type="number"
// //               rules={{ required: "Tax Deduct is required" }}
// //             />
// //             <FormInput
// //               name="pending_amount"
// //               label="Pending Amount"
// //               type="number"
// //               readOnly
// //             />
// //             <FormInput name="remarks" label="Remarks" />
// //           </div>

// //           {/* Buttons */}
// //           <div className="mt-6 flex gap-3">
// //             <Button
// //               type="button" // change from submit to button to prevent default form submit
// //               variant="success"
// //               disabled={isSubmitting}
// //               onClick={handleSubmit(onSubmit)} // trigger react-hook-form submit manually
// //             >
// //               Submit
// //             </Button>


// //             <Button
// //               type="button"
// //               variant="destructive"
// //               onClick={() => navigate("/payment-receive")}
// //             >
// //               Cancel
// //             </Button>

// //             <Button
// //               type="button"
// //               variant="secondary"
// //               onClick={() => reset()}
// //             >
// //               Reset
// //             </Button>

// //             <Button
// //               type="button"
// //               variant="default"
// //             >
// //               View
// //             </Button>
// //           </div>
// //         </div>

// //         {/* Table Display Placeholder */}
// //         <div className="mt-8 col-span-2">
// //           <table className="table-auto w-full border mt-4">
// //             <thead className="bg-gray-100">
// //               <tr>
// //                 <th>Sl#</th>
// //                 <th>Receive Date</th>
// //                 <th>Receive Amount</th>
// //                 <th>Tax Deduct</th>
// //                 <th>Pending Amount</th>
// //                 <th>Remarks</th>
// //                 <th>Action</th>
// //               </tr>
// //             </thead>
// //             <tbody>
// //               {/* TODO: Map your receive rows here */}
// //             </tbody>
// //           </table>
// //         </div>
// //       </FormLayout>
// //     </FormProvider>
// //   );
// // };

// // export default PaymentReceive;
// import React, { useEffect, useState } from "react";
// import { useForm, FormProvider } from "react-hook-form";
// import { useNavigate, useParams } from "react-router-dom";
// import FormLayout from "@/components/layouts/FormLayout";
// import FormInput from "@/pages/employee/custom/FormInput";
// import FormSelect from "@/pages/employee/custom/FormSelect";
// import apiClient from "@/api/axiosConfig";
// import { useMessageModal } from "@/hooks/useMessageModal";
// import { Button } from "@/components/ui/button";

// const PaymentReceive = () => {
//   const { id } = useParams();
//   const navigate = useNavigate();
//   const message = useMessageModal();

//   const methods = useForm({
//     defaultValues: {
//       bill_no: "",
//       bill_date: "",
//       client_name: "",
//       bill_amount: "",
//       subject: "",
//       release_date: "",
//       release_amount: "",
//       tax_deduct: "",
//       pending_amount: "",
//       remarks: "",
//     },
//   });

//   const { handleSubmit, reset, setValue, watch } = methods;

//   const [billOptions, setBillOptions] = useState([]);
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [isLoading, setIsLoading] = useState(!!id);
//   const [fetchingBillData, setFetchingBillData] = useState(false);
//   const [hasUserEditedReleaseOrTax, setHasUserEditedReleaseOrTax] = useState(false);

//   // Watch relevant fields
//   const billAmount = watch("bill_amount");
//   const releaseAmount = watch("release_amount");
//   const taxDeduct = watch("tax_deduct");
//   const selectedBillNo = watch("bill_no");

//   // Mark that user has started editing release_amount or tax_deduct
//   const handleFieldChange = (field) => (e) => {
//     setHasUserEditedReleaseOrTax(true);
//     setValue(field, e.target.value);
//   };

//   // Auto-calculate pending_amount only after user edits release_amount or tax_deduct
//   useEffect(() => {
//     if (!hasUserEditedReleaseOrTax) return;

//     const bill = parseFloat(billAmount) || 0;
//     const release = parseFloat(releaseAmount) || 0;
//     const tax = parseFloat(taxDeduct) || 0;
//     const pending = bill - (release + tax);
//     setValue("pending_amount", pending.toFixed(2));
//   }, [billAmount, releaseAmount, taxDeduct, hasUserEditedReleaseOrTax, setValue]);

//   // Fetch bill numbers for dropdown on mount
//   useEffect(() => {
//     const fetchBillNumbers = async () => {
//       try {
//         const res = await apiClient.get("/payment-receive/bill-numbers");
//         if (res.data.success && Array.isArray(res.data.billNumbers)) {
//           const formatted = res.data.billNumbers.map((billNo) => ({
//             value: billNo,
//             label: billNo,
//           }));
//           setBillOptions(formatted);
//         } else {
//           message.error("Failed to fetch bill numbers.");
//         }
//       } catch (error) {
//         message.error("Failed to fetch bill numbers.");
//       }
//     };

//     fetchBillNumbers();
//   }, [message]);

//   // If editing existing payment by id, fetch data on mount
//   useEffect(() => {
//     if (id) {
//       const fetchData = async () => {
//         setIsLoading(true);
//         try {
//           const res = await apiClient.get(`/payment-receive/${id}`);
//           reset(res.data);
//         } catch {
//           message.error("Failed to fetch payment data.");
//         } finally {
//           setIsLoading(false);
//         }
//       };
//       fetchData();
//     }
//   }, [id, reset, message]);

//   // Fetch invoice/payment details when bill_no changes
//   useEffect(() => {
//     if (!selectedBillNo) {
//       // Clear fields if no bill is selected
//       setValue("bill_date", "");
//       setValue("client_name", "");
//       setValue("bill_amount", "");
//       setValue("subject", "");
//       setValue("release_date", "");
//       setValue("release_amount", "");
//       setValue("tax_deduct", "");
//       setValue("pending_amount", "");
//       setValue("remarks", "");
//       setHasUserEditedReleaseOrTax(false); // reset auto-calc trigger
//       return;
//     }

//     const fetchBillDetails = async () => {
//       setFetchingBillData(true);
//       try {
//         const res = await apiClient.get('/payment-receive/get-data-by-bill', {
//           params: { bill_no: selectedBillNo }
//         });

//         if (res.data.success && res.data.invoices.length > 0) {
//           const invoice = res.data.invoices[0];

//           setValue("bill_date", invoice.date || "");
//           setValue("client_name", invoice.client_name || "");
//           setValue("bill_amount", invoice.grand_total || "");
//           setValue("subject", invoice.subject || "");
//           setValue("release_date", "");
//           setValue("release_amount", "");
//           setValue("tax_deduct", "");
//           setValue("remarks", "");

//           // Set initial pending amount from backend response
//           setValue("pending_amount", res.data.pending_amount || "");
//           setHasUserEditedReleaseOrTax(false); // reset auto-calc trigger
//         } else {
//           message.error("No invoices found for selected Bill No.");
//         }
//       } catch (error) {
//         message.error("Failed to fetch details for selected Bill No.");
//       } finally {
//         setFetchingBillData(false);
//       }
//     };

//     fetchBillDetails();
//   }, [selectedBillNo, setValue, message]);

//   const onSubmit = async (data) => {
//     setIsSubmitting(true);
//     try {
//       if (id) {
//         await apiClient.put(`/payment-receive/edit/${id}`, data);
//         message.success("Payment updated successfully.");
//       } else {
//         await apiClient.post("/payment-receive/add", data);
//         message.success("Payment added successfully.");
//       }
//       navigate("/payment-receive");
//     } catch (err) {
//       message.error(err.response?.data?.message || "Something went wrong.");
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <FormProvider {...methods}>
//       <FormLayout
//         title={id ? "Edit Payment Receive" : "Add Payment Receive"}
//         backPath="/payment-receive"
//         isSubmitting={isSubmitting}
//         submitText={id ? "Update" : "Submit"}
//         isLoading={isLoading || fetchingBillData}
//       >
//         <div className="col-span-2">
//           {/* Top Section */}
//           <div className="grid grid-cols-2 gap-6">
//             <FormSelect
//               name="bill_no"
//               label="Bill No"
//               options={billOptions}
//               rules={{ required: "Bill No is required" }}
//             />
//             <FormInput
//               name="bill_date"
//               label="Bill Date"
//               type="date"
//               rules={{ required: "Bill Date is required" }}
//               readOnly
//             />
//             <FormInput
//               name="client_name"
//               label="Client Name"
//               rules={{ required: "Client Name is required" }}
//               readOnly
//             />
//             <FormInput
//               name="bill_amount"
//               label="Bill Amount"
//               type="number"
//               rules={{ required: "Bill Amount is required" }}
//               readOnly
//             />
//             <div className="col-span-4">
//               <FormInput
//                 name="subject"
//                 label="Subject"
//                 type="textarea"
//                 rules={{ required: "Subject is required" }}
//                 readOnly
//               />
//             </div>
//           </div>
//         </div>

//         {/* Middle Row Input Section Styled like Table */}
//         <div className="mt-8 border border-gray-300 p-4 bg-gray-50 col-span-2">
//           <div className="grid grid-cols-5 gap-4 items-end">
//             <FormInput
//               name="release_date"
//               label="Release Date"
//               type="date"
//               rules={{ required: "Release Date is required" }}
//             />
//             <FormInput
//               name="release_amount"
//               label="Release Amount"
//               type="number"
//               rules={{ required: "Release Amount is required" }}
//               onChange={handleFieldChange("release_amount")}
//             />
//             <FormInput
//               name="tax_deduct"
//               label="Tax Deduct"
//               type="number"
//               rules={{ required: "Tax Deduct is required" }}
//               onChange={handleFieldChange("tax_deduct")}
//             />
//             <FormInput
//               name="pending_amount"
//               label="Pending Amount"
//               type="number"
//               readOnly
//             />
//             <FormInput name="remarks" label="Remarks" />
//           </div>

//           {/* Buttons */}
//           <div className="mt-6 flex gap-3">
//             <Button
//               type="button"
//               variant="success"
//               disabled={isSubmitting}
//               onClick={handleSubmit(onSubmit)}
//             >
//               Submit
//             </Button>
//             <Button
//               type="button"
//               variant="destructive"
//               onClick={() => navigate("/payment-receive")}
//             >
//               Cancel
//             </Button>
//             <Button
//               type="button"
//               variant="secondary"
//               onClick={() => reset()}
//             >
//               Reset
//             </Button>
//             <Button
//               type="button"
//               variant="default"
//             >
//               View
//             </Button>
//           </div>
//         </div>

//         {/* Table Display Placeholder */}
//         <div className="mt-8 col-span-2">
//           <table className="table-auto w-full border mt-4">
//             <thead className="bg-gray-100">
//               <tr>
//                 <th>Sl#</th>
//                 <th>Receive Date</th>
//                 <th>Receive Amount</th>
//                 <th>Tax Deduct</th>
//                 <th>Pending Amount</th>
//                 <th>Remarks</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {/* TODO: Map your receive rows here */}
//             </tbody>
//           </table>
//         </div>
//       </FormLayout>
//     </FormProvider>
//   );
// };

// export default PaymentReceive;
import React, { useEffect, useState } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/pages/employee/custom/FormInput";
import FormSelect from "@/pages/employee/custom/FormSelect";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Button } from "@/components/ui/button";

const PaymentReceive = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      bill_no: "",
      bill_date: "",
      client_name: "",
      bill_amount: "",
      subject: "",
      release_date: "",
      release_amount: "",
      tax_deduct: "",
      pending_amount: "",
      remarks: "",
    },
  });

  const { handleSubmit, reset, setValue, watch } = methods;

  const [billOptions, setBillOptions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);
  const [fetchingBillData, setFetchingBillData] = useState(false);
  const [paymentHistory, setPaymentHistory] = useState([]);

  // Watch relevant fields
  const billAmount = watch("bill_amount");
  const releaseAmount = watch("release_amount");
  const taxDeduct = watch("tax_deduct");
  const selectedBillNo = watch("bill_no");

  // Simplified handler for release_amount: updates state immediately
  const handleReleaseAmountChange = (e) => {
    setValue("release_amount", e.target.value, { shouldValidate: true });
  };

  // Simplified handler for tax_deduct: updates state immediately
  const handleTaxDeductChange = (e) => {
    setValue("tax_deduct", e.target.value, { shouldValidate: true });
  };

  // Auto-calculate pending_amount whenever billAmount, releaseAmount, or taxDeduct changes
  useEffect(() => {
    if (!billAmount) return;

    const bill = parseFloat(billAmount) || 0;
    const release = parseFloat(releaseAmount) || 0;
    const tax = parseFloat(taxDeduct) || 0;

    // Only run calculation if the user has entered values in the dynamic fields (release or tax)
    // This prevents overriding the API's pending_amount if the input fields are empty.
    if (release > 0 || tax > 0) {
      const pending = bill - (release + tax);
      // Use set value for pending amount
      setValue("pending_amount", pending.toFixed(2), { shouldValidate: false });
    }
  }, [billAmount, releaseAmount, taxDeduct, setValue]);

  // Fetch bill numbers for dropdown on mount
  useEffect(() => {
    const fetchBillNumbers = async () => {
      try {
        const res = await apiClient.get("/payment-receive/bill-numbers");
        if (res.data.success && Array.isArray(res.data.billNumbers)) {
          const formatted = res.data.billNumbers.map((billNo) => ({
            value: billNo,
            label: billNo,
          }));
          setBillOptions(formatted);
        } else {
          message.error("Failed to fetch bill numbers.");
        }
      } catch (error) {
        message.error("Failed to fetch bill numbers.");
      }
    };

    fetchBillNumbers();
  }, [message]);
  
  // Helper function to fetch bill details and payment history
  const fetchBillDetails = async (billNo) => {
    if (!billNo) return;
    setFetchingBillData(true);
    try {
      const res = await apiClient.get('/payment-receive/get-data-by-bill', {
        params: { bill_no: billNo }
      });

      if (res.data.success) {
        const invoice = res.data.invoices?.[0] || {};
        setValue("bill_date", invoice.date || "");
        setValue("client_name", invoice.client_name || "");
        setValue("bill_amount", invoice.grand_total || "");
        setValue("subject", invoice.subject || "");
        
        // Reset dynamic fields for new entry
        if (!id) {
            setValue("release_date", "");
            setValue("release_amount", "");
            setValue("tax_deduct", "");
            setValue("remarks", "");
        }

        // Set initial pending amount from API
        setValue("pending_amount", res.data.pending_amount || "");
        
        // Assuming paymentHistory is available in the API response
        setPaymentHistory(res.data.paymentHistory || []);

      } else {
        message.error("No invoices found for selected Bill No.");
        setPaymentHistory([]);
      }
    } catch (error) {
      console.error("Fetch bill details error:", error);
      message.error("Failed to fetch details for selected Bill No.");
      setPaymentHistory([]);
    } finally {
      setFetchingBillData(false);
    }
  };


  // If editing existing payment by id, fetch data on mount
  useEffect(() => {
    if (id) {
      const fetchData = async () => {
        setIsLoading(true);
        try {
          const res = await apiClient.get(`/payment-receive/${id}`);
          reset(res.data);
          if (res.data.bill_no) {
            await fetchBillDetails(res.data.bill_no);
          }
        } catch {
          message.error("Failed to fetch payment data.");
        } finally {
          setIsLoading(false);
        }
      };
      fetchData();
    }
  }, [id, reset, message]);

  // Fetch invoice/payment details when bill_no changes
  useEffect(() => {
    if (!selectedBillNo) {
      // Clear all fields if no bill is selected
      reset({
        bill_no: "",
        bill_date: "",
        client_name: "",
        bill_amount: "",
        subject: "",
        release_date: "",
        release_amount: "",
        tax_deduct: "",
        pending_amount: "",
        remarks: "",
      });
      setPaymentHistory([]);
      return;
    }

    if (!id || (id && selectedBillNo)) {
      fetchBillDetails(selectedBillNo);
    }
    
  }, [selectedBillNo, setValue, message, id, reset]); 

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    try {
      if (id) {
        await apiClient.put(`/payment-receive/edit/${id}`, data);
        message.success("Payment updated successfully.");
      } else {
        await apiClient.post("/payment-receive/add", data);
        message.success("Payment added successfully.");
      }
      navigate("/payment-receive");
    } catch (err) {
      message.error(err.response?.data?.message || "Something went wrong.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <FormProvider {...methods}>
      <FormLayout
        title={id ? "Edit Payment Receive" : "Add Payment Receive"}
        backPath="/payment-receive"
        isSubmitting={isSubmitting}
        submitText={id ? "Update" : "Submit"}
        isLoading={isLoading || fetchingBillData}
      >
        <div className="col-span-2">
          {/* Top Section - Use DISABLED for read-only fields since FormInput doesn't handle readOnly */}
          <div className="grid grid-cols-2 gap-6">
            <FormSelect
              name="bill_no"
              label="Bill No"
              options={billOptions}
              rules={{ required: "Bill No is required" }}
            />
            <FormInput
              name="bill_date"
              label="Bill Date"
              type="date"
              rules={{ required: "Bill Date is required" }}
              disabled // ⬅️ USED disabled INSTEAD OF readOnly
            />
            <FormInput
              name="client_name"
              label="Client Name"
              rules={{ required: "Client Name is required" }}
              disabled // ⬅️ USED disabled INSTEAD OF readOnly
            />
            <FormInput
              name="bill_amount"
              label="Bill Amount"
              type="number"
              rules={{ required: "Bill Amount is required" }}
              disabled // ⬅️ USED disabled INSTEAD OF readOnly
            />
            <div className="col-span-4">
              <FormInput
                name="subject"
                label="Subject"
                type="textarea"
                rules={{ required: "Subject is required" }}
                disabled // ⬅️ USED disabled INSTEAD OF readOnly
              />
            </div>
          </div>
        </div>

        {/* Middle Row Input Section (Editable fields) */}
        <div className="mt-8 border border-gray-300 p-4 bg-gray-50 col-span-2">
          <div className="grid grid-cols-5 gap-4 items-end">
            <FormInput
              name="release_date"
              label="Release Date"
              type="date"
              rules={{ required: "Release Date is required" }}
            />
            <FormInput
              name="release_amount"
              label="Release Amount"
              type="number"
              rules={{ required: "Release Amount is required" }}
              onChange={handleReleaseAmountChange} // Custom onChange to update state and trigger calculation
            />
            <FormInput
              name="tax_deduct"
              label="Tax Deduct"
              type="number"
              rules={{ required: "Tax Deduct is required" }}
              onChange={handleTaxDeductChange} // Custom onChange to update state and trigger calculation
            />
            <FormInput
              name="pending_amount"
              label="Pending Amount"
              type="number"
              disabled // ⬅️ USED disabled INSTEAD OF readOnly
            />
            <FormInput name="remarks" label="Remarks" />
          </div>

          {/* Buttons */}
          <div className="mt-6 flex gap-3">
            <Button
              type="button"
              variant="success"
              disabled={isSubmitting}
              onClick={handleSubmit(onSubmit)}
            >
              Submit
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={() => navigate("/payment-receive")}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => reset()}
            >
              Reset
            </Button>
            <Button
              type="button"
              variant="default"
            >
              View Bill
            </Button>
          </div>
        </div>

        {/* Table Display Placeholder (Payment History) */}
        <div className="mt-8 col-span-2">
          <h3 className="text-lg font-semibold mb-2">Payment History for Bill: {selectedBillNo}</h3>
          <table className="table-auto w-full border mt-4">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left">Sl#</th>
                <th className="px-4 py-2 text-left">Receive Date</th>
                <th className="px-4 py-2 text-right">Receive Amount</th>
                <th className="px-4 py-2 text-right">Tax Deduct</th>
                <th className="px-4 py-2 text-right">Pending Amount</th>
                <th className="px-4 py-2 text-left">Remarks</th>
                <th className="px-4 py-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {paymentHistory.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center py-4 text-gray-500">
                    {selectedBillNo ? "No previous payments found for this bill." : "Select a Bill No to view history."}
                  </td>
                </tr>
              ) : (
                paymentHistory.map((payment, index) => (
                  <tr key={payment.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="border px-4 py-2">{index + 1}</td>
                    <td className="border px-4 py-2">{payment.release_date}</td>
                    <td className="border px-4 py-2 text-right">{parseFloat(payment.release_amount).toFixed(2)}</td>
                    <td className="border px-4 py-2 text-right">{parseFloat(payment.tax_deduct).toFixed(2)}</td>
                    <td className="border px-4 py-2 text-right">{parseFloat(payment.pending_amount).toFixed(2)}</td>
                    <td className="border px-4 py-2">{payment.remarks}</td>
                    <td className="border px-4 py-2 text-center">
                      <Button 
                        variant="link" 
                        size="sm"
                        onClick={() => navigate(`/payment-receive/${payment.id}`)}
                      >
                        Edit
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default PaymentReceive;