import React, { useState, useEffect, useMemo } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import FormInput from "@/pages/employee/custom/FormInput";
import ShadcnDataTable from "@/components/common/DataTable";
import { Button } from "@/components/ui/button";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const ExpenseReportPage = () => {
  const methods = useForm({
    defaultValues: {
      from_date: "",
      to_date: "",
      payer_type: "",
      payer_id: "",
      status: "",
    },
  });
  const { handleSubmit, watch, setValue, getValues } = methods;

  const [payerOptions, setPayerOptions] = useState([]);
  const [apiUrl, setApiUrl] = useState("");
  const message = useMessageModal();
  const payerType = watch("payer_type");

  const { data, tableState } = useServerSideTable(apiUrl);

  const columns = useMemo(
    () => [
           {
      header: "SL No",
      cell: ({ row }) =>
        (tableState.currentPage - 1) * tableState.entriesPerPage + row.index + 1,
    },
      { accessorKey: "date", header: "Date", enableSorting: true },
      { accessorKey: "payer_type", header: "Payer Type", enableSorting: false },
      {
        id: "payer_name",
        header: "Payer Name",
        cell: ({ row }) =>
          row.original.staff?.name || row.original.supplier?.name || "N/A",
      },
      { accessorKey: "matter", header: "Matter", enableSorting: false },
      { accessorKey: "total_amt", header: "Total Amount", enableSorting: true },
      { accessorKey: "status", header: "Status", enableSorting: true },
    ],
    []
  );

  useEffect(() => {
    const fetchPayers = async () => {
      if (!payerType) {
        setPayerOptions([]);
        return;
      }
      try {
        const res = await apiClient.get(
          `/expense-verification/payers?type=${payerType}`
        );
        setPayerOptions(res.data.data);
      } catch {
        message.error(`Failed to load ${payerType} list.`);
      }
    };
    fetchPayers();
    setValue("payer_id", "");
  }, [payerType, message, setValue]);

  const onSearch = (data) => {
    const params = new URLSearchParams(data).toString();
    setApiUrl(`${import.meta.env.VITE_API_BASE_URL}/expense-reports?${params}`);
  };
  
  const handleCopy = async () => {
    const currentFilters = getValues();
    if (!currentFilters.from_date || !currentFilters.to_date) {
      message.error("Please select a date range to copy data.");
      return;
    }

    try {
      const params = new URLSearchParams(currentFilters).toString();
      const res = await apiClient.get(`/expense-reports/export?${params}&format=csv`);
      
      await navigator.clipboard.writeText(res.data);
      message.success("Report data copied to clipboard!");
    } catch (error) {
      message.error("Failed to copy data.");
    }
  };

  const handleExport = (format) => {
    const currentFilters = getValues();
    if (!currentFilters.from_date || !currentFilters.to_date) {
      message.error("Please select a date range to export.");
      return;
    }
    const params = new URLSearchParams(currentFilters).toString();
    const exportUrl = `${apiClient.defaults.baseURL}/expense-reports/export?${params}&format=${format}`;
    window.open(exportUrl, "_blank");
  };

  const handlePrint = () => {
    if (!data || data.length === 0) {
      message.error("No data to print.");
      return;
    }
    window.print();
  };

  const statusOptions = [
    { value: "pending", label: "Pending" },
    { value: "verified", label: "Verified" },
    { value: "approved", label: "Approved" },
    { value: "rejected", label: "Rejected" },
  ];

  const payerTypeOptions = [
    { value: "staff", label: "Staff" },
    { value: "supplier", label: "Supplier" },
  ];

  return (
    <FormProvider {...methods}>
      <PageLayout
        title="Expense Reports"
   
        topButtons={[
          { text: "Copy", onClick: handleCopy },
          { text: "CSV", onClick: () => handleExport("csv") },
          { text: "Excel", onClick: () => handleExport("excel") },
          { text: "Print", onClick: handlePrint },
        ]}
      >
        <div className="mb-4">
          <form onSubmit={handleSubmit(onSearch)}>
            <div className="grid grid-cols-5 gap-4 mb-4">
              <FormInput
                name="from_date"
                label="From Date"
                type="date"
                rules={{ required: true }}
              />
              <FormInput
                name="to_date"
                label="To Date"
                type="date"
                rules={{ required: true }}
              />
              <FormSelect
                name="payer_type"
                label="Type Name"
                options={payerTypeOptions}
                rules={{ required: true }}
              />
              <FormSelect
                name="status"
                label="Status"
                options={statusOptions}
                rules={{ required: true }}
              />
              <FormSelect
                name="payer_id"
                label="Name"
                options={payerOptions}
                disabled={!payerType}
                rules={{ required: true }}
              />
            </div>
            <div className="flex justify-end">
              <Button type="submit" disabled={tableState.loading}>
                {tableState.loading ? "Searching..." : "Search"}
              </Button>
            </div>
          </form>
        </div>

        <div className="print-section">
          <h2 className="text-xl font-bold mb-4">Expense Report</h2>
          {apiUrl && (
            <ShadcnDataTable
              columns={columns}
              data={data || []}
              tableState={tableState}
            />
          )}
        </div>
      </PageLayout>
    </FormProvider>
  );
};

export default ExpenseReportPage;
