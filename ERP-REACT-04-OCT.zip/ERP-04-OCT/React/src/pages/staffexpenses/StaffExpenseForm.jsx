import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, FormProvider } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/pages/employee/custom/FormInput";
import FormSelect from "@/pages/employee/custom/FormSelect";
import DocumentUploader from "@/components/common/forms/FormDocumentUpload";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const StaffExpenseFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      employee_id: "",
      date: "",
      expense_type: "",
      matter: "",
      approx_km: "",
      total_amt: "",
      document: null,
    },
  });

  const {
    handleSubmit,
    reset,
    formState: { isSubmitting },
  } = methods;

  const [nameOptions, setNameOptions] = useState([]);
  const [expenseTypeOptions, setExpenseTypeOptions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [dropdownsLoaded, setDropdownsLoaded] = useState(false); // ✅ new flag

  // Fetch dropdown options
  useEffect(() => {
    const fetchDropdowns = async () => {
      try {
        const res = await apiClient.get("/employee/employees");
        const names = res.data.data.map((emp) => ({
          label: emp.name,
          value: emp.id.toString(),
        }));
        setNameOptions(names);

        setExpenseTypeOptions([
          { label: "Client Visit", value: "client_visit" },
          { label: "Office Supplies", value: "office_supplies" },
        ]);

        setDropdownsLoaded(true); // ✅ mark dropdowns as ready
      } catch (error) {
        message.error("Failed to load dropdown options.");
      }
    };

    fetchDropdowns();
  }, [message]);

  // Fetch existing data for edit
  useEffect(() => {
    const fetchExpense = async () => {
      if (!id || !dropdownsLoaded) return; // ✅ wait for both

      setIsLoading(true);
      try {
        const res = await apiClient.get(`/staff-expenses/${id}`);
        const data = res.data;

        reset({
          employee_id: data.payer_id?.toString() || "",
          date: data.date || "",
          expense_type: data.expense_type || "",
          matter: data.matter || "",
          approx_km: data.approx_km || "",
          total_amt: data.total_amt || "",
          document: data.document || null,
        });
      } catch (error) {
        message.error("Failed to fetch expense data.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchExpense();
  }, [id, dropdownsLoaded, reset]);

  const onSubmit = async (formData) => {
    try {
      const payload = new FormData();

      Object.keys(formData).forEach((key) => {
        const value = formData[key];

        if (key === "document") {
          if (value instanceof File) {
            payload.append(key, value);
          } else if (typeof value === "string" && value !== "") {
            payload.append(key, value); // existing document path
          }
        } else if (value !== null && value !== undefined && value !== "") {
          payload.append(key, String(value));
        }
      });

      setIsLoading(true);

      if (id) {
        await apiClient.put(`/staff-expenses/edit/${id}`, payload, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        message.success("Expense updated successfully.");
      } else {
        await apiClient.post("/staff-expenses/add", payload, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        message.success("Expense added successfully.");
      }

      navigate("/staff-expenses");
    } catch (error) {
      console.error("Submit error:", error);
      message.error("Failed to submit the form.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <FormProvider {...methods}>
      <FormLayout
        title={id ? "Edit Staff Expense" : "Add Staff Expense"}
        backPath="/staff-expenses"
        onSubmit={handleSubmit(onSubmit)}
        isSubmitting={isSubmitting}
        submitText={id ? "Update" : "Submit"}
        onCancel={() => navigate("/staff-expenses")}
        onReset={() => reset()}
        isLoading={isLoading}
      >
        <div className="col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormSelect
              name="employee_id"
              label="Name"
              options={nameOptions}
              placeholder="Select Name"
              rules={{ required: "Employee is required" }}
              showSearch
            />
            <FormInput
              name="date"
              label="Date"
              type="date"
              rules={{ required: "Date is required" }}
            />
            <FormSelect
              name="expense_type"
              label="Expense Type"
              options={expenseTypeOptions}
              placeholder="Select Expense Type"
              rules={{ required: "Expense Type is required" }}
              showSearch
            />
            <FormInput
              name="matter"
              label="Matter Details"
              type="textarea"
              rows={3}
              rules={{ required: "Matter Details are required" }}
            />
            <FormInput
              name="approx_km"
              label="Approx Km"
              type="text"
              placeholder="Approx Km"
            />
            <FormInput
              name="total_amt"
              label="Amount"
              type="number"
              rules={{ required: "Amount is required" }}
            />
            <div className="md:col-span-2">
              <DocumentUploader
                name="document"
                label="Upload Support Documents"
                allowedTypes={["application/pdf"]}
                maxSizeMB={2}
                rules={{ required: !id ? "Document is required" : false }}
                folderName="staff-expenses"
              />
            </div>
          </div>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default StaffExpenseFormPage;
