// import React, { useMemo } from "react";
// import ShadcnDataTable from "@/components/common/DataTable";
// import PageLayout from "@/components/layouts/PageLayout";
// import { useServerSideTable } from "@/hooks/useServerSideTable";
// import { Button } from "@/components/ui/button";
// import { Link } from "react-router-dom";
// import { Edit, Eye, Download } from "lucide-react";

// const StatusBadge = ({ status }) => {
//   const config = {
//     Active: "bg-green-100 text-green-700",
//     Inactive: "bg-gray-100 text-gray-700",
//   };

//   const classes = config[status] || "bg-gray-100 text-gray-700";

//   return (
//     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${classes}`}>
//       {status || "Unknown"}
//     </span>
//   );
// };

// const InvoicePageList = () => {
//   // Using environment variable for base URL
//   const apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/invoices/all-invoices`;

//   const { data: invoices, tableState } = useServerSideTable(apiUrl);

//   const columns = useMemo(() => [
//     {
//       header: "Sl#",
//       cell: ({ row }) =>
//         (tableState.currentPage - 1) * tableState.entriesPerPage + row.index + 1,
//     },
//     {
//       header: "Bill No",
//       accessorKey: "bill_no",
//       enableSorting: true,
//     },
//     {
//       header: "Bill Date",
//       accessorKey: "date",
//       enableSorting: true,
//       cell: ({ row }) =>
//         row.original.date
//           ? new Date(row.original.date).toLocaleDateString("en-GB")
//           : "N/A",
//     },
//     {
//       header: "Client Name",
//       accessorKey: "client_name",
//       enableSorting: true,
//       cell: ({ row }) => row.original.client_name || "N/A",
//     },
//     {
//       header: "Total",
//       accessorKey: "total",
//       enableSorting: true,
//       cell: ({ row }) =>
//         row.original.total ? parseFloat(row.original.total).toFixed(2) : "0.00",
//     },
//     {
//       header: "GST",
//       accessorKey: "gst",
//       enableSorting: true,
//       cell: ({ row }) =>
//         row.original.gst ? parseFloat(row.original.gst).toFixed(2) : "0.00",
//     },
//     {
//       header: "Grand Total",
//       accessorKey: "grand_total",
//       enableSorting: true,
//       cell: ({ row }) =>
//         row.original.grand_total
//           ? parseFloat(row.original.grand_total).toFixed(2)
//           : "0.00",
//     },
//     {
//       header: "Status",
//       accessorKey: "status",
//       enableSorting: false,
//       cell: ({ row }) => (
//         <StatusBadge status={row.original.is_active ? "Active" : "Inactive"} />
//       ),
//     },
//     {
//       header: "Actions",
//       cell: ({ row }) => (
//         <div className="flex gap-2">
//           <Button asChild size="sm" variant="ghost">
//             <Link to={`/invoices/view/${row.original.id}`}>
//               <Eye className="w-4 h-4" />
//             </Link>
//           </Button>
//           <Button asChild size="sm" variant="ghost">
//             <Link to={`/invoices/edit/${row.original.id}`}>
//               <Edit className="w-4 h-4" />
//             </Link>
//           </Button>
//           <Button size="sm" variant="ghost" onClick={() => handleDownload(row.original)}>
//             <Download className="w-4 h-4" />
//           </Button>
//         </div>
//       ),
//     },
//   ], [tableState.currentPage, tableState.entriesPerPage]);

//   const handleDownload = (invoice) => {
//     alert(`Download invoice: ${invoice.bill_no}`);
//   };

//   return (
//     <PageLayout
//       title="Invoice Register"
//       addPath="/invoice/add"
//       addText="Add Invoice Register"
//     >
//       <ShadcnDataTable
//         Ltext="Invoice Register"
//         Rtext="Add Invoice Register"
//         addPath="/invoice/add"
//         data={invoices}
//         columns={columns}
//         tableState={tableState}
//       />
//     </PageLayout>
//   );
// };

// export default InvoicePageList;
import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Edit, Eye, Download } from "lucide-react";

const StatusBadge = ({ status }) => {
  const config = {
    Active: "bg-green-100 text-green-700",
    Inactive: "bg-gray-100 text-gray-700",
  };

  const classes = config[status] || "bg-gray-100 text-gray-700";

  return (
    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${classes}`}>
      {status || "Unknown"}
    </span>
  );
};

const InvoicePageList = () => {
  // Using environment variable for base URL
  const apiUrl = `${import.meta.env.VITE_API_BASE_URL}/invoices/all-invoices`;

  const { data: invoices, tableState } = useServerSideTable(apiUrl);

  const columns = useMemo(() => [
    {
      header: "Sl#",
      cell: ({ row }) =>
        (tableState.currentPage - 1) * tableState.entriesPerPage + row.index + 1,
    },
    {
      header: "Bill No",
      accessorKey: "bill_no",
      enableSorting: true,
    },
    {
      header: "Bill Date",
      accessorKey: "date",
      enableSorting: true,
      cell: ({ row }) =>
        row.original.date
          ? new Date(row.original.date).toLocaleDateString("en-GB")
          : "N/A",
    },
    {
      header: "Client Name",
      accessorKey: "client_name",
      enableSorting: true,
      cell: ({ row }) => row.original.client_name || "N/A",
    },
    {
      header: "Total",
      accessorKey: "total",
      enableSorting: true,
      cell: ({ row }) =>
        row.original.total ? parseFloat(row.original.total).toFixed(2) : "0.00",
    },
    {
      header: "GST",
      accessorKey: "gst",
      enableSorting: true,
      cell: ({ row }) =>
        row.original.gst ? parseFloat(row.original.gst).toFixed(2) : "0.00",
    },
    {
      header: "Grand Total",
      accessorKey: "grand_total",
      enableSorting: true,
      cell: ({ row }) =>
        row.original.grand_total
          ? parseFloat(row.original.grand_total).toFixed(2)
          : "0.00",
    },
    {
      header: "Status",
      accessorKey: "status",
      enableSorting: false,
      cell: ({ row }) => (
        <StatusBadge status={row.original.is_active ? "Active" : "Inactive"} />
      ),
    },
    {
      header: "Actions",
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button asChild size="sm" variant="ghost">
            <Link to={`/invoices/view/${row.original.id}`}>
              <Eye className="w-4 h-4" />
            </Link>
          </Button>
          <Button asChild size="sm" variant="ghost">
            <Link to={`/invoice/edit/${row.original.id}`}>
              <Edit className="w-4 h-4" />
            </Link>
          </Button>
          <Button size="sm" variant="ghost" onClick={() => handleDownload(row.original)}>
            <Download className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ], [tableState.currentPage, tableState.entriesPerPage]);

  const handleDownload = (invoice) => {
    alert(`Download invoice: ${invoice.bill_no}`);
  };

  return (
    <PageLayout
      title="Invoice Register"
      addPath="/invoice/add"
      addText="Add Invoice Register"
    >
      <ShadcnDataTable
        Ltext="Invoice Register"
        Rtext="Add Invoice Register"
        addPath="/invoices/add"
        data={invoices}
        columns={columns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default InvoicePageList;
