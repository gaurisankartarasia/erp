import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, FormProvider, useWatch } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/pages/employee/custom/FormInput";
import FormSelect from "@/pages/employee/custom/FormSelect";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const UOM_OPTIONS = [
  { label: "PCS", value: "pcs" },
  { label: "KG", value: "kg" },
  { label: "Litre", value: "litre" },
  { label: "Meter", value: "meter" },
];

const GST_OPTIONS = [
  { label: "0%", value: 0 },
  { label: "5%", value: 5 },
  { label: "12%", value: 12 },
  { label: "18%", value: 18 },
  { label: "28%", value: 28 },
];

const InvoiceFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      bill_no: "",
      bill_date: "",
      client_name: "",
      reference_no: "",
      subject: "",
      total_amount: "",
    },
  });

  const {
    handleSubmit,
    reset,
    formState: { isSubmitting },
    setValue,
    control,
    watch,
    register,
  } = methods;

  // Dropdown options
  const [clientOptions, setClientOptions] = useState([]);
  const [referenceOptions, setReferenceOptions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [dropdownsLoaded, setDropdownsLoaded] = useState(false);

  // Particulars row inputs
  const [particulars, setParticulars] = useState({
    description: "",
    hsn_sac: "",
    rate_unit: "",
    quantity: "",
    uom: "",
    gst: 0,
  });

  // List of added particulars rows
  const [items, setItems] = useState([]);

  // Watch client and reference selects
  const selectedClientId = useWatch({ control, name: "client_name" });
  const selectedReferenceId = useWatch({ control, name: "reference_no" });

  // Fetch clients
  useEffect(() => {
    const fetchClients = async () => {
      try {
        const res = await apiClient.get("/clients");
        // const clients = res.data.data.map((client) => ({
        //   label: client.clientNm,
        //   value: client.id.toString(),
        // }));
        const clients = res.data.data.map((client) => ({
          label: client.clientNm,
          value: client.id.toString(), // ✅ Ensure value is a string
        }));

        setClientOptions(clients);
        setDropdownsLoaded(true);
      } catch (error) {
        message.error("Failed to load clients.");
      }
    };
    fetchClients();
  }, [message]);

  // Fetch reference numbers based on client
  useEffect(() => {
    if (!selectedClientId) {
      setReferenceOptions([]);
      setValue("reference_no", "");
      return;
    }

    const fetchWorkOrderNos = async () => {
      try {
        setIsLoading(true);
        const selectedClient = clientOptions.find(
          (c) => c.value === selectedClientId
        );
        if (!selectedClient) {
          setReferenceOptions([]);
          setValue("reference_no", "");
          return;
        }

        const res = await apiClient.get("/invoices/reference-number", {
          params: { clientName: selectedClient.label },
        });

        const references = res.data.data.map((wo) => ({
          label: wo.work_order_no,
          value: wo.id.toString(),
        }));

        setReferenceOptions(references);

        if (
          !references.find(
            (ref) => ref.value === methods.getValues("reference_no")
          )
        ) {
          setValue("reference_no", "");
        }
      } catch (error) {
        message.error("Failed to load reference numbers.");
        setReferenceOptions([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchWorkOrderNos();
  }, [selectedClientId, clientOptions, message, setValue, methods]);

  // Fetch Subject & Total Amount when reference_no is selected
  useEffect(() => {
    if (!selectedReferenceId) {
      setValue("subject", "");
      setValue("total_amount", "");
      return;
    }

    const fetchWorkOrderDetails = async () => {
      try {
        const selectedRef = referenceOptions.find(
          (r) => r.value === selectedReferenceId
        );
        if (!selectedRef) return;

        const res = await apiClient.get("/invoices/work-order-details", {
          params: { workOrderNo: selectedRef.label },
        });

        const data = res.data.data;
        setValue("subject", data.subject || "");
        setValue("total_amount", data.total_amount?.toString() || "");
      } catch (error) {
        message.error("Failed to fetch work order details.");
        setValue("subject", "");
        setValue("total_amount", "");
      }
    };

    fetchWorkOrderDetails();
  }, [selectedReferenceId, referenceOptions, setValue, message]);

  // Fetch invoice data for edit mode
 useEffect(() => {
  if (!id || !dropdownsLoaded) return;

  setIsLoading(true);
  (async () => {
    try {
      const res = await apiClient.get(`/invoices/${id}`);
      const data = res.data.data; // <-- extract data correctly

      reset({
        bill_no: data.bill_no || "",
        bill_date: data.date || "",           // <-- date field
        client_name: data.client_code?.toString() || "",  // <-- client_code as value
        reference_no: data.reference || "",  // <-- set reference as string (you might need to match dropdown value)
        subject: data.subject || "",
        total_amount: data.total?.toString() || "",
      });

      // Load particulars from details array, map fields to expected format for your table
      if (data.details && Array.isArray(data.details)) {
        const mappedItems = data.details.map((item) => ({
          id: item.id,
          description: item.desc,
          hsn_sac: item.sac,
          rate_unit: parseFloat(item.unit_price),
          quantity: parseFloat(item.qty),
          uom: item.uom,
          gst: parseFloat(item.gstp),
          amount: parseFloat(item.amnt),
        }));

        setItems(mappedItems);
      } else {
        setItems([]);
      }
    } catch (error) {
      message.error("Failed to fetch invoice data.");
    } finally {
      setIsLoading(false);
    }
  })();
}, [id, dropdownsLoaded, reset]);

  // Handle particulars input change
  const handleParticularChange = (e) => {
    const { name, value } = e.target;
    setParticulars((prev) => ({
      ...prev,
      [name]: name === "gst" ? Number(value) : value,
    }));
  };

  // Calculate amount for a particulars row
  const calculateAmount = (rate, qty, gstPercent) => {
    const baseAmount = parseFloat(rate) * parseFloat(qty);
    const gstAmount = (baseAmount * gstPercent) / 100;
    return baseAmount + gstAmount;
  };

  // Add particulars row
  const handleAddParticular = () => {
    const { description, hsn_sac, rate_unit, quantity, uom, gst } = particulars;

    if (
      !description.trim() ||
      !rate_unit ||
      !quantity ||
      !uom ||
      isNaN(rate_unit) ||
      isNaN(quantity)
    ) {
      message.error("Please fill all particulars fields correctly.");
      return;
    }

    const amount = calculateAmount(rate_unit, quantity, gst);

    setItems((prev) => [
      ...prev,
      {
        id: Date.now(),
        description,
        hsn_sac,
        rate_unit: Number(rate_unit),
        quantity: Number(quantity),
        uom,
        gst,
        amount,
      },
    ]);

    // Reset particulars input fields
    setParticulars({
      description: "",
      hsn_sac: "",
      rate_unit: "",
      quantity: "",
      uom: "",
      gst: 0,
    });
  };

  // Remove particulars row
  const handleRemoveItem = (id) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Calculate totals for summary
  const totals = items.reduce(
    (acc, item) => {
      acc.total += item.amount;
      const gstAmount = (item.rate_unit * item.quantity * item.gst) / 100;
      // Split GST equally into SGST & CGST, or all IGST if required
      acc.sgst += gstAmount / 2;
      acc.cgst += gstAmount / 2;
      // For simplicity, assume no IGST here
      return acc;
    },
    { total: 0, sgst: 0, cgst: 0, igst: 0 }
  );

  totals.grandTotal = totals.total;

  // On form submit, include particulars items
  // On form submit, include particulars items
  const onSubmit = async (formData) => {
    if (!dropdownsLoaded) {
      message.error("Please wait until client options are loaded.");
      return;
    }

    if (items.length === 0) {
      message.error("Please add at least one invoice particular.");
      return;
    }

    try {
      setIsLoading(true);

      // Prepare details array matching backend keys
      const details = items.map((item) => ({
        invoice_code: "", // You can set this if needed
        desc: item.description,
        sac: item.hsn_sac,
        qty: item.quantity,
        uom: item.uom,
        unit_price: item.rate_unit,
        amnt: item.amount,
        gstp: item.gst,
        gst_amt: ((item.rate_unit * item.quantity * item.gst) / 100) || 0,
      }));

      // ✅ Safely extract client and reference values
      const selectedClient = clientOptions.find(
        (c) => c.value === formData.client_name
      );
      const selectedReference = referenceOptions.find(
        (r) => r.value === formData.reference_no
      );

      if (!selectedClient) {
        message.error("Client not found. Please select a valid client.");
        return;
      }

      if (!selectedReference) {
        message.error("Reference not found. Please select a valid reference.");
        return;
      }

      // ✅ Build the payload correctly
      const payload = {
        date: formData.bill_date,
        client_name: selectedClient.label,   // ✅ name from dropdown label
        client_code: selectedClient.value,   // ✅ id from dropdown value
        subject: formData.subject,
        reference: selectedReference.label,
        gst: totals.sgst + totals.cgst + totals.igst,
        cgst: totals.cgst,
        sgst: totals.sgst,
        igst: totals.igst,
        total: totals.total,
        grand_total: totals.grandTotal,
        details,
      };

      // ✅ Submit the data
      if (id) {
        await apiClient.put(`/invoices/edit/${id}`, payload);
        message.success("Invoice updated successfully.");
      } else {
        await apiClient.post("/invoices/create", payload);
        message.success("Invoice created successfully.");
      }

      console.log(payload)
      navigate("/invoice");
    } catch (error) {
      console.error("Submit Error:", error);
      message.error("Failed to submit invoice.");
    } finally {
      setIsLoading(false);
    }
  };


  //newly added
  useEffect(() => {
    // Only fetch bill no if not editing existing invoice
    if (id) return;

    const fetchLatestBillNo = async () => {
      try {
        const res = await apiClient.get("/invoices/get-latest-bill-no");
        if (res.data.success) {
          const nextBillNo = res.data.data.nextBillNo;
          if (nextBillNo) {
            setValue("bill_no", nextBillNo);
          }
        }
      } catch (error) {
        message.error("Failed to fetch latest bill number.");
      }
    };

    fetchLatestBillNo();
  }, [id, setValue, message]);




  return (
    <FormProvider {...methods}>
      <FormLayout
        title={id ? "Edit Invoice" : "Add Invoice"}
        backPath="/invoice"
        onSubmit={handleSubmit(onSubmit)}
        isSubmitting={isSubmitting}
        submitText={id ? "Update" : "Submit"}
        onCancel={() => navigate("/invoice-register")}
        onReset={() => {
          reset();
          setItems([]);
          setParticulars({
            description: "",
            hsn_sac: "",
            rate_unit: "",
            quantity: "",
            uom: "",
            gst: 0,
          });
        }}
        isLoading={isLoading}
      >
        <div className="col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormInput
              name="bill_no"
              label="Bill No"
              rules={{ required: "Bill No is required" }}
              placeholder="Enter Bill No"
              disabled
            />
            <FormInput
              name="bill_date"
              label="Bill Date"
              type="date"
              rules={{ required: "Bill Date is required" }}
            />
            <FormSelect
              name="client_name"
              label="Client Name"
              options={clientOptions}
              placeholder="Select Client"
              rules={{ required: "Client is required" }}
              showSearch
            />
            <FormSelect
              name="reference_no"
              label="Reference No"
              options={referenceOptions}
              placeholder={
                selectedClientId
                  ? referenceOptions.length > 0
                    ? "Select Reference No"
                    : "No references found"
                  : "Select Client first"
              }
              rules={{ required: "Reference No is required" }}
              showSearch
              disabled={!selectedClientId || referenceOptions.length === 0}
            />
            <div className="md:col-span-2">
              <FormInput
                name="subject"
                label="Subject"
                type="textarea"
                rows={3}
                rules={{ required: "Subject is required" }}
              />
            </div>
            <FormInput
              name="total_amount"
              label="Workorder Amount"
              type="number"
              disabled
              placeholder="Auto-filled from Work Order"
            />
          </div>

          {/* Invoice Particulars Section */}
          <h3 className="text-center mt-8 mb-4 font-semibold text-lg">
            Particulars
          </h3>

          <div className="grid grid-cols-12 gap-2 items-center mb-2">
            <textarea
              name="description"
              value={particulars.description}
              onChange={handleParticularChange}
              placeholder="Description"
              className="col-span-4 border border-gray-300 rounded px-2 py-1"
              rows={2}
            />
            <input
              type="text"
              name="hsn_sac"
              value={particulars.hsn_sac}
              onChange={handleParticularChange}
              placeholder="HSN/SAC"
              className="col-span-1 border border-gray-300 rounded px-2 py-1"
            />
            <input
              type="number"
              name="rate_unit"
              value={particulars.rate_unit}
              onChange={handleParticularChange}
              placeholder="Rate/Unit"
              className="col-span-1 border border-gray-300 rounded px-2 py-1"
              min={0}
            />
            <input
              type="number"
              name="quantity"
              value={particulars.quantity}
              onChange={handleParticularChange}
              placeholder="Quantity"
              className="col-span-1 border border-gray-300 rounded px-2 py-1"
              min={0}
            />
            <select
              name="uom"
              value={particulars.uom}
              onChange={handleParticularChange}
              className="col-span-2 border border-gray-300 rounded px-2 py-1"
            >
              <option value="">-Select-</option>
              {UOM_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <select
              name="gst"
              value={particulars.gst}
              onChange={handleParticularChange}
              className="col-span-1 border border-gray-300 rounded px-2 py-1"
            >
              {GST_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={handleAddParticular}
              className="col-span-1 bg-pink-500 text-white rounded px-4 py-1 hover:bg-pink-600"
            >
              Add
            </button>
          </div>

          {/* Particulars Table */}
          <table className="w-full border-collapse border border-gray-800">
            <thead>
              <tr className="bg-gray-800 text-white text-sm">
                <th className="border border-gray-700 p-1">#SL</th>
                <th className="border border-gray-700 p-1">Description</th>
                <th className="border border-gray-700 p-1">HSN/SAC</th>
                <th className="border border-gray-700 p-1">Rate/Unit</th>
                <th className="border border-gray-700 p-1">Quantity</th>
                <th className="border border-gray-700 p-1">UOM</th>
                <th className="border border-gray-700 p-1">GST(%)</th>
                <th className="border border-gray-700 p-1">Amount</th>
                <th className="border border-gray-700 p-1">Action</th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 ? (
                <tr>
                  <td
                    colSpan={9}
                    className="border border-gray-700 text-center p-2 text-gray-500"
                  >
                    No particulars added yet.
                  </td>
                </tr>
              ) : (
                items.map((item, index) => (
                  <tr key={item.id} className="text-sm text-center">
                    <td className="border border-gray-700 p-1">{index + 1}</td>
                    <td className="border border-gray-700 p-1 text-left">
                      {item.description}
                    </td>
                    <td className="border border-gray-700 p-1">{item.hsn_sac}</td>
                    <td className="border border-gray-700 p-1">
                      {item.rate_unit.toFixed(2)}
                    </td>
                    <td className="border border-gray-700 p-1">{item.quantity}</td>
                    <td className="border border-gray-700 p-1">{item.uom}</td>
                    <td className="border border-gray-700 p-1">{item.gst}%</td>
                    <td className="border border-gray-700 p-1">
                      {item.amount.toFixed(2)}
                    </td>
                    <td className="border border-gray-700 p-1">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.id)}
                        className="text-red-600 hover:underline"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Totals Section */}
          <div className="flex justify-end mt-4 gap-4 w-full max-w-xs ml-auto text-sm font-semibold">
            <div className="w-full">
              <div className="flex justify-between border-b border-gray-300 py-1">
                <span>Total:</span>
                <span>{totals.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-b border-gray-300 py-1">
                <span>SGST:</span>
                <span>{totals.sgst.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-b border-gray-300 py-1">
                <span>CGST:</span>
                <span>{totals.cgst.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-b border-gray-300 py-1">
                <span>IGST:</span>
                <span>{totals.igst.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-gray-300 font-bold">
                <span>Grand Total:</span>
                <span>{totals.grandTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default InvoiceFormPage;
