// import React, { useState, useMemo } from "react";
// import { useFormContext, Controller } from "react-hook-form";
// import { Label } from "@/components/ui/label";
// import {
//   Select,
//   SelectContent,
//   SelectItem,
//   SelectTrigger,
//   SelectValue,
// } from "@/components/ui/select";
// import { Input } from "@/components/ui/input";
// import { cn } from "@/lib/utils";

// const FormSelect = ({
//   name,
//   label,
//   placeholder = "--Select an option--",
//   options,
//   required = false,
//   showSearch = false,
//   ...props
// }) => {
//   const {
//     control,
//     formState: { errors },
//   } = useFormContext();
//   const error = errors[name]?.message

//   const [search, setSearch] = useState("");
//   const filteredOptions = useMemo(
//     () =>
//       options.filter((opt) =>
//         opt.label.toLowerCase().includes(search.toLowerCase())
//       ),
//     [search, options]
//   );

//   return (
//     <div className="grid gap-2">
//       <Label htmlFor={name}>
//         {label}
//         {required && <span className="text-destructive">*</span>}
//       </Label>

//       <Controller
//         name={name}
//         control={control}
//         rules={props.rules}
//         render={({ field }) => (
//           <Select value={field.value} onValueChange={field.onChange}>
//             <SelectTrigger
//               className={cn(error && "border-destructive")}
//               id={name}
//             >
//               <SelectValue placeholder={placeholder} />
//             </SelectTrigger>
//             <SelectContent>
//               {showSearch && (
//                 <div className="p-2">
//                   <Input
//                     placeholder="Search..."
//                     value={search}
//                     onChange={(e) => setSearch(e.target.value)}
//                     className="mb-2"
//                   />
//                 </div>
//               )}

// {filteredOptions.map((option, index) => (
//   <SelectItem key={option.value} value={String(option.value)}>
//    {index + 1}. {option.label}
//   </SelectItem>
// ))}
//               {filteredOptions.length === 0 && (
//                 <div className="px-2 py-1 text-sm text-muted-foreground">
//                   No results found
//                 </div>
//               )}
//             </SelectContent>
//           </Select>
//         )}
//       />

//     </div>
//   );
// };

// export default React.memo(FormSelect);

import React from "react";
import Select from "react-select";
import { Controller, useFormContext } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const FormSelect = ({
  name,
  label,
  placeholder = "--Select an option--",
  options = [],
  required = false,
  isMulti = false,
  isClearable = true,
  isSearchable = true,
  isDisabled = false,
  isLoading,
  rules = {},
  className = "",
  ...props
}) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();

  const error = errors?.[name]?.message;

  return (
    <div className="grid gap-2">
      {label && (
        <Label htmlFor={name}>
          {label}
          {required && <span className="text-destructive">*</span>}
        </Label>
      )}

      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field }) => (
          <Select
            {...props}
            {...field}
            inputId={name}
            options={options}
            placeholder={placeholder}
            isClearable={isClearable}
            isSearchable={isSearchable}
            isMulti={isMulti}
            isDisabled={isDisabled}
            isLoading={isLoading}
            className={cn("react-select-container", className)}
            classNames={{
              control: (state) =>
                cn(
                  "react-select__control !rounded-md !cursor-pointer !bg-input !border-none",
                  error && "!border-destructive",
                  state.isFocused && "shadow-none"
                ),
              valueContainer: () => "py-0.5",
               option: () => "!cursor-pointer",
            }}
            classNamePrefix="react-select"
            onChange={(selected) => {
              field.onChange(
                isMulti
                  ? selected?.map((opt) => opt.value)
                  : selected?.value ?? ""
              );
            }}
            value={
              isMulti
                ? options.filter((opt) =>
                    Array.isArray(field.value)
                      ? field.value.includes(opt.value)
                      : false
                  )
                : options.find((opt) => opt.value === field.value) || null
            }
          />
        )}
      />
    </div>
  );
};

export default React.memo(FormSelect);
