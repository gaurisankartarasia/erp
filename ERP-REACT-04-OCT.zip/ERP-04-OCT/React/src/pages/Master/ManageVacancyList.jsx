import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check } from "lucide-react";
import apiClient from "@/api/axiosConfig";

const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const ManageVacancyList = () => {
  const {
    data: vacancies,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/vacancies/`
  );

  const confirm = useConfirmModal();

  const handleToggleStatus = async (vacancy) => {
    const ok = await confirm({
      title: "Change Status",
      description: `Are you sure you want to ${
        vacancy.is_active ? "deactivate" : "activate"
      } this vacancy?`,
    });

    if (!ok) return;

    try {
      // Corrected endpoint path here
      await apiClient.patch(`/vacancies/toggle-status/${vacancy.id}`);
      refreshData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const vacancyColumns = useMemo(
    () => [
      {
        header: "Sl#",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "Post Name",
        accessorKey: "post_name",
        enableSorting: true,
      },
      {
        header: "Date",
        accessorKey: "date",
        enableSorting: true,
        cell: ({ row }) =>
          row.original.date
            ? new Date(row.original.date).toLocaleDateString()
            : "N/A",
      },
      {
        header: "Description",
        accessorKey: "description",
        enableSorting: false,
        cell: ({ row }) => (
          <span className="line-clamp-2 text-sm text-gray-700">
            {row.original.description || "—"}
          </span>
        ),
      },
      {
        header: "Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const vacancy = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(vacancy)}
                aria-label={
                  vacancy.is_active ? "Deactivate vacancy" : "Activate vacancy"
                }
              >
                {vacancy.is_active ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>

              <Button asChild size="sm" variant="ghost">
                <Link to={`/master/vacancies/edit/${vacancy.id}`}>
                  <Edit className="text-indigo-600" />
                </Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage]
  );

  return (
    <PageLayout
      title="Manage Vacancy"
      rightButton={{ text: "Add Vacancy", path: "add" }}
    >
      <ShadcnDataTable
        Ltext="Manage Vacancy"
        Rtext="+ Add Vacancy"
        addPath="add"
        data={vacancies}
        columns={vacancyColumns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default ManageVacancyList;
