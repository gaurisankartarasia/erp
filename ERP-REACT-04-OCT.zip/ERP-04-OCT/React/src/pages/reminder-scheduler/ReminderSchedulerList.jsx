import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirm } from "@/contexts/ConfirmModalProvider";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check, Trash } from "lucide-react";
import apiClient from "@/api/axiosConfig";
import { useServerSideTable } from "@/hooks/useServerSideTable";

// Status badge component
const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const ReminderSchedulerList = () => {
  // Fetch reminders data using the server side hook
  const { data: reminders, tableState, refreshData } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/reminder-schedulers`
  );

  const confirm = useConfirm();

  // Toggle active/inactive status for reminder
  const handleToggleStatus = async (reminder) => {
    const ok = await confirm({
      title: "Change Reminder Status",
      description: `Are you sure you want to ${
        reminder.is_active ? "deactivate" : "activate"
      } this reminder "${reminder.reminder_matter}"?`,
    });

    if (!ok) return;

    try {
      // Backend PATCH endpoint to toggle status
      await apiClient.patch(`/reminder-schedulers/toggle-status/${reminder.id}`);
      refreshData();
    } catch (error) {
      console.error("Error updating reminder status:", error);
      // Optionally show a toast or modal here
    }
  };

  // Delete reminder handler
  const handleDelete = async (reminder) => {
    const ok = await confirm({
      title: "Delete Reminder",
      description: `Are you sure you want to delete the reminder "${reminder.reminder_matter}"? This action cannot be undone.`,
    });

    if (!ok) return;

    try {
      await apiClient.delete(`/reminder-schedulers/delete/${reminder.id}`);
      refreshData();
    } catch (error) {
      console.error("Error deleting reminder:", error);
      // Optionally show a toast or modal here
    }
  };

  // Define table columns
  const columns = useMemo(
    () => [
      {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage + row.index + 1,
      },
      {
        header: "Reminder Matter",
        accessorKey: "reminder_matter",
        enableSorting: true,
      },
      {
        header: "Email ID",
        accessorKey: "email_id",
        enableSorting: true,
      },
      {
        header: "Mobile No.",
        accessorKey: "mobile_no",
        enableSorting: false,
      },
      {
        header: "Due Date",
        accessorKey: "due_date",
        enableSorting: true,
        cell: ({ row }) => new Date(row.original.due_date).toLocaleDateString(),
      },
      {
        header: "Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const reminder = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(reminder)}
                title={reminder.is_active ? "Deactivate Reminder" : "Activate Reminder"}
              >
                {reminder.is_active ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>

              <Button asChild size="sm" variant="ghost" title="Edit Reminder">
                <Link to={`/tools/reminderschedulers/edit/${reminder.id}`}>
                  <Edit />
                </Link>
              </Button>

              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleDelete(reminder)}
                title="Delete Reminder"
                className="text-red-600 hover:text-red-800"
              >
                <Trash />
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage, confirm]
  );

  return (
    <PageLayout title="Reminder Scheduler List" rightButton={{ text: "Add Reminder", path: "add" }}>
      <ShadcnDataTable
        Ltext="Reminder Scheduler List"
        Rtext="Add Reminder"
        addPath="add"
        data={reminders}
        columns={columns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default ReminderSchedulerList;
