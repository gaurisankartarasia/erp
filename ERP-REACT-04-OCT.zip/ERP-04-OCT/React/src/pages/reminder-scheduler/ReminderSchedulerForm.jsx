import apiClient from '@/api/axiosConfig'
import FormInput from '@/components/common/forms/FormInput'
import FormLayout from '@/components/layouts/FormLayout'
import { useMessageModal } from '@/hooks/useMessageModal'
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'


const ReminderSchedulerForm = () => {
    const { id } = useParams()
    const navigate = useNavigate()
    const [formData, setFormData] = useState({
        reminder_matter: "",
        due_date: "",
        email_id: "",
        mobile_no: ""
    })

    const [initialData, setInitialData] = useState({
        reminder_matter: "",
        due_date: "",
        email_id: "",
        mobile_no: ""
    })

    const [formErrors, setFormErrors] = useState({})
    const message = useMessageModal();
    const isEditMode = !!id;

useEffect(() => {
    if (isEditMode) {
        apiClient.get(`/reminder-schedulers/${id}`)
        .then((response) => {
            const data = response.data;
            // Populate form with API data
            setFormData({
                reminder_matter: data.reminder_matter || "",
                due_date: data.due_date || "",
                email_id: data.email_id || "",
                mobile_no: data.mobile_no || ""
            });
            // Keep initial data for reset
            setInitialData({
                reminder_matter: data.reminder_matter || "",
                due_date: data.due_date || "",
                email_id: data.email_id || "",
                mobile_no: data.mobile_no || ""
            });
        })
        .catch(err => {
            console.error("Failed to fetch reminder:", err);
            message.error("Failed to load reminder data.");
        });
    }
}, [isEditMode, id, message]);


    const handleChange = (e) => {
        const { name, value } = e.target
        setFormData((prev) => ({
            ...prev,
            [name]: value
        }))
    }
    const validateForm = () => {
        const errors = {}
        if (!formData.reminder_matter.trim()) {
            errors.reminder_matter = "Reminder Matter is required"
        }
        if (!formData.due_date.trim()) {
            errors.due_date = "Due Date is required"
        }
        if (!formData.email_id.trim()) {
            errors.email_id = "Email is required"
        }
        if (!formData.mobile_no.trim()) {
            errors.mobile_no = "Mobile Number is required"

        }
        return errors

    }

    const handleSubmit = async (e) => {
        console.log(formData)
        const validationFormErrors = validateForm()
        setFormErrors(validationFormErrors)

        if (Object.keys(validationFormErrors).length > 0) {
            return
        }

        const payload = {
            reminder_matter: formData.reminder_matter,
            due_date: formData.due_date,
            email_id: formData.email_id,
            mobile_no: formData.mobile_no
        }

        try {
            if(isEditMode){
                 await apiClient.put(`/reminder-schedulers/edit/${id}`, payload)
                 message.success("Reminder updated successfully!")

            }else{
                 await apiClient.post('/reminder-schedulers/create', payload)
                 message.success("Reminder added successfully!")
            }
           navigate("/tools/reminderschedulers")


        } catch (err) {
            message.error(
                err.response?.data?.message || "An unexpected error occured"
            );
            console.error(err)
        }
    }



    return (
        <FormLayout
            title={"Add Reminder Scheduler "}
            onSubmit={handleSubmit}
            submitText='Submit'
            onCancel={() => navigate("/tools/reminderschedulers")}
            onReset={() => {
                setFormData(initialData);
                setFormErrors({})
            }}
        >
            <FormInput
                required
                label={"Reminder Matter"}
                name="reminder_matter"
                placeholder={"Enter Reminder Matter"}
                value={formData.reminder_matter}
                onChange={handleChange}
                error={formErrors.reminder_matter}

            />

            <FormInput
                required
                label={"Due Date"}
                name="due_date"
                type='date'
                placeholder={"Enter Due Date"}
                value={formData.due_date}
                onChange={handleChange}
                error={formErrors.due_date}
            />
            <FormInput
                required
                label={"Email Id"}
                name="email_id"
                placeholder={"Enter Email Id"}
                value={formData.email_id}
                onChange={handleChange}
                error={formErrors.email_id}
            />
<FormInput
  required
  label={"Mobile Number"}
  name="mobile_no"
  placeholder={"Enter Mobile Number"}
  value={formData.mobile_no}
  onChange={handleChange}
  error={formErrors.mobile_no}
  type="tel"  // triggers handleKeyDown logic to allow digits only
  maxLength={10} // optional, you can adjust max length
/>





        </FormLayout>
    )
}

export default ReminderSchedulerForm
