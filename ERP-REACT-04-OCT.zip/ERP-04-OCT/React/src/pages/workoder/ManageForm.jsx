
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import FormSelect from "@/components/common/forms/FormSelect";
import MessageModal from "@/components/common/modals/MessageModal";
import apiClient from "@/api/axiosConfig";
const ManageForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = Boolean(id);

  // State for form fields
  const [formData, setFormData] = useState({
    client_id: "",
    work_order_no: "",
    start_date: "",
    expiry_date: "",
    subject: "",
    taxable_price: "",
    tax_id: "",
    tax_amount: "",
    total_amount: "",
    document: null, 
  });
  const [existingDocumentName, setExistingDocumentName] = useState("");
  const [initialFormData, setInitialFormData] = useState({});
  // State for dropdown data, errors, and UI
  const [clients, setClients] = useState([]);
  const [taxRates] = useState([
    { id: 0, name: "0%", rate: 0 },
    { id: 5, name: "5%", rate: 5 },
    { id: 12, name: "12%", rate: 12 },
    { id: 18, name: "18%", rate: 18 },
  ]);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [messageModal, setMessageModal] = useState({ isOpen: false, message: "", variant: "danger" });

  // Fetch initial data and existing record data (if editing)
  useEffect(() => {
    const fetchData = async () => {
      try {
        const clientRes = await apiClient.get("/work-orders/clients");
        setClients(clientRes.data.data);

        if (isEditMode) {
          const res = await apiClient.get(`/work-orders/${id}`);
          const data = res.data.data;

          const loadedForm = {
            client_id: data.client_id || "",
            work_order_no: data.work_order_no || "",
            start_date: data.start_date ? data.start_date.slice(0, 10) : "",
            expiry_date: data.expiry_date ? data.expiry_date.slice(0, 10) : "",
            subject: data.subject || "",
            taxable_price: data.taxable_price || "",
            tax_id: data.tax_id || "",
            tax_amount: data.tax_amount || "",
            total_amount: data.total_amount || "",
            document: null, 
          };

          setFormData(loadedForm);
          setInitialFormData(loadedForm); 
          
 
          if (data.document) {
            setExistingDocumentName(data.document.split('/').pop()); // Show just the filename
          }
        }
      } catch (error) {
        toast.error("Failed to load required data.");
        console.error(error);
      }
    };
    fetchData();
  }, [id, isEditMode]);


  useEffect(() => {
    const taxablePrice = parseFloat(formData.taxable_price);
    const selectedTax = taxRates.find((tax) => String(tax.id) === String(formData.tax_id));
    if (!isNaN(taxablePrice) && selectedTax) {
      const taxAmount = (taxablePrice * selectedTax.rate) / 100;
      const totalAmount = taxablePrice + taxAmount;
      setFormData((prev) => ({ ...prev, tax_amount: taxAmount.toFixed(2), total_amount: totalAmount.toFixed(2) }));
    } else {
      setFormData((prev) => ({ ...prev, tax_amount: "", total_amount: "" }));
    }
  }, [formData.taxable_price, formData.tax_id, taxRates]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowedTypes = ["application/pdf", "image/jpeg"];
    const maxSize = 10 * 1024 * 1024;
    if (!allowedTypes.includes(file.type) || file.size > maxSize) {
      toast.error("Invalid file: Must be PDF/JPG and under 10MB.");
      e.target.value = null;
      return;
    }
    setFormData((prev) => ({ ...prev, document: file }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!formData.client_id) newErrors.client_id = "Client Name is required.";
    if (!formData.work_order_no.trim()) newErrors.work_order_no = "Work Order No is required.";
    if (!formData.start_date) newErrors.start_date = "Date is required.";
    if (!formData.expiry_date) newErrors.expiry_date = "Expiry Date is required.";
    if (!formData.subject.trim()) newErrors.subject = "Subject is required.";
    if (!formData.taxable_price) newErrors.taxable_price = "Taxable Price is required.";
    if (!formData.tax_id) newErrors.tax_id = "Tax Rate is required.";
    if (!formData.tax_amount) newErrors.tax_amount = "Tax Amount is required.";
    if (!formData.total_amount) newErrors.total_amount = "Total Amount is required.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleReset = () => {
    setFormData(initialFormData); 
    setErrors({});
    const fileInput = document.getElementById("document-upload");
    if (fileInput) fileInput.value = null;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      toast.error("Please fill in all required fields.");
      return;
    }
    setIsSubmitting(true);

    const payload = new FormData();
    

    Object.entries(formData).forEach(([key, value]) => {

      if (key === 'document' && value instanceof File) {
        payload.append(key, value);
      } else if (key !== 'document' && value !== null) {
        payload.append(key, value);
      }
    });

    try {
      if (isEditMode) {
        // Use POST with method override for better file upload compatibility on updates
        payload.append("_method", "PUT");
        await apiClient.post(`/work-orders/${id}`, payload, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        setMessageModal({ isOpen: true, message: "Work Order updated successfully!", variant: "success" });
      } else {
        await apiClient.post("/work-orders", payload, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        setMessageModal({ isOpen: true, message: "Work Order created successfully!", variant: "success" });
      }
    } catch (err) {
      const apiMsg = err.response?.data?.message;
      setMessageModal({ isOpen: true, message: apiMsg || "Failed to save Work Order.", variant: "danger" });
    } finally {
      setIsSubmitting(false);
    }
  };

  // --- FIX #4: IMPROVED MODAL CLOSE LOGIC ---
  const handleCloseModal = () => {
    // Only navigate away on success
    if (messageModal.variant === 'success') {
      navigate("/mangeorder-list");
    }
    // Always reset the modal state
    setMessageModal({ isOpen: false, message: "", variant: "info" });
  };

  return (
    <>
      <FormLayout
        headerText={isEditMode ? "Edit Work Order" : "Add Work Order"}
        backButton={{ text: "Back", onClick: () => navigate(-1) }}
        onSubmit={handleSubmit}
        isSubmitting={isSubmitting}
        submitText={isEditMode ? "Update" : "Submit"}
        showCancel={true}
        onCancel={() => navigate("/mangeorder-list")}
        showReset={true}
        onReset={handleReset}
      >
        <FormSelect
          name="client_id"
          label="Client Name"
          placeholder="--Select Client Name--"
          value={String(formData.client_id)}
          onValueChange={(val) => setFormData((prev) => ({ ...prev, client_id: val }))}
          required
          error={errors.client_id}
          options={clients.map((c) => ({ value: String(c.id), label: c.clientNm }))}
        />
        <FormInput name="work_order_no" label="Work Order No" value={formData.work_order_no} placeholder="Work Order No"  onChange={handleChange} required error={errors.work_order_no} />
        <FormInput name="start_date" label="Date" type="date" value={formData.start_date} onChange={handleChange} required error={errors.start_date} />
        <FormInput name="expiry_date" label="Expiry Date" type="date" value={formData.expiry_date} onChange={handleChange} required error={errors.expiry_date} />
        <FormInput name="subject" label="Subject" value={formData.subject} placeholder="Subject"  onChange={handleChange} required error={errors.subject} />
        <FormInput name="taxable_price" label="Taxable Price" type="number"placeholder="Taxable Price"  value={formData.taxable_price} onChange={handleChange} required error={errors.taxable_price} />
        <FormSelect
          name="tax_id"
          placeholder="--Select Tax Rate--"  
          label="Tax Rate"
          value={String(formData.tax_id)}
          onValueChange={(val) => setFormData((prev) => ({ ...prev, tax_id: val }))}
          required
          error={errors.tax_id}
          options={taxRates.map((tax) => ({ value: String(tax.id), label: tax.name }))}
        />
        <FormInput name="tax_amount" label="Tax Amount"placeholder="Tax Amount" type="number" value={formData.tax_amount} readOnly required error={errors.tax_amount} />
        <FormInput name="total_amount" label="Total Amount" type="number" placeholder="Total Amount" value={formData.total_amount} readOnly required error={errors.total_amount} className="font-bold bg-gray-100" />

        <div className="pt-2">
          <label className="block text-sm font-medium text-gray-700">Document Soft Copy</label>
          <div className="mt-1 flex justify-between items-center w-full border border-gray-300 rounded-md shadow-sm">
    
            <span className="px-3 text-gray-500 truncate">
              {formData.document?.name || existingDocumentName || "Upload Letter Soft Copy"}
            </span>
            <label htmlFor="document-upload" className="cursor-pointer">
              <div className="bg-red-500 text-white py-2 px-4 rounded-r-md hover:bg-red-600">Upload</div>
              <input id="document-upload" name="document" type="file" className="sr-only" accept=".pdf,.jpg,.jpeg" onChange={handleFileChange} />
            </label>
          </div>
          {isEditMode && !formData.document && existingDocumentName && (
            <p className="text-xs text-gray-500 mt-1">Current file: {existingDocumentName}. Upload a new file to replace it.</p>
          )}
        </div>
      </FormLayout>

      <MessageModal
        isOpen={messageModal.isOpen}
        onClose={handleCloseModal} // Use the new close handler
        message={messageModal.message}
        variant={messageModal.variant}
      />
    </>
  );
};

export default ManageForm; 