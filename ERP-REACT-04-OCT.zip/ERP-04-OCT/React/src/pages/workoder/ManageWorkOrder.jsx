import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Edit, Eye, X, Check, Trash2} from "lucide-react"; 
import { FaFilePdf, FaFileImage, FaUniversity } from "react-icons/fa";

import ShadcnDataTable from "@/components/common/DataTable";
import PageLayout from "@/components/layouts/PageLayout";
import { Button } from "@/components/ui/button";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import apiClient from "@/api/axiosConfig";

// Import the modal components you provided
import ConfirmModal from "@/components/common/modals/ConfirmationModal";
import MessageModal from "@/components/common/modals/MessageModal";
import BankGuaranteeModal from "./BankGuaranteeModal";
import WorkOrderViewModal from "./WorkOrderViewModal";

// A badge component to show the status (Active/Inactive)
const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}>
      {config[status].text}
    </span>
  );
};

// Main component for the Manage Work Order page
const ManageWorkOrder = () => {
  const { data: workOrders, tableState, refreshData } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/work-orders`
  );

  // --- MODAL STATE MANAGEMENT ---
  const [modalState, setModalState] = useState({
    isConfirmOpen: false,
    title: "",
    description: "",
    onConfirm: () => {},
  });
  const [messageModal, setMessageModal] = useState({
    isOpen: false,
    message: "",
    variant: "info",
  });

  // --- BANK GUARANTEE MODAL STATE ---
  const [bgModalOpen, setBgModalOpen] = useState(false);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedWorkOrderId, setSelectedWorkOrderId] = useState(null);
  const [viewWorkOrder, setViewWorkOrder] = useState(null);

  // Fetch and show work order details in modal
  const handleViewWorkOrder = async (id) => {
    setSelectedWorkOrderId(id);
    setViewModalOpen(true);
    try {
      const res = await apiClient.get(`/work-orders/${id}`);
      setViewWorkOrder(res.data.data);
    } catch (err) {
      setViewWorkOrder(null);
      setMessageModal({ isOpen: true, message: 'Failed to fetch work order details.', variant: 'danger' });
    }
  };

  // Toggles the status of a work order after confirmation
  const handleToggleStatus = async (workOrder) => {
    // Set the content and action for the confirmation modal
    setModalState({
      isConfirmOpen: true,
      title: "Change Status",
      description: `Are you sure you want to ${workOrder.is_active ? "deactivate" : "activate"} this work order?`,
      onConfirm: () => confirmToggleStatus(workOrder),
    });
  };

  // The function that runs after the user confirms the status change
  const confirmToggleStatus = async (workOrder) => {
    try {
      await apiClient.patch(`/work-orders/${workOrder.id}/status`);
      setMessageModal({ isOpen: true, message: "Status updated successfully!", variant: "success" });
      refreshData();
    } catch (error) {
      setMessageModal({ isOpen: true, message: "Failed to update status.", variant: "danger" });
      console.error("Error updating status:", error);
    } finally {
      setModalState({ ...modalState, isConfirmOpen: false }); // Close the confirmation modal
    }
  };

  // Define columns for the data table
  const workOrderColumns = useMemo(
    () => [
      {
        header: "Sl NO.",
        cell: ({ row }) => (tableState.currentPage - 1) * tableState.entriesPerPage + row.index + 1,
      },
      {
        header: "Client Name",
        accessorKey: "Client.clientNm",
        enableSorting: true,
      },
      {
        header: "Work Order no",
        accessorKey: "work_order_no",
        enableSorting: true,
      },
      {
        header: "Date",
        accessorKey: "start_date",
        enableSorting: true,
        cell: ({ row }) => row.original.start_date ? new Date(row.original.start_date).toLocaleDateString() : "N/A",
      },
      {
        header: "Expiry Date",
        accessorKey: "expiry_date",
        enableSorting: true,
        cell: ({ row }) => row.original.expiry_date ? new Date(row.original.expiry_date).toLocaleDateString() : "N/A",
      },
      {
        header: "Subject",
        accessorKey: "subject",
        enableSorting: false,
      },
      {
        header: "Total Amount",
        accessorKey: "total_amount",
        enableSorting: true,
        cell: ({ row }) => row.original.total_amount ? parseFloat(row.original.total_amount).toFixed(2) : "N/A",
      },
      {
        header: "Soft Copy",
        accessorKey: "document",
        cell: ({ row }) => {
          const documentPath = row.original.document;
          if (!documentPath) {
            return <span className="text-gray-400 italic text-xs">No document</span>;
          }
const fileUrl = `${import.meta.env.VITE_API_BASE_URL.replace(/\/api$/, '')}/uploads/work-orders/${documentPath}`;

        
          const extension = documentPath.split(".").pop().toLowerCase();
          return (
            <a href={fileUrl} target="_blank" rel="noopener noreferrer" title={documentPath.split("/").pop()} className="flex justify-center cursor-pointer">
              {extension === 'pdf' ? <FaFilePdf className="text-red-500" size={22} /> : <FaFileImage className="text-blue-500" size={22} />}
            </a>
          );
        },
      },
      {
        header: "Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const workOrder = row.original;
          return (
            <div className="flex gap-1">
              <Button size="sm" variant="ghost" onClick={() => handleToggleStatus(workOrder)}>
                {workOrder.is_active ? <X className="text-red-500 h-4 w-4" /> : <Check className="text-green-500 h-4 w-4" />}
              </Button>
              <Button asChild size="sm" variant="ghost">
                <Link to={`/work-orders/${workOrder.id}/edit`}>
                  <Edit className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="sm" variant="ghost" title="View Work Order" onClick={() => handleViewWorkOrder(workOrder.id)}>
                <Eye className="h-4 w-4" />
              </Button>
              
              <Button size="sm" variant="ghost" title="Bank Guarantee" onClick={() => { setSelectedWorkOrderId(workOrder.id); setBgModalOpen(true); }}>
                <FaUniversity className="text-blue-700 h-4 w-4" />
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage, refreshData]
  );

  return (
    <>
      <PageLayout
        title="Manage Work Order"
        rightButton={{ text: " Add Work Order", path: "add" }}
      >
        <ShadcnDataTable
          data={workOrders}
          columns={workOrderColumns}
          tableState={tableState}
        />
      </PageLayout>

      {/* --- INTEGRATED MODALS --- */}
      <ConfirmModal
        isOpen={modalState.isConfirmOpen}
        onClose={() => setModalState({ ...modalState, isConfirmOpen: false })}
        onConfirm={modalState.onConfirm}
        title={modalState.title}
        description={modalState.description}
      />

      <MessageModal
        isOpen={messageModal.isOpen}
        onClose={() => setMessageModal({ isOpen: false, message: "", variant: "info" })}
        message={messageModal.message}
        variant={messageModal.variant}
      />
  <BankGuaranteeModal isOpen={bgModalOpen} onClose={() => setBgModalOpen(false)} workOrderId={selectedWorkOrderId} />
  <WorkOrderViewModal isOpen={viewModalOpen} onClose={() => setViewModalOpen(false)} workOrder={viewWorkOrder} />
    </>
  );
};

export default ManageWorkOrder;