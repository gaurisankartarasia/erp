


import React, { useMemo, useCallback } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check } from "lucide-react";
import { FaFilePdf, FaFileImage } from "react-icons/fa";
import apiClient from "@/api/axiosConfig";

const StatusBadge = ({ active }) => {
  const status = active ? "Active" : "Inactive";
  const config = {
    Active: { text: "Active", classes: "bg-green-100 text-green-800" },
    Inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };
  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const DispatchRegister = () => {
  const {
    data: dispatches,
    tableState,
    refreshData,
    setSearch,
    setSort,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/dispatches`
  );
  const confirm = useConfirmModal();

  const handleToggleStatus = useCallback(
    async (dispatch) => {
      const ok = await confirm({
        title: "Change Status",
        description: `Are you sure you want to ${
          dispatch.status === true || dispatch.status === "Active"
            ? "deactivate"
            : "activate"
        } this dispatch?`,
      });
      if (!ok) return;
      try {
        await apiClient.patch(`/dispatches/${dispatch.id}/toggle-status`);
        refreshData();
      } catch (error) {
        console.error("Error updating status:", error);
      }
    },
    [confirm, refreshData]
  );

  const dispatchColumns = useMemo(
    () => [
      {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "SUrl",
        accessorKey: "sUrl",
        enableSorting: true,
      },
      {
        header: "Letter No",
        accessorKey: "letterNo",
        enableSorting: true,
      },
      {
        header: "Date",
        accessorKey: "date",
        enableSorting: true,
        cell: ({ row }) =>
          row.original.date
            ? new Date(row.original.date).toLocaleDateString()
            : "-",
      },
      {
        header: "Send To",
        accessorKey: "sendTo",
        enableSorting: true,
      },
      {
        header: "Subject",
        accessorKey: "subject",
        enableSorting: true,
      },
      {
        header: "Soft Copy",
        accessorKey: "softCopy",
        enableSorting: false,
        cell: ({ row }) => {
          const file = row.original.softCopy;
          if (!file) return <span className="text-gray-400">—</span>;
          const url = file.startsWith("http")
            ? file
            : `${import.meta.env.VITE_API_BASE_URL.replace(/\/api$/, "")}/uploads/dispatches/${file}`;
          const ext = file.split('.').pop()?.toLowerCase();
          const isPdf = ext === 'pdf';
          const isImage = ["jpg", "jpeg", "png", "gif", "bmp", "webp"].includes(ext);
          return (
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              title="View File"
              className="text-red-600 text-lg flex items-center gap-1"
            >
              {isPdf ? <FaFilePdf className="text-xl text-red-600" /> : null}
              {isImage ? <FaFileImage className="text-xl text-blue-600" /> : null}
              {!isPdf && !isImage ? <span>📄</span> : null}
            </a>
          );
        },
      },
      {
        header: "Status",
        accessorKey: "status",
        enableSorting: true,
        cell: ({ row }) => (
          <StatusBadge
            active={row.original.status === true || row.original.status === "Active"}
          />
        ),
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const dispatch = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(dispatch)}
                title={
                  dispatch.status === true || dispatch.status === "Active"
                    ? "Deactivate"
                    : "Activate"
                }
              >
                {dispatch.status === true || dispatch.status === "Active" ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>
              <Button asChild size="sm" variant="ghost" title="Edit">
                <Link to={`/workflow/dispatch-register/edit/${dispatch.id}`}>
                  <Edit />
                </Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage, handleToggleStatus]
  );

  return (
    <PageLayout
      title="Dispatch Register"
      addPath="add"
      addText="Add Dispatch"
    >
      <ShadcnDataTable
        Ltext="Dispatch Register"
        Rtext="Add Dispatch"
        addPath="add"
        data={dispatches}
        columns={dispatchColumns}
        tableState={tableState}
        onSearch={setSearch}
        onSort={setSort}
      />
    </PageLayout>
  );
};

export default DispatchRegister;
