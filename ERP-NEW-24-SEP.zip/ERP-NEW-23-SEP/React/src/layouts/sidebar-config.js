import {
  MdCurrencyRupee,
  MdHome,
  MdLock,
  MdOutlineDashboard
} from "react-icons/md";
import { GoTriangleRight } from "react-icons/go";
import { RiAdminLine } from "react-icons/ri";
import { PiUsersThreeLight } from "react-icons/pi";



// import { permissions } from "@/utils/permissions";

export const navItems = [
  {
    href: "/",
    icon: MdOutlineDashboard,
    label: "Dashboard",
    permission: null,
  },

  {
    href: "/page-permissions",
    icon: GoTriangleRight,
    label: "Page Permissions",
    permission: "PP",
  },
  {
    href: "/employees",
    icon: PiUsersThreeLight,
    label: "Employees",
    permission: null,
  },
  {
    label: "Master",
    icon: RiAdminLine,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/clients",
        icon: MdHome,
        label: "Manage Client",
        permission: null,
      },
      {
        href: "/company-profile",
        icon: MdLock,
        label: "Company Profile",
        permission: null,
      },
       {
        href: "/designations",
        icon: GoTriangleRight ,
        label: "Manage Designations",
        permission: null,
      },
      {
        href: "/contributions",
        icon: GoTriangleRight ,
        label: "Manage EPF/ESI",
        permission: null,
      },
      {
        href: "/manage-unit",
        icon: GoTriangleRight ,
        label: "Manage Unit", 
        permission: null,
      },
      {
        href: "/manage-item",
        icon: GoTriangleRight ,
        label: "Manage Item", 
        permission: null,
      },
      {
    href: "/master/vacancies",
    icon: GoTriangleRight ,
    label: "Manage Vacancy",
    permission: null,
  },





  //master vendor
  {
    href: "/master/vendors",
    icon: GoTriangleRight ,
    label: "Manage Vendor",
    permission: null,
  },

    ],
  },

  {
    label: "Increments",
    icon: GoTriangleRight,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/incrementschemes",
        icon: GoTriangleRight,
        label: "Increment Schemes",
        permission: null,
      },
      {
        href: "/increment-reports",
        icon: GoTriangleRight,
        label: "Increment Reports",
        permission: null,
      },
    ],
  },
  {
    label: "Tasks",
    icon: GoTriangleRight,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/tasks",
        icon: GoTriangleRight,
        label: "Tasks",
        permission: null,
      },
      {
        href: "/tasks/history",
        icon: GoTriangleRight,
        label: "Tasks History",
        permission: null,
      },
      {
        href: "/tasks/all-employees",
        icon: GoTriangleRight,
        label: "All Employee Tasks",
        permission: null,
      },
    ],
  },
  {
    label: "Payroll",
    icon: GoTriangleRight,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/salary-components",
        icon: GoTriangleRight,
        label: "Salary Policy",
        permission: null,
      },
      {
        href: "/salary-stucture",
        icon: GoTriangleRight,
        label: "SalaryStructurePage",
        permission: null,
      },
      {
        href: "/salary-payroll",
        icon: MdCurrencyRupee,
        label: "Generate Salary",
        permission: null,
      },
    ],
  },
  {
    label: "Leaves",
    icon: GoTriangleRight,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/leave-types",
        icon: GoTriangleRight,
        label: "Leave Types",
        permission: null,
      },
      {
        href: "/manage-leaves",
        icon: GoTriangleRight,
        label: "Manage Leaves",
        permission: null,
      },
      {
        href: "/request-leave",
        icon: GoTriangleRight,
        label: "Request Leave",
        permission: null,
      },
    ],
  },
  {
    href: "/log",
    icon: GoTriangleRight,
    label: "ActivityLog",
    permission: null,
  },
  // {
  //   label: "Master",
  //   icon: GoTriangleRight,
  //   permission: null,
  //   isSubmenu: true,
  //   subItems: [
  //     {
  //       href: "/clients",
  //       icon: MdHome,
  //       label: "Manage Client",
  //       permission: null,
  //     },
  //     {
  //       href: "/company-profile",
  //       icon: MdLock,
  //       label: "Company Profile",
  //       permission: null,
  //     },
  //      {
  //       href: "/designations",
  //       icon: GoTriangleRight ,
  //       label: "Manage Designations",
  //       permission: null,
  //     },
  //     {
  //       href: "/contributions",
  //       icon: GoTriangleRight ,
  //       label: "Manage EPF/ESI",
  //       permission: null,
  //     },
  //     {
  //       href: "/manage-unit",
  //       icon: GoTriangleRight ,
  //       label: "Manage Unit", 
  //       permission: null,
  //     },
  //     {
  //       href: "/manage-item",
  //       icon: GoTriangleRight ,
  //       label: "Manage Item", 
  //       permission: null,
  //     },
  //     {
  //   href: "/master/vacancies",
  //   icon: GoTriangleRight ,
  //   label: "Manage Vacancy",
  //   permission: null,
  // },





  // //master vendor
  // {
  //   href: "/master/vendors",
  //   icon: GoTriangleRight ,
  //   label: "Manage Vendor",
  //   permission: null,
  // },

  //   ],
  // },
];
