// import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from "@/components/ui/button";

// export default function PageLayout({ title, rightButton, children }) {
//   return (
//     <div className="shadow-2xl border bg-white p-6 ">
//       <div className="flex justify-between items-center mb-6">
//         {title && <h1 className="text-xl font-semibold">{title}</h1>}
//         {rightButton && (
//           <Link to={rightButton.path}>
//             <Button>{rightButton.text}</Button>
//           </Link>
//         )}
//       </div>

//       <div>{children}</div>
//     </div>
//   );
// }

import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function PageLayout({ title, rightButton, topButtons = [], children }) {
  // Convert old rightButton into the new format
  const normalizedButtons = [
    ...topButtons,
    ...(rightButton ? [{ text: rightButton.text, path: rightButton.path }] : []),
  ];

  return (
    <div className="shadow-2xl border bg-white p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        {title && <h1 className="text-xl font-semibold">{title}</h1>}
        <div className="flex gap-3">
          {normalizedButtons.map((btn, idx) =>
            btn.path ? (
              <Link key={idx} to={btn.path}>
                <Button>{btn.text}</Button>
              </Link>
            ) : (
              <Button key={idx} onClick={btn.onClick}>
                {btn.text}
              </Button>
            )
          )}
        </div>
      </div>

      {/* Content */}
      <div>{children}</div>
    </div>
  );
}
