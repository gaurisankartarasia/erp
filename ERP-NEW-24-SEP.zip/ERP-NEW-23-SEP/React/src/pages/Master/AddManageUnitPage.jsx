
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import apiClient from "@/api/axiosConfig";
import { toast } from "sonner";

const AddManageUnitPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    unit_name: "",
    description: "",
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);

  useEffect(() => {
    if (!id) return;
    const fetchUnit = async () => {
      setIsLoading(true);
      try {
        const res = await apiClient.get(`/units/${id}`);
        if (res.data.success && res.data.data) {
          const unit = res.data.data;
          setFormData((prev) => ({
            ...prev,
            unit_name: unit.unit_name || "",
            description: unit.description || "",
          }));
        } else {
          toast.error("Unit not found.");
        }
      } catch (err) {
        toast.error("Failed to load unit data.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchUnit();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.unit_name.trim()) newErrors.unit_name = "Unit name is required.";
    if (!formData.description.trim()) newErrors.description = "Description is required.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    setIsSubmitting(true);
    try {
      let res;
      if (id) {
        res = await apiClient.put(`/units/${id}`, {
          name: formData.unit_name,
          description: formData.description,
        });
        toast.success("Unit updated successfully!");
      } else {
        res = await apiClient.post(`/units`, {
          name: formData.unit_name,
          description: formData.description,
        });
        toast.success("Unit created successfully!");
      }
      navigate("/manage-unit");
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate("/manage-unit");
  };

  if (isLoading) {
    return (
      <div className="text-center py-10">
        <p>Loading unit data...</p>
      </div>
    );
  }

  return (
    <FormLayout
      headerText={id ? "Edit Unit" : "Add Unit"}
      descriptionText={id ? "Update the details of the unit." : "Fill in the details to create a new unit."}
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText={id ? "Update Unit" : "Create Unit"}
      showCancel={true}
      onCancel={handleCancel}
    >
      <FormInput
        name="unit_name"
        label="Unit Name"
        value={formData.unit_name}
        onChange={handleChange}
        required
        error={errors.unit_name}
      />
      <FormInput
        name="description"
        label="Description"
        type="textarea"
        rows="3"
        value={formData.description}
        onChange={handleChange}
        required
        error={errors.description}
      />
    </FormLayout>
  );
};

export default AddManageUnitPage;
