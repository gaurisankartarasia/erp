import { DataTypes } from 'sequelize';

export default (sequelize) => {
  // Define the 'State' model
  sequelize.define('State', {
    // Define attributes
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    state_name: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true // Corresponds to tinyint(1) default of 1
    },
    is_delete: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false // Corresponds to tinyint(1) default of 0
    }
  }, {
    // Model options
    tableName: 'erp_state', // <<< This now correctly points to your table
    timestamps: true,       // Enables created_at and updated_at fields
    createdAt: 'created_at',// Maps to the 'created_at' column
    updatedAt: 'updated_at' // Maps to the 'updated_at' column
  });
};