import { models } from "../models/index.js";
import { Op } from "sequelize";
const { Designation } = models;



const generateNextDesignationId = async () => {
  const lastDesignation = await Designation.findOne({
    order: [['id', 'DESC']],
  });

  if (!lastDesignation) {
    return 'DES001';
  }

  const numericPart = parseInt(lastDesignation.designation_id.substring(3), 10);
  const nextNumericPart = numericPart + 1;
  return `DES${String(nextNumericPart).padStart(3, '0')}`;
};

export const addDesignation = async (req, res) => {
  try {
    const { designation_name, description } = req.body;

    if (!designation_name || !description) {
      return res.status(400).json({ message: 'Designation Name and Description are required.' });
    }

    const existingDesignation = await Designation.findOne({ where: { designation_name } });
    if (existingDesignation) {
      return res.status(409).json({ message: 'A designation with this name already exists.' });
    }

    const designation_id = await generateNextDesignationId();

    const newDesignation = await Designation.create({
      designation_id,
      designation_name,
      description,
    });

    res.status(201).json({
      message: 'Designation added successfully.',
      designation: newDesignation,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error adding designation.' });
  }
};

export const editDesignation = async (req, res) => {
  try {
    const { id } = req.params;
    const { designation_name, description, is_active } = req.body;

    if (!designation_name || !description) {
      return res.status(400).json({ message: 'Designation Name and Description are required.' });
    }

    const designationToUpdate = await Designation.findByPk(id);
    if (!designationToUpdate) {
      return res.status(404).json({ message: 'Designation not found.' });
    }

    const existingDesignation = await Designation.findOne({
      where: {
        designation_name,
        id: { [Op.ne]: id },
      },
    });

    if (existingDesignation) {
      return res.status(409).json({ message: 'Another designation with this name already exists.' });
    }

    const updatedDesignation = await designationToUpdate.update({
      designation_name,
      description,
      is_active,
    });

    res.status(200).json({
      message: 'Designation updated successfully.',
      designation: updatedDesignation,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating designation.' });
  }
};

export const getAllDesignations = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = '',
      sort = 'createdAt',
      order = 'desc',
    } = req.query;

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const whereClause = {
      is_delete: false,
      [Op.or]: [
        { designation_id: { [Op.like]: `%${search}%` } },
        { designation_name: { [Op.like]: `%${search}%` } },
        { description: { [Op.like]: `%${search}%` } },
      ],
    };

    const { count, rows } = await Designation.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit, 10),
      offset,
      order: [[sort, order.toUpperCase()]],
    });

    res.status(200).json({
      data: rows,
      total: count,
    });
  } catch (error) {
    console.error("Error fetching designations:", error);
    res.status(500).json({ message: "Failed to fetch designations" });
  }
};

export const updateDesignationStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { is_active } = req.body;

    if (typeof is_active !== 'boolean') {
      return res.status(400).json({ message: 'Invalid status value provided.' });
    }

    const designation = await Designation.findByPk(id);

    if (!designation) {
      return res.status(404).json({ message: 'Designation not found.' });
    }

    await designation.update({ is_active });

    res.status(200).json({ message: 'Designation status updated successfully.' });
  } catch (error) {
    console.error('Error updating designation status:', error);
    res.status(500).json({ message: 'Failed to update designation status.' });
  }
};

export const getDesignationById = async (req, res) => {
  const { id } = req.params;

  try {
    const designation = await Designation.findByPk(id);

    if (!designation) {
      return res.status(400).json({
        message: "Designation Not Found",
      });
    }


    res.status(200).json(designation); 

  } catch (err) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: err.message, 
    });
  }
};