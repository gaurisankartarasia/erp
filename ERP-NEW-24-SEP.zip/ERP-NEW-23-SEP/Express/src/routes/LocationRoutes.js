import { Router } from 'express';
import {
  getAllStates,
  getStateWithDistricts,
  createState,
  getAllDistricts,
  getDistrictsByState,
  createDistrict
} from '../controllers/LocationController.js';
const router = Router();
router.get('/states', getAllStates);
router.post('/states', createState);
router.get('/states/:id', getStateWithDistricts);
router.get('/districts', getAllDistricts);
router.post('/districts', createDistrict);
router.get('/states/:stateId/districts', getDistrictsByState);

export default router;