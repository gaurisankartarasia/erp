import { Router } from 'express';
import {
  addContribution,
  editContribution,
  getAllContributions,
  getContributionById,
  updateContributionStatus,
} from '../controllers/ContributionController.js';

const router = Router();

router.get('/', getAllContributions);
router.get('/:id', getContributionById);
router.post('/', addContribution);
router.put('/:id', editContribution);
router.patch('/status/:id', updateContributionStatus);

export default router;