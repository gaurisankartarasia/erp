import { DataTypes } from 'sequelize';

export default (sequelize) => {
  // Define the 'District' model
  sequelize.define('District', {
    // Define attributes
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    district_name: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    state_id: {
      type: DataTypes.INTEGER,
      allowNull: true, // Based on your schema allowing NULL
      references: {
        model: 'erp_state', // This is the table name of the referenced model
        key: 'id'           // This is the column name of the referenced model
      }
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true // Corresponds to tinyint(1) default of 1
    },
    is_delete: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false // Corresponds to tinyint(1) default of 0
    }
  }, {
    // Model options
    tableName: 'erp_districts', // Correctly points to your table
    timestamps: true,           // Enables created_at and updated_at fields
    createdAt: 'created_at',    // Maps to the 'created_at' column
    updatedAt: 'updated_at'     // Maps to the 'updated_at' column
  });
};