
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import apiClient from "@/api/axiosConfig";
import { toast } from "sonner";

const AddManageItem = () => {
  const navigate = useNavigate();
  const { id } = useParams();  // id agar edit hai

  const [formData, setFormData] = useState({
    item_name: "",
    model_name: "",
    unit: "",         // ye unit:value hoga selected unit_id ya unit name, decide karo
  });
  const [units, setUnits] = useState([]);  // units array fetched from backend
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);

  // Fetch units list for dropdown
  useEffect(() => {
    const fetchUnits = async () => {
      try {
        const res = await apiClient.get("/units");
        if (res.data.success) {
          const unitOptions = res.data.data
            .filter((u) => u.status === "Active" || u.is_active === 1)
            .map((u) => ({
              value: u.unit_id,
              label: u.unit_name,
            }));
          setUnits(unitOptions);
        } else {
          setUnits([]);
        }
      } catch (error) {
        console.error("Error fetching units for dropdown:", error);
        setUnits([]);
      }
    };
    fetchUnits();
  }, []);

  // If in edit mode, fetch the item data and set form fields
  useEffect(() => {
    if (!id) {
      setIsLoading(false);
      return;
    }
    const fetchItem = async () => {
      setIsLoading(true);
      try {
        const res = await apiClient.get(`/items/${id}`);
        if (res.data.success && res.data.data) {
          const item = res.data.data;
          // item.unit should be the unit_id, not item_id
          setFormData((prev) => ({
            ...prev,
            item_name: item.item_name || "",
            model_name: item.model_name || "",
            unit: item.unit || "", // only use item.unit (unit_id)
          }));
        } else {
          toast.error("Failed to fetch item data.");
        }
      } catch (err) {
        console.error("Fetch item error:", err);
        toast.error("Failed to load item data.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchItem();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.item_name.trim()) {
      newErrors.item_name = "Item name is required.";
    }
    if (!formData.model_name.trim()) {
      newErrors.model_name = "Model name is required.";
    }
    if (!formData.unit.trim()) {
      newErrors.unit = "Unit is required.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    if (!validateForm()) return;
    setIsSubmitting(true);
    try {
      if (id) {
        // edit
        const res = await apiClient.put(`/items/${id}`, {
          item_name: formData.item_name,
          model_name: formData.model_name,
          unit: formData.unit,  // sending unit_id
        });
        if (res.data.success) {
          toast.success("Item updated successfully!");
          navigate("/manage-item");
        } else {
          toast.error(res.data.message || "Update failed.");
        }
      } else {
        // create
        const res = await apiClient.post("/items", {
          item_name: formData.item_name,
          model_name: formData.model_name,
          unit: formData.unit,  // sending unit_id
        });
        if (res.data.success) {
          toast.success("Item created successfully!");
          navigate("/manage-item");
        } else {
          toast.error(res.data.message || "Creation failed.");
        }
      }
    } catch (err) {
      console.error("Submit error:", err);
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate("/manage-item");
  };

  if (isLoading) {
    return (
      <div className="text-center py-10">
        <p>Loading item data...</p>
      </div>
    );
  }

  return (
    <FormLayout
      headerText={id ? "Edit Item" : "Add Item"}
      descriptionText={
        id
          ? "Update the details of the item."
          : "Fill in the details to create a new item."
      }
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText={id ? "Update Item" : "Create Item"}
      showCancel={true}
      onCancel={handleCancel}
    >
      <FormInput
        name="item_name"
        label="Item Name"
        value={formData.item_name}
        onChange={handleChange}
        required
        error={errors.item_name}
      />
      <FormInput
        name="model_name"
        label="Model Name"
        value={formData.model_name}
        onChange={handleChange}
        required
        error={errors.model_name}
      />
      <div className="form-group">
        <label htmlFor="unit" className="block font-medium mb-1">
          Unit <span className="text-red-500">*</span>
        </label>
        <select
          id="unit"
          name="unit"
          value={formData.unit}
          onChange={handleChange}
          required
          className={`border rounded px-2 py-1 w-full ${
            errors.unit ? "border-red-500" : "border-gray-300"
          }`}
          disabled={units.length === 0}
        >
          <option value="">-- Select Unit --</option>
          {units.map((u) => (
            <option key={u.value} value={u.value}>
              {u.label}
            </option>
          ))}
        </select>
        {errors.unit && (
          <p className="text-red-500 text-sm mt-1">{errors.unit}</p>
        )}
      </div>
    </FormLayout>
  );
};

export default AddManageItem;
