import React, { useState, useEffect, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import FormSelect from "@/components/common/forms/FormSelect";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Spinner } from "@/components/ui/spinner";

const SectionHeader = ({ title }) => (
  <div className="col-span-4 border-b pb-2">
    <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
  </div>
);

const AddressFields = ({
  type,
  formData,
  errors,
  stateOptions,
  districtOptions,
  handleChange,
  handleSelectChange,
  isDisabled = false,
}) => (
  <>
    <SectionHeader
      title={`${type.charAt(0).toUpperCase() + type.slice(1)} Address`}
    />
    <FormInput
      name={`${type}_address`}
      label="Address"
      value={formData[`${type}_address`]}
      onChange={handleChange}
      disabled={isDisabled}
      error={errors?.[`${type}_address`]}
      required
    />
    <FormInput
      name={`${type}_pin_code`}
      label="Pincode"
      value={formData[`${type}_pin_code`]}
      onChange={handleChange}
      disabled={isDisabled}
      error={errors?.[`${type}_pin_code`]}
      required
    />
    <FormSelect
      name={`${type}_state`}
      label="State"
      value={formData[`${type}_state`]}
      onValueChange={(value) => handleSelectChange(`${type}_state`, value)}
      options={stateOptions}
      disabled={isDisabled}
      error={errors?.[`${type}_state`]}
      required
    />
    <FormSelect
      name={`${type}_district`}
      label="District"
      value={formData[`${type}_district`]}
      onValueChange={(value) => handleSelectChange(`${type}_district`, value)}
      options={districtOptions}
      disabled={isDisabled || !formData[`${type}_state`]}
      error={errors?.[`${type}_district`]}
      placeholder={
        !formData[`${type}_state`]
          ? "Select a state first"
          : "Select a district"
      }
      required
    />
  </>
);

const EmployeeFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const message = useMessageModal();

  const getInitialState = () => ({
    user_type:"",
    name: "",
     email: "",
    mobile_no: "",
    dob: "",
    doj: "",
    designation: "",
    client: "",
    guardian_contact: "",
    gender: "",
    religion: "",
    father_name: "",
    mother_name: "",
    marital_status: "",
    spouse_name: "",
    qualification: "",
    extra_qualification: "",
    pan_no: "",
    bank_name: "",
    aadhar_no: "",
    branch_name: "",
     branch_id: "",
    esi_ip_no: "",
    ifsc_code: "",
    epf_uan_no: "",
    bank_ac_no: "",
    blood_group: "",
    gross_salary: "",
    dor: "",
    upload_image: null,
    upload_resume: null,
    present_address: "",
    present_district: "",
    present_state: "",
    present_pin_code: "",
    permanent_address: "",
    permanent_district: "",
    permanent_state: "",
    permanent_pin_code: "",
  });

  const [formData, setFormData] = useState(getInitialState());
    const [initialData, setInitialData] = useState(getInitialState());
  const [options, setOptions] = useState({
    designations: [],
    clients: [],
    states: [],
  });
  const [districts, setDistricts] = useState({ present: [], permanent: [] });
  const [isSameAddress, setIsSameAddress] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);

  const formatOptionsForSelect = (data, valueKey, labelKey) => {
    if (!Array.isArray(data)) return [];
    return data
      .filter((item) => item && item[valueKey] != null) 
      .map((item) => ({
        value: String(item[valueKey]), 
        label: item[labelKey],
      }));
  };

  const fetchData = useCallback(
    async (endpoint, valueKey, labelKey) => {
      try {
        const response = await apiClient.get(endpoint);
        return formatOptionsForSelect(response.data.data, valueKey, labelKey);
      } catch {
        message.error(`Failed to fetch options from ${endpoint}`);
        return [];
      }
    },
    [message]
  );

  const fetchDistricts = useCallback(
    async (stateId) => {
      if (!stateId) return [];
      try {
        return await fetchData(
          `/locations/states/${stateId}/districts`,
          "id",
          "district_name"
        );
      } catch {
        return [];
      }
    },
    [fetchData]
  );

  useEffect(() => {
    const fetchInitialOptions = async () => {
      const [designations, clients, states] = await Promise.all([
        fetchData("master/designations", "id", "designation_name"),
        fetchData("master/clients", "id", "projNm"),
        fetchData("/locations/states", "id", "state_name"),
      ]);
      setOptions({ designations, clients, states });
    };
    fetchInitialOptions();
  }, [fetchData]);

  useEffect(() => {
    if (!id) return;
    const fetchEmployee = async () => {
      setIsLoading(true);
      try {
        const res = await apiClient.get(`/employee/employees/${id}`);
        setFormData((prev) => ({ ...prev, ...res.data }));
        setInitialData((prev) => ({ ...prev, ...res.data }))
      } catch (err) {
        message.error("Failed to load employee data.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchEmployee();
  }, [id, message]);

  useEffect(() => {
    if (formData.present_state) {
      fetchDistricts(formData.present_state).then((d) =>
        setDistricts((prev) => ({ ...prev, present: d }))
      );
    }
  }, [formData.present_state, fetchDistricts]);

  useEffect(() => {
    if (!isSameAddress && formData.permanent_state) {
      fetchDistricts(formData.permanent_state).then((d) =>
        setDistricts((prev) => ({ ...prev, permanent: d }))
      );
    }
  }, [isSameAddress, formData.permanent_state, fetchDistricts]);

  useEffect(() => {
    if (isSameAddress) {
      setFormData((prev) => ({
        ...prev,
        permanent_address: prev.present_address,
        permanent_pin_code: prev.present_pin_code,
        permanent_state: prev.present_state,
        permanent_district: prev.present_district,
      }));
      setDistricts((prev) => ({ ...prev, permanent: prev.present }));
    }
  }, [
    isSameAddress,
    formData.present_address,
    formData.present_pin_code,
    formData.present_state,
    formData.present_district,
  ]);

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData((prev) => ({ ...prev, [name]: files[0] }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectChange = (name, value) => {
    setFormData((prev) => {
      const newState = { ...prev, [name]: value };
      if (name === "present_state" || name === "permanent_state") {
        newState[name.replace("_state", "_district")] = "";
      }
      return newState;
    });
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Full Name is required.";
    if (!formData.mobile_no.trim())
      newErrors.mobile_no = "Mobile Number is required.";
    if (!formData.doj) newErrors.doj = "Date of Joining is required.";
    if (!formData.designation)
      newErrors.designation = "Designation is required.";
    if (!formData.client) newErrors.client = "Client Location is required.";
    if (!formData.father_name)
      newErrors.father_name = "Father's Name is required.";
    if (!formData.guardian_contact)
      newErrors.guardian_contact = "Guardian Contact is required.";
    if (!formData.gender) newErrors.gender = "Gender is required.";
    if (!formData.marital_status)
      newErrors.marital_status = "Marital Status is required.";
    if (!formData.pan_no) newErrors.pan_no = "PAN Number is required.";
    if (!formData.aadhar_no) newErrors.aadhar_no = "Aadhar Number is required.";
    if (!formData.bank_name) newErrors.bank_name = "Bank Name is required.";
    if (!formData.bank_ac_no)
      newErrors.bank_ac_no = "Bank Account Number is required.";
       if (!formData.bank_ac_no)
      newErrors.branch_id = "Branch Id is required.";
    if (!formData.branch_name)
      newErrors.branch_name = "Branch Name is required.";
    if (!formData.ifsc_code) newErrors.ifsc_code = "IFSC Code is required.";
    if (!formData.present_address)
      newErrors.present_address = "Present Address Line is required.";
    if (!formData.present_pin_code)
      newErrors.present_pin_code = "Present Pincode is required.";
    if (!formData.present_state)
      newErrors.present_state = "Present State is required.";
    if (!formData.present_district)
      newErrors.present_district = "Present District is required.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    const payload = new FormData();
    Object.keys(formData).forEach((key) => {
      if (formData[key] !== null && formData[key] !== undefined) {
        payload.append(key, formData[key]);
      }
    });

    try {
      if (id) {
        await apiClient.put(`/employee/edit/${id}`, payload);
        message.success("Employee updated successfully.");
      } else {
        const res = await apiClient.post("/employee/register", payload);
        message.success("Employee registered successfully.");
        if (res.data.generatedPassword) {
          message.info(`Generated Password: ${res.data.generatedPassword}`);
        }
      }
      navigate("/employees"); 
    } catch (err) {
      message.error(
        err.response?.data?.message || "An unexpected error occurred."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectOptions = {
     user_type: [
      { value: "user", label: "User" },
      { value: "admin", label: "Admin" },
      { value: "master", label: "Master" },
    ],
    gender: [
      { value: "male", label: "Male" },
      { value: "female", label: "Female" },
      { value: "others", label: "Others" },
    ],
    religion: [
      { value: "Hindu", label: "Hindu" },
      { value: "Muslim", label: "Muslim" },
      { value: "Christian", label: "Christian" },
    ],
    marital_status: [
      { value: "single", label: "Single" },
      { value: "married", label: "Married" },
      { value: "divorced", label: "Divorced" },
      { value: "widowed", label: "Widowed" },
    ],
    blood_group: ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(
      (bg) => ({ value: bg, label: bg })
    ),
  };

  // if (isLoading)
  //   return (
  //     <div className="text-center py-10">
  //       <Spinner/>
  //     </div>
  //   );

  return (
    <FormLayout
      title={id ? "Edit Employee" : "Register Employee"}
      backPath= "/employees"
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText={id ? "Update" : "Submit"}
      onCancel={() => navigate("/employees")}
    onReset={() => {
  setFormData(initialData);
  setErrors({});
}}
 isLoading={isLoading}
    >
      <div className="col-span-2">
        <div className="grid grid-cols-4 gap-6">
          <FormSelect
          placeholder="--Slect User Type--"
            name="user_type"
            label="User Type"
            value={formData.user_type}
            onValueChange={(value) => handleSelectChange("user_type", value)}
            options={selectOptions.user_type}
            required
            error={errors.gender}
            showSearch="false"
          />
          <FormInput
          placeholder="Enter Name"
            name="name"
            label="Name"
            value={formData.name}
            onChange={handleChange}
            required
            error={errors.name}
          />
          <FormInput
            name="mobile_no"
            label="Mobile No"
            placeholder="Mobile No"
            value={formData.mobile_no}
            onChange={handleChange}
            required
            error={errors.mobile_no}
            maxLength={10}
          />
          <FormInput
            name="dob"
            label={"DOB"}
            type="date"
            value={formData.dob}
            onChange={handleChange}
            required
            error={errors.dob}
          />
          <FormInput
            name="doj"
            label="DOJ"
            type="date"
            value={formData.doj}
            onChange={handleChange}
            required
            error={errors.doj}
          />
          <FormSelect
            name="designation"
            label="Designation"
            placeholder="--Select Designation--"
            value={formData.designation}
            onValueChange={(value) => handleSelectChange("designation", value)}
            options={options.designations}
            required
            error={errors.designation}
          />
          <FormSelect
            name="client"
            label="Client Location"
            value={formData.client}
            onValueChange={(value) => handleSelectChange("client", value)}
            options={options.clients}
            required
            error={errors.client}
          />
           <FormInput
            name="email"
            label="Email Id"
             placeholder="Email Id"
            value={formData.email}
            onChange={handleChange}
            required
            error={errors.email}
          />
              <FormInput
            name="guardian_contact"
            label="Guardian Contact"
            value={formData.guardian_contact}
            onChange={handleChange}
            required
            error={errors.guardian_contact}
          />
          
          <FormSelect
            name="gender"
            label="Gender"
            value={formData.gender}
            onValueChange={(value) => handleSelectChange("gender", value)}
            options={selectOptions.gender}
            required
            error={errors.gender}
          />
               <FormSelect
            name="religion"
            label="Religion"
            value={formData.religion}
            onValueChange={(value) => handleSelectChange("religion", value)}
            options={selectOptions.religion}
            error={errors.religion}
          />
               <FormInput
            name="father_name"
            label="Father's Name"
            value={formData.father_name}
            onChange={handleChange}
            required
            error={errors.father_name}
          />
          <FormInput
            name="mother_name"
            label="Mother's Name"
            value={formData.mother_name}
            onChange={handleChange}
            error={errors.mother_name}
          />
      
     
          <FormSelect
            name="marital_status"
            label="Marital Status"
            value={formData.marital_status}
            onValueChange={(value) =>
              handleSelectChange("marital_status", value)
            }
            options={selectOptions.marital_status}
            required
            error={errors.marital_status}
          />
                    <FormInput
            name="spouse_name"
            label="Spouse's Name"
            value={formData.spouse_name}
            onChange={handleChange}
            error={errors.spouse_name}
          />
          <FormSelect
            name="blood_group"
            label="Blood Group"
            value={formData.blood_group}
            onValueChange={(value) => handleSelectChange("blood_group", value)}
            options={selectOptions.blood_group}
            error={errors.blood_group}
          />
          <FormInput
            name="qualification"
            label="Qualification"
            value={formData.qualification}
            onChange={handleChange}
            error={errors.qualification}
          />
          <FormInput
            name="extra_qualification"
            label="Extra Qualification"
            value={formData.extra_qualification}
            onChange={handleChange}
            error={errors.extra_qualification}
          />
          
          <FormInput
            name="pan_no"
            label="PAN Number"
            value={formData.pan_no}
            onChange={handleChange}
            required
            error={errors.pan_no}
          />
          <FormInput
            name="aadhar_no"
            label="Aadhar Number"
            value={formData.aadhar_no}
            onChange={handleChange}
            required
            error={errors.aadhar_no}
          />
              <FormInput
            name="esi_ip_no"
            label="ESI IP Number"
            value={formData.esi_ip_no}
            onChange={handleChange}
            error={errors.esi_ip_no}
          />
             <FormInput
            name="epf_uan_no"
            label="EPF UAN Number"
            value={formData.epf_uan_no}
            onChange={handleChange}
            error={errors.epf_uan_no}
          />
                  <FormInput
            name="bank_name"
            label="Bank Name"
            value={formData.bank_name}
            onChange={handleChange}
            required
            error={errors.bank_name}
          />
              <FormInput
            name="branch_name"
            label="Branch Name"
            value={formData.branch_name}
            onChange={handleChange}
            required
            error={errors.branch_name}
          />
              <FormInput
            name="ifsc_code"
            label="IFSC Code"
            value={formData.ifsc_code}
            onChange={handleChange}
            required
            error={errors.ifsc_code}
          />
          
          <FormInput
            name="bank_ac_no"
            label="Bank Account Number"
            value={formData.bank_ac_no}
            onChange={handleChange}
            required
            error={errors.bank_ac_no}
          />
           <FormInput
            name="branch_id"
            label="Branch Id"
            value={formData.branch_id}
            onChange={handleChange}
            required
            error={errors.branch_id}
          />
      
    

  
      

          <AddressFields
            type="present"
            formData={formData}
            errors={errors}
            stateOptions={options.states}
            districtOptions={districts.present}
            handleChange={handleChange}
            handleSelectChange={handleSelectChange}
          />

          <div className="col-span-4 flex items-center gap-2">
            <input
              type="checkbox"
              id="sameAddress"
              checked={isSameAddress}
              onChange={(e) => setIsSameAddress(e.target.checked)}
            />
            <label htmlFor="sameAddress" className="text-sm font-medium">
              Permanent Address is same as Present Address
            </label>
          </div>

          <AddressFields
            type="permanent"
            formData={formData}
            errors={errors}
            stateOptions={options.states}
            districtOptions={
              isSameAddress ? districts.present : districts.permanent
            }
            handleChange={handleChange}
            handleSelectChange={handleSelectChange}
            isDisabled={isSameAddress}
          />
      <FormInput
            name="gross_salary"
            label="Gross Salary"
            type="number"
            value={formData.gross_salary}
            onChange={handleChange}
            error={errors.gross_salary}
          />
          <FormInput
            name="dor"
            label="Date of Resignation"
            type="date"
            value={formData.dor}
            onChange={handleChange}
            error={errors.dor}
          />
            
            <FormInput
              name="upload_image"
              label="Upload Image"
              type="file"
              accept="image/*"
              onChange={handleChange}
              error={errors.upload_image}
            />
          
            <FormInput
              name="upload_resume"
              label="Upload Resume"
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={handleChange}
              error={errors.upload_resume}
            />
        </div>
      </div>
    </FormLayout>
  );
};

export default EmployeeFormPage;
