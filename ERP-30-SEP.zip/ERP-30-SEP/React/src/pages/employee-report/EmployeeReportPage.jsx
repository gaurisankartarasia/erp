import React, { useState, useEffect, useMemo } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import ShadcnDataTable from "@/components/common/DataTable";
import { Button } from "@/components/ui/button";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import { Spinner } from "@/components/ui/spinner";
import { Link } from "react-router-dom";
import { Eye } from "lucide-react";


const EmployeeReportPage = () => {
  const methods = useForm({ defaultValues: { client: "" } });
  const { handleSubmit, watch } = methods;

  const [clientOptions, setClientOptions] = useState([]);
  const [apiUrl, setApiUrl] = useState("");
  const message = useMessageModal();
  const selectedClient = watch("client");

  const { data: paginatedData, tableState } = useServerSideTable(apiUrl);

  const columns = useMemo(
    () => [
       {
      header: "SL No",
      cell: ({ row }) =>
        (tableState.currentPage - 1) * tableState.entriesPerPage + row.index + 1,
    },
      {
        accessorKey: "client_info.projNm",
        header: "Client Name",
        enableSorting: true,
      },
      { accessorKey: "emp_code", header: "Emp Code", enableSorting: true },
      { accessorKey: "name", header: "Name", enableSorting: true },
        {
        accessorKey: "designation_info.designation_name",
        header: "Designation",
        enableSorting: true,
      },
       { accessorKey: "mobile_no", header: "Mobile No", enableSorting: true },
            {
        accessorKey: "client_info.location",
        header: "Project Location",
        enableSorting: true,
      },
    
     { accessorKey: "bank_name", header: "Bank Name", enableSorting: true },
      { accessorKey: "branch_id", header: "Branch Code", enableSorting: true },
       { accessorKey: "bank_ac_no", header: "Bank A/C No", enableSorting: true },
       {
        header:"Actions",
        cell: ({row}) => (
          <Button variant={"ghost"}  asChild>
            
            <Link to={`view/${row.original.id}`} >
            <Eye/>
            </Link>
            
            </Button>  
        )
       }
     
    ],
    []
  );

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const res = await apiClient.get("/master/clients");
        const options = res.data.data.map((c) => ({
          value: String(c.id),
          label: c.projNm,
        }));
        setClientOptions(options);
      } catch {
        message.error("Failed to load clients.");
      }
    };
    fetchClients();
  }, [message]);

  const onSearch = (data) => {
    if (!data.client) {
      message.error("Please select a client to search.");
      return;
    }
    setApiUrl(
      `${
        import.meta.env.VITE_API_BASE_URL
      }/employee-reports/by-client?clientId=${data.client}`
    );
  };

  

  const handleExport = (format) => {
    if (!selectedClient) {
      message.error("Please select a client first to export data.");
      return;
    }
    const exportUrl = `${apiClient.defaults.baseURL}/employee-reports/by-client/export?clientId=${selectedClient}&format=${format}`;
    window.open(exportUrl, "_blank");
  };

  const handleCopy = async () => {
    if (!selectedClient) {
      message.error("Please select a client to copy data.");
      return;
    }
    try {
      const res = await apiClient.get(
        `/employee-reports/by-client/export?clientId=${selectedClient}&format=csv`
      );
      navigator.clipboard.writeText(res.data);
      message.success("Data copied to clipboard!");
    } catch {
      message.error("Failed to copy data.");
    }
  };

  const handlePrint = () => {
    if (!paginatedData || paginatedData.length === 0) {
      message.error("No data to print.");
      return;
    }
    window.print();
  };

  const selectedClientLabel = clientOptions.find(
    (c) => c.value === selectedClient
  )?.label;

  const safeData = paginatedData || [];
  const safeTableState = {
    ...tableState,
    totalItems: tableState.totalItems || 0,
  };


  return (
    <FormProvider {...methods}>
      <PageLayout
        title="Employee Reports"
        topButtons={[
          { text: "Copy", onClick: handleCopy },
          { text: "CSV", onClick: () => handleExport("csv") },
          { text: "Excel", onClick: () => handleExport("excel") },
          { text: "Print", onClick: handlePrint },
        ]}
      >
        <div className="mb-4" >
          <form
            onSubmit={handleSubmit(onSearch)}
            className="flex items-end gap-4 w-fit"
          >
            <div className="flex-grow">
              <FormSelect
                name="client"
                label="Select Client / Project"
                options={clientOptions}
                rules={{ required: "Client is required." }}
                className="w-fit"
              />
            </div>
            <Button type="submit" disabled={tableState.loading}>
              {tableState.loading ? <Spinner color="white" size={20} /> : "Show"}
            </Button>
          </form>
        </div>

        <div className="print-section">
          {/* {selectedClientLabel && (
            <h2 className="text-lg font-bold mb-4">
              Employee Report for: {selectedClientLabel}
            </h2>
          )} */}

          {apiUrl && (
            <ShadcnDataTable
              columns={columns}
              data={safeData}
              tableState={safeTableState}
            />
          )}
        </div>
      </PageLayout>
    </FormProvider>
  );
};

export default EmployeeReportPage;
