import React, {useEffect, useState} from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, FormProvider } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/pages/employee/custom/FormInput";
import apiClient from "@/api/axiosConfig";

const SectionHeader = ({ title }) => (
  <div className="col-span-4 mt-4 border-b pb-2">
    <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
  </div>
);

const AddressFields = ({ type }) => (
  <>
    <SectionHeader
      title={`${type.charAt(0).toUpperCase() + type.slice(1)} Address`}
    />
    <FormInput name={`${type}_address`} label="Address" />
    <FormInput name={`${type}_pin_code`} label="Pincode" />
    <FormInput name={`${type}_state_info.state_name`} label="State" />
    <FormInput name={`${type}_district_info.district_name`} label="District" />
  </>
);

const EmployeeDetailsView = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const methods = useForm({
    defaultValues: {
      user_type: "",
      name: "",
      email: "",
      mobile_no: "",
      dob: "",
      doj: "",
      designation_info: { designation_name: "" },
      client_info: { projNm: "" },
      guardian_contact: "",
      gender: "",
      religion: "",
      father_name: "",
      mother_name: "",
      marital_status: "",
      spouse_name: "",
      qualification: "",
      extra_qualification: "",
      pan_no: "",
      bank_name: "",
      aadhar_no: "",
      branch_name: "",
      branch_id: "",
      esi_ip_no: "",
      ifsc_code: "",
      epf_uan_no: "",
      bank_ac_no: "",
      blood_group: "",
      gross_salary: "",
      dor: "",
      present_address: "",
      present_district_info: { district_name: "" },
      present_state_info: { state_name: "" },
      present_pin_code: "",
      permanent_address: "",
      permanent_district_info: { district_name: "" },
      permanent_state_info: { state_name: "" },
      permanent_pin_code: "",
    },
  });

  const { watch, reset } = methods;
  const maritalStatus = watch("marital_status");
  const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const response = await apiClient.get(`/employee/employees/${id}`);
        const data = response.data;

        // populate form
        reset(data);
      } catch (error) {
        console.error("Failed to fetch employee", error);
        navigate("/employees");
      } finally {
        setIsLoading(false);
      }
    };

    if (id) fetchEmployee();
  }, [id, reset, navigate]);

  return (
    <FormProvider {...methods}>
      <FormLayout
        title="Employee Details"
        backPath="/employee-report"
        isLoading={isLoading}
        disabled
      >
        <div className="col-span-2">
          <div className="grid grid-cols-4 gap-6">
            <FormInput name="user_type" label="User Type" />
            <FormInput name="name" label="Name" />
            <FormInput name="mobile_no" label="Mobile No" />
            <FormInput name="dob" label="DOB" type="date" />
            <FormInput name="doj" label="DOJ" type="date" />
            <FormInput
              name="designation_info.designation_name"
              label="Designation"
            />
            <FormInput name="client_info.projNm" label="Client Location" />
            <FormInput name="email" label="Email Id" />
            <FormInput name="father_name" label="Father's Name" />
            <FormInput name="mother_name" label="Mother's Name" />
            <FormInput name="guardian_contact" label="Guardian Contact" />
            <FormInput name="gender" label="Gender" />
            <FormInput name="religion" label="Religion" />
            <FormInput name="marital_status" label="Marital Status" />
            {maritalStatus === "married" && (
              <FormInput name="spouse_name" label="Spouse's Name" />
            )}
            <FormInput name="blood_group" label="Blood Group" />
            <FormInput name="qualification" label="Qualification" />
            <FormInput name="extra_qualification" label="Extra Qualification" />
            <FormInput name="pan_no" label="PAN Number" />
            <FormInput name="aadhar_no" label="Aadhar Number" />
            <FormInput name="epf_uan_no" label="EPF UAN Number" />
            <FormInput name="esi_ip_no" label="ESI IP Number" />
            <FormInput name="bank_name" label="Bank Name" />
            <FormInput name="bank_ac_no" label="Bank Account Number" />
            <FormInput name="branch_name" label="Branch Name" />
            <FormInput name="ifsc_code" label="IFSC Code" />
            <FormInput name="branch_id" label="Branch Id" />

            <AddressFields type="present" />
            <AddressFields type="permanent" />

            <FormInput name="gross_salary" label="Gross Salary" type="number" />
            <FormInput name="dor" label="Date of Resignation" type="date" />
          </div>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default EmployeeDetailsView;