import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import apiClient from '@/api/axiosConfig'; // Make sure this path is correct
import FormLayout from '@/components/layouts/FormLayout'; // Make sure this path is correct
import FormInput from '@/components/common/forms/FormInput'; // Make sure this path is correct

// Component to display calculated, read-only values
const ReadOnlyField = ({ label, monthly, annual }) => (
  <div className="grid grid-cols-1 gap-4 items-center mb-4">
    <label className="font-semibold text-gray-700">{label}</label>
    <div>
      <FormInput
        value={monthly}
        readOnly
        className="bg-gray-200 text-gray-800 font-bold"
      />
    </div>
    <div>
      <FormInput
        value={annual}
        readOnly
        className="bg-gray-200 text-gray-800 font-bold"
      />
    </div>
  </div>
);

const Anxeture = () => {
  const navigate = useNavigate();
  const [salary, setSalary] = useState({
    basic: 0.00,
    hra: 0.00,
    otherAllowance: 0.00,
    yourContributionPf: 0.00,
    yourContributionEsi: 0.00,
    professionalTax: 0.00,
    companySharePf: 0.00,
    pfAdminCharges: 0.00,
    companyShareEsi: 0.00,
    overTime: 0.00,
  });

  const [calculated, setCalculated] = useState({
    salaryComponent: 0,
    net: 0,
    totalCTC: 0,
  });

  const [annexureId, setAnnexureId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatAnnual = (monthlyValue) => (monthlyValue * 12).toFixed(2);

  // Load saved data on component mount
  const loadSavedData = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await apiClient.get('/salary-annexures');
      if (response.data.success && response.data.data && response.data.data.length > 0) {
        const latestAnnexure = response.data.data[0];
        setSalary({
          basic: parseFloat(latestAnnexure.basic) || 0,
          hra: parseFloat(latestAnnexure.hra) || 0,
          otherAllowance: parseFloat(latestAnnexure.otherAllowance) || 0,
          yourContributionPf: parseFloat(latestAnnexure.yourContributionPf) || 0,
          yourContributionEsi: parseFloat(latestAnnexure.yourContributionEsi) || 0,
          professionalTax: parseFloat(latestAnnexure.professionalTax) || 0,
          companySharePf: parseFloat(latestAnnexure.companySharePf) || 0,
          pfAdminCharges: parseFloat(latestAnnexure.pfAdminCharges) || 0,
          companyShareEsi: parseFloat(latestAnnexure.companyShareEsi) || 0,
          overTime: parseFloat(latestAnnexure.overTime) || 0,
        });
        setAnnexureId(latestAnnexure.id);
        toast.info("Salary annexure data loaded.");
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
      toast.error('Could not load annexure data. Creating a new one.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSavedData();
  }, [loadSavedData]);

  // Calculate values whenever salary changes
  useEffect(() => {
    const salaryComponent = (salary.basic || 0) + (salary.hra || 0) + (salary.otherAllowance || 0);
    const totalDeductions = (salary.yourContributionPf || 0) + (salary.yourContributionEsi || 0) + (salary.professionalTax || 0);
    const net = salaryComponent - totalDeductions;
    const companyContributions = (salary.companySharePf || 0) + (salary.pfAdminCharges || 0) + (salary.companyShareEsi || 0) + (salary.overTime || 0);
    const totalCTC = salaryComponent + companyContributions;

    setCalculated({ salaryComponent, net, totalCTC });
  }, [salary]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSalary(prev => ({
      ...prev,
      [name]: value === '' ? 0 : parseFloat(value) || 0,
    }));
  };

  const handleReset = () => {
    setSalary({
      basic: 0.00,
      hra: 0.00,
      otherAllowance: 0.00,
      yourContributionPf: 0.00,
      yourContributionEsi: 0.00,
      professionalTax: 0.00,
      companySharePf: 0.00,
      pfAdminCharges: 0.00,
      companyShareEsi: 0.00,
      overTime: 0.00,
    });
    setAnnexureId(null);
    toast.info("The form has been reset.");
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const requestData = {
        ...salary,
        salaryComponent: calculated.salaryComponent,
        net: calculated.net,
        totalCTC: calculated.totalCTC
      };

      let response;
      if (annexureId) {
        // Update existing record
        response = await apiClient.put(`/salary-annexures/${annexureId}`, requestData);
        toast.success("Salary annexure updated successfully!");
      } else {
        // Create new record
        response = await apiClient.post('/salary-annexures/create', requestData);
        setAnnexureId(response.data.data.id);
        toast.success("Salary annexure created successfully!");
      }
      console.log("Saved salary data:", response.data);
    } catch (error) {
      console.error('Error saving data:', error);
      toast.error(error.response?.data?.message || "Error saving data. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate(-1);
  };

  const inputFields = [
    { name: 'basic', label: 'Basic' },
    { name: 'hra', label: 'HRA' },
    { name: 'otherAllowance', label: 'Other Allowance' },
    { name: 'yourContributionPf', label: 'Your Contribution to PF' },
    { name: 'yourContributionEsi', label: 'Your Contribution to ESI' },
    { name: 'professionalTax', label: 'Professional Tax' },
    { name: 'companySharePf', label: "Company's Share of PF" },
    { name: 'pfAdminCharges', label: 'PF Admin Charges' },
    { name: 'companyShareEsi', label: "Company's Share of ESI" },
    { name: 'overTime', label: 'Over Time' },
  ];

  if (isLoading) {
    return (
      <div className="text-center py-10">
        <p>Loading annexure data...</p>
      </div>
    );
  }

  return (
    <FormLayout
      headerText={annexureId ? `Edit Salary Annexure (ID: ${annexureId})` : 'Create Salary Annexure'}
      descriptionText="Fill in the details to calculate and save the salary structure."
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText={annexureId ? 'Update Annexure' : 'Save Annexure'}
      showCancel={true}
      onCancel={handleCancel}
      customButtons={
        <button
          type="button"
          className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 disabled:opacity-50"
          onClick={handleReset}
          disabled={isSubmitting}
        >
          Reset
        </button>
      }
    >
      {/* --- Headers --- */}
      <div className="grid grid-cols-1 gap-4 mb-2 font-bold text-sm text-gray-600">
        <div>Salary Component</div>
        <div>Monthly</div>
        <div>Annual</div>
      </div>

      {/* --- Input Fields --- */}
      {inputFields.slice(0, 3).map(field => (
        <div key={field.name} className="grid grid-cols-1 gap-4 items-center mb-4">
          <label htmlFor={field.name} className="font-semibold">{field.label}</label>
          <FormInput
            type="number"
            name={field.name}
            value={salary[field.name]}
            onChange={handleChange}
            step="0.01"
            min="0"
          />
          <FormInput
            type="text"
            value={formatAnnual(salary[field.name])}
            readOnly
            className="bg-gray-100"
          />
        </div>
      ))}

      {/* --- Total Salary Component --- */}
      <ReadOnlyField 
        label="Salary Component (Total)" 
        monthly={calculated.salaryComponent.toFixed(2)} 
        annual={formatAnnual(calculated.salaryComponent)} 
      />

      <hr className="my-6" />

      {/* --- Deduction Fields --- */}
      {inputFields.slice(3, 6).map(field => (
        <div key={field.name} className="grid grid-cols-1 gap-4 items-center mb-4">
          <label htmlFor={field.name} className="font-semibold">{field.label}</label>
          <FormInput
            type="number"
            name={field.name}
            value={salary[field.name]}
            onChange={handleChange}
            step="0.01"
            min="0"
          />
          <FormInput
            type="text"
            value={formatAnnual(salary[field.name])}
            readOnly
            className="bg-gray-100"
          />
        </div>
      ))}

      {/* --- Net Salary --- */}
      <ReadOnlyField 
        label="Net Salary" 
        monthly={calculated.net.toFixed(2)} 
        annual={formatAnnual(calculated.net)} 
      />

      <hr className="my-6" />

      {/* --- Company Contributions --- */}
      {inputFields.slice(6).map(field => (
        <div key={field.name} className="grid grid-cols-1 gap-4 items-center mb-4">
          <label htmlFor={field.name} className="font-semibold">{field.label}</label>
          <FormInput
            type="number"
            name={field.name}
            value={salary[field.name]}
            onChange={handleChange}
            step="0.01"
            min="0"
          />
          <FormInput
            type="text"
            value={formatAnnual(salary[field.name])}
            readOnly
            className="bg-gray-100"
          />
        </div>
      ))}

      <hr className="my-6 border-t-2 border-gray-300" />

      {/* --- Total CTC --- */}
      <ReadOnlyField 
        label="Total Cost to Company (CTC)" 
        monthly={calculated.totalCTC.toFixed(2)} 
        annual={formatAnnual(calculated.totalCTC)} 
      />
    </FormLayout>
  );
};

export default Anxeture;
