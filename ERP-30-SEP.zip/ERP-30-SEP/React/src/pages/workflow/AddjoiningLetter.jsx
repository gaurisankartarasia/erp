// // import React, { useState, useEffect } from "react";
// // import { useNavigate } from "react-router-dom";

// // import FormLayout from "@/components/layouts/FormLayout";
// // import FormInput from "@/components/common/forms/FormInput";
// // import MessageModal from "@/components/common/modals/MessageModal";
// // import apiClient from "@/api/axiosConfig";

// // const AddjoiningLetter = () => {
// //   const navigate = useNavigate();

// //   // Helper to get today's date in YYYY-MM-DD format
// //   const getTodayDate = () => new Date().toISOString().slice(0, 10);

// //   const [formData, setFormData] = useState({
// //     name: "",
// //     designation: "",
// //     date: "", // Default to today's date as shown in the screenshot
// //     date_of_joining: "",
// //     cost_to_company: "",
// //     phone_number: "",
// //     address: "",
// //   });

// //   const [errors, setErrors] = useState({});
// //   const [isSubmitting, setIsSubmitting] = useState(false);
// //   const [messageModal, setMessageModal] = useState({ isOpen: false, message: "", variant: "info" });

// //   const handleChange = (e) => {
// //     const { name, value } = e.target;
// //     setFormData((prev) => ({ ...prev, [name]: value }));
// //     if (errors[name]) {
// //       setErrors((prev) => ({ ...prev, [name]: null }));
// //     }
// //   };

// //   const validateForm = () => {
// //     const newErrors = {};
// //     if (!formData.name.trim()) newErrors.name = "Name is required.";
// //     if (!formData.designation.trim()) newErrors.designation = "Designation is required.";
// //     if (!formData.date) newErrors.date = "Date is required.";
// //     if (!formData.date_of_joining) newErrors.date_of_joining = "Date of Joining is required.";
// //     if (!formData.cost_to_company) newErrors.cost_to_company = "Cost to Company is required.";
// //     if (!formData.phone_number.trim()) newErrors.phone_number = "Contact/Phone No is required.";
// //     if (!formData.address.trim()) newErrors.address = "Address is required.";
// //     return newErrors;
// //   };

// //   const handleReset = () => {
// //     setFormData({
// //       name: "", designation: "", date: getTodayDate(), date_of_joining: "",
// //       cost_to_company: "", phone_number: "", address: "",
// //     });
// //     setErrors({});
// //   };

// //   const handleSubmit = async () => {
// //     const formErrors = validateForm();
// //     setErrors(formErrors);
// //     if (Object.keys(formErrors).length > 0) {
// //     //   setMessageModal({ isOpen: true, message: "Please fill all required fields.", variant: "warning" });
// //       return;
// //     }

// //     setIsSubmitting(true);

// //     try {
// //       await apiClient.post("/joining-letters/create", formData);
// //       setMessageModal({ isOpen: true, message: "Joining Letter created successfully!", variant: "success" });
// //     } catch (err) {
// //       setMessageModal({ isOpen: true, message: err.response?.data?.message || "Failed to create joining letter.", variant: "danger" });
// //     } finally {
// //       setIsSubmitting(false);
// //     }
// //   };

// //   const handleCloseModal = () => {
// //     if (messageModal.variant === 'success') {
// //       navigate(-1); // Go back to the previous page on success
// //     }
// //     setMessageModal({ isOpen: false, message: "", variant: "info" });
// //   };

// //   return (
// //     <>
// //       <FormLayout
// //         headerText="Add Joining Letter"
// //         backButton={{ text: "Back", onClick: () => navigate(-1) }}
// //         onSubmit={handleSubmit}
// //         isSubmitting={isSubmitting}
// //         submitText="Submit"
// //         showCancel={true}
// //         onCancel={() => navigate(-1)}
// //         showReset={true}
// //         onReset={handleReset}
// //       >
// //         {/* Use a grid for the two-column layout */}
// //         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
// //           <FormInput name="name" label="Name" value={formData.name} onChange={handleChange} required error={errors.name} placeholder="Name" />
// //           <FormInput name="designation" label="Designation" value={formData.designation} onChange={handleChange} required error={errors.designation} placeholder="Designation" />
// //           <FormInput name="date" label="Date" type="date" value={formData.date} onChange={handleChange} required error={errors.date} />
// //           <FormInput name="date_of_joining" label="Date of Joining" type="date" value={formData.date_of_joining} onChange={handleChange} required error={errors.date_of_joining} />
// //           <FormInput name="cost_to_company" label="Cost to Company" type="number" value={formData.cost_to_company} onChange={handleChange} required error={errors.cost_to_company} placeholder="Cost to Company" />
// //           <FormInput name="phone_number" label="Contact/Phone No" value={formData.phone_number} onChange={handleChange} required error={errors.phone_number} placeholder="Phone Number" />
          
// //           {/* Address field spans both columns */}
// //           <div className="md:col-span-2">
// //             <FormInput name="address" label="Address" type="textarea" value={formData.address} onChange={handleChange} required error={errors.address} placeholder="Address" rows={4} />
// //           </div>
// //         </div>
// //       </FormLayout>

// //       <MessageModal
// //         isOpen={messageModal.isOpen}
// //         onClose={handleCloseModal}
// //         message={messageModal.message}
// //         variant={messageModal.variant}
// //       />
// //     </>
// //   );
// // };

// // export default AddjoiningLetter;

// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import FormLayout from "@/components/layouts/FormLayout";
// import FormInput from "@/components/common/forms/FormInput";
// import MessageModal from "@/components/common/modals/MessageModal";
// import apiClient from "@/api/axiosConfig";

// const AddJoiningLetter = () => {
//   const navigate = useNavigate();

//   // Helper to get today's date in YYYY-MM-DD format
//   const getTodayDate = () => new Date().toISOString().slice(0, 10);

//   const [formData, setFormData] = useState({
//     name: "",
//     designation: "",
//     date: getTodayDate(), // Default to today's date
//     date_of_joining: "",
//     cost_to_company: "",
//     phone_number: "",
//     address: "",
//   });

//   const [errors, setErrors] = useState({});
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [messageModal, setMessageModal] = useState({ isOpen: false, message: "", variant: "info" });

//   // Use useEffect to set default date when component mounts
//   useEffect(() => {
//     setFormData(prev => ({
//       ...prev,
//       date: getTodayDate()
//     }));
//   }, []);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({ ...prev, [name]: value }));
//     if (errors[name]) {
//       setErrors((prev) => ({ ...prev, [name]: null }));
//     }
//   };

//   const validateForm = () => {
//     const newErrors = {};
//     if (!formData.name.trim()) newErrors.name = "Name is required.";
//     if (!formData.designation.trim()) newErrors.designation = "Designation is required.";
//     if (!formData.date) newErrors.date = "Date is required.";
//     if (!formData.date_of_joining) newErrors.date_of_joining = "Date of Joining is required.";
//     if (!formData.cost_to_company) newErrors.cost_to_company = "Cost to Company is required.";
//     if (!formData.phone_number.trim()) newErrors.phone_number = "Contact/Phone No is required.";
//     if (!formData.address.trim()) newErrors.address = "Address is required.";
//     return newErrors;
//   };

//   const handleReset = () => {
//     setFormData({
//       name: "", 
//       designation: "", 
//       date: getTodayDate(), 
//       date_of_joining: "",
//       cost_to_company: "", 
//       phone_number: "", 
//       address: "",
//     });
//     setErrors({});
//   };

//   const handleSubmit = async () => {
//     const formErrors = validateForm();
//     setErrors(formErrors);
//     if (Object.keys(formErrors).length > 0) {
//       return;
//     }

//     setIsSubmitting(true);

//     try {
//       await apiClient.post("/joining-letters/create", formData);
//       setMessageModal({ isOpen: true, message: "Joining Letter created successfully!", variant: "success" });
//     } catch (err) {
//       setMessageModal({ isOpen: true, message: err.response?.data?.message || "Failed to create joining letter.", variant: "danger" });
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   const handleCloseModal = () => {
//     if (messageModal.variant === 'success') {
//       navigate(-1);
//     }
//     setMessageModal({ isOpen: false, message: "", variant: "info" });
//   };

//   return (
//     <>
//       <FormLayout
//         headerText="Add Joining Letter"
//         backButton={{ text: "Back", onClick: () => navigate(-1) }}
//         onSubmit={handleSubmit}
//         isSubmitting={isSubmitting}
//         submitText="Submit"
//         showCancel={true}
//         onCancel={() => navigate(-1)}
//         showReset={true}
//         onReset={handleReset}
//       >
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//           <FormInput name="name" label="Name" value={formData.name} onChange={handleChange} required error={errors.name} placeholder="Name" />
//           <FormInput name="designation" label="Designation" value={formData.designation} onChange={handleChange} required error={errors.designation} placeholder="Designation" />
//           <FormInput name="date" label="Date" type="date" value={formData.date} onChange={handleChange} required error={errors.date} />
//           <FormInput name="date_of_joining" label="Date of Joining" type="date" value={formData.date_of_joining} onChange={handleChange} required error={errors.date_of_joining} />
//           <FormInput name="cost_to_company" label="Cost to Company" type="number" value={formData.cost_to_company} onChange={handleChange} required error={errors.cost_to_company} placeholder="Cost to Company" />
//           <FormInput name="phone_number" label="Contact/Phone No" value={formData.phone_number} onChange={handleChange} required error={errors.phone_number} placeholder="Phone Number" />
          
//           <div className="md:col-span-2">
//             <FormInput name="address" label="Address" type="textarea" value={formData.address} onChange={handleChange} required error={errors.address} placeholder="Address" rows={4} />
//           </div>
//         </div>
//       </FormLayout>

//       <MessageModal
//         isOpen={messageModal.isOpen}
//         onClose={handleCloseModal}
//         message={messageModal.message}
//         variant={messageModal.variant}
//       />
//     </>
//   );
// };

// export default AddJoiningLetter;



import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import MessageModal from "@/components/common/modals/MessageModal";
import apiClient from "@/api/axiosConfig";

const AddEditJoiningLetter = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // Get ID from URL for edit mode
  
  const isEditMode = Boolean(id); // Check if we're in edit mode

  // Helper to get today's date in YYYY-MM-DD format
  const getTodayDate = () => new Date().toISOString().slice(0, 10);

  const [formData, setFormData] = useState({
    name: "",
    designation: "",
    date: getTodayDate(),
    date_of_joining: "",
    cost_to_company: "",
    phone_number: "",
    address: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(isEditMode); // Load data only in edit mode
  const [messageModal, setMessageModal] = useState({ isOpen: false, message: "", variant: "info" });

  // Fetch existing data when in edit mode
  useEffect(() => {
    if (isEditMode) {
      fetchJoiningLetterData();
    } else {
      // Set default date for add mode
      setFormData(prev => ({
        ...prev,
        date: getTodayDate()
      }));
      setLoading(false);
    }
  }, [id, isEditMode]);

  // Fetch joining letter data for editing
  const fetchJoiningLetterData = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get(`/joining-letters/${id}`);
      const letterData = response.data.data;
      
      // Format dates for input fields (YYYY-MM-DD)
      setFormData({
        name: letterData.name || "",
        designation: letterData.designation || "",
        date: letterData.date ? letterData.date.split('T')[0] : getTodayDate(),
        date_of_joining: letterData.date_of_joining ? letterData.date_of_joining.split('T')[0] : "",
        cost_to_company: letterData.cost_to_company || "",
        phone_number: letterData.phone_number || "",
        address: letterData.address || "",
      });
    } catch (error) {
      console.error("Error fetching joining letter data:", error);
      setMessageModal({
        isOpen: true,
        message: "Failed to load joining letter data",
        variant: "danger"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name is required.";
    if (!formData.designation.trim()) newErrors.designation = "Designation is required.";
    if (!formData.date) newErrors.date = "Date is required.";
    if (!formData.date_of_joining) newErrors.date_of_joining = "Date of Joining is required.";
    if (!formData.cost_to_company) newErrors.cost_to_company = "Cost to Company is required.";
    if (!formData.phone_number.trim()) newErrors.phone_number = "Contact/Phone No is required.";
    if (!formData.address.trim()) newErrors.address = "Address is required.";
    return newErrors;
  };

  const handleReset = () => {
    if (isEditMode) {
      // In edit mode, reset to original fetched data
      fetchJoiningLetterData();
    } else {
      // In add mode, reset to empty form
      setFormData({
        name: "",
        designation: "",
        date: getTodayDate(),
        date_of_joining: "",
        cost_to_company: "",
        phone_number: "",
        address: "",
      });
    }
    setErrors({});
  };

  const handleSubmit = async () => {
    const formErrors = validateForm();
    setErrors(formErrors);
    if (Object.keys(formErrors).length > 0) {
      return;
    }

    setIsSubmitting(true);

    try {
      if (isEditMode) {
        // Update existing record
        await apiClient.put(`/joining-letters/${id}`, formData);
        setMessageModal({ 
          isOpen: true, 
          message: "Joining Letter updated successfully!", 
          variant: "success" 
        });
      } else {
        // Create new record
        await apiClient.post("/joining-letters/create", formData);
        setMessageModal({ 
          isOpen: true, 
          message: "Joining Letter created successfully!", 
          variant: "success" 
        });
      }
    } catch (err) {
      const errorMessage = err.response?.data?.message || 
        (isEditMode ? "Failed to update joining letter." : "Failed to create joining letter.");
      setMessageModal({ 
        isOpen: true, 
        message: errorMessage, 
        variant: "danger" 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCloseModal = () => {
    if (messageModal.variant === 'success') {
      navigate(-1); // Go back to list page on success
    }
    setMessageModal({ isOpen: false, message: "", variant: "info" });
  };

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '50vh',
        fontSize: '18px'
      }}>
        Loading joining letter data...
      </div>
    );
  }

  return (
    <>
      <FormLayout
        headerText={isEditMode ? "Edit Joining Letter" : "Add Joining Letter"}
        backButton={{ text: "Back", onClick: () => navigate(-1) }}
        onSubmit={handleSubmit}
        isSubmitting={isSubmitting}
        submitText={isEditMode ? "Update" : "Submit"}
        showCancel={true}
        onCancel={() => navigate(-1)}
        showReset={true}
        onReset={handleReset}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormInput 
            name="name" 
            label="Name" 
            value={formData.name} 
            onChange={handleChange} 
            required 
            error={errors.name} 
            placeholder="Name" 
          />
          <FormInput 
            name="designation" 
            label="Designation" 
            value={formData.designation} 
            onChange={handleChange} 
            required 
            error={errors.designation} 
            placeholder="Designation" 
          />
          <FormInput 
            name="date" 
            label="Date" 
            type="date" 
            value={formData.date} 
            onChange={handleChange} 
            required 
            error={errors.date} 
          />
          <FormInput 
            name="date_of_joining" 
            label="Date of Joining" 
            type="date" 
            value={formData.date_of_joining} 
            onChange={handleChange} 
            required 
            error={errors.date_of_joining} 
          />
          <FormInput 
            name="cost_to_company" 
            label="Cost to Company" 
            type="number" 
            value={formData.cost_to_company} 
            onChange={handleChange} 
            required 
            error={errors.cost_to_company} 
            placeholder="Cost to Company" 
          />
          <FormInput 
            name="phone_number" 
            label="Contact/Phone No" 
            value={formData.phone_number} 
            onChange={handleChange} 
            required 
            error={errors.phone_number} 
            placeholder="Phone Number" 
          />
          
          <div className="md:col-span-2">
            <FormInput 
              name="address" 
              label="Address" 
              type="textarea" 
              value={formData.address} 
              onChange={handleChange} 
              required 
              error={errors.address} 
              placeholder="Address" 
              rows={4} 
            />
          </div>
        </div>
      </FormLayout>

      <MessageModal
        isOpen={messageModal.isOpen}
        onClose={handleCloseModal}
        message={messageModal.message}
        variant={messageModal.variant}
      />
    </>
  );
};

export default AddEditJoiningLetter;