import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import PageLayout from "@/components/layouts/PageLayout";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import { Button } from "@/components/ui/button";
import { Edit, Printer, Plus } from "lucide-react";

const JoiningLetter = () => {
  const {
    data: joiningLetters,
    tableState,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/joining-letters`
  );

  const handlePrint = (letter) => {
    // Helper function to format currency or return an empty string if value is not present
    const formatCurrency = (value) => {
      if (typeof value === 'number') {
        return value.toFixed(2);
      }
      return ''; // Return blank if no value
    };
    
    // Helper function to calculate annual value or return empty string
    const formatAnnual = (value) => {
        if (typeof value === 'number') {
            return (value * 12).toFixed(2);
        }
        return ''; // Return blank if no value
    };

    // Extract salary details from the letter object. Use 0 for calculation if not present.
    const salaryDetails = {
      basic: letter.basic_salary,
      hra: letter.hra,
      other_allowance: letter.other_allowance,
      your_contribution_pf: letter.your_contribution_pf,
      your_contribution_esi: letter.your_contribution_esi,
      professional_tax: letter.professional_tax,
      company_share_pf: letter.company_share_pf,
      pf_admin_charges: letter.pf_admin_charges,
      company_share_esi: letter.company_share_esi,
      over_time: letter.over_time,
      remarks: letter.remarks || "", // Keep remarks or make it blank
    };

    // Calculate totals, treating missing values as 0
    const monthlyGross = (salaryDetails.basic || 0) + (salaryDetails.hra || 0) + (salaryDetails.other_allowance || 0);
    const monthlyDeductions = (salaryDetails.your_contribution_pf || 0) + (salaryDetails.your_contribution_esi || 0) + (salaryDetails.professional_tax || 0);
    const netSalary = monthlyGross - monthlyDeductions;
    const monthlyCTC = monthlyGross + (salaryDetails.company_share_pf || 0) + (salaryDetails.pf_admin_charges || 0) + (salaryDetails.company_share_esi || 0) + (salaryDetails.over_time || 0);
    const annualCTC = monthlyCTC * 12;


    const qrData = `Name: ${letter.name}, Ref: ${letter.reference_number || `MTPL-${letter.id}`}`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(qrData)}`;

    const printWindow = window.open("", "_blank");

    printWindow.document.write(`
      <html>
        <head>
          <title>Offer Letter - ${letter.name}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Times+New+Roman&display=swap');
            body { 
              font-family: 'Times New Roman', Times, serif;
              font-size: 12pt;
              line-height: 1.5;
              margin: 0;
              padding: 0;
            }
            .page {
              width: 210mm;
              min-height: 297mm;
              padding: 20mm;
              margin: 0 auto;
              box-sizing: border-box;
            }
            .page-break {
              page-break-after: always;
            }
            .header-underline {
              text-align: center;
              font-weight: bold;
              text-decoration: underline;
              font-size: 16pt;
              margin-bottom: 30px;
            }
            .details-container {
              display: flex;
              justify-content: space-between;
              align-items: flex-start;
            }
            .personal-details p, .date-details p {
              margin: 4px 0;
            }
            .qr-code {
              text-align: right;
            }
            .terms-list {
              padding-left: 20px;
              list-style-type: none;
            }
            .terms-list li {
              margin-bottom: 15px;
              position: relative;
              text-align: justify;
            }
            .terms-list li::before {
              content: '■';
              position: absolute;
              left: -20px;
              font-size: 10pt;
            }
            .signature-section {
              margin-top: 40px;
              text-align: right;
            }
            .annexure-table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            .annexure-table th, .annexure-table td {
              border: 1px solid black;
              padding: 8px;
              text-align: left;
            }
            .annexure-table th {
              background-color: #f2f2f2;
            }
            .annexure-table td:nth-child(3), .annexure-table td:nth-child(4) {
              text-align: right;
            }
            .total-row {
              font-weight: bold;
            }
            .footer-signatures {
              display: flex;
              justify-content: space-between;
              margin-top: 100px;
            }

            @media print {
              body, .page {
                margin: 0;
                box-shadow: 0;
              }
            }
          </style>
        </head>
        <body>
          <!-- PAGE 1: Offer Letter and All Terms -->
          <div class="page">
            <h2 class="header-underline">OFFER LETTER</h2>
            <div class="details-container">
              <div class="personal-details">
                <p><strong>Name:</strong> ${letter.name || ''}</p>
                <p><strong>Designation:</strong> ${letter.designation || ''}</p>
                <p><strong>Date of Joining:</strong> ${new Date(letter.date_of_joining).toLocaleDateString("en-GB")}</p>
                <p><strong>Cost to Company:</strong> ${formatCurrency(letter.cost_to_company)}</p>
                <p><strong>Mobile No:</strong> ${letter.phone_number || ''}</p>
                <p><strong>Address:</strong> ${letter.address || ''}</p>
              </div>
              <div class="date-details">
                <p><strong>Date:</strong> ${new Date().toLocaleDateString("en-GB")}</p>
                <div class="qr-code">
                   <img src="${qrCodeUrl}" alt="QR Code" />
                </div>
              </div>
            </div>
            <br/>
            <p>This is reference to your application and subsequent interviews with us, we are pleased to appoint you in our organization. Your employment will be governed by the following terms and conditions;</p>
            <ul class="terms-list">
              <li><strong>Salary:</strong> Your Cost to Company (CTC) and detail breakup is attached in Annexure-I.</li>
              <li><strong>Working Hours:</strong> Your working hours will be 10:00 AM to 7:00 PM as per the current company policy (including Lunch Hour). The company observes Six days of work in a week.</li>
              <li><strong>Salary Increment:</strong> The performance will be reviewed periodically. The increments in the salary range will be on the basis of demonstrated results and effectiveness of performance during the period. Further, you cannot apply your resignation within 3 months of receiving the increment.</li>
              <li><strong>Probation Period:</strong> You will be on probation for a period of six months from the date of your appointment. On satisfactory completion of the probation period, you will be confirmed in service. If not confirmed after six months, this order will continue to be in operation & the probation period will stand extended automatically till further notice.</li>
              <li><strong>Responsibilities:</strong> In view of your office, you must effectively perform to ensure results. Your performance would be reviewed as per the Company’s Performance Management System. You have managed overall operation and management of the projects as well as liaison on the company projects as and when required.</li>
              <li><strong>Leave:</strong> You will be governed by the current Leave Policy of the company for permanent employees.</li>
              <li><strong>Travel:</strong> Whenever you are required to undertake travel on Company work, you will be reimbursed travel expenses as per Company rules.</li>
              <li><strong>Transfer:</strong> You will be liable to be transferred to any other department or establishment or branch or subsidiary of the Company in India or abroad. In such a case, you will be governed by the terms and conditions of service as applicable to the new assignment.</li>
              <li><strong>Contract with Past Employers:</strong> It will be your personal responsibility to discharge all obligations arising out of any contract or bond with previous employers.</li>
              <li><strong>Notice Period:</strong> This appointment may be terminated by either side by giving three months’ notice period, after completion of the probation period (Six Months). Otherwise, company will take necessary action as per court of laws.</li>
              <li><strong>Other Work:</strong> Your position with the Company calls for whole time employment and you will devote yourself exclusively to the business of the Company. You will not take up any other work for remuneration (part time or work on advisory capacity or be interested directly or indirectly except as shareholder or debenture holder) in any other trade or business during your employment with the Company, without permission from the Company.</li>
              <li><strong>Conflict of Interest:</strong> You will not seek full time or part time job or be involved in any way with competitor’s business activities either directly or indirectly during the event of cessation of your employment with the Company.</li>
              <li><strong>Confidential Information:</strong> You will not disclose or divulge or make public except under legal obligation, any information regarding Company’s affairs of administration or research at any time without the consent of the Company.</li>
              <li><strong>On Termination:</strong> On termination of this contract, you will immediately give up to the Company all correspondence, specifications, formulae, books, documents, market data, cost data, literature, drawings, effect or records, etc. belonging to the Company or relating to its business and shall not make or retain any copies of these items, otherwise company will take necessary action against you as per court of Law.</li>
              <li><strong>General:</strong> The above terms and conditions are based on Company Policy, Procedures and other Rules and Regulations currently applicable to the Company’s employees and are subject to amendments and adjustments from time to time.</li>
              <li><strong>Legal:</strong> This offer letter is not valid for any legal or financial purpose. The company will not be liable for your legal or financial matters.</li>
            </ul>
            <p>We welcome you to the <strong>Mindtrack</strong> family and trust we will have a long and mutually rewarding association.</p>
            <div class="signature-section">
                <p>Yours faithfully</p>
                <br/><br/><br/>
                <p>For Mindtrack Technologies Pvt Ltd</p>
            </div>
            <p><strong>Note: Please communicate your acceptance on the duplicate copy of this offer letter.</strong></p>
          </div>
          <div class="page-break"></div>
          
          <!-- PAGE 2: Annexure -->
          <div class="page">
            <div style="text-align: right; font-weight: bold;">Annexure-I</div>
            <p><strong>Applicant Name:</strong> ${letter.name || ''}</p>
            <table class="annexure-table">
              <thead>
                <tr>
                  <th>#Sl</th>
                  <th>DETAILS OF SALARY</th>
                  <th>MONTHLY (INR)</th>
                  <th>ANNUALLY (INR)</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>A</td><td>Basic</td><td>${formatCurrency(salaryDetails.basic)}</td><td>${formatAnnual(salaryDetails.basic)}</td></tr>
                <tr><td>B</td><td>HRA</td><td>${formatCurrency(salaryDetails.hra)}</td><td>${formatAnnual(salaryDetails.hra)}</td></tr>
                <tr><td>C</td><td>Other Allowance</td><td>${formatCurrency(salaryDetails.other_allowance)}</td><td>${formatAnnual(salaryDetails.other_allowance)}</td></tr>
                <tr class="total-row"><td></td><td><strong>Gross Salary (A+B+C)</strong></td><td><strong>${formatCurrency(monthlyGross)}</strong></td><td><strong>${formatAnnual(monthlyGross)}</strong></td></tr>
                <tr><td>D</td><td>Your Contribution PF</td><td>${formatCurrency(salaryDetails.your_contribution_pf)}</td><td>${formatAnnual(salaryDetails.your_contribution_pf)}</td></tr>
                <tr><td>E</td><td>Your Contribution ESI</td><td>${formatCurrency(salaryDetails.your_contribution_esi)}</td><td>${formatAnnual(salaryDetails.your_contribution_esi)}</td></tr>
                <tr><td>F</td><td>Professional Tax</td><td>${formatCurrency(salaryDetails.professional_tax)}</td><td>${formatAnnual(salaryDetails.professional_tax)}</td></tr>
                <tr class="total-row"><td></td><td><strong>Total Deductions (D+E+F)</strong></td><td><strong>${formatCurrency(monthlyDeductions)}</strong></td><td><strong>${formatAnnual(monthlyDeductions)}</strong></td></tr>
                <tr class="total-row"><td></td><td><strong>Net Salary</strong></td><td><strong>${formatCurrency(netSalary)}</strong></td><td><strong>${formatAnnual(netSalary)}</strong></td></tr>
                <tr><td>G</td><td>Company Share of PF</td><td>${formatCurrency(salaryDetails.company_share_pf)}</td><td>${formatAnnual(salaryDetails.company_share_pf)}</td></tr>
                <tr><td>H</td><td>PF Admin Charges</td><td>${formatCurrency(salaryDetails.pf_admin_charges)}</td><td>${formatAnnual(salaryDetails.pf_admin_charges)}</td></tr>
                <tr><td>I</td><td>Company Share of ESI</td><td>${formatCurrency(salaryDetails.company_share_esi)}</td><td>${formatAnnual(salaryDetails.company_share_esi)}</td></tr>
                <tr><td>J</td><td>Over Time</td><td>${formatCurrency(salaryDetails.over_time)}</td><td>${formatAnnual(salaryDetails.over_time)}</td></tr>
                <tr class="total-row">
                  <td colspan="2">Your Total Cost to Company (CTC)</td>
                  <td>${formatCurrency(monthlyCTC)}</td>
                  <td>${formatCurrency(annualCTC)}</td>
                </tr>
              </tbody>
            </table>
            <br/>
            <p><strong>Remarks:</strong> ${salaryDetails.remarks}</p>
            <div class="footer-signatures">
              <span>For Mindtrack Technologies Pvt Ltd</span>
              <span>Authorized Signature</span>
            </div>
          </div>
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    // Use a timeout to ensure content is loaded before printing
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 250);
  };

  const columns = useMemo(
    () => [
      {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "Ref No",
        accessorKey: "reference_number",
        cell: ({ row }) => row.original.reference_number || `MTPL-${row.original.id}`,
      },
      {
        header: "Name",
        accessorKey: "name",
        enableSorting: true,
      },
      {
        header: "Designation",
        accessorKey: "designation",
        enableSorting: true,
      },
      {
        header: "Contact",
        accessorKey: "phone_number",
      },
      {
        header: "Date of Joining",
        accessorKey: "date_of_joining",
        cell: ({ row }) =>
          new Date(row.original.date_of_joining).toLocaleDateString("en-GB"),
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const letter = row.original;
          return (
            <div className="flex gap-2">
              <Button asChild size="sm" variant="ghost" title="Edit">
                <Link to={`/workflow/edit-joining-letter/${letter.id}`}>
                  <Edit className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="sm"
                variant="ghost"
                title="Print"
                onClick={() => handlePrint(letter)}
              >
                <Printer className="h-4 w-4 text-green-500" />
              </Button>
              {/* --- THIS IS THE CHANGED PART --- */}
              <Button
                asChild
                size="sm"
                variant="ghost"
                title="Add Annexure"
              >
                <Link to={`/workflow/anxeture/${letter.id}`}>
                    <Plus className="h-4 w-4 text-blue-500" />
                </Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage]
  );

  return (
    <PageLayout
      title="Joining Letter List"
      rightButton={{ text: "Add Joining Letter", path: "/workflow/add-joining-letter" }}
    >
      <ShadcnDataTable
        data={joiningLetters}
        columns={columns}
        tableState={tableState}
        Ltext="All Joining Letters" 
      />
    </PageLayout>
  );
};

export default JoiningLetter;