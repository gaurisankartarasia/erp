import React from "react";


const WorkOrderViewModal = ({ isOpen, onClose, workOrder }) => {
  if (!isOpen) return null;
  // Defensive: fallback if no data
  if (!workOrder) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
        <div className="bg-white rounded-lg shadow-lg p-6 w-[700px] relative">
          <button className="absolute top-2 right-2 text-gray-500" onClick={onClose}>&times;</button>
          <div className="text-center py-10 text-gray-500">No data found for this work order.</div>
        </div>
      </div>
    );
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="bg-white rounded-lg shadow-lg p-6 w-[700px] relative">
        <button className="absolute top-2 right-2 text-gray-500" onClick={onClose}>
          &times;
        </button>
        <table className="w-full border">
          <tbody>
            <tr>
              <td className="border px-3 py-2 font-semibold">Client Name:</td>
              <td className="border px-3 py-2">{workOrder.Client?.clientNm || "-"}</td>
              <td className="border px-3 py-2 font-semibold">Work Order no:</td>
              <td className="border px-3 py-2">{workOrder.work_order_no}</td>
            </tr>
            <tr>
              <td className="border px-3 py-2 font-semibold">Date:</td>
              <td className="border px-3 py-2">{workOrder.start_date ? new Date(workOrder.start_date).toLocaleDateString() : "-"}</td>
              <td className="border px-3 py-2 font-semibold">Expiry Date :</td>
              <td className="border px-3 py-2">{workOrder.expiry_date ? new Date(workOrder.expiry_date).toLocaleDateString() : "-"}</td>
            </tr>
            <tr>
              <td className="border px-3 py-2 font-semibold">Subject:</td>
              <td className="border px-3 py-2">{workOrder.subject}</td>
              <td className="border px-3 py-2 font-semibold">Taxable Price:</td>
              <td className="border px-3 py-2">{workOrder.taxable_price}</td>
            </tr>
            <tr>
              <td className="border px-3 py-2 font-semibold">Tax Amount:</td>
              <td className="border px-3 py-2">{workOrder.tax_amount}</td>
              <td className="border px-3 py-2 font-semibold">Total Amount :</td>
              <td className="border px-3 py-2">{workOrder.total_amount}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WorkOrderViewModal;
