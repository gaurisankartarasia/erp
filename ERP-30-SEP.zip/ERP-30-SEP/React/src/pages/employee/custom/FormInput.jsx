
import React from "react";
import { useFormContext } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const FormInput = ({
  name,
  label,
  placeholder,
  required = false,
  type = "text",
  maxLength,
  rows,
  disabled,
  ...props
}) => {
  const {
    register,
    formState: { errors },
  } = useFormContext();

  const error = errors[name]?.message 
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <Label className="text-sm font-medium" htmlFor={name}>
          {label} {required && <span className="text-red-500">*</span>}
        </Label>
      </div>

      {type === "textarea" ? (
        <textarea
          id={name}
          placeholder={placeholder}
          rows={rows || 3}
          maxLength={maxLength}
          className={cn(
            "w-full border rounded-md px-3 py-2 text-sm bg-input",
            error ? "border-red-500" : ""
          )}
          {...register(name, props.rules)}
        />
      ) : (
        <Input
          id={name}
          type={type}
          placeholder={placeholder}
          maxLength={maxLength ?? (type === "tel" ? 10 : undefined)}
          className={cn(error ? "border-red-500" : "", "bg-input")}
          disabled={disabled ? true : false}
          
          {...register(name, props.rules)}
        />
      )}

      {/* {error && <p className="mt-1 text-xs text-red-600">{error}</p>} */}
    </div>
  );
};

export default React.memo(FormInput);
