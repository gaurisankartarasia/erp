import { useEffect, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import apiClient from "@/api/axiosConfig";
import useAuth from "@/hooks/useAuth";
import PageLayout from "@/components/layouts/PageLayout";

export default function AccountPage() {
  const [employee, setEmployee] = useState(null);

  const { user } = useAuth();

  useEffect(() => {
    apiClient
      .get(`/accounts/${user.id}`)
      .then((res) => {
        setEmployee(res.data);
      })
      .catch((error) => {
        console.error("Error fetching employee data:", error);
      });
  }, [user.id]);

  if (!employee) return <p className="text-center text-gray-500">Loading...</p>;
  const apiBaseUrl = import.meta.env.VITE_API_BASE_URL.replace("/api", "");
  return (
    <PageLayout>
      <img src={`${apiBaseUrl}/uploads/employees/${employee.upload_image}`} alt="Image" className="object-contain w-48" />

<div className="grid grid-cols-4 gap-6" >
  <p>ID: {employee.id}</p>
<p>Employee Code: {employee.emp_code}</p>
<p>User Type: {employee.user_type}</p>
<p>Name: {employee.name}</p>
<p>Email: {employee.email}</p>
<p>Mobile No: {employee.mobile_no}</p>
<p>Date of Birth: {employee.dob}</p>
<p>Date of Joining: {employee.doj}</p>
<p>Designation: {employee.designation}</p>
<p>Client: {employee.client}</p>
<p>Guardian Contact: {employee.guardian_contact}</p>
<p>Gender: {employee.gender}</p>
<p>Religion: {employee.religion}</p>
<p>Father's Name: {employee.father_name}</p>
<p>Mother's Name: {employee.mother_name}</p>
<p>Marital Status: {employee.marital_status}</p>
<p>Spouse Name: {employee.spouse_name}</p>
<p>Qualification: {employee.qualification}</p>
<p>Extra Qualification: {employee.extra_qualification}</p>
<p>Bank Name: {employee.bank_name}</p>
<p>Branch Name: {employee.branch_name}</p>
<p>ESI IP No: {employee.esi_ip_no}</p>
<p>IFSC Code: {employee.ifsc_code}</p>
<p>EPF UAN No: {employee.epf_uan_no}</p>
<p>Blood Group: {employee.blood_group}</p>
<p>Branch ID: {employee.branch_id}</p>
<p>Permanent Address: {employee.permanent_address}</p>
<p>Present Address: {employee.present_address}</p>
<p>Permanent District: {employee.permanent_district}</p>
<p>Present District: {employee.present_district}</p>
<p>Permanent State: {employee.permanent_state}</p>
<p>Present State: {employee.present_state}</p>
<p>Permanent Pin Code: {employee.permanent_pin_code}</p>
<p>Present Pin Code: {employee.present_pin_code}</p>
<p>Gross Salary: {employee.gross_salary}</p>
<p>Date of Resignation: {employee.dor}</p>
<p>Upload Image: {employee.upload_image}</p>
<p>Upload Resume: {employee.upload_resume}</p>
<p>Active: {employee.is_active}</p>
<p>Deleted: {employee.is_delete}</p>
<p>Master User: {employee.is_master}</p>
<p>Last Login: {employee.last_login}</p>
<p>Created At: {employee.createdAt}</p>
<p>Updated At: {employee.updatedAt}</p>

<p>Designation ID: {employee.designation_info.designation_id}</p>
<p>Designation Name: {employee.designation_info.designation_name}</p>

<p>Client ID: {employee.client_info.clientid}</p>
<p>Project Name: {employee.client_info.projNm}</p>
<p>Client Name: {employee.client_info.ClientNm}</p>

<p>Permanent State Name: {employee.permanent_state_info.state_name}</p>
<p>Present State Name: {employee.present_state_info.state_name}</p>

<p>Permanent District Name: {employee.permanent_district_info.district_name}</p>
<p>Present District Name: {employee.present_district_info.district_name}</p>

</div>
    </PageLayout>
  );
}
