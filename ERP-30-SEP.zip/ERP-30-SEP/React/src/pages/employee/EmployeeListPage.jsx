import React, { useMemo, useState } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "../../hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check, Eye } from "lucide-react";
import apiClient from "@/api/axiosConfig";
import Modal from "@/components/common/modals/Modal";


const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const EmployeeListPage = () => {
  const {
    data: employees,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/employee/employees`
  );
  const confirm = useConfirmModal();
  const [openModal, setOpenModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  const handleToggleStatus = async (employee) => {
    const ok = await confirm({
      title: "Change Status",
      description: `Are you sure you want to ${
        employee.is_active ? "deactivate" : "activate"
      } this employee?`,
    });

    if (!ok) return;

    try {
      await apiClient.patch(`/employee/${employee.id}/status`);
      refreshData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const employeeColumns = useMemo(
    () => [
      {
        id: "sl_no",
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        id: "emp_code",
        header: "Emp Id",
        accessorFn: (row) => row.emp_code || "-",
        enableSorting: true,
      },
      {
        id: "name",
        header: "Name",
        accessorFn: (row) => row.name || "-",
        enableSorting: true,
      },
      {
        id: "designation",
        header: "Designation",
        accessorFn: (row) => row.designation_info?.designation_name || "-",
        enableSorting: true,
      },
      {
        id: "mobile_no",
        header: "Mobile No",
        accessorFn: (row) => row.mobile_no || "-",
        enableSorting: true,
      },
      {
        id: "email",
        header: "Email Id",
        accessorFn: (row) => row.email || "-",
        enableSorting: true,
      },
      {
        id: "client_location",
        header: "Client Location",
        accessorFn: (row) => row.client_info?.projNm || "-",
        enableSorting: true,
      },
      {
        id: "status",
        header: "Status",
        accessorFn: (row) => row.is_active,
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          const employee = row.original;
          return (
            <div className="flex items-center">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(employee)}
              >
                {employee.is_active ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>

              <Button asChild size="sm" variant="ghost">
                <Link to={`/employees/${employee.id}/edit`}>
                  <Edit />
                </Link>
              </Button>

              <Button
                variant="ghost"
                onClick={() => {
                  setSelectedEmployee(employee);
                  setOpenModal(true);
                }}
              >
                <Eye />
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage]
  );

  return (
    <PageLayout title="Employee List" addPath={"add"} addText="Add Employee">
      <ShadcnDataTable
        Ltext="Employee List"
        Rtext="Add Employee"
        addPath="add"
        data={employees}
        columns={employeeColumns}
        tableState={tableState}
      />

      <Modal open={openModal} onOpenChange={setOpenModal} size="full">
        {selectedEmployee && (
          <div className="grid grid-cols-2 gap-4">
            {Object.entries({
              "Employee ID": selectedEmployee.emp_code,
              "User Type": selectedEmployee.user_type,
              Name: selectedEmployee.name,
              Email: selectedEmployee.email,
              "Mobile No": selectedEmployee.mobile_no,
              "Date of Birth": selectedEmployee.dob,
              "Date of Joining": selectedEmployee.doj,
              "Guardian Contact": selectedEmployee.guardian_contact,
              Gender: selectedEmployee.gender,
              Religion: selectedEmployee.religion,
              "Father Name": selectedEmployee.father_name,
              "Mother Name": selectedEmployee.mother_name,
              "Marital Status": selectedEmployee.marital_status,
              "Spouse Name": selectedEmployee.spouse_name,
              Qualification: selectedEmployee.qualification,
              "Extra Qualification": selectedEmployee.extra_qualification,
              "PAN No": selectedEmployee.pan_no,
              "Bank Name": selectedEmployee.bank_name,
              "Aadhar No": selectedEmployee.aadhar_no,
              "Branch Name": selectedEmployee.branch_name,
              "ESI IP No": selectedEmployee.esi_ip_no,
              "IFSC Code": selectedEmployee.ifsc_code,
              "EPF UAN No": selectedEmployee.epf_uan_no,
              "Bank AC No": selectedEmployee.bank_ac_no,
              "Blood Group": selectedEmployee.blood_group,
              "Branch ID": selectedEmployee.branch_id,
              "Permanent Address": selectedEmployee.permanent_address,
              "Present Address": selectedEmployee.present_address,
              "Permanent District":
                selectedEmployee.permanent_district_info?.district_name,
              "Present District":
                selectedEmployee.present_district_info?.district_name,
              "Permanent State":
                selectedEmployee.permanent_state_info?.state_name,
              "Present State": selectedEmployee.present_state_info?.state_name,
              "Permanent Pin Code": selectedEmployee.permanent_pin_code,
              "Present Pin Code": selectedEmployee.present_pin_code,
              "Gross Salary": selectedEmployee.gross_salary,
              "Date of Retirement": selectedEmployee.dor,
              Designation: selectedEmployee.designation_info?.designation_name,
              "Client Location": selectedEmployee.client_info?.projNm,
              Status: selectedEmployee.is_active ? "Active" : "Inactive",
            }).map(([key, value]) => (
              <div
                key={key}
                className="flex items-center justify-between border-b py-2"
              >
                <span className="font-medium text-md text-muted-foreground">
                  {key}
                </span>
                <span className="text-right">{value || "-"}</span>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </PageLayout>
  );
};

export default EmployeeListPage;
