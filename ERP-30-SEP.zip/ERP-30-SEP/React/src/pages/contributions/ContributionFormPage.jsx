import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";


export default function ContributionFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = !!id;
  const message = useMessageModal();
  const [formData, setFormData] = useState({
    epf_employee_share: "",
    epf_employer_share: "",
    esi_employee_share: "",
    esi_employer_share: "",
  });
    const [initialData, setInitialData] = useState({
    epf_employee_share: "",
    epf_employer_share: "",
    esi_employee_share: "",
    esi_employer_share: "",
  });
  const [formErrors, setFormErrors] = useState({});


  useEffect(() => {
    if (isEditMode) {
      apiClient.get(`/contributions/${id}`)
        .then((response) => {
          const { data } = response;
          const response_data = {
            epf_employee_share: data.epf_employee_share,
            epf_employer_share: data.epf_employer_share,
            esi_employee_share: data.esi_employee_share,
            esi_employer_share: data.esi_employer_share,
          }
          setFormData(response_data);
          setInitialData(response_data)
        })
        .catch(() => message.error("Failed to fetch contribution data."));
    }
  }, [isEditMode, id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (isNaN(formData.epf_employee_share) || formData.epf_employee_share === "") errors.epf_employee_share = "Must be a valid number.";
    if (isNaN(formData.epf_employer_share) || formData.epf_employer_share === "") errors.epf_employer_share = "Must be a valid number.";
    if (isNaN(formData.esi_employee_share) || formData.esi_employee_share === "") errors.esi_employee_share = "Must be a valid number.";
    if (isNaN(formData.esi_employer_share) || formData.esi_employer_share === "") errors.esi_employer_share = "Must be a valid number.";
    return errors;
  };

  const handleSubmit = async (e) => {
    const validationErrors = validateForm();
    setFormErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) return;

    try {
      if (isEditMode) {
        await apiClient.put(`/contributions/${id}`, formData);
        message.success("Contribution updated successfully!");
      } else {
        await apiClient.post("/contributions", formData);
        message.success("Contribution added successfully!");
      }
      navigate("/contributions")
    } catch (err) {
      message.error(err.response?.data?.message || "An unexpected error occurred.");
    }
  };

  return (
    <FormLayout
      title={isEditMode ? "Edit Contribution Details" : "Add Contribution Details"}
      onSubmit={handleSubmit}
          submitText={isEditMode ? "Update" : "Submit" }
      onCancel={() => navigate("/contributions")}
      onReset={() => setFormData(initialData)}
      
    >
      
      <FormInput
        required
        label="EPF Emp Share"
        name="epf_employee_share"
        type="number"
        placeholder="0.00"
        value={formData.epf_employee_share}
        onChange={handleChange}
        error={formErrors.epf_employee_share}
      />
      <FormInput
        required
        label="EPF Empr Share"
        name="epf_employer_share"
        type="number"
        placeholder="0.00"
        value={formData.epf_employer_share}
        onChange={handleChange}
        error={formErrors.epf_employer_share}
      />
      <FormInput
        required
        label="ESI Emp Share"
        name="esi_employee_share"
        type="number"
        placeholder="0.00"
        value={formData.esi_employee_share}
        onChange={handleChange}
        error={formErrors.esi_employee_share}
      />
      <FormInput
        required
        label="ESI Empr Share"
        name="esi_employer_share"
        type="number"
        placeholder="0.00"
        value={formData.esi_employer_share}
        onChange={handleChange}
        error={formErrors.esi_employer_share}
      />
   
    </FormLayout>
  );
}