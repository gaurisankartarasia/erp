import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

export default function DesignationsForm() {
    const {id } = useParams()
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    designation_name: "",
    description: "",
  });
  const [initialData, setInitialData] = useState({
  designation_name: "",
  description: "",
});
  const [formErrors, setFormErrors] = useState({});
  const message = useMessageModal();

  const isEditMode = !!id;

useEffect(() => {
  if (isEditMode) {
    apiClient
      .get(`/designations/${id}`)
      .then((response) => {
        const data = {
          designation_name: response.data.designation_name,
          description: response.data.description,
        };
        setFormData(data);
        setInitialData(data); 
      })
      .catch((err) => {
        console.error(err);
      });
  }
}, [isEditMode, id]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.designation_name.trim()) {
      errors.designation_name = "Designation Name is required.";
    }
    if (!formData.description.trim()) {
      errors.description = "Description is required.";
    }
    return errors;
  };

  const handleSubmit = async (e) => {
    const validationErrors = validateForm();
    setFormErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    const payload = {
      designation_name: formData.designation_name,
      description: formData.description,
    };

    try {
      if (isEditMode) {
        await apiClient.put(`/designations/edit/${id}`, payload);
        message.success("Designation updated successfully!");
      } else {
        await apiClient.post("/designations/create", payload);
        message.success("Designation added successfully!");
      }
      setTimeout(() => navigate("/designations"), 2000);
    } catch (err) {
      message.error(
        err.response?.data?.message || "An unexpected error occurred."
      );
      console.error(err);
    }
  };

  return (
    <FormLayout
      title={
        isEditMode ? "Edit Designation" : "Add Designation"
      }
      onSubmit={handleSubmit}
      submitText={isEditMode ? "Update" : "Submit" }
      onCancel={() => navigate("/designations")}
   onReset={() => {
  setFormData(initialData); 
  setFormErrors({});
}}

    >
      <FormInput
        required
        label={"Designation Name"}
        name="designation_name"
        placeholder={"Enter Designation Name"}
        value={formData.designation_name}
        onChange={handleChange}
        error={formErrors.designation_name}
      />

      <FormInput
        required
        label={"Description"}
        name="description"
        placeholder={"Enter Description"}
        value={formData.description}
        onChange={handleChange}
        error={formErrors.description}
      />
    </FormLayout>
  );
}
