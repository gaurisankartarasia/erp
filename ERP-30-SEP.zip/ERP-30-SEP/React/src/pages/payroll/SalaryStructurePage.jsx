import React, { useEffect, useState } from "react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Spinner } from "@/components/ui/spinner";
import PageLayout from "@/components/layouts/PageLayout";
import SalaryStructureForm from "./SalaryStructureForm";
import axios from "axios";
import MessageModal from "@/components/common/modals/MessageModal";
axios.defaults.withCredentials = true;
const SalaryStructurePage = () => {
  const [employees, setEmployees] = useState([]);
  const [salaryComponents, setSalaryComponents] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [messageModalText, setMessageModalText] = useState("");
  const [messageModalVariant, setMessageModalVariant] = useState("info");

  useEffect(() => {
    const fetchInitialData = async () => {
      setIsLoading(true);
      try {
        const [empResponse, compResponse] = await Promise.all([
          axios.get(
            `${import.meta.env.VITE_API_BASE_URL}/salary/list-employees`,
            { withCredentials: true }
          ),
          axios.get(
            `${import.meta.env.VITE_API_BASE_URL}/salary/components?limit=1000`,
            { withCredentials: true }
          ),
        ]);

        setEmployees(empResponse.data);
        setSalaryComponents(compResponse.data.data);
      } catch (error) {
        console.error("Failed to load initial data:", error);
        setMessageModalText(
          error.response?.data?.message || "Failed to load required data."
        );
        setMessageModalVariant("danger");
        setIsMessageModalOpen(true);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInitialData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner />
      </div>
    );
  }

  return (
    <PageLayout title="Employee Salary Structure">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Select Employee</CardTitle>
            <CardDescription>
              Choose an employee to view or define their salary structure.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="max-w-sm">
              <Label htmlFor="employee-select">Employee</Label>
              <Select onValueChange={setSelectedEmployeeId}>
                <SelectTrigger id="employee-select">
                  <SelectValue placeholder="Select an employee..." />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={String(emp.id)}>
                      {emp.name} (ID: {emp.id})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
        <MessageModal
          isOpen={isMessageModalOpen}
          onClose={() => setIsMessageModalOpen(false)}
          message={messageModalText}
          variant={messageModalVariant}
        />

        {selectedEmployeeId && (
          <SalaryStructureForm
            key={selectedEmployeeId}
            employeeId={selectedEmployeeId}
            masterComponents={salaryComponents}
            showMessage={(msg, variant = "success") => {
              setMessageModalText(msg);
              setMessageModalVariant(variant);
              setIsMessageModalOpen(true);
            }}
          />
        )}
      </div>
    </PageLayout>
  );
};

export default SalaryStructurePage;
