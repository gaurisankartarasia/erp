import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import FormSelect from "@/components/common/forms/FormSelect";
import { toast } from "sonner";
import apiClient from "@/api/axiosConfig";

const ManageVendorForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    name: "",
    gst_no: "",
    mobile_no: "",
    email_id: "",
    pan_no: "",
    tax_type: "",
    address: "",
    state: "",
    district: "",
    pin_code: "",
    bank_name: "",
    branch_name: "",
    ifsc_code: "",
    bank_ac_no: "",
    beneficiary_name: "",
    remarks: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [states, setStates] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [vendorLoaded, setVendorLoaded] = useState(false);
  
  // This holds the vendor's district ID initially, to set after districts load
  const [initialDistrict, setInitialDistrict] = useState(null);

  const taxTypeOptions = [
    { label: "Inner State", value: "Inner State" },
    { label: "Intra State", value: "Intra State" },
  ];

  // Fetch states on mount
  useEffect(() => {
    const fetchStates = async () => {
      try {
        const res = await apiClient.get("/locations/states");
        const options = res.data.data.map((state) => ({
          label: state.state_name.trim(),
          value: state.id.toString(),
        }));
        setStates(options);
      } catch (err) {
        console.error("Failed to load states:", err);
        toast.error("Failed to load states");
      }
    };
    fetchStates();
  }, []);

  // Fetch vendor details if editing
  useEffect(() => {
    if (!id) {
      setVendorLoaded(false);
      setInitialDistrict(null);
      return;
    }

    const fetchVendor = async () => {
      try {
        const res = await apiClient.get(`/vendors/${id}`);
        const vendor = res.data;

        setFormData({
          name: vendor.name || "",
          gst_no: vendor.gst_no || "",
          mobile_no: vendor.mobile_no || "",
          email_id: vendor.email_id || "",
          pan_no: vendor.pan_no || "",
          tax_type: vendor.tax_type?.trim() || "",
          address: vendor.address || "",
          state: vendor.state?.toString() || "",
          district: "", // we will set district after districts load
          pin_code: vendor.pin_code || "",
          bank_name: vendor.bank_name || "",
          branch_name: vendor.branch_name || "",
          ifsc_code: vendor.ifsc_code || "",
          bank_ac_no: vendor.bank_ac_no || "",
          beneficiary_name: vendor.beneficiary_name || "",
          remarks: vendor.remarks || "",
        });

        // Save vendor district id for later use after districts load
        setInitialDistrict(vendor.district?.toString() || null);

        setVendorLoaded(true);
      } catch (err) {
        console.error("Failed to fetch vendor details:", err);
        toast.error("Failed to load vendor details");
      }
    };

    fetchVendor();
  }, [id]);

  // Fetch districts when state changes
  useEffect(() => {
    const fetchDistricts = async () => {
      if (!formData.state) {
        setDistricts([]);
        setFormData((prev) => ({ ...prev, district: "" }));
        return;
      }

      try {
        const res = await apiClient.get(`/locations/states/${formData.state}/districts`);
        const options = res.data.data.map((district) => ({
          label: district.district_name.trim(),
          value: district.id.toString(),
        }));
        setDistricts(options);

        // If we have an initial district to set (edit mode), set it now if valid
        if (initialDistrict) {
          const isValidDistrict = options.some(d => d.value === initialDistrict);
          if (isValidDistrict) {
            setFormData(prev => ({ ...prev, district: initialDistrict }));
          } else {
            // fallback if district is not valid anymore
            setFormData(prev => ({ ...prev, district: "" }));
          }
          setInitialDistrict(null); // reset so it doesn't overwrite on next changes
        }
      } catch (err) {
        console.error("Failed to load districts:", err);
        toast.error("Failed to load districts");
      }
    };

    if (vendorLoaded || !id) {
      fetchDistricts();
    }
  }, [formData.state, vendorLoaded, id, initialDistrict]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle select changes
  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Validation
  const validateForm = () => {
    const newErrors = {};
    const requiredFields = [
      "name",
      "gst_no",
      "mobile_no",
      "email_id",
      "pan_no",
      "tax_type",
      "address",
      "state",
      "district",
      "pin_code",
      "bank_name",
      "branch_name",
      "ifsc_code",
      "bank_ac_no",
      "beneficiary_name",
    ];

    requiredFields.forEach((field) => {
      if (!formData[field]?.toString().trim()) {
        newErrors[field] = `${field.replace(/_/g, " ")} is required.`;
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit handler
  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      if (id) {
        await apiClient.put(`/vendors/edit/${id}`, formData);
        toast.success("Vendor updated successfully!");
      } else {
        await apiClient.post("/vendors/add", formData);
        toast.success("Vendor added successfully!");
      }
      navigate("/master/vendors");
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => navigate("/master/vendors");

  const handleReset = () => {
    setFormData({
      name: "",
      gst_no: "",
      mobile_no: "",
      email_id: "",
      pan_no: "",
      tax_type: "",
      address: "",
      state: "",
      district: "",
      pin_code: "",
      bank_name: "",
      branch_name: "",
      ifsc_code: "",
      bank_ac_no: "",
      beneficiary_name: "",
      remarks: "",
    });
    setErrors({});
    setDistricts([]);
    setVendorLoaded(false);
    setInitialDistrict(null);
  };

  return (
    <FormLayout
      title={id ? "Edit Vendor" : "Add Vendor"}
      descriptionText={id ? "Update vendor details." : "Fill in the details to register a new vendor."}
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText={id ? "Update" : "Submit"}
      showCancel
      onCancel={handleCancel}
      showReset
      onReset={handleReset}
    >
      <div className="col-span-2">
        <div className="grid grid-cols-4 gap-6">
          <FormInput
            name="name"
            label="Name"
            value={formData.name}
            onChange={handleChange}
            required
            error={errors.name}
          />
          <FormInput
            name="gst_no"
            label="GST No"
            value={formData.gst_no}
            onChange={handleChange}
            required
            error={errors.gst_no}
          />
          <FormInput
            name="mobile_no"
            label="Mobile No"
            value={formData.mobile_no}
            onChange={handleChange}
            required
            error={errors.mobile_no}
          />
          <FormInput
            name="email_id"
            label="Email Id"
            value={formData.email_id}
            onChange={handleChange}
            required
            error={errors.email_id}
          />
          <FormInput
            name="pan_no"
            label="PAN No"
            value={formData.pan_no}
            onChange={handleChange}
            required
            error={errors.pan_no}
          />

          <FormSelect
            name="tax_type"
            label="Tax Type"
            value={formData.tax_type}
            onValueChange={(val) => handleSelectChange("tax_type", val)}
            options={taxTypeOptions}
            placeholder="--Select Tax Type--"
            required
            error={errors.tax_type}
          />

          <FormInput
            name="address"
            label="Address"
            type="textarea"
            rows="2"
            value={formData.address}
            onChange={handleChange}
            required
            error={errors.address}
          />

          <FormSelect
            name="state"
            label="State"
            value={formData.state}
            onValueChange={(val) => handleSelectChange("state", val)}
            options={states}
            placeholder="--Select State--"
            required
            error={errors.state}
          />

          <FormSelect
            name="district"
            label="District"
            value={formData.district}
            onValueChange={(val) => handleSelectChange("district", val)}
            options={districts}
            placeholder="--Select District--"
            required
            error={errors.district}
          />

          <FormInput
            name="pin_code"
            label="Pin Code"
            value={formData.pin_code}
            onChange={handleChange}
            required
            error={errors.pin_code}
          />
          <FormInput
            name="bank_name"
            label="Bank Name"
            value={formData.bank_name}
            onChange={handleChange}
            required
            error={errors.bank_name}
          />
          <FormInput
            name="branch_name"
            label="Branch Name"
            value={formData.branch_name}
            onChange={handleChange}
            required
            error={errors.branch_name}
          />
          <FormInput
            name="ifsc_code"
            label="IFSC Code"
            value={formData.ifsc_code}
            onChange={handleChange}
            required
            error={errors.ifsc_code}
          />
          <FormInput
            name="bank_ac_no"
            label="Bank A/C No"
            value={formData.bank_ac_no}
            onChange={handleChange}
            required
            error={errors.bank_ac_no}
          />
          <FormInput
            name="beneficiary_name"
            label="Beneficiary Name"
            value={formData.beneficiary_name}
            onChange={handleChange}
            required
            error={errors.beneficiary_name}
          />
          <FormInput
            name="remarks"
            label="Remarks"
            type="textarea"
            rows="3"
            value={formData.remarks}
            onChange={handleChange}
            error={errors.remarks}
          />
        </div>
      </div>
    </FormLayout>
  );
};

export default ManageVendorForm;
