
// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";

// const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

// const ManageUnit = () => {
//   const [units, setUnits] = useState([]);
//   const [search, setSearch] = useState("");
//   const [loading, setLoading] = useState(true);
//   const navigate = useNavigate();

//   // Fetch units from API
//   const fetchUnits = async () => {
//     try {
//       setLoading(true);
//       const response = await axios.get(`${API_BASE_URL}/units`);
//       if (response.data.success) {
//         setUnits(response.data.data);
//       }
//     } catch (error) {
//       console.error('Error fetching units:', error);
//       alert('Error fetching units');
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchUnits();
//   }, []);

//   // Toggle active/inactive
//   const toggleUnitStatus = async (unitId, currentStatus) => {
//     try {
//       const newStatus = currentStatus === "Active" ? "Inactive" : "Active";
//       const response = await axios.put(`${API_BASE_URL}/units/${unitId}`, {
//         status: newStatus
//       });
//       if (response.data.success) {
//         fetchUnits();
//       } else {
//         alert('Error updating status: ' + response.data.message);
//       }
//     } catch (error) {
//       console.error('Error updating status:', error);
//       alert('Error updating status');
//     }
//   };

//   // Edit unit function
//   const editUnit = (unitId) => {
//     navigate(`/manage-unit/edit/${unitId}`);
//   };

//   // Filter units based on search
//   const filteredUnits = units.filter((unit) => {
//     if (!unit) return false;
//     const searchLower = search.toLowerCase();
//     return (
//       (unit.unit_id && unit.unit_id.toLowerCase().includes(searchLower)) ||
//       (unit.unit_name && unit.unit_name.toLowerCase().includes(searchLower)) ||
//       (unit.description && unit.description.toLowerCase().includes(searchLower))
//     );
//   });

//   if (loading) {
//     return <div style={{ padding: 20, textAlign: 'center' }}>Loading...</div>;
//   }

//   return (
//     <div style={{ padding: 20, fontFamily: "Arial, sans-serif" }}>
//       <h2>Manage Unit</h2>
//       <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 15, alignItems: "center" }}>
//         <div>
//           Show{" "}
//           <select style={{ padding: 5 }}>
//             <option value="10">10</option>
//             <option value="25">25</option>
//           </select>{" "}
//           entries
//         </div>
//         <div>
//           Search:{" "}
//           <input
//             type="text"
//             placeholder="Search"
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             style={{ padding: 5 }}
//           />
//         </div>
//         <button
//           style={{
//             backgroundColor: "#ff5722",
//             border: "none",
//             color: "white",
//             padding: "8px 15px",
//             borderRadius: 4,
//             cursor: "pointer",
//           }}
//           onClick={() => navigate("/manage-unit/add")}
//         >
//           + Add Unit
//         </button>
//       </div>
//       <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: 14 }}>
//         <thead>
//           <tr style={{ backgroundColor: "#333", color: "white" }}>
//             <th style={{ padding: "10px" }}>Sl#</th>
//             <th style={{ padding: "10px" }}>Unit Id</th>
//             <th style={{ padding: "10px" }}>Unit Name</th>
//             <th style={{ padding: "10px" }}>Description</th>
//             <th style={{ padding: "10px" }}>Status</th>
//             <th style={{ padding: "10px" }}>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {filteredUnits.length === 0 ? (
//             <tr>
//               <td colSpan={6} style={{ padding: 15, textAlign: "center" }}>
//                 No entries found
//               </td>
//             </tr>
//           ) : (
//             filteredUnits.map((unit, index) => (
//               <tr key={unit.unit_id} style={{ borderBottom: "1px solid #ddd" }}>
//                 <td style={{ padding: 10 }}>{index + 1}</td>
//                 <td style={{ padding: 10 }}>{unit.unit_id}</td>
//                 <td style={{ padding: 10 }}>{unit.unit_name || '-'}</td>
//                 <td style={{ padding: 10 }}>{unit.description || '-'}</td>
//                 <td style={{ padding: 10, color: unit.status === 'Active' ? "green" : "red" }}>
//                   {unit.status}
//                 </td>
//                 <td style={{ padding: 10 }}>
//                   {unit.status === "Active" ? (
//                     <button
//                       style={{
//                         backgroundColor: "transparent",
//                         border: "none",
//                         cursor: "pointer",
//                         color: "red",
//                         marginRight: 10,
//                         fontWeight: "bold",
//                         fontSize: 16,
//                       }}
//                       title="Set Inactive"
//                       onClick={() => toggleUnitStatus(unit.unit_id, unit.status)}
//                     >
//                       ✗
//                     </button>
//                   ) : (
//                     <button
//                       style={{
//                         backgroundColor: "transparent",
//                         border: "none",
//                         cursor: "pointer",
//                         color: "green",
//                         marginRight: 10,
//                         fontWeight: "bold",
//                         fontSize: 16,
//                       }}
//                       title="Set Active"
//                       onClick={() => toggleUnitStatus(unit.unit_id, unit.status)}
//                     >
//                       ✔
//                     </button>
//                   )}
//                   <button
//                     style={{
//                       backgroundColor: "transparent",
//                       border: "none",
//                       cursor: "pointer",
//                       color: "blue",
//                       fontSize: 16,
//                     }}
//                     title="Edit"
//                     onClick={() => editUnit(unit.unit_id)}
//                   >
//                     ✎
//                   </button>
//                 </td>
//               </tr>
//             ))
//           )}
//         </tbody>
//       </table>
//       <div style={{ marginTop: 10 }}>
//         Showing {filteredUnits.length} of {units.length} entries
//       </div>
//     </div>
//   );
// };

// export default ManageUnit;






import React, { useMemo } from "react";
import ShadcnDataTable from "@/components/common/DataTable";
import { useServerSideTable } from "@/hooks/useServerSideTable";
import PageLayout from "@/components/layouts/PageLayout";
import { useConfirmModal } from "@/hooks/useConfirmModal";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { X, Edit, Check } from "lucide-react";
import apiClient from "@/api/axiosConfig";

const StatusBadge = ({ active }) => {
  const status = active ? "active" : "inactive";
  const config = {
    active: { text: "Active", classes: "bg-green-100 text-green-800" },
    inactive: { text: "Inactive", classes: "bg-red-100 text-red-800" },
  };
  return (
    <span
      className={`px-2 py-1 text-xs font-semibold rounded-full ${config[status].classes}`}
    >
      {config[status].text}
    </span>
  );
};

const ManageUnit = () => {
  const {
    data: units,
    tableState,
    refreshData,
  } = useServerSideTable(
    `${import.meta.env.VITE_API_BASE_URL}/units`
  );
  const confirm = useConfirmModal();
  const handleToggleStatus = async (unit) => {
    const ok = await confirm({
      title: "Change Status",
      description: `Are you sure you want to ${
        unit.is_active ? "deactivate" : "activate"
      } this unit?`,
    });
    if (!ok) return;
    try {
      await apiClient.put(`/units/${unit.unit_id}`, {
        status: unit.is_active ? "Inactive" : "Active",
      });
      refreshData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const unitColumns = useMemo(
    () => [
      {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        header: "Unit Id",
        accessorKey: "unit_id",
        enableSorting: true,
      },
      {
        header: "Unit Name",
        accessorKey: "unit_name",
        enableSorting: true,
      },
      {
        header: "Description",
        accessorKey: "description",
        enableSorting: false,
        cell: ({ row }) => row.original.description || "-",
      },
      {
        header: "Status",
        accessorKey: "is_active",
        enableSorting: true,
        cell: ({ row }) => <StatusBadge active={row.original.is_active} />,
      },
      {
        header: "Actions",
        cell: ({ row }) => {
          const unit = row.original;
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleToggleStatus(unit)}
              >
                {unit.is_active ? <X className="text-red-500" /> : <Check className="text-green-500" />}
              </Button>
              <Button asChild size="sm" variant="ghost">
                <Link to={`/manage-unit/edit/${unit.id}`}><Edit /></Link>
              </Button>
            </div>
          );
        },
      },
    ],
    [tableState.currentPage, tableState.entriesPerPage]
  );

  return (
    <PageLayout
      title="Unit List"
      rightButton={{ text: "Add Unit", path: "add" }}
    >
      <ShadcnDataTable
        Ltext="Unit List"
        Rtext="Add Unit"
        addPath="add"
        data={units}
        columns={unitColumns}
        tableState={tableState}
      />
    </PageLayout>
  );
};

export default ManageUnit;


