import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "@/components/common/forms/FormInput";
import { toast } from "sonner";
import apiClient from "@/api/axiosConfig";

const ManageVacancyForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();  // Grab id from URL params

  const [formData, setFormData] = useState({
    post_name: "",
    date: "",
    description: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);

  // Fetch existing vacancy data when editing
  useEffect(() => {
    if (!id) return;

    const fetchVacancy = async () => {
      setIsLoading(true);
      try {
        const res = await apiClient.get(`/vacancies/${id}`);
        const vacancy = res.data;

        setFormData({
          post_name: vacancy.post_name || "",
          date: vacancy.date ? vacancy.date.split("T")[0] : "",
          description: vacancy.description || "",
        });
      } catch (err) {
        toast.error("Failed to load vacancy data.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchVacancy();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.post_name.trim()) newErrors.post_name = "Post Name is required.";
    if (!formData.date.trim()) newErrors.date = "Date is required.";
    if (!formData.description.trim()) newErrors.description = "Description is required.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      if (id) {
        // Edit vacancy
        await apiClient.put(`/vacancies/edit/${id}`, formData);
        toast.success("Vacancy updated successfully!");
      } else {
        // Create vacancy
        await apiClient.post("/vacancies/add", formData);
        toast.success("Vacancy created successfully!");
      }
      navigate("/master/vacancies");
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate("/master/vacancies");
  };

  const handleReset = () => {
    setFormData({
      post_name: "",
      date: "",
      description: "",
    });
    setErrors({});
  };

  if (isLoading) {
    return (
      <div className="text-center py-10">
        <p>Loading vacancy data...</p>
      </div>
    );
  }

  return (
    <FormLayout
      title={id ? "Edit Vacancy" : "Add Vacancy"}
      descriptionText={
        id
          ? "Update the details of the job vacancy."
          : "Fill in the details to post a new job vacancy."
      }
      onSubmit={handleSubmit}
      isSubmitting={isSubmitting}
      submitText={id ? "Update Vacancy" : "Submit"}
      showCancel={true}
      onCancel={handleCancel}
      showReset={!id}  // Reset only shown on Add mode
      onReset={handleReset}
    >
      <FormInput
        name="post_name"
        label="Post Name"
        value={formData.post_name}
        onChange={handleChange}
        required
        error={errors.post_name}
      />

      <FormInput
        name="date"
        label="Date"
        type="date"
        value={formData.date}
        onChange={handleChange}
        required
        error={errors.date}
      />

      <FormInput
        name="description"
        label="Description"
        type="textarea"
        rows="4"
        value={formData.description}
        onChange={handleChange}
        required
        error={errors.description}
      />
    </FormLayout>
  );
};

export default ManageVacancyForm;
