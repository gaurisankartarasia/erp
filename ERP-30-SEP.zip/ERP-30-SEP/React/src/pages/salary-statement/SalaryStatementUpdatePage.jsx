import React, { useState, useEffect, useMemo } from "react";
import {
  useForm,
  FormProvider,
  useFieldArray,
  useWatch,
  useFormContext,
} from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormSelect from "@/pages/employee/custom/FormSelect";
import FormInput from "@/pages/employee/custom/FormInput";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Edit, Save } from "lucide-react";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";

const EditableSalaryRow = ({
  index,
  control,
  onUpdate,
  isEditing,
  setEditingRow,
}) => {
  const { getValues } = useFormContext();
  const fieldData = useWatch({ control, name: `employees` })[index];

  const handleUpdate = async () => {
    const rowData = getValues(`employees.${index}`);
    await onUpdate(rowData);
  };

  return (
    <TableRow className={isEditing ? "bg-yellow-100" : ""}>
         <TableCell>{index + 1}</TableCell>
      <TableCell>{fieldData.Employee.emp_code}</TableCell>
      <TableCell>{fieldData.Employee.name}</TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.Absent_Day`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.other_allowence`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.EPF_Employee_Share`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.EPF_Employer_Share`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.ESI_Employee_Share`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.ESI_Employer_Share`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>
        <FormInput
          name={`employees.${index}.Tds`}
          type="number"
          disabled={!isEditing}
        />
      </TableCell>
      <TableCell>{fieldData.paid_amt}</TableCell>
      <TableCell>
        {isEditing ? (
          <Button type="button" size="icon" onClick={handleUpdate}>
            <Save className="h-4 w-4" />
          </Button>
        ) : (
          <Button
            type="button"
            size="icon"
            variant="outline"
            onClick={() => setEditingRow(fieldData.id)}
          >
            <Edit className="h-4 w-4" />
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
};
const SalaryStatementUpdatePage = () => {
  const methods = useForm({
    defaultValues: { statement_id: "", employees: [] },
  });
  const { handleSubmit, control, reset } = methods;
  const { fields, replace } = useFieldArray({ control, name: "employees" });

  const [statementOptions, setStatementOptions] = useState([]);
  const [isSearched, setIsSearched] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const message = useMessageModal();

  useEffect(() => {
    const fetchStatements = async () => {
      try {
        const res = await apiClient.get("/salary-statement/list-statements");
        const options = res.data.data.map((s) => ({
          value: String(s.id),
          label: s.salary_statement_id,
        }));
        setStatementOptions(options);
      } catch (error) {
        message.error("Failed to load salary statements.");
      }
    };
    fetchStatements();
  }, [message]);

  const onSearch = async (data) => {
    setIsLoading(true);
    replace([]);
    try {
      const res = await apiClient.get("/salary-statement/details", {
        params: { statement_id: data.statement_id },
      });
      replace(res.data.data);
      setIsSearched(true);
    } catch (error) {
      message.error("Failed to fetch statement details.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateRecord = async (rowData) => {
    try {
      await apiClient.patch(
        `/salary-statement/update-record/${rowData.id}`,
        rowData
      );
      message.success("Record updated successfully!");
      setEditingRow(null);
      handleSubmit(onSearch)();
    } catch (error) {
      message.error("Failed to update record.");
    }
  };

  const handleReset = () => {
    reset();
    replace([]);
    setIsSearched(false);
    setEditingRow(null);
  };

  return (
    <FormProvider {...methods}>
      <FormLayout
        title="Update Salary Statement"
        onSubmit={handleSubmit(onSearch)}
        onReset={handleReset}
        isSubmitting={isLoading}
        isLoading={isLoading}
        submitText="Search"
      >
        <div className="grid grid-cols-2 gap-6">
          <FormSelect
            name="statement_id"
            label="Select Salary Statement ID"
            options={statementOptions}
            rules={{ required: "Statement ID is required." }}
          />
        </div>
        <div className="col-span-2">
          {isSearched && fields.length > 0 && (
            <div className="mt-6">
              <div className="border rounded-md overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sl No</TableHead>
                      <TableHead>Emp Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Absent Days</TableHead>
                      <TableHead>Other Allowance</TableHead>
                      <TableHead>EPF (Emp)</TableHead>
                      <TableHead>EPF (Empr)</TableHead>
                      <TableHead>ESI (Emp)</TableHead>
                      <TableHead>ESI (Empr)</TableHead>
                      <TableHead>TDS</TableHead>
                      <TableHead>Payable Amt</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                 <TableBody>
  {fields.map((field, index) => {
    const rowData = methods.getValues(`employees.${index}`);
    return (
      <EditableSalaryRow
        key={field.id}
        index={index}
        control={control}
        onUpdate={handleUpdateRecord}
        isEditing={editingRow === rowData.id}
        setEditingRow={setEditingRow}
      />
    );
  })}
</TableBody>

                </Table>
              </div>
            </div>
          )}
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default SalaryStatementUpdatePage;
