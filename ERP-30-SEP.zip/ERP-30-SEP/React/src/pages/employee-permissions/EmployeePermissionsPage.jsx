import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import apiClient from "@/api/axiosConfig";
import PageLayout from "@/components/layouts/PageLayout";
import { Spinner } from "@/components/ui/spinner";

const EmployeePermissionsPage = ({ employeeId }) => {
  const [permissions, setPermissions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPermissions = async () => {
      try {
        const res = await apiClient.get(`/employee-permissions`);
        setPermissions(
          res.data.map((perm, index) => ({
            ...perm,
            slNo: index + 1,
          }))
        );
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchPermissions();
  }, [employeeId]);

  if (loading) return <Spinner/>

  return (
    <PageLayout title="My Permissions">
   
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px] text-center">SL No</TableHead>
                <TableHead>Page Name</TableHead>
                <TableHead>Code Name</TableHead>
                <TableHead>Description</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {permissions.map((perm) => (
                <TableRow key={perm.slNo}>
                  <TableCell className="text-center">{perm.slNo}</TableCell>
                  <TableCell>{perm.page_name}</TableCell>
                  <TableCell>{perm.code_name}</TableCell>
                  <TableCell>{perm.description}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
    
    </PageLayout>
  );
};

export default EmployeePermissionsPage;
