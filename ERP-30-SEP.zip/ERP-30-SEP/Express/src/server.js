import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import { fileURLToPath } from "url";
import path from "path";
import cookieParser from "cookie-parser";
import sequelize from "../configs/db.js";
import useragent from "express-useragent";
import authRoutes from "./routes/AuthRoutes.js";
import taskRoutes from "./routes/TaskRoutes.js";
import pagePermissionRoutes from "./routes/PagePermissionRoutes.js";
import SalaryRoutes from "./routes/SalaryRoutes.js";
import employeeRouter from "./routes/EmployeeRoutes.js";
import RulesRoutes from "./routes/RulesRoutes.js";
import incrementSchemesRouter from "./routes/IncrementSchemeRoutes.js";
import leaveRequestRoutes from "./routes/LeaveRoutes.js";
import logRecordRouter from "./routes/LogRecordsRoutes.js";
import payrollRoutes from "./routes/PayrollRoutes.js";
import attendanceRoutes from "./routes/AttendanceRoutes.js";
import leaveRoutes from "./routes/LeaveRoutes.js";
import dashboardRoutes from "./routes/DashboardRoutes.js";
import locationRoutes from "./routes/LocationRoutes.js";
import clientRoutes from "./routes/ClientRoutes.js";
import adminProfileRoutes from "./routes/AdminProfileRoutes.js";
import designationRoutes from "./routes/DesignationRoutes.js";
import contributionRoutes from "./routes/ContributionRoutes.js";
import unit from "./routes/units.js";
import item from "./routes/ItemRoutes.js";
import vacancyRoutes from "./routes/VacancyRoutes.js";
import vendorRoutes from "./routes/VendorRoutes.js";
import masterRoutes from "./routes/MasterRoutes.js";
import supplierExpenseRoutes from "./routes/SupplierExpenseRoutes.js";
import expenseVerificationRoutes from "./routes/ExpensesVerificationRoutes.js";
import expenseApprovalRoutes from "./routes/ExpensesApproveRoutes.js";
import StaffExpenseRouter from "./routes/StaffExpenseRoute.js";
import workorder from "./routes/workorderRoutes.js";
import bank from "./routes/BankRoutes.js";
import invoiceRouter from "./routes/InvoiceRoute.js";
import DispatchRoutes from './routes/DispatchRoutes.js';
import taxRoutes from './routes/TaxRoutes.js';
import employeeReportRoutes from './routes/EmployeeReportRoutes.js';
import expenseReportRoutes from './routes/ExpenseReportRoutes.js';
import salaryStatementRoutes from "./routes/SalaryStatementRoutes.js";
import employeePermissionRoutes from "./routes/EmployeePermissionRoutes.js"


dotenv.config();
const app = express();
const PORT = process.env.PORT;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(
  cors({
    origin: process.env.CORS_ORIGIN,
    credentials: true,
  })
);
app.use(cookieParser());
app.use(express.json());
app.use(useragent.express());
app.use(express.static(path.join(__dirname, "../public")));

//routes here
app.use("/api/auth", authRoutes);
app.use("/api/master", masterRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/page-permissions", pagePermissionRoutes);
app.use("/api/salary", SalaryRoutes);
app.use("/api/employee", employeeRouter);
app.use("/api/rules", RulesRoutes);
app.use("/api/leave", leaveRequestRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/payroll", payrollRoutes);
app.use("/api/increment-scheme", incrementSchemesRouter);
app.use("/api/logs", logRecordRouter);
app.use("/api/leave", leaveRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/locations", locationRoutes);
app.use("/api/clients", clientRoutes);
app.use("/api/admin-profile", adminProfileRoutes);
app.use("/api/designations", designationRoutes);
app.use("/api/contributions", contributionRoutes);
app.use("/api/units", unit);
app.use("/api/items", item);
app.use("/api/vacancies", vacancyRoutes);
app.use("/api/vendors", vendorRoutes);
app.use("/api/supplier-expenses", supplierExpenseRoutes);
app.use("/api/expense-verification", expenseVerificationRoutes);
app.use("/api/expense-approve", expenseApprovalRoutes);
app.use("/api/staff-expenses", StaffExpenseRouter);
app.use("/api/work-orders", workorder);
app.use("/api/bank-guarantees", bank);
app.use("/api/invoices", invoiceRouter);
app.use('/api/dispatches', DispatchRoutes);
app.use('/api/tax_entry', taxRoutes);
app.use('/api/employee-reports', employeeReportRoutes);
app.use('/api/expense-reports', expenseReportRoutes);
app.use('/api/salary-statement', salaryStatementRoutes);
app.use("/api/employee-permissions", employeePermissionRoutes)


const startServer = async () => {
  try {
    await sequelize.authenticate();
    console.log("db success");

    // await sequelize.sync({ alter: true });
    // console.log('sync success');

    app.listen(PORT, () => {
      console.log(`bluetooth connected on ${PORT}`);
    });
  } catch (error) {
    console.error(error);
  }
};

startServer();

