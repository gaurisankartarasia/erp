import { sequelize } from "../models/index.js";
const {Permission, Employee} = sequelize.models

export const getEmployeePermissions = async (req, res) => {
  try {
    const { id: employeeId } = req.user;

    if (!employeeId) {
      return res.status(400).json({ message: "Employee ID is required" });
    }

    const employee = await Employee.findByPk(employeeId, {
      include: {
        model: Permission,
        through: { attributes: [] },
      },
    });

    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const permissions = employee.Permissions.map((perm, index) => ({
      slNo: index + 1,
      page_name: perm.page_name,
      code_name: perm.code_name,
      description: perm.description,
    }));

    res.json(permissions);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
