import { models } from '../models/index.js';
import { Op } from 'sequelize';

// Generate custom ID like UM001, UM002, etc.
const generateUnitId = async () => {
  try {
    const lastUnit = await models.Unit.findOne({
      order: [['created_at', 'DESC']]
    });
    if (!lastUnit) {
      return 'UM001';
    }
    const lastUnitId = lastUnit.unit_id;
    const number = parseInt(lastUnitId.replace('UM', '')) + 1;
    return `UM${number.toString().padStart(3, '0')}`;
  } catch (error) {
    return `UM${Date.now().toString().slice(-3)}`;
  }
};

// Get all units with search and pagination

export const getAllUnits = async (req, res) => {
  try {
    const { search = '', page = 1, limit = 10, sort, order } = req.query;
    const offset = (page - 1) * limit;

    // Build where condition for search
    const whereCondition = {
      is_delete: 0,
      ...(search ? {
        [Op.or]: [
          { unit_id: { [Op.like]: `%${search}%` } },
          { unit_name: { [Op.like]: `%${search}%` } },
          { description: { [Op.like]: `%${search}%` } }
        ]
      } : {})
    };

    // Sorting logic
    let orderArray = [['created_at', 'DESC']]; // default
    if (sort) {
      let sortField = sort;
      // Only allow sorting on certain fields
      const allowedSortFields = ['unit_id', 'unit_name', 'description', 'status', 'created_at', 'updated_at'];
      if (allowedSortFields.includes(sortField)) {
        // For status, sort by is_active
        if (sortField === 'status') sortField = 'is_active';
        orderArray = [[sortField, order && order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC']];
      }
    }

    const { count, rows: units } = await models.Unit.findAndCountAll({
      where: whereCondition,
      order: orderArray,
      limit: parseInt(limit),
      offset: offset
    });

    const transformedUnits = units.map(unit => {
      const obj = {
        id: unit.id,
        unit_id: unit.unit_id,
        unit_name: unit.unit_name,
        description: unit.description,
        status: unit.is_active ? 'Active' : 'Inactive',
        is_active: unit.is_active,
        is_delete: unit.is_delete,
        created_at: unit.createdAt || unit.created_at,
        updated_at: unit.updatedAt || unit.updated_at
      };
      return obj;
    });

    res.json({
      success: true,
      data: transformedUnits,
      total: count,
      currentPage: parseInt(page),
      totalPages: Math.ceil(count / limit)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching units',
      error: error.message
    });
  }
};

// Get unit by ID
export const getUnitById = async (req, res) => {
  try {
    const { id } = req.params;
    const unit = await models.Unit.findByPk(id);
    if (!unit) {
      return res.status(404).json({
        success: false,
        message: 'Unit not found'
      });
    }
    const transformedUnit = {
      id: unit.id,
      unit_id: unit.unit_id,
      unit_name: unit.unit_name,
      description: unit.description,
      status: unit.is_active ? 'Active' : 'Inactive',
      is_active: unit.is_active,
      is_delete: unit.is_delete,
      created_at: unit.created_at,
      updated_at: unit.updated_at
    };
    res.json({
      success: true,
      data: transformedUnit
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching unit',
      error: error.message
    });
  }
};

// Create new unit
export const createUnit = async (req, res) => {
  try {
    const { name, description, status = 'Active' } = req.body;
    if (!name || !description) {
      return res.status(400).json({
        success: false,
        message: 'Unit name and description are required'
      });
    }
    const unitId = await generateUnitId();
    const is_active = status === 'Active' ? 1 : 0;
    const newUnit = await models.Unit.create({
      unit_id: unitId,
      unit_name: name,
      description: description,
      is_active: is_active,
      is_delete: 0,
      created_at: new Date(),
      updated_at: new Date()
    });
    const transformedUnit = {
      id: newUnit.id,
      unit_id: newUnit.unit_id,
      unit_name: newUnit.unit_name,
      description: newUnit.description,
      status: newUnit.is_active ? 'Active' : 'Inactive',
      created_at: newUnit.created_at
    };
    res.status(201).json({
      success: true,
      message: 'Unit created successfully',
      data: transformedUnit
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating unit',
      error: error.message
    });
  }
};

// Update unit (edit or status toggle)
export const updateUnit = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, status } = req.body;
    const unit = await models.Unit.findOne({ where: { unit_id: id, is_delete: 0 } });
    if (!unit) {
      return res.status(404).json({
        success: false,
        message: 'Unit not found'
      });
    }
    let updateFields = {};
    if (name !== undefined) updateFields.unit_name = name;
    if (description !== undefined) updateFields.description = description;
    if (status !== undefined) updateFields.is_active = status === 'Active' ? 1 : 0;
    updateFields.updated_at = new Date();
    await unit.update(updateFields);
    const transformedUnit = {
      id: unit.id,
      unit_id: unit.unit_id,
      unit_name: unit.unit_name,
      description: unit.description,
      status: unit.is_active ? 'Active' : 'Inactive',
      updated_at: unit.updated_at
    };
    res.json({
      success: true,
      message: 'Unit updated successfully',
      data: transformedUnit
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating unit',
      error: error.message
    });
  }
};