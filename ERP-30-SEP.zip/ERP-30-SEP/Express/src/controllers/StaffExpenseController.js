import { sequelize } from "../models/index.js";
import { Op } from "sequelize";

const { Employee, Expense } = sequelize.models;

/**
 * @description Get all staff expenses with pagination, search, and sorting
 */
export const getAllStaffExpenses = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      sort = "createdAt",
      order = "desc",
    } = req.query;

    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const whereClause = {
      is_delete: false,
      payer_type: "staff",
      [Op.or]: [
        { matter: { [Op.like]: `%${search}%` } },
        { expense_type: { [Op.like]: `%${search}%` } },
      ],
    };

    const { count, rows } = await Expense.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit, 10),
      offset,
      order: [[sort, order.toUpperCase()]],
      include: [
        {
          model: Employee,
          as: "staff",
          attributes: ["name", "emp_code"],
          required: false,
        },
      ],
    });

    const baseUrl = req.host;

    const dataWithFullUrls = rows.map((expense) => {
      return {
        ...expense.toJSON(),
        documentUrl: expense.document
          ? baseUrl + "/uploads/staff-expenses/" + expense.document
          : null,
        staffName: expense.staff ? expense.staff.name : null,
      };
    });

    res.status(200).json({
      data: dataWithFullUrls,
      total: count,
    });
  } catch (error) {
    console.error("Error fetching staff expenses:", error);
    res.status(500).json({
      message: "Failed to fetch staff expenses",
      error: error.message,
    });
  }
};

/**
 * @description Get a single staff expense by ID
 */
export const getStaffExpenseById = async (req, res) => {
  const { id } = req.params;

  try {
    const expense = await Expense.findOne({
      where: {
        id,
        payer_type: "staff",
        is_delete: false,
      },
      include: [
        {
          model: Employee,
          as: "staff",
          attributes: ["name", "emp_code"],
          required: false,
        },
      ],
    });

    if (!expense) {
      return res.status(404).json({ message: "Expense not found" });
    }

    res.status(200).json(expense);
  } catch (error) {
    console.error("Error fetching staff expense:", error);
    res.status(500).json({
      message: "Failed to fetch staff expense",
      error: error.message,
    });
  }
};
/**
 * @description Add a new staff expense
 */
export const addStaffExpense = async (req, res) => {
  try {
    const data = { ...req.body };
    data.payer_type = "staff";
    data.payer_id = data.employee_id;

    if (req.file) {
      data.document = req.file.path;
    }

    const newExpense = await Expense.create(data);

    res.status(201).json({
      message: "Staff expense added successfully.",
      expense: newExpense,
    });
  } catch (error) {
    console.error("Add Staff Expense Error:", error);
    res.status(500).json({
      message: "Failed to add staff expense",
      error: error.message,
    });
  }
};

/**
 * @description Edit an existing staff expense
 */
export const editStaffExpense = async (req, res) => {
  const { id } = req.params;

  try {
    const expense = await Expense.findOne({
      where: { id, payer_type: "staff", is_delete: false },
    });

    if (!expense) {
      return res.status(404).json({ message: "Expense record not found." });
    }

    const data = { ...req.body };
    data.payer_id = data.employee_id;

    if (typeof data.document !== "string") {
      delete data.document;
    }

    if (req.file) {
      data.document = req.file.path;
    }

    await expense.update(data);

    res.status(200).json({
      message: "Staff expense updated successfully.",
      expense,
    });
  } catch (error) {
    console.error("Update Staff Expense Error:", error);
    res.status(500).json({
      message: "Failed to update staff expense",
      error: error.message,
    });
  }
};
