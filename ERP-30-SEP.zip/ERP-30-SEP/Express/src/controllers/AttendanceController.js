import { sequelize } from "../models/index.js";

const { Employee, Attendance, Client, Designation } = sequelize.models;


export const searchEmployeesForAttendance = async (req, res) => {
  const { year, month, client } = req.query;

  if (!year || !month || !client) {
    return res
      .status(400)
      .json({ message: "Year, Month, and Client are required." });
  }

  try {
    const employeesForClient = await Employee.findAll({
      where: { client: client, is_active: true, is_delete: false },
      attributes: ["id", "emp_code", "name"],
      include: [
        {
          model: Client,
          as: "client_info",
          attributes: ["id", "projNm"],
        },
        {
          model: Designation,
          as: "designation_info",
          attributes: ["id", "designation_name"],
        },
      ],
    });

    if (employeesForClient.length === 0) {
      return res.status(200).json({ data: [] });
    }

    const employeeIds = employeesForClient.map((emp) => emp.id);

    const existingAttendances = await Attendance.findAll({
      where: {
        year,
        month,
        employee_id: employeeIds,
      },
      attributes: ["employee_id"],
    });

    const existingEmpIds = new Set(
      existingAttendances.map((att) => att.employee_id)
    );

    const employeesWithoutAttendance = employeesForClient.filter(
      (emp) => !existingEmpIds.has(emp.id)
    );

    res.status(200).json({ data: employeesWithoutAttendance });
  } catch (error) {
    console.error("Error searching employees for attendance:", error);
    res.status(500).json({ message: "Failed to search employees." });
  }
};

export const generateAttendance = async (req, res) => {
  const { year, month, client, employees } = req.body;

  if (
    !year ||
    !month ||
    !client ||
    !Array.isArray(employees) ||
    employees.length === 0
  ) {
    return res.status(400).json({ message: "Missing required data." });
  }

  try {
    const clientInfo = await Client.findByPk(client);
    if (!clientInfo) {
      return res.status(404).json({ message: "Client not found." });
    }

    const recordsToInsert = employees.map((emp) => {
      const absentday = parseInt(emp.absentday, 10) || 0;
      const attendance_id = `${String(month).padStart(2, "0")}${year}-${
        clientInfo.projNm
      }-${emp.emp_code}`;

      return {
        employee_id: emp.id,
        attendance_id,
        year,
        month,
        client_location: clientInfo.projNm,
        absentday: String(absentday),
      };
    });

    await Attendance.bulkCreate(recordsToInsert);

    res.status(201).json({
      message: `Successfully generated attendance for ${recordsToInsert.length} employees.`,
    });
  } catch (error) {
    console.error("Error generating attendance:", error);
    res.status(500).json({ message: "Failed to generate attendance." });
  }
};

export const listAttendanceGroups = async (req, res) => {
  try {
    const groups = await Attendance.findAll({
      attributes: ["year", "month", "attendance_id"],
      group: ["year", "month", "attendance_id"],
      order: [
        ["year", "DESC"],
        ["month", "DESC"],
        ["attendance_id", "ASC"],
      ],
    });
    res.status(200).json({ data: groups });
  } catch (error) {
    console.error("Error listing attendance groups:", error);
    res.status(500).json({ message: "Failed to list attendance groups." });
  }
};

export const getAttendanceDetailsByGroup = async (req, res) => {
  const { attendance_id } = req.query;

  if (!attendance_id) {
    return res
      .status(400)
      .json({ message: "Attendance ID is required." });
  }

  try {
    const attendanceRecords = await Attendance.findAll({
      where: {
        attendance_id
      },
      include: [
        {
          model: Employee,
          attributes: ["emp_code", "name"],
          required: true,
          include: [
            {
              model: Client,
              as: "client_info",
              attributes: ["projNm"],
            },
            {
              model: Designation,
              as: "designation_info",
              attributes: ["designation_name"],
            },
          ],
        },
      ],
      order: [[Employee, "name", "ASC"]],
    });

    res.status(200).json({ data: attendanceRecords });
  } catch (error) {
    console.error("Error fetching attendance details:", error);
    res.status(500).json({ message: "Failed to fetch attendance details." });
  }
};


export const updateAttendanceRecords = async (req, res) => {
  const { employees } = req.body; 

  if (!Array.isArray(employees) || employees.length === 0) {
    return res.status(400).json({ message: 'An array of employee attendance data is required.' });
  }

  const transaction = await sequelize.transaction();

  try {
    for (const emp of employees) {
      const absentday = parseInt(emp.absentday, 10) || 0;
      
      await Attendance.update(
        { absentday: String(absentday) },
        {
          where: { id: emp.id }, 
          transaction,
        }
      );
    }

    await transaction.commit();
    res.status(200).json({ message: `Successfully updated attendance for ${employees.length} employees.` });
  } catch (error) {
    await transaction.rollback();
    console.error("Error updating attendance:", error);
    res.status(500).json({ message: "Failed to update attendance." });
  }
};

export const updateSingleAttendanceRecord = async (req, res) => {
  const { id } = req.params; 
  const { absentday } = req.body;

  if (absentday === undefined || absentday === null) {
    return res.status(400).json({ message: 'Absent day value is required.' });
  }

  try {
    const record = await Attendance.findByPk(id);
    if (!record) {
      return res.status(404).json({ message: 'Attendance record not found.' });
    }

    const absentValue = parseInt(absentday, 10) || 0;
    
    await record.update({ absentday: String(absentValue) });

    res.status(200).json({ message: `Attendance for record ${id} updated successfully.` });
  } catch (error) {
    console.error("Error updating single attendance record:", error);
    res.status(500).json({ message: "Failed to update attendance record." });
  }
};