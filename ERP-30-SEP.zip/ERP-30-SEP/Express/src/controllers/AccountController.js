// routes/employees.js
import { sequelize } from "../models/index.js";

const { Employee, Designation, Client, State, District } = sequelize.models;

export const getMyProfile = async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id, {
      attributes: {
        exclude: [
          "password",
          "aadhar_no",
          "bank_ac_no",
          "pan_no",
          "activation_token",
          "activation_token_expires_at",
        ],
      },
      include: [
        {
          model: Designation,
          as: "designation_info",
          attributes: ["designation_id", "designation_name"],
        },
        { model: Client, as: "client_info", attributes: ["clientid", "projNm", "ClientNm"] },
        {
          model: State,
          as: "permanent_state_info",
          attributes: ["state_name"],
        },
        { model: State, as: "present_state_info", 
         attributes: ["state_name"],
         },
        {
          model: District,
          as: "permanent_district_info",
          attributes: ["district_name"],
        },
        {
          model: District,
          as: "present_district_info",
          attributes: ["district_name"],
        },
      ],
    });

    if (!employee)
      return res.status(404).json({ message: "Employee not found" });
    res.json(employee);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};
