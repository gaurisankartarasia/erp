import { Op } from "sequelize";
import { sequelize } from "../models/index.js";
import { stringify } from "csv-stringify";
import * as XLSX from "xlsx";

const { Expense, Employee, Vendor } = sequelize.models;

const getExpenseQueryOptions = (queryParams) => {
  const {
    from_date,
    to_date,
    payer_type,
    payer_id,
    status,
    search = "",
  } = queryParams;

  const whereClause = {
    is_delete: false,
    date: { [Op.between]: [from_date, to_date] },
  };

  if (payer_type) whereClause.payer_type = payer_type;
  if (payer_id) whereClause.payer_id = payer_id;
  if (status) whereClause.status = status;

  if (search) {
    whereClause[Op.or] = [
      { matter: { [Op.like]: `%${search}%` } },
      { invoice_no: { [Op.like]: `%${search}%` } },
    ];
  }

  return {
    where: whereClause,
    include: [
      { model: Employee, as: "staff", attributes: ["name"], required: false },
      { model: Vendor, as: "supplier", attributes: ["name"], required: false },
    ],
    order: [["date", "DESC"]],
    raw: true,
    nest: true,
  };
};

/**
 * @description Fetches a paginated expense report for UI display.
 */
export const getExpenseReport = async (req, res) => {
  const { page = 1, limit = 10 } = req.query;

  try {
    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);
    const queryOptions = getExpenseQueryOptions(req.query);

    const { rows: expenses, count: totalItems } = await Expense.findAndCountAll(
      {
        ...queryOptions,
        limit: parseInt(limit),
        offset,
        distinct: true,
      }
    );

    res.status(200).json({ data: expenses, total: totalItems });
  } catch (error) {
    console.error("Error fetching expense report:", error);
    res.status(500).json({ message: "Failed to fetch expense report." });
  }
};

/**
 * @description Generates and streams a full expense report as a file.
 */
export const exportExpenseReport = async (req, res) => {
  const { format = "csv" } = req.query;
  try {
    const expenses = await Expense.findAll(getExpenseQueryOptions(req.query));

    const dataToExport = expenses.map((exp) => ({
      Date: exp.date,
      "Payer Type": exp.payer_type,
      "Payer Name": exp.staff?.name || exp.supplier?.name || "N/A",
      Matter: exp.matter,
      "Invoice No": exp.invoice_no,
      "Total Amount": exp.total_amt,
      Status: exp.status,
    }));

    const filename = `expense-report-${Date.now()}`;

    if (format === "csv") {
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${filename}.csv"`
      );
      stringify(dataToExport, { header: true }).pipe(res);
    } else if (format === "excel") {
      const ws = XLSX.utils.json_to_sheet(dataToExport);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Expenses");
      const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
      res.setHeader(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${filename}.xlsx"`
      );
      res.send(buffer);
    }
  } catch (error) {
    console.error("Error exporting expense report:", error);
    res.status(500).json({ message: "Failed to export data." });
  }
};
