import { Op } from "sequelize";
import { sequelize } from "../models/index.js";
const {
  Employee,
  Attendance,
  Contribution,
  SalaryStatementStructure,
  SalaryStatement,
  Client,
  Designation,
} = sequelize.models;

const getDaysInMonth = (year, month) => new Date(year, month, 0).getDate();

export const previewSalaryStatement = async (req, res) => {
  const { year, month } = req.query;
  if (!year || !month) {
    return res.status(400).json({ message: "Year and Month are required." });
  }

  try {
    const existingStatement = await SalaryStatementStructure.findOne({
      where: { year, month },
    });
    if (existingStatement) {
      return res.status(409).json({
        message: `Salary statement for ${month}/${year} has already been generated.`,
      });
    }

    const [employees, latestContributions, attendances] = await Promise.all([
      Employee.findAll({
        where: { is_active: true, is_delete: false, dor: null },
        include: [
          { model: Client, as: "client_info", attributes: ["projNm"] },
          {
            model: Designation,
            as: "designation_info",
            attributes: ["designation_name"],
          },
        ],
        order: [
          ["client_info", "projNm", "ASC"],
          ["name", "ASC"],
        ],
      }),
      Contribution.findOne({ order: [["date", "DESC"]] }),
      Attendance.findAll({ where: { year, month } }),
    ]);

    if (!latestContributions) {
      return res.status(404).json({
        message: "Contribution rates not found. Please set them first.",
      });
    }

    const attendanceMap = new Map(
      attendances.map((att) => [att.employee_id, att])
    );
    const workingDays = getDaysInMonth(parseInt(year), parseInt(month));

    const salaryData = employees.map((emp) => {
      const attendance = attendanceMap.get(emp.id);
      const grossSalary = parseFloat(emp.gross_salary) || 0;
      const absentDay = attendance
        ? parseInt(attendance.absentday, 10)
        : workingDays;

      const netAmount = grossSalary - absentDay * (grossSalary / workingDays);
      const epfEmployeeDeduction =
        (netAmount * parseFloat(latestContributions.epf_employee_share)) / 100;
      const esiEmployeeDeduction =
        (netAmount * parseFloat(latestContributions.esi_employee_share)) / 100;
      const paidAmount =
        netAmount - (epfEmployeeDeduction + esiEmployeeDeduction);

      return {
        id: emp.id,
        emp_code: emp.emp_code,
        name: emp.name,
        client: emp.client_info?.projNm,
        designation: emp.designation_info?.designation_name,
        Gross_Salary: grossSalary.toFixed(2),
        Absent_Day: absentDay,
        net_amt: netAmount.toFixed(2),
        other_allowence: "0.00",
        EPF_Employee_Share: epfEmployeeDeduction.toFixed(2),
        EPF_Employer_Share: (
          (netAmount * parseFloat(latestContributions.epf_employer_share)) /
          100
        ).toFixed(2),
        ESI_Employee_Share: esiEmployeeDeduction.toFixed(2),
        ESI_Employer_Share: (
          (netAmount * parseFloat(latestContributions.esi_employer_share)) /
          100
        ).toFixed(2),
        Tds: "0.00",
        paid_amt: paidAmount.toFixed(2),
        contributionRates: {
          epf_employee: latestContributions.epf_employee_share,
          esi_employee: latestContributions.esi_employee_share,
        },
      };
    });

    res.status(200).json({ data: salaryData });
  } catch (error) {
    console.error("Error previewing salary statement:", error);
    res.status(500).json({ message: "Failed to preview salary statement." });
  }
};

export const generateSalaryStatement = async (req, res) => {
  const { year, month, employees } = req.body;
  if (!year || !month || !Array.isArray(employees) || employees.length === 0) {
    return res.status(400).json({ message: "Missing required data." });
  }

  const transaction = await sequelize.transaction();
  try {
    const salary_statement_id = `${String(month).padStart(2, "0")}${year}`;

    const [masterStatement, created] =
      await SalaryStatementStructure.findOrCreate({
        where: { year, month, salary_statement_id },
        defaults: { year, month, salary_statement_id },
        transaction,
      });

    if (!created) {
      await transaction.rollback();
      return res.status(409).json({
        message: `Salary statement for ${month}/${year} has already been generated.`,
      });
    }

    let lastSalaryId = (await SalaryStatement.max("id", { transaction })) || 0;

    const recordsToInsert = employees.map((emp) => {
      lastSalaryId++;

      return {
        statement_id: masterStatement.id,
        emp_id: emp.id,
        salary_id: `SL${String(lastSalaryId).padStart(5, "0")}`,
        year,
        month,
        Gross_Salary: emp.Gross_Salary,
        Absent_Day: emp.Absent_Day,
        net_amt: emp.net_amt,
        other_allowence: emp.other_allowence,
        EPF_Employee_Share: emp.EPF_Employee_Share,
        EPF_Employer_Share: emp.EPF_Employer_Share,
        ESI_Employee_Share: emp.ESI_Employee_Share,
        ESI_Employer_Share: emp.ESI_Employer_Share,
        Tds: emp.Tds,
        paid_amt: emp.paid_amt,
      };
    });

    await SalaryStatement.bulkCreate(recordsToInsert, { transaction });
    await transaction.commit();
    res
      .status(201)
      .json({ message: "Salary statement generated successfully." });
  } catch (error) {
    await transaction.rollback();
    console.error("Error generating salary statement:", error);
    res.status(500).json({ message: "Failed to generate salary statement." });
  }
};



export const listSalaryStatements = async (req, res) => {
  try {
    const statements = await SalaryStatementStructure.findAll({
      attributes: ["id", "salary_statement_id"],
      order: [
        ["year", "DESC"],
        ["month", "DESC"],
      ],
    });

    res.status(200).json({ data: statements });
  } catch (error) {
    console.error("Error listing salary statements:", error);
    res.status(500).json({ message: "Failed to list statements." });
  }
};



export const getSalaryStatementDetails = async (req, res) => {
  const { statement_id } = req.query;
  if (!statement_id) {
    return res.status(400).json({ message: "Statement ID is required." });
  }
  try {
    const details = await SalaryStatement.findAll({
      where: { statement_id },
      include: [
        {
          model: Employee,
          attributes: ["emp_code", "name"],
        },
      ],
      order: [[Employee, "name", "ASC"]],
      raw: true,
      nest: true,
    });
    res.status(200).json({ data: details });
  } catch (error) {
    console.error("Error fetching statement details:", error);
    res.status(500).json({ message: "Failed to fetch details." });
  }
};



export const updateSalaryRecord = async (req, res) => {
  const { id } = req.params;
  const dataToUpdate = req.body;

  try {
    const record = await SalaryStatement.findByPk(id);
    if (!record) {
      return res.status(404).json({ message: "Salary record not found." });
    }

    const allowedUpdates = {
      Absent_Day: dataToUpdate.Absent_Day,
      other_allowence: dataToUpdate.other_allowence,
      EPF_Employee_Share: dataToUpdate.EPF_Employee_Share,
      EPF_Employer_Share: dataToUpdate.EPF_Employer_Share,
      ESI_Employee_Share: dataToUpdate.ESI_Employee_Share,
      ESI_Employer_Share: dataToUpdate.ESI_Employer_Share,
      Tds: dataToUpdate.Tds,
      paid_amt: dataToUpdate.paid_amt,
      net_amt: dataToUpdate.net_amt,
    };

    await record.update(allowedUpdates);

    res.status(200).json({ message: "Record updated successfully." });
  } catch (error) {
    console.error("Error updating salary record:", error);
    res.status(500).json({ message: "Failed to update record." });
  }
};
