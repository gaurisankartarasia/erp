import { sequelize } from "../models/index.js";
const { Designation, Client } = sequelize.models;

export const getActiveDesignations = async (req, res) => {
  try {
    const designations = await Designation.findAll({
      where: {
        is_active: true,
        is_delete: false,
      },
      attributes: ["id", "designation_id", "designation_name"],
      order: [["designation_name", "ASC"]],
    });

    return res.status(200).json({
      data: designations,
    });
  } catch (error) {
    console.error("Error fetching designations:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

export const getClientList = async (req, res) => {
  try {
    const clients = await Client.findAll({
      where: {
        is_active: true,
        is_delete: false,
      },
      attributes: ["id", "clientid", "projNm"],
      order: [["projNm", "ASC"]],
    });

    return res.status(200).json({
      data: clients,
    });
  } catch (error) {
    console.error("Error fetching clients:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};
