// Endpoint to get the next letter number for Add Dispatch page
export const getNextLetterNo = async (req, res) => {
  try {
    const fyShort = getShortFinancialYear();
    // Get the next id (max id + 1)
    const maxId = await Dispatch.max('id');
    const nextId = (maxId || 0) + 1;
    const nextLetterNo = `MTPL/${fyShort}/L-${nextId.toString().padStart(3, '0')}`;
    res.json({ nextLetterNo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
// Helper to get financial year in short format (e.g., 2526 for 2025-2026)
export function getShortFinancialYear() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  let fyStart, fyEnd;
  if (month >= 4) {
    fyStart = year % 100;
    fyEnd = (year + 1) % 100;
  } else {
    fyStart = (year - 1) % 100;
    fyEnd = year % 100;
  }
  return `${fyStart.toString().padStart(2, '0')}${fyEnd.toString().padStart(2, '0')}`;
}


import { Op } from 'sequelize';
import { models } from '../models/index.js';
const Dispatch = models.Dispatch;

// Helper function to validate sort order
const validSortOrders = ['asc', 'desc'];

export const getAllDispatches = async (req, res) => {
  try {

    // Support both sort/sortBy and order/sortOrder for frontend compatibility
    let {
      search,
      page = 1,
      limit = 10,
      sort,
      order,
      sortBy,
      sortOrder
    } = req.query;

    const offset = (page - 1) * parseInt(limit);

    // Prefer sort/sortBy and order/order for compatibility
    const sortField = sortBy || sort || 'createdAt';
    const orderDirection = (sortOrder || order || 'desc').toLowerCase();

    // Validate sortBy column, only allow specific columns to avoid SQL injection
    const allowedSortFields = [
      'sUrl',
      'letterNo',
      'date',
      'sendTo',
      'subject',
      'status',
      'createdAt',
    ];
    const orderField = allowedSortFields.includes(sortField) ? sortField : 'createdAt';

    // Build where condition for searching
    let whereCondition = {};
    if (search) {
      whereCondition = {
        [Op.or]: [
          { letterNo: { [Op.like]: `%${search}%` } },
          { sendTo: { [Op.like]: `%${search}%` } },
          { subject: { [Op.like]: `%${search}%` } }
        ]
      };
    }

    // Query dispatches with search, sorting, pagination
    const { count, rows } = await Dispatch.findAndCountAll({
      where: whereCondition,
      limit: parseInt(limit),
      offset,
      order: [[orderField, orderDirection.toUpperCase()]], // Sequelize expects 'ASC'/'DESC'
    });

    const totalPages = Math.ceil(count / parseInt(limit));

    // Map camelCase to snake_case for createdAt/updatedAt
    const dispatches = rows.map(d => {
      const obj = d.toJSON();
      obj.created_at = obj.createdAt;
      obj.updated_at = obj.updatedAt;
      delete obj.createdAt;
      delete obj.updatedAt;
      return obj;
    });

    res.json({
      total: count,
      page: parseInt(page),
      totalPages,
      data: dispatches
    });
  } catch (error) {
    console.error('Error fetching dispatches:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Rest of your existing handlers unchanged:

export const getDispatchById = async (req, res) => {
  try {
    const dispatch = await Dispatch.findByPk(req.params.id);
    if (!dispatch) {
      return res.status(404).json({ error: 'Dispatch not found' });
    }
    res.json(dispatch);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};



export const createDispatch = async (req, res) => {
  try {
    const fyShort = getShortFinancialYear();
    const maxSurl = await Dispatch.max('sUrl');
    const nextSurl = (maxSurl || 0) + 1;



    // Accept file from req.file or from req.files if present (middleware flexibility)
    let file = req.file;
    if (!file && req.files && Object.values(req.files).length > 0) {
      file = Object.values(req.files).flat()[0];
    }
    if (!file) {
      return res.status(400).json({ error: 'Soft copy file is required.' });
    }
    // Use filename if available, else path
    const softCopyPath = file.filename || file.path;

    const { date, sendTo, subject } = req.body;

    // First, create the dispatch with a temporary letterNo (not null)
    const tempLetterNo = 'TEMP';
    const newDispatch = await Dispatch.create({
      sUrl: nextSurl,
      letterNo: tempLetterNo,
      date,
      sendTo,
      subject,
      softCopy: softCopyPath,
      status: true
    });

    // Now update letterNo to use the new id
    const letterNo = `MTPL/${fyShort}/L-${newDispatch.id.toString().padStart(3, '0')}`;
    await newDispatch.update({ letterNo });

    res.status(201).json(newDispatch);
  } catch (error) {
    console.error('Error creating dispatch:', error);
    res.status(400).json({ error: error.message });
  }
};

export const updateDispatch = async (req, res) => {
  try {
    const dispatch = await Dispatch.findByPk(req.params.id);
    if (!dispatch) {
      return res.status(404).json({ error: 'Dispatch not found' });
    }

    // Build update object
    const updateObj = {};
    if (req.body.date) updateObj.date = req.body.date;
    if (req.body.sendTo) updateObj.sendTo = req.body.sendTo;
    if (req.body.subject) updateObj.subject = req.body.subject;

    // Accept file from req.file or from req.files if present (middleware flexibility)
    let file = req.file;
    if (!file && req.files && Object.values(req.files).length > 0) {
      file = Object.values(req.files).flat()[0];
    }
    if (file) {
      updateObj.softCopy = file.filename || file.path;
    }

    await dispatch.update(updateObj);
    res.json(dispatch);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const toggleStatus = async (req, res) => {
  try {
    const dispatch = await Dispatch.findByPk(req.params.id);
    if (!dispatch) {
      return res.status(404).json({ error: 'Dispatch not found' });
    }

    await dispatch.update({ status: !dispatch.status });
    res.json(dispatch);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteDispatch = async (req, res) => {
  try {
    const dispatch = await Dispatch.findByPk(req.params.id);
    if (!dispatch) {
      return res.status(404).json({ error: 'Dispatch not found' });
    }

    await dispatch.destroy();
    res.json({ message: 'Dispatch deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
