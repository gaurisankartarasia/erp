import { DataTypes } from 'sequelize';

export default (sequelize) => {
  const Client = sequelize.define('Client', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    clientid: {
      type: DataTypes.STRING(60),
      allowNull: true
    },
    projNm: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Project Name'
    },
    clientNm: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Client Name'
    },
    location: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    person: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Contact Person Name'
    },
    mob: {
      type: DataTypes.STRING(20),
      allowNull: true,
      comment: 'Mobile Number'
    },
    phone: {
      type: DataTypes.STRING(20),
      allowNull: true,
      comment: 'Alternate Phone Number'
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: true,
      // It's good practice to add validation for emails
      validate: {
        isEmail: true
      }
    },
    gstno: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'GST Number'
    },
    taxtype: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    dist: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'District Name'
    },
    state: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'State Name'
    },
    pin: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Pin Code'
    },
    pan: {
      type: DataTypes.STRING(20),
      allowNull: true,
      comment: 'PAN Number'
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true
    },
    is_delete: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    }
  }, {
    // Model options
    tableName: 'mtpl_clients',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  });

  return Client;
};