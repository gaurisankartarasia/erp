import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "SalaryStatement",
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      statement_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
      emp_id: { type: DataTypes.INTEGER, allowNull: false },
      salary_id: { type: DataTypes.STRING, allowNull: false, unique: true },
      year: { type: DataTypes.STRING, allowNull: false },
      month: { type: DataTypes.STRING, allowNull: false },
      Gross_Salary: { type: DataTypes.DECIMAL(10, 2) },
      Absent_Day: { type: DataTypes.INTEGER },
      net_amt: { type: DataTypes.DECIMAL(10, 2) },
      other_allowence: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0.0 },
      EPF_Employee_Share: { type: DataTypes.DECIMAL(10, 2) },
      EPF_Employer_Share: { type: DataTypes.DECIMAL(10, 2) },
      ESI_Employee_Share: { type: DataTypes.DECIMAL(10, 2) },
      ESI_Employer_Share: { type: DataTypes.DECIMAL(10, 2) },
      Tds: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0.0 },
      paid_amt: { type: DataTypes.DECIMAL(10, 2) },
    },
    {
      tableName: "mtpl_salary_statements",
      timestamps: true,
      underscored: true,
    }
  );
};
