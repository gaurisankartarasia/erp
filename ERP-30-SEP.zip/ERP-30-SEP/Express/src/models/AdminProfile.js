import { DataTypes } from "sequelize";
import bcrypt from "bcrypt";

export default (sequelize) => {
  const AdminProfile = sequelize.define(
    "AdminProfile",
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      admin_name: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      admin_type_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      admin_id: {
        type: DataTypes.STRING(30),
        allowNull: true,
      },
      email: {
        type: DataTypes.STRING(70),
        allowNull: true,
        unique: true,
        validate: {
          isEmail: true,
        },
      },
      password: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      permission: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: "Could store a JSON string of permissions",
      },
      mobile_no: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      address: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      branch_code: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      account_no: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      ifsc_code: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      tan_no: {
        type: DataTypes.STRING(10),
        allowNull: true,
      },
      pan_no: {
        type: DataTypes.STRING(10),
        allowNull: true,
      },
      gst_no: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      cin_no: {
        type: DataTypes.STRING(30),
        allowNull: true,
      },
      bank_name: {
        type: DataTypes.STRING(30),
        allowNull: true,
      },
      invoice_bank_name: {
        type: DataTypes.STRING(30),
        allowNull: true,
      },
      invoice_account_no: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      invoice_ifsc_code: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      is_active: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      is_delete: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      tableName: "mtpl_admin",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",

      hooks: {
        beforeCreate: async (profile) => {
          if (profile.password) {
            const salt = await bcrypt.genSalt(10);
            profile.password = await bcrypt.hash(profile.password, salt);
          }
        },
        beforeUpdate: async (profile) => {
          if (profile.changed("password")) {
            const salt = await bcrypt.genSalt(10);
            profile.password = await bcrypt.hash(profile.password, salt);
          }
        },
      },
    }
  );

  AdminProfile.prototype.comparePassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
  };

  return AdminProfile;
};
