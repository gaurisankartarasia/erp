import { DataTypes } from "sequelize";
export default (sequelize) => {
  sequelize.define(
    "Unit",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      unit_id: {
        type: DataTypes.STRING(10),
        allowNull: false,
        unique: true,
      },
      unit_name: {
        type: DataTypes.STRING(150),
      },
      description: {
        type: DataTypes.TEXT,
      },
      is_active: {
        type: DataTypes.TINYINT(1),
        defaultValue: 1,
      },
      is_delete: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
    },
    {
      tableName: "mtpl_units",
      timestamps: true,
      underscored: true,
    }
  );
};
