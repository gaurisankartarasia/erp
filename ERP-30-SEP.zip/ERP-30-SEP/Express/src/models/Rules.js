import { DataTypes } from 'sequelize';

export default (sequelize) => {
  sequelize.define('Rules', {
    rule_key: {
      type: DataTypes.STRING(50),
      primaryKey: true
    },
    rule_value: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true
    }
  }, {
    tableName: 'mtpl_company_rules',
    timestamps: true,
    createdAt: true,
    updatedAt: 'updated_at'
  });
};