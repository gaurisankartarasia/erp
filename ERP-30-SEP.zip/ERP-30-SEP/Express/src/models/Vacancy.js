import { DataTypes } from 'sequelize';

export default (sequelize) => {
  sequelize.define('Vacancy', {
    post_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
  }, {
    tableName: 'mtpl_vacancies',
    timestamps: true,
    underscored: true
  });
};
