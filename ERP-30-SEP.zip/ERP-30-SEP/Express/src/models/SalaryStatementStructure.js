import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "SalaryStatementStructure",
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      salary_statement_id: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      year: { type: DataTypes.STRING, allowNull: false },
      month: { type: DataTypes.STRING, allowNull: false },
    },
    {
      tableName: "mtpl_salary_statement_structures",
      timestamps: true,
      underscored: true,
    }
  );
};
