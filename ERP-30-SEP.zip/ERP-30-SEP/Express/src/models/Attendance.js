import { DataTypes } from "sequelize";

export default (sequelize) => {
  sequelize.define(
    "Attendance",
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      employee_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "mtpl_employees",
          key: "id",
        },
      },
      attendance_id: {
        type: DataTypes.STRING(150),
        allowNull: false,
        unique: false,
      },
      year: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      month: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      client_location: {
        type: DataTypes.STRING(50),
        allowNull: false,
      },
      presentday: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      absentday: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      workingday: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      is_delete: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      tableName: "mtpl_attendances",
      timestamps: true,
      underscored: true,
    }
  );
};
