
import { DataTypes } from 'sequelize';

export default (sequelize) => {
  return sequelize.define('Dispatch', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    sUrl: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    letterNo: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    sendTo: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    subject: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    softCopy: {
      type: DataTypes.STRING,
      defaultValue: null
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'mtpl_dispatches',
    timestamps: true,
    underscored: true
  });
};
