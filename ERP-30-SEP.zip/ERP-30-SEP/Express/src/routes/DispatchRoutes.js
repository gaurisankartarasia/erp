
import express from 'express';


import {
  getAllDispatches,
  getDispatchById,
  createDispatch,
  updateDispatch,
  toggleStatus,
  deleteDispatch,
  getNextLetterNo
} from '../controllers/DispatchController.js';
import upload from '../middlewares/UploadMiddleware.js';

const router = express.Router();

// Endpoint to get the next letter number
router.get('/next-letter-no', getNextLetterNo);

router.get('/', getAllDispatches);
router.get('/:id', getDispatchById);
// Ensure upload middleware is applied before createDispatch
router.post(
  '/',
  upload({
    field: 'softCopy',
    allowedTypes: [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/png',
      'image/jpg',
    ],
    maxSize: 2 * 1024 * 1024, // 2MB
    uploadDir: 'public/uploads/dispatches',
    mode: 'single',
  }),
  createDispatch
);
router.put(
  '/:id',
  upload({
    field: 'softCopy',
    allowedTypes: [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/png',
      'image/jpg',
    ],
    maxSize: 2 * 1024 * 1024, // 2MB
    uploadDir: 'public/uploads/dispatches',
    mode: 'single',
  }),
  updateDispatch
);
router.patch('/:id/toggle-status', toggleStatus);
router.delete('/:id', deleteDispatch);

export default router;