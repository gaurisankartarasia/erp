import express from "express";
import {
  editEmployee,
  getAccountById,
  getAllEmployees,
  getEmployeeById,
  registerEmployee,
  toggleEmployeeStatus,
  updateAccount,
} from "../controllers/EmployeeController.js";
import { protect } from "../middlewares/AuthMiddleware.js";
import upload from "../middlewares/UploadMiddleware.js";

const router = express.Router();
router.use(protect);

router.get("/employees", getAllEmployees);
router.get("/employees/:id", getEmployeeById);

router.post(
  "/register",
 upload({
    field: [
      { name: "upload_image", maxCount: 1 },
      { name: "upload_resume", maxCount: 1 },
    ],
    prefix: "employee",
    resize: true,
    uploadDir: "public/uploads/employees",
    allowedTypes: ["image/", "application/pdf"], 
  }),
  registerEmployee
);

router.put(
  "/edit/:id",
    upload({
    field: [
      { name: "upload_image", maxCount: 1 },
      { name: "upload_resume", maxCount: 1 },
    ],
    prefix: "employee",
    resize: true,
    uploadDir: "public/uploads/employees",
    allowedTypes: ["image/", "application/pdf"], 
  }),
  editEmployee
);

//account related croutes
router.get("/employee/account", getAccountById);
router.put(
  "/employee/account/edit",
  upload({
    field: "upload_image",
    prefix: "employee",
    resize: true,
    uploadDir: "public/uploads/employees",
  }),
  updateAccount
);

router.patch("/:id/status", toggleEmployeeStatus);

export default router;
