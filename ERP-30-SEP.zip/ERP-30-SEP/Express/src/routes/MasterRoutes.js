import express from 'express';
import { getActiveDesignations, getClientList } from '../controllers/MasterController.js';

const router = express.Router();

router.get('/designations', getActiveDesignations);
router.get('/clients', getClientList)

export default router;
