import { Router } from "express";
import {
  getAllStates,
  getStateWithDistricts,
  createState,
  getAllDistricts,
  getDistrictsByState,
  createDistrict,
} from "../controllers/LocationController.js";

const router = Router();

router.get("/states", getAllStates);
router.get("/states/:stateId/districts", getDistrictsByState);
router.get("/states/:id", getStateWithDistricts);
router.get("/districts", getAllDistricts);
router.post("/states", createState);
router.post("/districts", createDistrict);

export default router;
