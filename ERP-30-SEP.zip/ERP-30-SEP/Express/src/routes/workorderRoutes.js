
import { Router } from 'express';
import { body } from 'express-validator';
import {
  createWorkOrder,
  getAllWorkOrders,
  getWorkOrderById,
  updateWorkOrder,
  deleteWorkOrder,
  toggleWorkOrderStatus,
  getAllClients
} from "../controllers/workorderController.js";
import upload from "../middlewares/UploadMiddleware.js";
import { protect } from "../middlewares/AuthMiddleware.js";

const router = Router();

const workOrderUploadOptions = {
  field: 'document',
  uploadDir: 'public/uploads/work-orders',
  allowedTypes: ['application/pdf', 'image/jpeg', 'image/jpg'],
  prefix: 'workorder-doc',
  resize: false,
};

const validationRules = [
  body('client_id').isInt({ min: 1 }).withMessage('A valid Client must be selected.'),
  body('work_order_no').trim().notEmpty().withMessage('Work Order No is required.'),
  body('start_date').isDate({ format: 'YYYY-MM-DD' }).withMessage('A valid start date is required.'),
  body('expiry_date').isDate({ format: 'YYYY-MM-DD' }).withMessage('A valid expiry date is required.'),
  body('subject').trim().notEmpty().withMessage('Subject is required.'),
  body('taxable_price').isDecimal().withMessage('Taxable Price must be a valid number.'),
  body('tax_id').isInt({ min: 1 }).withMessage('A valid Tax Rate must be selected.'),
  body('tax_amount').isDecimal().withMessage('Tax Amount must be a valid number.'),
  body('total_amount').isDecimal().withMessage('Total Amount must be a valid number.'),
];

router.use(protect);

// GET all clients (for dropdown)
router.get('/clients', getAllClients);

// Work Orders collection
router.route('/')
  .post(...upload(workOrderUploadOptions), validationRules, createWorkOrder)
  .get(getAllWorkOrders);

// Work Orders by ID
router.route('/:id')
  .get(getWorkOrderById)
  .put(...upload(workOrderUploadOptions), validationRules, updateWorkOrder)
  .delete(deleteWorkOrder);

// Toggle status
router.route('/:id/status').patch(toggleWorkOrderStatus);

export default router;
