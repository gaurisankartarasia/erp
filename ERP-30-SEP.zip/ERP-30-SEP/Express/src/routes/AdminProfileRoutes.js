import { Router } from 'express';
import {
  getAdminProfile,
  updateAdminProfile
} from '../controllers/AdminProfileController.js';
// Optional: Add authentication middleware
// import { protect, admin } from '../middleware/authMiddleware.js';

const router = Router();

// Define a single route that handles both GET and PUT requests.
// You could add `protect` and `admin` middleware here to secure these endpoints.
router.route('/')
  .get(getAdminProfile)
  .put(updateAdminProfile);

export default router;