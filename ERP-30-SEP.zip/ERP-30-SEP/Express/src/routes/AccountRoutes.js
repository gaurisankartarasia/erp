import express from "express";
import { protect } from "../middlewares/AuthMiddleware.js";
import { getMyProfile } from "../controllers/AccountController.js";

const router = express.Router()

router.use(protect);

router.get("/:id", getMyProfile);


export default router;