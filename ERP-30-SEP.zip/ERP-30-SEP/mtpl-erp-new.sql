-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2025 at 04:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mtpl-erp-new`
--

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_admin`
--

CREATE TABLE `mtpl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `admin_name` varchar(50) DEFAULT NULL,
  `admin_type_id` int(11) DEFAULT NULL,
  `admin_id` varchar(30) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `permission` text DEFAULT NULL COMMENT 'Could store a JSON string of permissions',
  `mobile_no` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `branch_code` varchar(100) DEFAULT NULL,
  `account_no` varchar(100) DEFAULT NULL,
  `ifsc_code` varchar(100) DEFAULT NULL,
  `tan_no` varchar(10) DEFAULT NULL,
  `pan_no` varchar(10) DEFAULT NULL,
  `gst_no` varchar(20) DEFAULT NULL,
  `cin_no` varchar(30) DEFAULT NULL,
  `bank_name` varchar(30) DEFAULT NULL,
  `invoice_bank_name` varchar(30) DEFAULT NULL,
  `invoice_account_no` varchar(20) DEFAULT NULL,
  `invoice_ifsc_code` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_attendances`
--

CREATE TABLE `mtpl_attendances` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `attendance_id` varchar(150) NOT NULL,
  `year` varchar(100) DEFAULT NULL,
  `month` varchar(100) DEFAULT NULL,
  `client_location` varchar(50) NOT NULL,
  `presentday` varchar(100) DEFAULT NULL,
  `absentday` varchar(100) DEFAULT NULL,
  `workingday` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_attendances_2`
--

CREATE TABLE `mtpl_attendances_2` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in_time` datetime DEFAULT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_bank_guarantees`
--

CREATE TABLE `mtpl_bank_guarantees` (
  `id` int(11) NOT NULL,
  `work_order_id` bigint(20) UNSIGNED NOT NULL,
  `bg_no` varchar(255) NOT NULL,
  `bg_date` date NOT NULL,
  `bg_validity` date NOT NULL,
  `bg_amount` decimal(12,2) NOT NULL,
  `document` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_clients`
--

CREATE TABLE `mtpl_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clientid` varchar(60) DEFAULT NULL,
  `projNm` varchar(255) DEFAULT NULL COMMENT 'Project Name',
  `clientNm` varchar(255) DEFAULT NULL COMMENT 'Client Name',
  `location` text DEFAULT NULL,
  `person` varchar(255) DEFAULT NULL COMMENT 'Contact Person Name',
  `mob` varchar(20) DEFAULT NULL COMMENT 'Mobile Number',
  `phone` varchar(20) DEFAULT NULL COMMENT 'Alternate Phone Number',
  `email` varchar(255) DEFAULT NULL,
  `gstno` varchar(255) DEFAULT NULL COMMENT 'GST Number',
  `taxtype` varchar(255) DEFAULT NULL,
  `dist` varchar(255) DEFAULT NULL COMMENT 'District Name',
  `state` varchar(255) DEFAULT NULL COMMENT 'State Name',
  `pin` int(11) DEFAULT NULL COMMENT 'Pin Code',
  `pan` varchar(20) DEFAULT NULL COMMENT 'PAN Number',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_clients`
--

INSERT INTO `mtpl_clients` (`id`, `clientid`, `projNm`, `clientNm`, `location`, `person`, `mob`, `phone`, `email`, `gstno`, `taxtype`, `dist`, `state`, `pin`, `pan`, `is_active`, `is_delete`, `created_at`, `updated_at`) VALUES
(1, 'CLNT001', 'HEAD OFFICE', 'BANALATA DAS', 'PLOT NO - 541/3544, SWASTIK VILLA, PAHALA, BHUBANESWAR.', 'SAMBHUSIL MANOHAR DAS', '9777070639', '9937070639', 'mindtrackodisha@gmail.com', '21AAKCM8582E1ZD', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751032, 'AAKCM8582E', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:13:21'),
(2, 'CLNT002', 'BSNL CUTTACK', 'GENERAL MANAGER', 'O/O GMTD,BSNL, LINKROAD, CUTTACK', 'ANIL KUMAR GIRI', '9437082288', '9437082288', 'bsnl@gmail.com', '21AABCB5576G1ZX', 'INTRA STATE', 'CUTTACK', 'ODISHA', 751013, '1', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:06:11'),
(3, 'CLNT003', 'DHH JAJPUR', 'CDM & PHO', 'DISTRICT HEADQUARTER HSOPITAL, JAJPUR TOWN, JAJPUR', 'SURYAKANTA MISHRA', '9439992264', '9439992264', 'hdtjajpur@gmail.com', 'NA', 'INTRA STATE', 'JAJAPUR', 'ODISHA', 755001, 'NA', 1, 0, '0000-00-00 00:00:00', '2024-02-15 16:30:30'),
(4, 'CLNT004', 'DHH DHENKANAL', 'CDM & PHO', 'DHENKANAL', 'SANTOSH KUMAR MANSINGH', '9439980653', '9439980653', 'hdtdkl@gmail.com', 'NA', 'INTRA STATE', 'DHENKANAL', 'ODISHA', 759013, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:17:41'),
(5, 'CLNT005', 'DHH PURI', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, PURI', 'HOSPITAL MANAGER', '9439994067', '9439994067', 'hdtpuri@gmail.com', 'NA', 'INTRA STATE', 'PURI', 'ODISHA', 752001, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:20:00'),
(6, 'CLNT006', 'BOSE CUTTACK', 'PRINCIPAL', 'SCB MEDICAL ROAD, JOBRA, CUTTACK', 'PANKAJINI MOHANTY', '9437306661', '9437306661', 'bose@gmail.com', 'NA', 'INTRA STATE', 'CUTTACK', 'ODISHA', 0, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-17 14:03:00'),
(7, 'CLNT007', 'IDCOL SOFTWARE LTD', 'MANAGING DIRECTOR', 'IDCOL HOUSE, UNIT-II, ASHOK NAGAR, BHUBANESWAR-751009', 'SUBASH KUMAR DAS', '9861438807', '6742530868', 'idcolsoftware@gmail.com', '21AAACI8294F2ZN', 'INTRA STATE', 'KHORDHA', 'ODISHA', 0, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-17 15:51:17'),
(8, 'CLNT008', 'ITI CUTTACK', 'PRINCIPAL', 'PRESS CHAKA, MADHUPATNA, CUTTACK', 'H K MOHANTY', '9437154223', '9437154223', 'iticuttack@nic.in', NULL, 'Intra State', 'CUTTACK', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'CLNT009', 'IMIT CUTTACK', 'PRINCIPAL', 'SCB MEDICAL ROAD, BOSE CAMPUS,  CUTTACK-753007.', 'SUVENDU JAYSINGH', '9861016676', '9861016676', 'imit@gmail.com', NULL, 'Intra State', 'CUTTACK', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'CLNT010', 'ITI PURI', 'PRINCIPAL', 'SHREEVIHAR, WATER WORKS ROAD, PURI-752003', 'PRINCIPAL', '9778391607', '9778391607', 'itipuri@gmail.com', NULL, 'Intra State', 'PURI', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'CLNT011', 'BRANCH OFFICE', 'BRANCH OFFICE', 'BHUBANESWAR', 'SAMBIT KUMAR PATRI', '9776070639', '6742567567', 'mindtrackodisha@gmail.com', NULL, 'Intra State', 'KHORDHA', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'CLNT012', 'TIRTH INFOTECH', 'DIRECTOR', '2ND JAIVEE COMPLEX., AHMEDABAD-380015', 'TIRTHESH SHETH', '9825029662', '671234567', 'tirthesh.sheth@gmail.com', '24AAKPS5428A1ZV', 'Inter State', NULL, NULL, NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'CLNT013', 'CAPITAL HOSPITAL', 'DIRECTOR', 'UNIT-6, BHUBANESWAR', 'LALIT MOHAN SAHU', '9439156188', '9439991156', 'hdtbbsr@gmail.com', '2331455', 'Intra State', 'KHORDHA', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'CLNT014', 'DHH BHADRAK', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, BHADRAK.', 'S. MISHRA', '9439986822', '9439986822', 'abc@gmail.com', 'NA', 'INTRA STATE', 'BHADRAK', 'ODISHA', 756100, 'NA', 1, 0, '0000-00-00 00:00:00', '2024-02-03 19:38:00'),
(15, 'CLNT015', 'STOCKHOLDING DMS LTD', 'MANAGER (OPERATION)', 'SHCIL HOUSE, PLOT NO. P-51, T.T.C., INDUSTRIAL AREA, MIDC, MAHAPE, NAVI MUMBAI - 400701', 'AWADESH SHARMA', '9987210005', '2261778737', 'marketing@stockholdingdms.com', '27AAKCS1549P1ZN', 'Inter State', NULL, NULL, NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'CLNT016', 'SR INFOSYSTEM SOLUTION', 'MANAGING PARTNER', 'HARIPUR ROAD, BUXIBAZAR, PURIGHAT  ODISHA, CUTTACK -753001', 'PRASANJIT SWAIN', '8328960697', '8328960697', 'srinfosystemsolution@gmail.com', '21ADYFS1013L1ZY', 'Intra State', 'CUTTACK', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'CLNT017', 'GP SAMBALPUR', 'PRINCIPAL', 'GOVERNMENT POLYTECHNIC, AT/PO: RENGALI, SAMBALPUR', 'SWARNAPRADA SETHI', '9853266681', '0663-2560070', 'principal_gpsambalpur@rediffmail.com', NULL, 'Intra State', 'SAMBALPUR', 'ODISHA', 768212, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'CLNT018', 'DHH KENDUJHAR', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, KENDUJHAR', '0', '0', '0', 'k@k.com', 'NA', 'Intra State', 'KENDUJHAR', 'ODISHA', 0, '0', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'CLNT019', 'SDH NILGIRI', 'SUPERINTENDENT', 'SDH NILGIRI, DIST-BALASORE', 'BISWAJIT DAS', '9439980856', '9439980856', 'sdhnilgiri@gmail.com', NULL, 'Intra State', 'BALESWAR', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 'CLNT020', 'CHC BHANDA', 'SUPERINTENDENT', 'CHC, BHANDA, KENDUJHAR', 'SAKTIPRASAD MOHANTY', '9658441488', '7008699877', 'bpmubhanda1@gmail.com', NULL, 'Intra State', 'KEONJHAR', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 'CLNT021', 'SCBMCH', 'REGISTRAR (ADMINISTRATION)', 'SCB MEDICAL COLLEGE & HOSPITAL, MANGLABAG, CUTTACK-753007', 'SMT DR. CHAINI', '9437310666', '6712414080', 'scbsuperintendent@gmail.com', NULL, 'Intra State', 'CUTTACK', 'ODISHA', 753007, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 'CLNT022', 'ODISHA COMPUTER APPLICATION CENTRE', 'GENERAL MANAGER (ADMIN)', 'OCAC, N-1/7-D, ACHARYA VIHAR PO- RRL, BHUBANESWAR - 751013', 'SUBRAT KUMAR MOHANTY', '9437233907', '0', 'contact@ocac.in', '21AAAAO0246R1ZL', 'Intra State', 'KHORDHA', 'ODISHA', 751013, 'AAAAO0246R', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 'CLNT023', 'DHH SONEPUR', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, SUBARNAPUR', '9439987557', '9439987557', '9439987557', 'sone@gmail.com', 'NA', 'INTRA STATE', 'SUBARNAPUR (SONAPUR)', 'ODISHA', 767017, 'NA', 1, 0, '0000-00-00 00:00:00', '2024-02-02 16:20:00'),
(24, 'CLNT024', 'ODISHA MINING CORPORATION LTD', 'DIRECTOR (FINANCE)', 'BHUBANESWAR', 'S K PANI', '9437605892', '9437605892', 'idcolsoftware@gmail.com', '21AAACO3324L2ZR', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751001, 'AAACO3324L', 1, 0, '0000-00-00 00:00:00', '2024-01-05 13:23:45'),
(25, 'CLNT025', 'DHH ANUGUL', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, ANGUL', '9439981888', '9439981888', '9439981888', 'hdtangul@gmail.com', 'NA', 'Intra State', 'ANGUL', 'ODISHA', 759122, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'CLNT026', 'DHH BARGARH', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, BARGARH', '9439981591', '9439981591', '9439981591', 'bargarh1@gmail.com', 'NA', 'Intra State', 'BARGARH', 'ODISHA', 768028, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 'CLNT027', 'DHH BOLANGIR', 'CDM&PHO', 'BOLANGIR', '9439987163', '9439987163', '9439987163', 'balangir1@gmail.com', 'NA', 'INTRA STATE', 'BALANGIR', 'ODISHA', 767001, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-12-15 13:31:27'),
(28, 'CLNT028', 'DHH BALASORE', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, BALASORE', '9439982004', '9439982004', '9439982004', 'balasore2@gmail.com', 'NA', 'Intra State', 'BALASORE', 'ODISHA', 756001, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 'CLNT029', 'DHH CUTTACK', 'CDM&PHO', 'BUXIBAZAR, CUTTACK.', '9439995373', '9439995373', '9439995373', 'dhhc@gmail.com', 'NA', 'INTRA STATE', 'CUTTACK', 'ODISHA', 753012, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-10-12 11:58:58'),
(30, 'CLNT030', 'DHH DEOGARH', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, DEOGARH', '9439991239', '9439991239', '9439991239', 'deogarh@gmail.com', 'NA', 'Intra State', 'DEOGARH', 'ODISHA', NULL, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 'CLNT031', 'DHH BOUDH', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, BOUDH', '9439981100', '9439981100', '9439981100', 'dam-boudh-od@gov.in', 'NA', 'INTRA STATE', 'BOUDH', 'ODISHA', 762014, 'NA', 1, 0, '0000-00-00 00:00:00', '2024-02-02 16:23:27'),
(32, 'CLNT032', 'DHH GANJAM', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, GANJAM', '9439985017', '9439985017', '9439985017', 'ganjam@gmail.com', 'NA', 'Intra State', 'GANJAM', 'ODISHA', 760001, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 'CLNT033', 'DHH JAGATSINGHPUR', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, JAGATSINGHPUR', '9439991453', '9439991453', '9439991453', 'jagatsinghpur@gmail.com', 'NA', 'Intra State', 'JAGATSINGHAPUR', 'ODISHA', 754103, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 'CLNT034', 'DHH GAJAPATI', 'CDM & PHO', 'JAJPUR', '9439992262', '9439992262', '9439992262', 'jajpur@gmail.com', NULL, 'Intra State', 'JAJPUR', 'ODISHA', 75501, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 'CLNT035', 'DHH JHARSUGUDA', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, JHARSUGUDA', '9439986872', '9439986872', '9439986872', 'jharsuguda@gmail.com', 'NA', 'Intra State', 'JHARSUGUDA', 'ODISHA', 768201, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 'CLNT036', 'DHH KALAHANDI', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, KALAHANDI', '9439980004', '9439980004', '9439980004', 'kalahandi@gmail.com', 'NA', 'Intra State', 'KALAHANDI', 'ODISHA', 766102, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 'CLNT037', 'DHH KANDHAMAL', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, KANDHAMAL', '9439990208', '9439990208', '9439990208', 'kandhamal@gmail.com', 'NA', 'Intra State', 'KANDHAMAL', 'ODISHA', 762029, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 'CLNT038', 'DHH KENDRAPARA', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, KENDRAPARA', '9439996008', '9439996008', '9439996008', 'kendrapara@gmail.com', 'NA', 'Intra State', 'KENDRAPARA', 'ODISHA', 754211, NULL, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 'CLNT039', 'DHH MALKANGIRI', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, MALKANGIRI', '9439987009', '9439987009', '9439987009', 'ddo1.hfw.or@gembuyer.in', 'NA', 'INTRA STATE', 'MALKANGIRI', 'ODISHA', 764045, 'NA', 1, 0, '0000-00-00 00:00:00', '2024-02-02 16:26:06'),
(40, 'CLNT040', 'DHH KHURDA', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, KHURDA', '9439997091', '9439997091', '9439997091', 'khorda@gmail.com', 'NA', 'INTRA STATE', 'KHORDHA', 'ODISHA', 752055, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:29:59'),
(41, 'CLNT041', 'DHH KORAPUT', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, KORAPUT', '9439992974', '9439992974', '9439992974', 'koraput@gmail.com', 'NA', 'INTRA STATE', 'KORAPUT', 'ODISHA', 764020, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:27:20'),
(42, 'CLNT042', 'DHH MAYURBHANJ', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, MAYURBHANJ', '9439995514', '9439995514', '9439995514', 'mayurbhanj@gmail.com', 'NA', 'INTRA STATE', 'MAYURBHANJ', 'ODISHA', 752055, 'NA', 1, 0, '0000-00-00 00:00:00', '2024-02-03 19:37:03'),
(43, 'CLNT043', 'DHH NAWARANGPUR', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, NAWARANGPUR', '9439990206', '9439990206', '9439990206', 'nawrang@gmail.com', 'NA', 'INTRA STATE', 'NABARANGPUR', 'ODISHA', 764059, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:25:44'),
(44, 'CLNT044', 'DHH RAYAGADA', 'CDM &PHO', 'DISTRICT HEADQUARTER HOSPITAL, RAYAGADA', '8327760426', '8327760426', '8327760426', 'rayagada@gmail.com', 'NA', 'INTRA STATE', 'RAYAGADA', 'ODISHA', 765001, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:25:08'),
(45, 'CLNT045', 'RGH ROURKELA', 'DIRECTOR', 'RGH ROURKELA', '7008102679', '7008102679', '7008102679', 'rourkela@gmail.com', 'NA', 'INTRA STATE', 'SUNDARGARH', 'ODISHA', 769001, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:24:39'),
(46, 'CLNT046', 'DHH SAMBALPUR', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, SAMBALPUR', '9439986008', '9439986008', '9439986008', 'sambalpur@gmail.com', 'NA', 'INTRA STATE', 'SAMBALPUR', 'ODISHA', 768001, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-16 17:23:25'),
(47, 'CLNT047', 'DHH SUNDARGARH', 'CDM & PHO', 'DISTRICT HEADQUARTER HOSPITAL, SUNDARGARH', '9439999168', '9439999168', '9439999168', 'sundargarh@gmail.com', 'NA', 'INTRA STATE', 'SUNDARGARH', 'ODISHA', 770001, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-02 14:09:49'),
(48, 'CLNT048', 'DHH NUAPADA', 'CDM & PHO', 'NUAPADA', '9439989500', '9439989500', '9439989500', 'nuapada@gmail.com', 'NA', 'INTRA STATE', 'NUAPADA', 'ODISHA', 766105, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-02 14:09:22'),
(49, 'CLNT049', 'GP KENDRAPARA', 'PRINCIPAL', 'CDM & PHO KENDRAPARA', '9439996008', '9439996008', '9439996008', 'kendrapara@gmail.com', 'NA', 'INTRA STATE', 'KENDRAPARA', 'ODISHA', 754220, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-02 14:08:59'),
(50, 'CLNT050', 'NANDANKANAN ZOOLOGICAL PARK', 'DEPUTY DIRECTOR', 'NANDANKANAN ZOOLOGICAL PARK, BHUBANESWAR-754005, ODISHA, INDIA', 'DEPUTY DIRECTOR', '6742466075', '6742466075', 'support@nandankanan.org', '21BBNW00027G1DL', 'INTRA STATE', 'KHORDHA', 'ODISHA', 754005, 'NA', 1, 0, '0000-00-00 00:00:00', '2023-11-02 14:08:29'),
(51, 'CLNT051', 'IDC OF ODISHA LIMITED', 'EXECUTIVE DIRECTOR (FINANCE)', 'IDCOL HOUSE, UNIT-II, ASHOK NAGAR, BHUBANESWAR-751009', '9861438807', '9861438807', '6742530868', 'idcolsoftware@gmail.com', '21AAACI4821L1ZU', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751009, 'AAACI4821L', 1, 0, '0000-00-00 00:00:00', '2023-11-02 14:08:11'),
(52, 'CLNT052', 'ODISHA STATE WAREHOUSING CORPORATION', 'MANAGING DIRECTOR', 'PLOT NO: 2, CUTTACK ROAD, BHUBANESWAR', 'P. BEHERA', '9437653698', '0674-2575157', 'gm@oswc.in', '21AAACO4742N1ZG', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751006, 'AAACO4742N', 1, 0, '0000-00-00 00:00:00', '2023-08-30 18:54:19'),
(55, 'CLNT053', 'WORLD SKILL CENTRE', 'DY. PRINCIPAL', 'RASULGARH INDUSTRIAL ESTATE', 'S. K. DAS', '0000000000', '067425631544', 'skdas@wsc.in', '21XXXXX8582E1ZD', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751013, 'XXXXX8582X', 1, 0, '2023-08-30 12:33:17', '2023-10-25 11:13:42'),
(57, 'CLNT054', 'ADDSOFT TECHNOLOGIES PVT LTD', 'MANAGING DIRECTOR', 'CUTTACK', 'DEBASIS MOHAPATRA', '9437314790', '0', 'accounts@addsofttech.in', '21AAFCA4430N1ZW', 'INTRA STATE', 'KHORDHA', 'ODISHA', 753001, 'AAFCA4430N', 1, 0, '2023-08-31 16:57:01', '2024-03-31 17:47:12'),
(58, 'CLNT055', 'SDH ATHAGARH', 'SUPERINTENDENT', 'SDH ATHAGARH, CUTTACK', 'JR HM', '08763372887', '08763372887', 'superintendentsdhathgarh@gmail.com', 'NA', 'INTRA STATE', 'CUTTACK', 'ODISHA', 754029, 'NA', 1, 0, '2023-10-12 13:05:07', '2023-10-12 13:05:07'),
(59, 'CLNT056', 'ADITYA BIRLA RENEWABLES ENERGY LIMITED', 'PROJECT MANAGER', 'VILLAGE - DUMERMUNDA, SAINTALA', 'SUBHASIS BHATTACHARYA', '8309255421', '8309255421', 'subhasis.b@adityabirla.com', 'NA', 'INTRA STATE', 'BALANGIR', 'ODISHA', 767032, 'NA', 1, 0, '2023-11-02 14:07:41', '2023-11-02 15:36:32'),
(60, 'CLNT057', 'ODISHA STATE MEDICAL CORPORATION LIMITED', 'GM OPERATION (EQUIPMENT)', 'INFRONT OF RAM MANDIR, CONVENT SQUARE, UNIT-3, BHUBANESWAR.', 'GM OPERATION', '06742380950', '06742380950', 'proc.osmcl.od@nic.in', '21AABCO9370P1Z1', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751007, 'NA', 1, 0, '2023-11-15 19:08:11', '2023-11-15 19:41:33'),
(61, 'CLNT058', 'NUHM, BHUBANESWAR', 'ADDL. DISTRICT URBAN PUBLIC HEALTH OFFICER', 'ADUPHO-CUM- NODAL OFFICER, NHUM, BHUBANESWAR.', 'HM UPHC', '9439991229', '7008145604', 'cpmunhm.bbsr@gmail.com', 'NA', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751009, 'NA', 1, 0, '2023-11-17 17:18:57', '2023-12-05 20:29:57'),
(62, 'CLNT059', 'SDH BANKI', 'SUPERINTENDENT', 'SDH BANKI, CUTTACK', 'JR HM', '9439994807', '9439994807', 'sdmobanki2021@gmail.com', 'NA', 'INTRA STATE', 'CUTTACK', 'ODISHA', 754008, 'NA', 1, 0, '2023-12-05 19:47:01', '2023-12-05 19:47:01'),
(63, 'CLNT060', 'NUHM, BRAHMAPUR', 'ADDL. DISTRICT URBAN PUBLIC HEALTH OFFICER', 'ADUPHO-CUM- NODAL OFFICER, NHUM, BRAHMAPUR.', 'HM UPHC', '9439998623', '9439998623', 'cpmuberhampur@gmail.com', 'NA', 'INTRA STATE', 'GANJAM', 'ODISHA', 760001, 'NA', 1, 0, '2023-12-05 20:30:12', '2023-12-05 20:30:12'),
(64, 'CLNT061', 'RENEWABLE ENVIROGIC PVT LTD', 'DIRECTOR', 'PLOT NO-2637/A, LEWIS ROAD, BHUBANESWAR', 'ACCOUNT MANAGER', '9937210010', '9937210010', 'envirogic@gmail.com', '21AAJCR3111R1ZB', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751014, 'AJCR3111R1Z', 1, 0, '2023-12-07 18:45:00', '2023-12-09 17:40:18'),
(65, 'CLNT062', 'MEDIAID MARKETING SERVICES', 'DIRECTOR', 'PLOT NO. N3/445, IRC VILLAGE, NAYAPALLI', 'ACCOUNTS MANAGER', '06742551141', '06742551143', 'mediaidms@gmail.com', '21AMDPS5830M1ZW', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751015, 'AMDPS5830M', 1, 0, '2023-12-14 19:03:23', '2023-12-15 18:13:35'),
(66, 'CLNT063', 'L & T CONSTRUCTION WET IC', 'STORE MANAGER', 'LOWER SUKTEL UGPL IRRIGATION PROJECT, BALANGIR', 'ACCOUNT MANAGER', '8114370223', '8637269737', 'kolanjivel@lntecc.com', '21AAACL0140P4ZS', 'INTRA STATE', 'BALANGIR', 'ODISHA', 767002, 'AAACL0140P', 1, 0, '2023-12-28 20:05:19', '2023-12-29 16:18:56'),
(67, 'CLNT064', 'M/S ROYAL', 'M/S ROYAL', 'KADAMPADA, DADHIBAMANPUR, CUTTACK SADAR', 'SAROJ SWAIN', '7980193309', '7980193309', 'msroyale2020@gmail.com', '21ESEPR4644K1ZI', 'INTRA STATE', 'CUTTACK', 'ODISHA', 754112, 'ESEPR4644K', 1, 0, '2024-01-19 15:26:00', '2024-01-19 15:26:00'),
(68, 'CLNT065', 'PM CONTRACTORS PVT LTD', 'MANAGING DIRECTOR', 'PLOT NO-424/2388', 'SAMPAD SWAIN', '6371960253', '9437930369', 'pmcpl69@gmail.com', '21AAGCP7009K1ZH', 'INTRA STATE', 'KHORDHA', 'ODISHA', 751024, 'AAGCP7009K', 1, 0, '2024-01-31 18:44:44', '2025-09-26 13:35:22'),
(69, 'CLNT066', 'NUHM SAMBALPUR', 'ADDL. DISTRICT URBAN PUBLIC HEALTH OFFICER', 'ADUPHO-CUM- NODAL OFFICER, SMC', 'HM UPHC', '9439998332', '9439998332', 'cpmu.sbp@gmail.com', 'NA', 'INTRA STATE', 'SAMBALPUR', 'ODISHA', 768001, 'NA', 1, 0, '2024-04-01 15:25:21', '2024-04-01 15:40:05'),
(70, 'CLNT067', 'ITI LIMITED', 'GENERAL MANAGER (NSU & MSP-EZ)', '22, CR AVENUE, UNITED LIFE ASSURANCE BLDG., 2ND FLOOR, KOLKATA-700072', 'PIYOOSH GUPTA', '9432233188', '8240724210', 'pgupta_nsu@itiltd.co.in', '19AAACI4625C1ZW', 'INTER STATE', 'KOLKATA', 'WEST BENGAL', 700072, 'AAACI4625C', 1, 0, '2024-04-11 17:59:12', '2024-04-11 17:59:12'),
(71, 'CLNT068', 'LEPROSY HOME AND HOSPITAL', 'SUPERINTENDENT', 'NAYABAZAR, CUTTACK', 'BIRENDRA BEHURA', '6372556990', '6372556990', 'lhhcuttack@gmail.com', 'NA', 'INTRA STATE', 'CUTTACK', 'ODISHA', 753004, 'NA', 1, 0, '2024-07-01 18:51:46', '2024-07-01 18:51:46'),
(72, 'CLNT069', 'SLN KORAPUT', 'SUSHANT KUMAR SAHOO', 'JANIGUDA', 'SANGEETA RANI DAS', '7752083714', '7752083714', 'abc@gmail.com', 'NA', 'INTRA STATE', 'KORAPUT', 'ODISHA', 764020, 'NA', 1, 0, '2024-11-02 18:04:15', '2024-11-02 18:04:15');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_company_rules`
--

CREATE TABLE `mtpl_company_rules` (
  `rule_key` varchar(50) NOT NULL,
  `rule_value` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_contributions`
--

CREATE TABLE `mtpl_contributions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cont_id` varchar(100) DEFAULT NULL,
  `epf_employee_share` decimal(18,2) NOT NULL,
  `epf_employer_share` decimal(18,2) NOT NULL,
  `esi_employee_share` decimal(18,2) NOT NULL,
  `esi_employer_share` decimal(18,2) NOT NULL,
  `date` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_designations`
--

CREATE TABLE `mtpl_designations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `designation_id` varchar(255) NOT NULL,
  `designation_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_designations`
--

INSERT INTO `mtpl_designations` (`id`, `designation_id`, `designation_name`, `description`, `is_active`, `is_delete`, `created_at`, `updated_at`) VALUES
(1, 'DES001', 'Software Engineer', 'Responsible for developing software', 1, 0, '2025-09-30 18:11:54', '2025-09-30 18:11:54'),
(2, 'DES002', 'Team Lead', 'Leads a team of software engineers', 1, 0, '2025-09-30 18:11:54', '2025-09-30 18:11:54'),
(3, 'DES003', 'Project Manager', 'Manages projects and timelines', 1, 0, '2025-09-30 18:11:54', '2025-09-30 18:11:54'),
(4, 'DES004', 'HR Manager', 'Handles recruitment and employee relations', 1, 0, '2025-09-30 18:11:54', '2025-09-30 18:11:54'),
(5, 'DES005', 'Accountant', 'Manages financial records and accounts', 1, 0, '2025-09-30 18:11:54', '2025-09-30 18:11:54');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_dispatches`
--

CREATE TABLE `mtpl_dispatches` (
  `id` int(11) NOT NULL,
  `s_url` int(11) NOT NULL,
  `letter_no` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `send_to` text NOT NULL,
  `subject` text NOT NULL,
  `soft_copy` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_districts`
--

CREATE TABLE `mtpl_districts` (
  `id` int(11) NOT NULL,
  `district_name` varchar(100) NOT NULL,
  `state_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_districts`
--

INSERT INTO `mtpl_districts` (`id`, `district_name`, `state_id`, `is_active`, `is_delete`, `created_at`, `updated_at`) VALUES
(1, 'Angul', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Balangir', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Baleswar', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Bargarh', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Bhadrak', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Boudh', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Cuttack', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Debagarh', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Dhenkanal', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'Gajapati', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'Ganjam', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'Jagatsinghapur', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'Jajapur', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'Jharsuguda', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'Kalahandi', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'Kandhamal', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'Kendrapara', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'Kendujhar', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'Khordha', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 'Koraput', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 'Malkangiri', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 'Mayurbhanj', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 'Nabarangapur', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 'Nayagarh', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 'Nuapada', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'Puri', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 'Rayagada', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 'Sambalpur', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 'Subarnapur (Sonapur)', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 'Sundergarh', 26, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 'Anantnag', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 'Bandipore', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 'Baramulla', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 'Budgam', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 'Doda', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 'Ganderbal', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 'Jammu', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 'Kargil', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 'Kathua', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 'Kishtwar', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 'Kulgam', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 'Kupwara', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, 'Leh (Ladakh)', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, 'Poonch', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, 'Pulwama', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, 'Rajouri', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, 'Ramban', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, 'Reasi', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, 'Samba', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, 'Shopian', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, 'Srinagar', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, 'Udhampur', 15, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, 'Bilaspur (Himachal Pradesh)', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, 'Chamba', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, 'Hamirpur (Himachal Pradesh)', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, 'Kangra', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(57, 'Kinnaur', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(58, 'Kullu', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(59, 'Lahul & Spiti', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(60, 'Mandi', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, 'Shimla', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, 'Sirmaur', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, 'Solan', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, 'Una', 14, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, 'Amritsar', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(66, 'Barnala', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, 'Bathinda', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, 'Faridkot', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, 'Fatehgarh Sahib', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, 'Firozpur', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, 'Gurdaspur', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, 'Hoshiarpur', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(73, 'Jalandhar', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(74, 'Kapurthala', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(75, 'Ludhiana', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, 'Mansa', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(77, 'Moga', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(78, 'Muktsar', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(79, 'Patiala', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(80, 'Rupnagar (Ropar)', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(81, 'Sahibzada Ajit Singh Nagar (Mohali)', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(82, 'Sangrur', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(83, 'Shahid Bhagat Singh Nagar (Nawanshahr)', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(84, 'Tarn Taran', 28, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(85, 'Chandigarh', 6, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(86, 'Almora', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(87, 'Bageshwar', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(88, 'Chamoli', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(89, 'Champawat', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(90, 'Dehradun', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(91, 'Haridwar', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(92, 'Nainital', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(93, 'Pauri Garhwal', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(94, 'Pithoragarh', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(95, 'Rudraprayag', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(96, 'Tehri Garhwal', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(97, 'Udham Singh Nagar', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(98, 'Uttarkashi', 34, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(99, 'Ambala', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(100, 'Bhiwani', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(101, 'Faridabad', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(102, 'Fatehabad', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(103, 'Gurgaon', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(104, 'Hisar', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(105, 'Jhajjar', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(106, 'Jind', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(107, 'Kaithal', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(108, 'Karnal', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(109, 'Kurukshetra', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(110, 'Mahendragarh', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(111, 'Mewat', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(112, 'Palwal', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(113, 'Panchkula', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(114, 'Panipat', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(115, 'Rewari', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(116, 'Rohtak', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(117, 'Sirsa', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(118, 'Sonipat', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(119, 'Yamuna Nagar', 13, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(120, 'Central Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(121, 'East Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(122, 'New Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(123, 'North Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(124, 'North East Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(125, 'North West Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(126, 'South Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(127, 'South West Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(128, 'West Delhi', 10, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(129, 'Ajmer', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(130, 'Alwar', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(131, 'Banswara', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(132, 'Baran', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(133, 'Barmer', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(134, 'Bharatpur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(135, 'Bhilwara', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(136, 'Bikaner', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(137, 'Bundi', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(138, 'Chittorgarh', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(139, 'Churu', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(140, 'Dausa', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(141, 'Dholpur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(142, 'Dungarpur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(143, 'Ganganagar', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(144, 'Hanumangarh', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(145, 'Jaipur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(146, 'Jaisalmer', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(147, 'Jalor', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(148, 'Jhalawar', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(149, 'Jhunjhunu', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(150, 'Jodhpur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(151, 'Karauli', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(152, 'Kota', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(153, 'Nagaur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(154, 'Pali', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(155, 'Pratapgarh (Rajasthan)', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(156, 'Rajsamand', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(157, 'Sawai Madhopur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(158, 'Sikar', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(159, 'Sirohi', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(160, 'Tonk', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(161, 'Udaipur', 29, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(162, 'Agra', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(163, 'Aligarh', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(164, 'Allahabad', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(165, 'Ambedkar Nagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(166, 'Auraiya', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(167, 'Azamgarh', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(168, 'Bagpat', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(169, 'Bahraich', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(170, 'Ballia', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(171, 'Balrampur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(172, 'Banda', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(173, 'Barabanki', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(174, 'Bareilly', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(175, 'Basti', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(176, 'Bijnor', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(177, 'Budaun', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(178, 'Bulandshahr', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(179, 'Chandauli', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(180, 'Chitrakoot', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(181, 'Deoria', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(182, 'Etah', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(183, 'Etawah', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(184, 'Faizabad', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(185, 'Farrukhabad', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(186, 'Fatehpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(187, 'Firozabad', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(188, 'Gautam Buddha Nagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(189, 'Ghaziabad', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(190, 'Ghazipur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(191, 'Gonda', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(192, 'Gorakhpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(193, 'Hamirpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(194, 'Hardoi', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(195, 'Hathras', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(196, 'Jalaun', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(197, 'Jaunpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(198, 'Jhansi', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(199, 'Jyotiba Phule Nagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(200, 'Kannauj', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(201, 'Kanpur Dehat', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(202, 'Kanpur Nagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(203, 'Kanshiram Nagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(204, 'Kaushambi', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(205, 'Kheri', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(206, 'Kushinagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(207, 'Lalitpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(208, 'Lucknow', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(209, 'Maharajganj', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(210, 'Mahoba', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(211, 'Mainpuri', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(212, 'Mathura', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(213, 'Mau', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(214, 'Meerut', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(215, 'Mirzapur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(216, 'Moradabad', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(217, 'Muzaffarnagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(218, 'Pilibhit', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(219, 'Pratapgarh', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(220, 'Rae Bareli', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(221, 'Rampur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(222, 'Saharanpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(223, 'Sant Kabir Nagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(224, 'Sant Ravidas Nagar (Bhadohi)', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(225, 'Shahjahanpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(226, 'Shrawasti', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(227, 'Siddharthnagar', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(228, 'Sitapur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(229, 'Sonbhadra', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(230, 'Sultanpur', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(231, 'Unnao', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(232, 'Varanasi', 33, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(233, 'Araria', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(234, 'Arwal', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(235, 'Aurangabad (Bihar)', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(236, 'Banka', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(237, 'Begusarai', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(238, 'Bhagalpur', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(239, 'Bhojpur', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(240, 'Buxar', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(241, 'Darbhanga', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(242, 'East Champaran', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(243, 'Gaya', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(244, 'Gopalganj', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(245, 'Jamui', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(246, 'Jehanabad', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(247, 'Kaimur (Bhabua)', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(248, 'Katihar', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(249, 'Khagaria', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(250, 'Kishanganj', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(251, 'Lakhisarai', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(252, 'Madhepura', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(253, 'Madhubani', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(254, 'Munger', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(255, 'Muzaffarpur', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(256, 'Nalanda', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(257, 'Nawada', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(258, 'Patna', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(259, 'Purnia', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(260, 'Rohtas', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(261, 'Saharsa', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(262, 'Samastipur', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(263, 'Saran', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(264, 'Sheikhpura', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(265, 'Sheohar', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(266, 'Sitamarhi', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(267, 'Siwan', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(268, 'Supaul', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(269, 'Vaishali', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(270, 'West Champaran', 5, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(271, 'East Sikkim', 30, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(272, 'North Sikkim', 30, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(273, 'South Sikkim', 30, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(274, 'West Sikkim', 30, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(275, 'Anjaw', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(276, 'Changlang', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(277, 'Dibang Valley', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(278, 'East Kameng', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(279, 'East Siang', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(280, 'Kurung Kumey', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(281, 'Lohit', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(282, 'Lower Dibang Valley', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(283, 'Lower Subansiri', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(284, 'Papum Pare', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(285, 'Tawang', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(286, 'Tirap', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(287, 'Upper Siang', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(288, 'Upper Subansiri', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(289, 'West Kameng', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(290, 'West Siang', 3, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(291, 'Dimapur', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(292, 'Kiphire', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(293, 'Kohima', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(294, 'Longleng', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(295, 'Mokokchung', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(296, 'Mon', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(297, 'Peren', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(298, 'Phek', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(299, 'Tuensang', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(300, 'Wokha', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(301, 'Zunheboto', 25, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(302, 'Bishnupur', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(303, 'Chandel', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(304, 'Churachandpur', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(305, 'Imphal East', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(306, 'Imphal West', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(307, 'Senapati', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(308, 'Tamenglong', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(309, 'Thoubal', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(310, 'Ukhrul', 22, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(311, 'Aizawl', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(312, 'Champhai', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(313, 'Kolasib', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(314, 'Lawngtlai', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(315, 'Lunglei', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(316, 'Mamit', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(317, 'Saiha', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(318, 'Serchhip', 24, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(319, 'Dhalai', 32, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(320, 'North Tripura', 32, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(321, 'South Tripura', 32, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(322, 'West Tripura', 32, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(323, 'East Garo Hills', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(324, 'East Khasi Hills', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(325, 'Jaintia Hills', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(326, 'Ri Bhoi', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(327, 'South Garo Hills', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(328, 'West Garo Hills', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(329, 'West Khasi Hills', 23, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(330, 'Baksa', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(331, 'Barpeta', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(332, 'Bongaigaon', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(333, 'Cachar', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(334, 'Chirang', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(335, 'Darrang', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(336, 'Dhemaji', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(337, 'Dhubri', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(338, 'Dibrugarh', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(339, 'Dima Hasao (North Cachar Hills)', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(340, 'Goalpara', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(341, 'Golaghat', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(342, 'Hailakandi', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(343, 'Jorhat', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(344, 'Kamrup', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(345, 'Kamrup Metropolitan', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(346, 'Karbi Anglong', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(347, 'Karimganj', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(348, 'Kokrajhar', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(349, 'Lakhimpur', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(350, 'Morigaon', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(351, 'Nagaon', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(352, 'Nalbari', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(353, 'Sivasagar', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(354, 'Sonitpur', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(355, 'Tinsukia', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(356, 'Udalguri', 4, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(357, 'Bankura', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(358, 'Bardhaman', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(359, 'Birbhum', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(360, 'Cooch Behar', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(361, 'Dakshin Dinajpur (South Dinajpur)', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(362, 'Darjiling', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(363, 'Hooghly', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(364, 'Howrah', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(365, 'Jalpaiguri', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(366, 'Kolkata', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(367, 'Maldah', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(368, 'Murshidabad', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(369, 'Nadia', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(370, 'North 24 Parganas', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(371, 'Paschim Medinipur (West Midnapore)', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(372, 'Purba Medinipur (East Midnapore)', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(373, 'Puruliya', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(374, 'South 24 Parganas', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(375, 'Uttar Dinajpur (North Dinajpur)', 35, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(376, 'Bokaro', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(377, 'Chatra', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(378, 'Deoghar', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(379, 'Dhanbad', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(380, 'Dumka', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(381, 'East Singhbhum', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(382, 'Garhwa', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(383, 'Giridih', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(384, 'Godda', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(385, 'Gumla', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(386, 'Hazaribagh', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(387, 'Jamtara', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(388, 'Khunti', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(389, 'Koderma', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(390, 'Latehar', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(391, 'Lohardaga', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(392, 'Pakur', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(393, 'Palamu', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(394, 'Ramgarh', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(395, 'Ranchi', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(396, 'Sahibganj', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(397, 'Seraikela-Kharsawan', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(398, 'Simdega', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(399, 'West Singhbhum', 16, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(400, 'Bastar', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(401, 'Bijapur (Chhattisgarh)', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(402, 'Bilaspur (Chhattisgarh)', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(403, 'Dakshin Bastar Dantewada', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(404, 'Dhamtari', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(405, 'Durg', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(406, 'Janjgir-Champa', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(407, 'Jashpur', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(408, 'Kabirdham (Kawardha)', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(409, 'Korba', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(410, 'Koriya', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(411, 'Mahasamund', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(412, 'Narayanpur', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(413, 'Raigarh (Chhattisgarh)', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(414, 'Raipur', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(415, 'Rajnandgaon', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(416, 'Surguja', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(417, 'Uttar Bastar Kanker', 7, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(418, 'Alirajpur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(419, 'Anuppur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(420, 'Ashok Nagar', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(421, 'Balaghat', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(422, 'Barwani', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(423, 'Betul', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(424, 'Bhind', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(425, 'Bhopal', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(426, 'Burhanpur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(427, 'Chhatarpur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(428, 'Chhindwara', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(429, 'Damoh', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(430, 'Datia', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(431, 'Dewas', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(432, 'Dhar', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(433, 'Dindori', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(434, 'Guna', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(435, 'Gwalior', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(436, 'Harda', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(437, 'Hoshangabad', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(438, 'Indore', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(439, 'Jabalpur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(440, 'Jhabua', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(441, 'Katni', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(442, 'Khandwa (East Nimar)', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(443, 'Khargone (West Nimar)', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(444, 'Mandla', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(445, 'Mandsaur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(446, 'Morena', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(447, 'Narsinghpur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(448, 'Neemuch', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(449, 'Panna', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(450, 'Raisen', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(451, 'Rajgarh', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(452, 'Ratlam', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(453, 'Rewa', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(454, 'Sagar', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(455, 'Satna', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(456, 'Sehore', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(457, 'Seoni', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(458, 'Shahdol', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(459, 'Shajapur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(460, 'Sheopur', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(461, 'Shivpuri', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(462, 'Sidhi', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(463, 'Singrauli', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(464, 'Tikamgarh', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(465, 'Ujjain', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(466, 'Umaria', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(467, 'Vidisha', 20, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(468, 'Ahmedabad', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(469, 'Amreli', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(470, 'Anand', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(471, 'Banaskantha', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(472, 'Bharuch', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(473, 'Bhavnagar', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(474, 'Dahod', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(475, 'Gandhi Nagar', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(476, 'Jamnagar', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(477, 'Junagadh', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(478, 'Kachchh', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(479, 'Kheda', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(480, 'Mahesana', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(481, 'Narmada', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(482, 'Navsari', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(483, 'Panch Mahals', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(484, 'Patan', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(485, 'Porbandar', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(486, 'Rajkot', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(487, 'Sabarkantha', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(488, 'Surat', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(489, 'Surendra Nagar', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(490, 'Tapi', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(491, 'The Dangs', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(492, 'Vadodara', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(493, 'Valsad', 12, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(494, 'Daman', 9, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(495, 'Diu', 9, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(496, 'Dadra & Nagar Haveli', 8, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(497, 'Ahmed Nagar', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(498, 'Akola', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(499, 'Amravati', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(500, 'Aurangabad', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(501, 'Beed', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(502, 'Bhandara', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(503, 'Buldhana', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(504, 'Chandrapur', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(505, 'Dhule', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(506, 'Gadchiroli', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(507, 'Gondia', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(508, 'Hingoli', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(509, 'Jalgaon', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(510, 'Jalna', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(511, 'Kolhapur', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(512, 'Latur', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(513, 'Mumbai', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(514, 'Mumbai Suburban', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(515, 'Nagpur', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(516, 'Nanded', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(517, 'Nandurbar', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(518, 'Nashik', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(519, 'Osmanabad', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(520, 'Parbhani', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(521, 'Pune', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(522, 'Raigarh (Maharashtra)', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(523, 'Ratnagiri', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(524, 'Sangli', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(525, 'Satara', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(526, 'Sindhudurg', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(527, 'Solapur', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(528, 'Thane', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(529, 'Wardha', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(530, 'Washim', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(531, 'Yavatmal', 21, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(532, 'Adilabad', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(533, 'Anantapur', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(534, 'Chittoor', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(535, 'East Godavari', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(536, 'Guntur', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(537, 'Hyderabad', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(538, 'Kadapa (Cuddapah)', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(539, 'Karim Nagar', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(540, 'Khammam', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(541, 'Krishna', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(542, 'Kurnool', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(543, 'Mahbubnagar', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(544, 'Medak', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(545, 'Nalgonda', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(546, 'Nellore', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(547, 'Nizamabad', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(548, 'Prakasam', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(549, 'Rangareddy', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(550, 'Srikakulam', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(551, 'Visakhapatnam', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(552, 'Vizianagaram', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(553, 'Warangal', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(554, 'West Godavari', 2, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(555, 'Bagalkot', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(556, 'Bangalore', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(557, 'Bangalore Rural', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(558, 'Belgaum', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(559, 'Bellary', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(560, 'Bidar', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(561, 'Bijapur (Karnataka)', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(562, 'Chamrajnagar', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(563, 'Chickmagalur', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(564, 'Chikkaballapur', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(565, 'Chitradurga', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(566, 'Dakshina Kannada', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(567, 'Davanagere', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(568, 'Dharwad', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(569, 'Gadag', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(570, 'Gulbarga', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(571, 'Hassan', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(572, 'Haveri', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(573, 'Kodagu', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(574, 'Kolar', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(575, 'Koppal', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(576, 'Mandya', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(577, 'Mysore', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(578, 'Raichur', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(579, 'Ramanagara', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(580, 'Shimoga', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(581, 'Tumkur', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(582, 'Udupi', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(583, 'Uttara Kannada', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(584, 'Yadgir', 17, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(585, 'North Goa', 11, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(586, 'South Goa', 11, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(587, 'Lakshadweep', 19, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(588, 'Alappuzha', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(589, 'Ernakulam', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(590, 'Idukki', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(591, 'Kannur', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(592, 'Kasaragod', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(593, 'Kollam', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(594, 'Kottayam', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(595, 'Kozhikode', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(596, 'Malappuram', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(597, 'Palakkad', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(598, 'Pathanamthitta', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(599, 'Thiruvananthapuram', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(600, 'Thrissur', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(601, 'Wayanad', 18, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(602, 'Ariyalur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(603, 'Chennai', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(604, 'Coimbatore', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(605, 'Cuddalore', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(606, 'Dharmapuri', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(607, 'Dindigul', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(608, 'Erode', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(609, 'Kanchipuram', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(610, 'Kanyakumari', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(611, 'Karur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(612, 'Krishnagiri', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(613, 'Madurai', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(614, 'Nagapattinam', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(615, 'Namakkal', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(616, 'Nilgiris', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(617, 'Perambalur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(618, 'Pudukkottai', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(619, 'Ramanathapuram', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(620, 'Salem', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(621, 'Sivaganga', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(622, 'Thanjavur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(623, 'Theni', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(624, 'Thoothukudi (Tuticorin)', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(625, 'Tiruchirappalli', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(626, 'Tirunelveli', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(627, 'Tiruppur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(628, 'Tiruvallur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(629, 'Tiruvannamalai', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(630, 'Tiruvarur', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(631, 'Vellore', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(632, 'Viluppuram', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(633, 'Virudhunagar', 31, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(634, 'Karaikal', 27, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(635, 'Mahe', 27, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(636, 'Puducherry (Pondicherry)', 27, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(637, 'Yanam', 27, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(638, 'Nicobar', 1, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(639, 'North And Middle Andaman', 1, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(640, 'South Andaman', 1, 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_employees`
--

CREATE TABLE `mtpl_employees` (
  `id` int(11) NOT NULL,
  `emp_code` varchar(100) DEFAULT NULL,
  `user_type` enum('user','admin','master') DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `dob` date DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `designation` bigint(20) UNSIGNED DEFAULT NULL,
  `client` bigint(20) UNSIGNED DEFAULT NULL,
  `guardian_contact` varchar(100) DEFAULT NULL,
  `gender` enum('male','female','others') DEFAULT NULL,
  `religion` enum('Hindu','Muslim','Christian') DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `marital_status` enum('single','married','divorced','widowed') DEFAULT NULL,
  `spouse_name` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `extra_qualification` varchar(100) DEFAULT NULL,
  `pan_no` varchar(50) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `aadhar_no` varchar(20) DEFAULT NULL,
  `branch_name` varchar(100) DEFAULT NULL,
  `esi_ip_no` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `epf_uan_no` varchar(20) DEFAULT NULL,
  `bank_ac_no` varchar(100) NOT NULL,
  `blood_group` enum('A+','A-','B+','B-','O+','O-','AB+','AB-') DEFAULT NULL,
  `branch_id` varchar(20) DEFAULT NULL,
  `permanent_address` varchar(255) DEFAULT NULL,
  `present_address` varchar(255) DEFAULT NULL,
  `permanent_district` int(11) DEFAULT NULL,
  `present_district` int(11) DEFAULT NULL,
  `permanent_state` int(11) DEFAULT NULL,
  `present_state` int(11) DEFAULT NULL,
  `permanent_pin_code` varchar(10) DEFAULT NULL,
  `present_pin_code` varchar(10) DEFAULT NULL,
  `gross_salary` decimal(10,2) DEFAULT NULL,
  `dor` date DEFAULT NULL,
  `upload_image` varchar(255) DEFAULT NULL,
  `upload_resume` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `is_master` tinyint(1) DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `activation_token` varchar(255) DEFAULT NULL,
  `activation_token_expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_employees`
--

INSERT INTO `mtpl_employees` (`id`, `emp_code`, `user_type`, `name`, `email`, `mobile_no`, `dob`, `doj`, `designation`, `client`, `guardian_contact`, `gender`, `religion`, `father_name`, `mother_name`, `marital_status`, `spouse_name`, `qualification`, `extra_qualification`, `pan_no`, `bank_name`, `aadhar_no`, `branch_name`, `esi_ip_no`, `ifsc_code`, `epf_uan_no`, `bank_ac_no`, `blood_group`, `branch_id`, `permanent_address`, `present_address`, `permanent_district`, `present_district`, `permanent_state`, `present_state`, `permanent_pin_code`, `present_pin_code`, `gross_salary`, `dor`, `upload_image`, `upload_resume`, `password`, `is_active`, `is_delete`, `is_master`, `last_login`, `activation_token`, `activation_token_expires_at`, `created_at`, `updated_at`) VALUES
(10, 'EMP001', 'master', 'Mindtrack Technologies Private Limited', 'master@mtpl.com', '9876543210', '1987-04-30', '2020-01-01', 1, 1, '9876543211', 'male', 'Hindu', 'Mr. Sharma', 'Mrs. Sharma', 'married', NULL, 'MCA', NULL, 'ABCDE1234F', 'SBI', '123412341234', 'Cuttack Branch', NULL, 'SBIN0001234', NULL, '1234567890', 'B+', NULL, 'Mumbai Address', 'Mumbai', 1, 1, 1, 1, '400001', '400001', 150000.00, NULL, 'employee-1759238480054-1759238480054.png', NULL, '$2y$10$u49i/IET3YQlHG1EGaFwReivVPYSfzkLzFw3Y.kvTMN3rZQgSvrs6', 1, 0, 1, NULL, NULL, NULL, '2025-09-30 18:18:08', '2025-09-30 13:21:20'),
(11, 'EMP002', 'user', 'MTPL User', 'user@mtpl.com', '9876543212', '1988-11-05', '2021-02-15', 2, 1, '9876543213', 'male', 'Hindu', 'Mr. Kohli', 'Mrs. Kohli', 'married', NULL, 'MBA', NULL, 'XYZAB1234K', 'HDFC', '567856785678', 'Delhi Branch', NULL, 'HDFC0005678', NULL, '0987654321', 'O+', NULL, 'Delhi', 'Delhi Address', 2, 2, 2, 2, '110001', '110001', 200000.00, NULL, 'employee-1759238505214-1759238505214.png', NULL, '$2y$10$9oxXtNs7ePChvQDKV2He1.Y7r4sJZIqcXiphOpK03CcqVjOLqLaRi', 1, 0, 0, NULL, NULL, NULL, '2025-09-30 18:18:08', '2025-09-30 13:21:45');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_employee_permissions`
--

CREATE TABLE `mtpl_employee_permissions` (
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `employee_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_employee_permissions`
--

INSERT INTO `mtpl_employee_permissions` (`created_at`, `updated_at`, `employee_id`, `permission_id`) VALUES
('2025-09-30 13:12:35', '2025-09-30 13:12:35', 11, 12);

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_employee_salary_structures`
--

CREATE TABLE `mtpl_employee_salary_structures` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `component_id` int(11) NOT NULL,
  `calculation_type` enum('Flat','Percentage') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `dependencies` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dependencies`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_expenses`
--

CREATE TABLE `mtpl_expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payer_type` enum('staff','supplier') NOT NULL,
  `payer_id` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `expense_type` varchar(255) DEFAULT NULL,
  `matter` text NOT NULL,
  `approx_km` varchar(255) DEFAULT NULL,
  `invoice_no` varchar(255) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `taxable_amt` decimal(12,2) DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT NULL,
  `tax_amt` decimal(12,2) DEFAULT NULL,
  `discount` decimal(12,2) DEFAULT 0.00,
  `total_amt` decimal(12,2) NOT NULL,
  `document` varchar(255) DEFAULT NULL,
  `status` enum('pending','verified','approved','rejected') DEFAULT 'pending',
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_increment_schemes`
--

CREATE TABLE `mtpl_increment_schemes` (
  `id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `level` varchar(255) NOT NULL,
  `percentage` float NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_invoices`
--

CREATE TABLE `mtpl_invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bill_no` varchar(100) DEFAULT NULL,
  `date` varchar(200) DEFAULT NULL,
  `client_name` bigint(20) UNSIGNED DEFAULT NULL,
  `client_code` varchar(50) DEFAULT NULL,
  `subject` text DEFAULT NULL,
  `reference` text DEFAULT NULL,
  `gst` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cgst` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sgst` decimal(18,2) NOT NULL DEFAULT 0.00,
  `igst` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) DEFAULT NULL,
  `grand_total` decimal(18,2) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_invoice_details`
--

CREATE TABLE `mtpl_invoice_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_id` bigint(20) UNSIGNED NOT NULL,
  `invoice_code` varchar(200) DEFAULT NULL,
  `desc` text DEFAULT NULL,
  `sac` varchar(100) DEFAULT NULL,
  `qty` decimal(18,0) DEFAULT NULL,
  `uom` varchar(50) DEFAULT NULL,
  `unit_price` decimal(18,2) DEFAULT NULL,
  `amnt` decimal(18,2) DEFAULT NULL,
  `gstp` decimal(18,2) DEFAULT NULL,
  `gst_amt` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_items`
--

CREATE TABLE `mtpl_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_id` varchar(10) NOT NULL,
  `item_name` varchar(150) NOT NULL,
  `model_name` varchar(150) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_leave_requests`
--

CREATE TABLE `mtpl_leave_requests` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `manager_comments` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `batch_id` varchar(36) DEFAULT NULL,
  `days` int(11) NOT NULL DEFAULT 0,
  `created_by_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_leave_types`
--

CREATE TABLE `mtpl_leave_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_unpaid` tinyint(1) NOT NULL DEFAULT 0,
  `monthly_allowance_days` int(11) DEFAULT NULL,
  `max_days_per_request` int(11) DEFAULT NULL,
  `fallback_leave_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_log_records`
--

CREATE TABLE `mtpl_log_records` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `action` enum('CREATE','READ','UPDATE','DELETE','LOGIN','LOGOUT') NOT NULL,
  `page_name` varchar(255) NOT NULL,
  `target` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `user_agent` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_agent`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_log_records`
--

INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(1, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:01', '2025-09-30 12:49:01'),
(2, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:01', '2025-09-30 12:49:01'),
(3, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:01', '2025-09-30 12:49:01'),
(4, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:01', '2025-09-30 12:49:01'),
(5, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:41', '2025-09-30 12:49:41'),
(6, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:41', '2025-09-30 12:49:41'),
(7, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:41', '2025-09-30 12:49:41'),
(8, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:49:41', '2025-09-30 12:49:41'),
(9, 10, 'READ', 'ALL WORKORDERS PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:50:52', '2025-09-30 12:50:52'),
(10, 10, 'READ', 'ALL WORKORDERS PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 12:50:52', '2025-09-30 12:50:52'),
(11, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 12:54:12', '2025-09-30 12:54:12'),
(12, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 12:54:12', '2025-09-30 12:54:12'),
(13, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 12:54:12', '2025-09-30 12:54:12'),
(14, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 12:54:12', '2025-09-30 12:54:12'),
(15, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:07:42', '2025-09-30 13:07:42'),
(16, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:07:42', '2025-09-30 13:07:42'),
(17, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:07:42', '2025-09-30 13:07:42'),
(18, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:07:42', '2025-09-30 13:07:42'),
(19, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:39', '2025-09-30 13:11:39'),
(20, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:39', '2025-09-30 13:11:39'),
(21, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:39', '2025-09-30 13:11:39'),
(22, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:39', '2025-09-30 13:11:39'),
(23, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:56', '2025-09-30 13:11:56'),
(24, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:56', '2025-09-30 13:11:56'),
(25, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:56', '2025-09-30 13:11:56'),
(26, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:56', '2025-09-30 13:11:56'),
(27, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:57', '2025-09-30 13:11:57'),
(28, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:57', '2025-09-30 13:11:57'),
(29, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:57', '2025-09-30 13:11:57'),
(30, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:11:57', '2025-09-30 13:11:57'),
(31, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:12:39', '2025-09-30 13:12:39'),
(32, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:12:39', '2025-09-30 13:12:39'),
(33, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:12:39', '2025-09-30 13:12:39'),
(34, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:12:39', '2025-09-30 13:12:39'),
(35, 10, 'UPDATE', 'EMPLOYEE FORM PAGE', '10', '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:44', '2025-09-30 13:20:44');
INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(36, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:45', '2025-09-30 13:20:45'),
(37, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:46', '2025-09-30 13:20:46'),
(38, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:46', '2025-09-30 13:20:46'),
(39, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:46', '2025-09-30 13:20:46'),
(40, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:47', '2025-09-30 13:20:47'),
(41, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:47', '2025-09-30 13:20:47'),
(42, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:47', '2025-09-30 13:20:47'),
(43, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:20:47', '2025-09-30 13:20:47'),
(44, 10, 'UPDATE', 'EMPLOYEE FORM PAGE', '10', '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:21:20', '2025-09-30 13:21:20'),
(45, 11, 'UPDATE', 'EMPLOYEE FORM PAGE', '11', '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:21:45', '2025-09-30 13:21:45'),
(46, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:21:48', '2025-09-30 13:21:48'),
(47, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:21:48', '2025-09-30 13:21:48'),
(48, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:21:48', '2025-09-30 13:21:48'),
(49, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:21:48', '2025-09-30 13:21:48'),
(50, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:22:55', '2025-09-30 13:22:55'),
(51, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:22:55', '2025-09-30 13:22:55'),
(52, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:22:55', '2025-09-30 13:22:55'),
(53, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:22:55', '2025-09-30 13:22:55'),
(54, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:23:05', '2025-09-30 13:23:05'),
(55, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:23:05', '2025-09-30 13:23:05'),
(56, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:23:05', '2025-09-30 13:23:05'),
(57, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:23:05', '2025-09-30 13:23:05'),
(58, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:24:59', '2025-09-30 13:24:59'),
(59, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:24:59', '2025-09-30 13:24:59'),
(60, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:24:59', '2025-09-30 13:24:59'),
(61, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:24:59', '2025-09-30 13:24:59'),
(62, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:25:20', '2025-09-30 13:25:20'),
(63, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:25:20', '2025-09-30 13:25:20'),
(64, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:25:20', '2025-09-30 13:25:20'),
(65, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:25:20', '2025-09-30 13:25:20'),
(66, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:26:38', '2025-09-30 13:26:38'),
(67, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:26:38', '2025-09-30 13:26:38'),
(68, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:26:38', '2025-09-30 13:26:38'),
(69, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:26:38', '2025-09-30 13:26:38'),
(70, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:20', '2025-09-30 13:28:20');
INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(71, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:20', '2025-09-30 13:28:20'),
(72, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:20', '2025-09-30 13:28:20'),
(73, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:20', '2025-09-30 13:28:20'),
(74, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:22', '2025-09-30 13:28:22'),
(75, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:22', '2025-09-30 13:28:22'),
(76, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:22', '2025-09-30 13:28:22'),
(77, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:22', '2025-09-30 13:28:22'),
(78, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:34', '2025-09-30 13:28:34'),
(79, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:34', '2025-09-30 13:28:34'),
(80, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:34', '2025-09-30 13:28:34'),
(81, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:28:34', '2025-09-30 13:28:34'),
(82, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:29:16', '2025-09-30 13:29:16'),
(83, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:29:16', '2025-09-30 13:29:16'),
(84, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:29:38', '2025-09-30 13:29:38'),
(85, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:29:38', '2025-09-30 13:29:38'),
(86, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:29:38', '2025-09-30 13:29:38'),
(87, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:29:38', '2025-09-30 13:29:38'),
(88, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:52', '2025-09-30 13:30:52'),
(89, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:52', '2025-09-30 13:30:52'),
(90, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:52', '2025-09-30 13:30:52'),
(91, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:52', '2025-09-30 13:30:52'),
(92, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:58', '2025-09-30 13:30:58'),
(93, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:58', '2025-09-30 13:30:58'),
(94, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:58', '2025-09-30 13:30:58'),
(95, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:30:58', '2025-09-30 13:30:58'),
(96, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:09', '2025-09-30 13:31:09'),
(97, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:09', '2025-09-30 13:31:09'),
(98, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:09', '2025-09-30 13:31:09'),
(99, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:09', '2025-09-30 13:31:09'),
(100, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:42', '2025-09-30 13:31:42'),
(101, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:42', '2025-09-30 13:31:42'),
(102, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:42', '2025-09-30 13:31:42'),
(103, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:42', '2025-09-30 13:31:42'),
(104, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:49', '2025-09-30 13:31:49'),
(105, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:49', '2025-09-30 13:31:49');
INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(106, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:49', '2025-09-30 13:31:49'),
(107, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:31:49', '2025-09-30 13:31:49'),
(108, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:33:01', '2025-09-30 13:33:01'),
(109, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:33:01', '2025-09-30 13:33:01'),
(110, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:33:01', '2025-09-30 13:33:01'),
(111, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:33:01', '2025-09-30 13:33:01'),
(112, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:45', '2025-09-30 13:35:45'),
(113, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:45', '2025-09-30 13:35:45'),
(114, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:45', '2025-09-30 13:35:45'),
(115, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:45', '2025-09-30 13:35:45'),
(116, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:51', '2025-09-30 13:35:51'),
(117, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:51', '2025-09-30 13:35:51'),
(118, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:51', '2025-09-30 13:35:51'),
(119, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:35:51', '2025-09-30 13:35:51'),
(120, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:07', '2025-09-30 13:36:07'),
(121, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:07', '2025-09-30 13:36:07'),
(122, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:07', '2025-09-30 13:36:07'),
(123, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:07', '2025-09-30 13:36:07'),
(124, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:34', '2025-09-30 13:36:34'),
(125, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:34', '2025-09-30 13:36:34'),
(126, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:34', '2025-09-30 13:36:34'),
(127, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:36:34', '2025-09-30 13:36:34'),
(128, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:26', '2025-09-30 13:37:26'),
(129, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:26', '2025-09-30 13:37:26'),
(130, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:26', '2025-09-30 13:37:26'),
(131, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:26', '2025-09-30 13:37:26'),
(132, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:44', '2025-09-30 13:37:44'),
(133, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:44', '2025-09-30 13:37:44'),
(134, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:44', '2025-09-30 13:37:44'),
(135, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:37:44', '2025-09-30 13:37:44'),
(136, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:17', '2025-09-30 13:40:17'),
(137, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:17', '2025-09-30 13:40:17'),
(138, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:18', '2025-09-30 13:40:18'),
(139, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:18', '2025-09-30 13:40:18'),
(140, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:18', '2025-09-30 13:40:18');
INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(141, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:18', '2025-09-30 13:40:18'),
(142, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:55', '2025-09-30 13:40:55'),
(143, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:55', '2025-09-30 13:40:55'),
(144, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:55', '2025-09-30 13:40:55'),
(145, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:55', '2025-09-30 13:40:55'),
(146, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:57', '2025-09-30 13:40:57'),
(147, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:57', '2025-09-30 13:40:57'),
(148, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:57', '2025-09-30 13:40:57'),
(149, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:40:57', '2025-09-30 13:40:57'),
(150, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:21', '2025-09-30 13:41:21'),
(151, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:21', '2025-09-30 13:41:21'),
(152, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:21', '2025-09-30 13:41:21'),
(153, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:21', '2025-09-30 13:41:21'),
(154, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:25', '2025-09-30 13:41:25'),
(155, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:25', '2025-09-30 13:41:25'),
(156, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:25', '2025-09-30 13:41:25'),
(157, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:25', '2025-09-30 13:41:25'),
(158, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:31', '2025-09-30 13:41:31'),
(159, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:31', '2025-09-30 13:41:31'),
(160, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:31', '2025-09-30 13:41:31'),
(161, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:31', '2025-09-30 13:41:31'),
(162, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:38', '2025-09-30 13:41:38'),
(163, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:38', '2025-09-30 13:41:38'),
(164, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:38', '2025-09-30 13:41:38'),
(165, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:38', '2025-09-30 13:41:38'),
(166, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:51', '2025-09-30 13:41:51'),
(167, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:51', '2025-09-30 13:41:51'),
(168, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:51', '2025-09-30 13:41:51'),
(169, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:41:51', '2025-09-30 13:41:51'),
(170, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:02', '2025-09-30 13:42:02'),
(171, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:02', '2025-09-30 13:42:02'),
(172, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:02', '2025-09-30 13:42:02'),
(173, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:02', '2025-09-30 13:42:02'),
(174, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:42', '2025-09-30 13:42:42'),
(175, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:42', '2025-09-30 13:42:42');
INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(176, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:42', '2025-09-30 13:42:42'),
(177, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:42', '2025-09-30 13:42:42'),
(178, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:45', '2025-09-30 13:42:45'),
(179, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:45', '2025-09-30 13:42:45'),
(180, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:45', '2025-09-30 13:42:45'),
(181, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:45', '2025-09-30 13:42:45'),
(182, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:50', '2025-09-30 13:42:50'),
(183, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:50', '2025-09-30 13:42:50'),
(184, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:50', '2025-09-30 13:42:50'),
(185, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:42:50', '2025-09-30 13:42:50'),
(186, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:00', '2025-09-30 13:43:00'),
(187, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:00', '2025-09-30 13:43:00'),
(188, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:00', '2025-09-30 13:43:00'),
(189, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:00', '2025-09-30 13:43:00'),
(190, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:03', '2025-09-30 13:43:03'),
(191, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:03', '2025-09-30 13:43:03'),
(192, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:03', '2025-09-30 13:43:03'),
(193, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:43:03', '2025-09-30 13:43:03'),
(194, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:45:31', '2025-09-30 13:45:31'),
(195, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:45:31', '2025-09-30 13:45:31'),
(196, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:45:31', '2025-09-30 13:45:31'),
(197, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 13:45:31', '2025-09-30 13:45:31'),
(198, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:59:29', '2025-09-30 13:59:29'),
(199, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:59:29', '2025-09-30 13:59:29'),
(200, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:59:29', '2025-09-30 13:59:29'),
(201, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 13:59:29', '2025-09-30 13:59:29'),
(202, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:05', '2025-09-30 14:06:05'),
(203, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:04', '2025-09-30 14:06:04'),
(204, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:05', '2025-09-30 14:06:05'),
(205, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:05', '2025-09-30 14:06:05'),
(206, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:07', '2025-09-30 14:06:07'),
(207, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:07', '2025-09-30 14:06:07'),
(208, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:07', '2025-09-30 14:06:07'),
(209, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:07', '2025-09-30 14:06:07'),
(210, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:17', '2025-09-30 14:06:17');
INSERT INTO `mtpl_log_records` (`id`, `employee_id`, `action`, `page_name`, `target`, `ip`, `browser`, `os`, `platform`, `user_agent`, `created_at`, `updated_at`) VALUES
(211, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:17', '2025-09-30 14:06:17'),
(212, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:17', '2025-09-30 14:06:17'),
(213, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:06:17', '2025-09-30 14:06:17'),
(214, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:09:50', '2025-09-30 14:09:50'),
(215, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:09:50', '2025-09-30 14:09:50'),
(216, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:09:50', '2025-09-30 14:09:50'),
(217, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:09:50', '2025-09-30 14:09:50'),
(218, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:10:08', '2025-09-30 14:10:08'),
(219, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:10:08', '2025-09-30 14:10:08'),
(220, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:10:08', '2025-09-30 14:10:08'),
(221, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:10:09', '2025-09-30 14:10:09'),
(222, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 14:10:58', '2025-09-30 14:10:58'),
(223, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 14:10:58', '2025-09-30 14:10:58'),
(224, 10, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 14:10:58', '2025-09-30 14:10:58'),
(225, 10, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::1', 'Chrome', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":false,\"isWebkit\":false,\"isChrome\":true,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Chrome\",\"version\":\"140.0.0.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36\",\"isWechat\":false}', '2025-09-30 14:10:58', '2025-09-30 14:10:58'),
(226, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:11:06', '2025-09-30 14:11:06'),
(227, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:11:06', '2025-09-30 14:11:06'),
(228, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:11:06', '2025-09-30 14:11:06'),
(229, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:11:06', '2025-09-30 14:11:06'),
(230, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:48', '2025-09-30 14:17:48'),
(231, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:48', '2025-09-30 14:17:48'),
(232, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:48', '2025-09-30 14:17:48'),
(233, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:48', '2025-09-30 14:17:48'),
(234, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:49', '2025-09-30 14:17:49'),
(235, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:49', '2025-09-30 14:17:49'),
(236, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:49', '2025-09-30 14:17:49'),
(237, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:17:49', '2025-09-30 14:17:49'),
(238, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:10', '2025-09-30 14:18:10'),
(239, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:10', '2025-09-30 14:18:10'),
(240, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:10', '2025-09-30 14:18:10'),
(241, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:10', '2025-09-30 14:18:10'),
(242, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:11', '2025-09-30 14:18:11'),
(243, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:11', '2025-09-30 14:18:11'),
(244, 11, 'READ', 'DASHBOARD SUMMAERY PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:11', '2025-09-30 14:18:11'),
(245, 11, 'READ', 'DASHBOARD PERFOMRANCE CHART PAGE', NULL, '::ffff:127.0.0.1', 'Firefox', 'Windows 10.0', 'Microsoft Windows', '{\"isYaBrowser\":false,\"isAuthoritative\":true,\"isMobile\":false,\"isMobileNative\":false,\"isTablet\":false,\"isiPad\":false,\"isiPod\":false,\"isiPhone\":false,\"isiPhoneNative\":false,\"isAndroid\":false,\"isAndroidNative\":false,\"isBlackberry\":false,\"isOpera\":false,\"isIE\":false,\"isEdge\":false,\"isIECompatibilityMode\":false,\"isSafari\":false,\"isFirefox\":true,\"isWebkit\":false,\"isChrome\":false,\"isKonqueror\":false,\"isOmniWeb\":false,\"isSeaMonkey\":false,\"isFlock\":false,\"isAmaya\":false,\"isPhantomJS\":false,\"isEpiphany\":false,\"isDesktop\":true,\"isWindows\":true,\"isLinux\":false,\"isLinux64\":false,\"isMac\":false,\"isChromeOS\":false,\"isBada\":false,\"isSamsung\":false,\"isRaspberry\":false,\"isBot\":false,\"isCurl\":false,\"isAndroidTablet\":false,\"isWinJs\":false,\"isKindleFire\":false,\"isSilk\":false,\"isCaptive\":false,\"isSmartTV\":false,\"isUC\":false,\"isFacebook\":false,\"isAlamoFire\":false,\"isElectron\":false,\"silkAccelerated\":false,\"browser\":\"Firefox\",\"version\":\"143.0\",\"os\":\"Windows 10.0\",\"platform\":\"Microsoft Windows\",\"geoIp\":{},\"source\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0\",\"isWechat\":false}', '2025-09-30 14:18:11', '2025-09-30 14:18:11');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_payroll_reports`
--

CREATE TABLE `mtpl_payroll_reports` (
  `id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `status` enum('processing','completed','failed') NOT NULL DEFAULT 'processing',
  `generated_by_id` int(11) NOT NULL,
  `generated_at` datetime DEFAULT NULL,
  `error_log` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_permissions`
--

CREATE TABLE `mtpl_permissions` (
  `id` int(11) NOT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `code_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_permissions`
--

INSERT INTO `mtpl_permissions` (`id`, `page_name`, `code_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Dashboard', 'DB', 'Access to Dashboard page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(2, 'Page Permissions', 'PERM', 'Manage page permissions', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(3, 'Manage Client', 'CLIENT', 'Access to client management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(4, 'Company Profile', 'COMP', 'Access to company profile page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(5, 'Manage Designations', 'DESIG', 'Access to designation management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(6, 'Manage EPF/ESI', 'EPFESI', 'Access to contribution management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(7, 'Manage Unit', 'UNIT', 'Access to unit management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(8, 'Manage Item', 'ITEM', 'Access to item management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(9, 'Manage Vacancy', 'VAC', 'Access to vacancy management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(10, 'Manage Vendor', 'VENDOR', 'Access to vendor management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(11, 'Manage Employees', 'EMP', 'Access to employee management page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(12, 'Attendance Entry', 'ATT', 'Access to attendance entry page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(13, 'Work Orders', 'WORKORD', 'Access to work orders page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(14, 'Staff Expenses Entry', 'STAFFEXP', 'Access to staff expenses entry page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(15, 'Vendor Expenses Entry', 'SUPPEXP', 'Access to vendor expenses entry page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(16, 'Expenses Verification', 'EXPVER', 'Access to expenses verification page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(17, 'Expenses Approval', 'EXPAPP', 'Access to expenses approval page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(18, 'Salary Statement', 'SALSTMT', 'Access to salary statement page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(19, 'Invoice Register', 'INVREG', 'Access to invoice register page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(20, 'Working Dispatch', 'DISPATCH', 'Access to dispatch register page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(21, 'Tax Entry', 'TAX', 'Access to tax entry page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(22, 'Employee Reports', 'EMPREP', 'Access to employee reports', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(23, 'Expense Reports', 'EXPREP', 'Access to expense reports', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(24, 'Increment Schemes', 'INCSCH', 'Access to increment schemes', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(25, 'Increment Reports', 'INCREP', 'Access to increment reports', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(26, 'Tasks', 'TASK', 'Access to tasks page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(27, 'Tasks History', 'TASKHIS', 'Access to task history page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(28, 'All Employee Tasks', 'ALLTASK', 'Access to all employee tasks page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(29, 'Salary Components', 'SALCOMP', 'Access to salary components page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(30, 'Salary Structure', 'SALSTR', 'Access to salary structure page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(31, 'Generate Salary', 'GENSAL', 'Access to generate salary page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(32, 'Leave Types', 'LEAVTYP', 'Access to leave types page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(33, 'Manage Leaves', 'MANLEAVE', 'Access to manage leaves page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(34, 'Request Leave', 'REQLEAVE', 'Access to request leave page', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(35, 'Tax Entry (Leave)', 'TAX2', 'Access to tax entry under leaves', '2025-09-30 18:30:02', '2025-09-30 18:30:02'),
(36, 'Activity Log', 'LOG', 'Access to activity log page', '2025-09-30 18:30:02', '2025-09-30 18:30:02');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_salary_annexures`
--

CREATE TABLE `mtpl_salary_annexures` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `basic` decimal(12,2) DEFAULT 0.00,
  `hra` decimal(12,2) DEFAULT 0.00,
  `other_allowance` decimal(12,2) DEFAULT 0.00,
  `your_contribution_pf` decimal(12,2) DEFAULT 0.00,
  `your_contribution_esi` decimal(12,2) DEFAULT 0.00,
  `professional_tax` decimal(12,2) DEFAULT 0.00,
  `company_share_pf` decimal(12,2) DEFAULT 0.00,
  `pf_admin_charges` decimal(12,2) DEFAULT 0.00,
  `company_share_esi` decimal(12,2) DEFAULT 0.00,
  `over_time` decimal(12,2) DEFAULT 0.00,
  `salary_component` decimal(12,2) DEFAULT 0.00,
  `net` decimal(12,2) DEFAULT 0.00,
  `total_c_t_c` decimal(12,2) DEFAULT 0.00,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_salary_components`
--

CREATE TABLE `mtpl_salary_components` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('Earning','Deduction') NOT NULL,
  `is_base_component` tinyint(1) NOT NULL DEFAULT 0,
  `is_days_based` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_salary_slips`
--

CREATE TABLE `mtpl_salary_slips` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `gross_earnings` decimal(10,2) NOT NULL,
  `total_payable_days` int(11) NOT NULL,
  `total_deductions` decimal(10,2) NOT NULL,
  `net_salary` decimal(10,2) NOT NULL,
  `structure_breakdown` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`structure_breakdown`)),
  `attendance_breakdown` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attendance_breakdown`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_salary_statements`
--

CREATE TABLE `mtpl_salary_statements` (
  `id` int(10) UNSIGNED NOT NULL,
  `statement_id` int(10) UNSIGNED NOT NULL,
  `emp_id` int(11) NOT NULL,
  `salary_id` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `gross__salary` decimal(10,2) DEFAULT NULL,
  `absent__day` int(11) DEFAULT NULL,
  `net_amt` decimal(10,2) DEFAULT NULL,
  `other_allowence` decimal(10,2) DEFAULT 0.00,
  `e_p_f__employee__share` decimal(10,2) DEFAULT NULL,
  `e_p_f__employer__share` decimal(10,2) DEFAULT NULL,
  `e_s_i__employee__share` decimal(10,2) DEFAULT NULL,
  `e_s_i__employer__share` decimal(10,2) DEFAULT NULL,
  `tds` decimal(10,2) DEFAULT 0.00,
  `paid_amt` decimal(10,2) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_salary_statement_structures`
--

CREATE TABLE `mtpl_salary_statement_structures` (
  `id` int(10) UNSIGNED NOT NULL,
  `salary_statement_id` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_states`
--

CREATE TABLE `mtpl_states` (
  `id` int(11) NOT NULL,
  `state_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mtpl_states`
--

INSERT INTO `mtpl_states` (`id`, `state_name`, `is_active`, `is_delete`, `created_at`, `updated_at`) VALUES
(1, 'Andaman & Nicobar Islands', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Andhra Pradesh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Arunachal Pradesh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Assam', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Bihar', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Chandigarh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Chhattisgarh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Dadra & Nagar Haveli', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Daman & Diu', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'Delhi', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'Goa', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'Gujarat', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'Haryana', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'Himachal Pradesh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'Jammu & Kashmir', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'Jharkhand', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'Karnataka', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'Kerala', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'Lakshadweep', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 'Madhya Pradesh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 'Maharashtra', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 'Manipur', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 'Meghalaya', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 'Mizoram', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 'Nagaland', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'Odisha', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 'Puducherry', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 'Punjab', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 'Rajasthan', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 'Sikkim', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 'Tamil Nadu', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 'Tripura', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 'Uttar Pradesh', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 'Uttarakhand', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 'West Bengal', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_tasks`
--

CREATE TABLE `mtpl_tasks` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','in_progress','paused','completed') NOT NULL DEFAULT 'pending',
  `assigned_duration_minutes` int(11) DEFAULT NULL,
  `actual_start_time` datetime DEFAULT NULL,
  `actual_end_time` datetime DEFAULT NULL,
  `last_resume_time` datetime DEFAULT NULL,
  `accumulated_duration_seconds` int(11) DEFAULT 0,
  `completion_rating` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `EmployeeId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_tax_entry`
--

CREATE TABLE `mtpl_tax_entry` (
  `id` int(11) NOT NULL,
  `tax_id` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `epf` float DEFAULT 0,
  `esi` float DEFAULT 0,
  `gst` float DEFAULT 0,
  `tds` float DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_units`
--

CREATE TABLE `mtpl_units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unit_id` varchar(10) NOT NULL,
  `unit_name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_delete` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_vacancies`
--

CREATE TABLE `mtpl_vacancies` (
  `id` int(11) NOT NULL,
  `post_name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `description` text NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_vendors`
--

CREATE TABLE `mtpl_vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `vendor_code` varchar(255) DEFAULT NULL COMMENT 'Special unique string ID for the vendor',
  `name` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `tax_type` enum('Inner State','Intra State') DEFAULT 'Inner State',
  `is_active` tinyint(1) DEFAULT 0,
  `gst_no` varchar(255) NOT NULL,
  `pan_no` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `pin_code` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `ifsc_code` varchar(255) NOT NULL,
  `bank_ac_no` varchar(255) NOT NULL,
  `beneficiary_name` varchar(255) NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mtpl_work_orders`
--

CREATE TABLE `mtpl_work_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_by_client_id` bigint(20) UNSIGNED NOT NULL,
  `work_order_no` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `taxable_price` decimal(10,2) NOT NULL,
  `tax_id` int(11) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `document` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mtpl_admin`
--
ALTER TABLE `mtpl_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `mtpl_attendances`
--
ALTER TABLE `mtpl_attendances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attendance_id` (`attendance_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `mtpl_attendances_2`
--
ALTER TABLE `mtpl_attendances_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_bank_guarantees`
--
ALTER TABLE `mtpl_bank_guarantees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `work_order_id` (`work_order_id`);

--
-- Indexes for table `mtpl_clients`
--
ALTER TABLE `mtpl_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_company_rules`
--
ALTER TABLE `mtpl_company_rules`
  ADD PRIMARY KEY (`rule_key`);

--
-- Indexes for table `mtpl_contributions`
--
ALTER TABLE `mtpl_contributions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_designations`
--
ALTER TABLE `mtpl_designations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `designation_id` (`designation_id`),
  ADD UNIQUE KEY `designation_name` (`designation_name`);

--
-- Indexes for table `mtpl_dispatches`
--
ALTER TABLE `mtpl_dispatches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `letter_no` (`letter_no`);

--
-- Indexes for table `mtpl_districts`
--
ALTER TABLE `mtpl_districts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `mtpl_employees`
--
ALTER TABLE `mtpl_employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `pan_no` (`pan_no`),
  ADD UNIQUE KEY `aadhar_no` (`aadhar_no`),
  ADD KEY `designation` (`designation`),
  ADD KEY `client` (`client`),
  ADD KEY `permanent_district` (`permanent_district`),
  ADD KEY `present_district` (`present_district`),
  ADD KEY `permanent_state` (`permanent_state`),
  ADD KEY `present_state` (`present_state`);

--
-- Indexes for table `mtpl_employee_permissions`
--
ALTER TABLE `mtpl_employee_permissions`
  ADD PRIMARY KEY (`employee_id`,`permission_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `mtpl_employee_salary_structures`
--
ALTER TABLE `mtpl_employee_salary_structures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `component_id` (`component_id`);

--
-- Indexes for table `mtpl_expenses`
--
ALTER TABLE `mtpl_expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_increment_schemes`
--
ALTER TABLE `mtpl_increment_schemes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_invoices`
--
ALTER TABLE `mtpl_invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_invoice_details`
--
ALTER TABLE `mtpl_invoice_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `mtpl_items`
--
ALTER TABLE `mtpl_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_id` (`item_id`);

--
-- Indexes for table `mtpl_leave_requests`
--
ALTER TABLE `mtpl_leave_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `leave_type_id` (`leave_type_id`),
  ADD KEY `created_by_admin_id` (`created_by_admin_id`);

--
-- Indexes for table `mtpl_leave_types`
--
ALTER TABLE `mtpl_leave_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `fallback_leave_type_id` (`fallback_leave_type_id`);

--
-- Indexes for table `mtpl_log_records`
--
ALTER TABLE `mtpl_log_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_payroll_reports`
--
ALTER TABLE `mtpl_payroll_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `generated_by_id` (`generated_by_id`);

--
-- Indexes for table `mtpl_permissions`
--
ALTER TABLE `mtpl_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code_name` (`code_name`);

--
-- Indexes for table `mtpl_salary_annexures`
--
ALTER TABLE `mtpl_salary_annexures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_salary_components`
--
ALTER TABLE `mtpl_salary_components`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `mtpl_salary_slips`
--
ALTER TABLE `mtpl_salary_slips`
  ADD PRIMARY KEY (`id`),
  ADD KEY `report_id` (`report_id`);

--
-- Indexes for table `mtpl_salary_statements`
--
ALTER TABLE `mtpl_salary_statements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `salary_id` (`salary_id`),
  ADD KEY `statement_id` (`statement_id`),
  ADD KEY `emp_id` (`emp_id`);

--
-- Indexes for table `mtpl_salary_statement_structures`
--
ALTER TABLE `mtpl_salary_statement_structures`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `salary_statement_id` (`salary_statement_id`);

--
-- Indexes for table `mtpl_states`
--
ALTER TABLE `mtpl_states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_tasks`
--
ALTER TABLE `mtpl_tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmployeeId` (`EmployeeId`);

--
-- Indexes for table `mtpl_tax_entry`
--
ALTER TABLE `mtpl_tax_entry`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tax_id` (`tax_id`);

--
-- Indexes for table `mtpl_units`
--
ALTER TABLE `mtpl_units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unit_id` (`unit_id`);

--
-- Indexes for table `mtpl_vacancies`
--
ALTER TABLE `mtpl_vacancies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtpl_vendors`
--
ALTER TABLE `mtpl_vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vendor_code` (`vendor_code`);

--
-- Indexes for table `mtpl_work_orders`
--
ALTER TABLE `mtpl_work_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `work_order_no` (`work_order_no`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `created_by_client_id` (`created_by_client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mtpl_admin`
--
ALTER TABLE `mtpl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_attendances`
--
ALTER TABLE `mtpl_attendances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_attendances_2`
--
ALTER TABLE `mtpl_attendances_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_bank_guarantees`
--
ALTER TABLE `mtpl_bank_guarantees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_clients`
--
ALTER TABLE `mtpl_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `mtpl_contributions`
--
ALTER TABLE `mtpl_contributions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_designations`
--
ALTER TABLE `mtpl_designations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mtpl_dispatches`
--
ALTER TABLE `mtpl_dispatches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_districts`
--
ALTER TABLE `mtpl_districts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=641;

--
-- AUTO_INCREMENT for table `mtpl_employees`
--
ALTER TABLE `mtpl_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `mtpl_employee_salary_structures`
--
ALTER TABLE `mtpl_employee_salary_structures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_expenses`
--
ALTER TABLE `mtpl_expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_increment_schemes`
--
ALTER TABLE `mtpl_increment_schemes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_invoices`
--
ALTER TABLE `mtpl_invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_invoice_details`
--
ALTER TABLE `mtpl_invoice_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_items`
--
ALTER TABLE `mtpl_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_leave_requests`
--
ALTER TABLE `mtpl_leave_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_leave_types`
--
ALTER TABLE `mtpl_leave_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_log_records`
--
ALTER TABLE `mtpl_log_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=246;

--
-- AUTO_INCREMENT for table `mtpl_payroll_reports`
--
ALTER TABLE `mtpl_payroll_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_permissions`
--
ALTER TABLE `mtpl_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `mtpl_salary_annexures`
--
ALTER TABLE `mtpl_salary_annexures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_salary_components`
--
ALTER TABLE `mtpl_salary_components`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_salary_slips`
--
ALTER TABLE `mtpl_salary_slips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_salary_statements`
--
ALTER TABLE `mtpl_salary_statements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_salary_statement_structures`
--
ALTER TABLE `mtpl_salary_statement_structures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_states`
--
ALTER TABLE `mtpl_states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `mtpl_tasks`
--
ALTER TABLE `mtpl_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_tax_entry`
--
ALTER TABLE `mtpl_tax_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_units`
--
ALTER TABLE `mtpl_units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_vacancies`
--
ALTER TABLE `mtpl_vacancies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_vendors`
--
ALTER TABLE `mtpl_vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mtpl_work_orders`
--
ALTER TABLE `mtpl_work_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mtpl_attendances`
--
ALTER TABLE `mtpl_attendances`
  ADD CONSTRAINT `mtpl_attendances_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_bank_guarantees`
--
ALTER TABLE `mtpl_bank_guarantees`
  ADD CONSTRAINT `mtpl_bank_guarantees_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `mtpl_work_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_districts`
--
ALTER TABLE `mtpl_districts`
  ADD CONSTRAINT `mtpl_districts_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `mtpl_states` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_employees`
--
ALTER TABLE `mtpl_employees`
  ADD CONSTRAINT `mtpl_employees_ibfk_1` FOREIGN KEY (`designation`) REFERENCES `mtpl_designations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employees_ibfk_2` FOREIGN KEY (`client`) REFERENCES `mtpl_clients` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employees_ibfk_3` FOREIGN KEY (`permanent_district`) REFERENCES `mtpl_districts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employees_ibfk_4` FOREIGN KEY (`present_district`) REFERENCES `mtpl_districts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employees_ibfk_5` FOREIGN KEY (`permanent_state`) REFERENCES `mtpl_states` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employees_ibfk_6` FOREIGN KEY (`present_state`) REFERENCES `mtpl_states` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_employee_permissions`
--
ALTER TABLE `mtpl_employee_permissions`
  ADD CONSTRAINT `mtpl_employee_permissions_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employee_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `mtpl_permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_employee_salary_structures`
--
ALTER TABLE `mtpl_employee_salary_structures`
  ADD CONSTRAINT `mtpl_employee_salary_structures_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_employee_salary_structures_ibfk_2` FOREIGN KEY (`component_id`) REFERENCES `mtpl_salary_components` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_invoice_details`
--
ALTER TABLE `mtpl_invoice_details`
  ADD CONSTRAINT `mtpl_invoice_details_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `mtpl_invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_leave_requests`
--
ALTER TABLE `mtpl_leave_requests`
  ADD CONSTRAINT `mtpl_leave_requests_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_leave_requests_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `mtpl_leave_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_leave_requests_ibfk_3` FOREIGN KEY (`created_by_admin_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_leave_types`
--
ALTER TABLE `mtpl_leave_types`
  ADD CONSTRAINT `mtpl_leave_types_ibfk_1` FOREIGN KEY (`fallback_leave_type_id`) REFERENCES `mtpl_leave_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_payroll_reports`
--
ALTER TABLE `mtpl_payroll_reports`
  ADD CONSTRAINT `mtpl_payroll_reports_ibfk_1` FOREIGN KEY (`generated_by_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_salary_slips`
--
ALTER TABLE `mtpl_salary_slips`
  ADD CONSTRAINT `mtpl_salary_slips_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `mtpl_payroll_reports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_salary_statements`
--
ALTER TABLE `mtpl_salary_statements`
  ADD CONSTRAINT `mtpl_salary_statements_ibfk_1` FOREIGN KEY (`statement_id`) REFERENCES `mtpl_salary_statement_structures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_salary_statements_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `mtpl_employees` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_tasks`
--
ALTER TABLE `mtpl_tasks`
  ADD CONSTRAINT `mtpl_tasks_ibfk_1` FOREIGN KEY (`EmployeeId`) REFERENCES `mtpl_employees` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `mtpl_work_orders`
--
ALTER TABLE `mtpl_work_orders`
  ADD CONSTRAINT `mtpl_work_orders_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `mtpl_clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mtpl_work_orders_ibfk_2` FOREIGN KEY (`created_by_client_id`) REFERENCES `mtpl_clients` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
