import { models } from "../models/index.js";
import { Op } from "sequelize";

const { Client } = models;

/**
 * @desc    Create a new client
 * @route   POST /api/clients
 * @access  Private
 */
export const createClient = async (req, res) => {
  try {
    // Basic validation: ensure at least a client name is provided
    if (!req.body.clientNm) {
      return res.status(400).json({ message: "Client Name (clientNm) is required." });
    }

    const newClient = await Client.create(req.body);

    res.status(201).json({ message: "Client created successfully.", data: newClient });
  } catch (error) {
    console.error("Error creating client:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Get all non-deleted clients with pagination
 * @route   GET /api/clients
 * @access  Public
 */
export const getAllClients = async (req, res) => {
  try {
    // --- 1. PAGINATION LOGIC ---
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    // --- 2. SEARCHING LOGIC ---
    const searchTerm = req.query.search || '';
    
    // Start with a base `where` clause
    const where = {
      is_delete: false,
    };

    // If a search term is provided, add conditions to the `where` clause
    if (searchTerm) {
      where[Op.or] = [
        { clientNm: { [Op.like]: `%${searchTerm}%` } },
        { projNm: { [Op.like]: `%${searchTerm}%` } },
        { email: { [Op.like]: `%${searchTerm}%` } },
        { mob: { [Op.like]: `%${searchTerm}%` } },
      ];
    }

    // --- 3. SORTING LOGIC ---
    const sortBy = req.query.sort || 'created_at';
    const sortOrder = req.query.order || 'DESC';
    if (!['ASC', 'DESC'].includes(sortOrder.toUpperCase())) {
      return res.status(400).json({ message: "Invalid sort order." });
    }
    const order = [[sortBy, sortOrder]];

    // --- 4. DATABASE QUERY ---
    // Use all the prepared options in the query
    const { count, rows } = await Client.findAndCountAll({
      where: where,       // Use the dynamic where clause
      order: order,       // Use the dynamic order clause
      limit: limit,       // Apply the limit for pagination
      offset: offset,     // Apply the offset for pagination
    });

    res.status(200).json({
  message: "Clients retrieved successfully.",
  data: rows,
  
  // Add the total count at the top level
  total: count, 
  
  // Send the rest of the pagination info inside a 'meta' object
  meta: {       
    totalPages: Math.ceil(count / limit),
    currentPage: page,
  }
});
  } catch (error) {
    console.error("Error fetching clients:", error);
    if (error.name === 'SequelizeDatabaseError') {
      return res.status(400).json({ message: "Invalid sort or search column provided." });
    }
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Get a single client by its ID
 * @route   GET /api/clients/:id
 * @access  Public
 */
export const getClientById = async (req, res) => {
  try {
    const { id } = req.params;
    const client = await Client.findOne({
      where: {
        id: id,
        is_delete: false, // Ensure we don't fetch a deleted client
      },
    });

    if (!client) {
      return res.status(404).json({ message: "Client not found." });
    }

    res.status(200).json({ message: "Client retrieved successfully.", data: client });
  } catch (error) {
    console.error("Error fetching client:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Update an existing client by ID
 * @route   PUT /api/clients/:id
 * @access  Private
 */
export const updateClient = async (req, res) => {
  try {
    const { id } = req.params;
    const client = await Client.findOne({
        where: { id: id, is_delete: false }
    });

    if (!client) {
      return res.status(404).json({ message: "Client not found." });
    }

    // Update the client with the new data from the request body
    const updatedClient = await client.update(req.body);

    res.status(200).json({ message: "Client updated successfully.", data: updatedClient });
  } catch (error) {
    console.error("Error updating client:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

/**
 * @desc    Soft delete a client by ID
 * @route   DELETE /api/clients/:id
 * @access  Private
 */
export const deleteClient = async (req, res) => {
  try {
    const { id } = req.params;
    const client = await Client.findOne({
        where: { id: id, is_delete: false }
    });

    if (!client) {
      return res.status(404).json({ message: "Client not found." });
    }

    // Perform a soft delete by setting the is_delete flag to true
    client.is_delete = true;
    await client.save();

    res.status(200).json({ message: "Client deleted successfully." });
  } catch (error) {
    console.error("Error deleting client:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
export const toggleClientStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const client = await Client.findOne({
      where: { id: id, is_delete: false },
    });

    if (!client) {
      return res.status(404).json({ message: "Client not found." });
    }

    // Toggle the is_active status
    client.is_active = !client.is_active;
    await client.save();

    const status = client.is_active ? "activated" : "deactivated";
    res.status(200).json({ message: `Client successfully ${status}.`, data: client });

  } catch (error) {
    console.error("Error toggling client status:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};