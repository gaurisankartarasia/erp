import React from "react";
import { Button } from "@/components/ui/button";

export default function FormLayout({
  title,
  children,
  onSubmit,
  onReset,
  onCancel,
  submitText = "Submit",
  showSubmit = true,
}) {
  return (
    <div  className="bg-white" >
      <div className="flex justify-between items-center p-6">
        <h2 className="text-xl font-semibold">{title}</h2>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit && onSubmit();
        }}
        className="shadow p-6"
      >
        <div className="grid grid-cols-2 gap-6">{children}</div>

        <div className="mt-6 flex gap-3 justify-start">
          {showSubmit && (
            <Button type="submit" variant="default">
              {submitText}
            </Button>
          )}
          {onReset && (
            <Button
              type="button"
              variant="outline"
              onClick={() => onReset && onReset()}
            >
              Reset
            </Button>
          )}
          {onCancel && (
            <Button
              type="button"
              variant="destructive"
              onClick={() => onCancel && onCancel()}
            >
              Cancel
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}
