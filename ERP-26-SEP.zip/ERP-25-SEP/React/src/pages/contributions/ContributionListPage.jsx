import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import PageLayout from '@/components/layouts/PageLayout';
import ShadcnDataTable from '@/components/common/DataTable';
import { useServerSideTable } from '@/hooks/useServerSideTable';
import { Button } from '@/components/ui/button';

import {  X , Check, Edit } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import apiClient from '@/api/axiosConfig';
import { useMessageModal } from "@/hooks/useMessageModal";
import { useConfirmModal } from "@/hooks/useConfirmModal";

export default function ContributionListPage() {
  const { data, tableState, refreshData } = useServerSideTable(`${import.meta.env.VITE_API_BASE_URL}/contributions`);
  const message = useMessageModal();
  const confirm = useConfirmModal();
  const handleStatusToggle = async (contribution) => {
    const confirmed = await confirm({

          description: `Do you really want to ${
        contribution.is_active ? "deactivate" : "activate"
      } this record?`
    })
    if(!confirmed) return
    try {
      const newStatus = !contribution.is_active;
      await apiClient.patch(`/contributions/status/${contribution.id}`, {
        is_active: newStatus,
      });
      refreshData();
    } catch (error) {
      console.error('Failed to update status:', error);
      alert('Failed to update contribution status.');
    }
  };

  const columns = useMemo(
    () => [
          {
        header: "Sl. No",
        cell: ({ row }) =>
          (tableState.currentPage - 1) * tableState.entriesPerPage +
          row.index +
          1,
      },
      {
        accessorKey: 'cont_id',
        header: 'ID',
        enableSorting: true,
      },
      {
        accessorKey: 'date',
        header: 'Date',
        enableSorting: true,
      },
      {
        accessorKey: 'epf_employee_share',
        header: 'EPF Emp Share',
        enableSorting: false,
        enableSorting: true,
      },
      {
        accessorKey: 'epf_employer_share',
        header: 'EPF Empr Share',
        enableSorting: false,
        enableSorting: true,
      },
      {
        accessorKey: 'esi_employee_share',
        header: 'ESI Emp Share',
        enableSorting: false,
        enableSorting: true,
      },
      {
        accessorKey: 'esi_employer_share',
        header: 'ESI Empr Share',
        enableSorting: false,
        enableSorting: true,
      },
      {
        accessorKey: 'is_active',
        header: 'Status',
        enableSorting: true,
        cell: ({ row }) => {
          const isActive = row.original.is_active;
          return (
            <Badge variant={isActive ? 'default' : 'destructive'}>
              {isActive ? 'Active' : 'Inactive'}
            </Badge>
          );
        },
      },
      {
        header: 'Actions',
        cell: ({ row }) => {
          const contribution = row.original;
          return (
            <>
                    <Button
                variant={"ghost"}
                onClick={() => handleStatusToggle(contribution)}
              >
                {contribution.is_active ? (
                  <X className="text-red-500" />
                ) : (
                  <Check className="text-green-500" />
                )}
              </Button>
              <Button variant={"ghost"} asChild>
                <Link to={`/contributions/edit/${contribution.id}`}>
                  <Edit className="text-blue-500" />
                </Link>
              </Button>
            {/* <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <span className="sr-only">Open menu</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link to={`/contributions/edit/${contribution.id}`}>Edit</Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusToggle(contribution)}>
                  {contribution.is_active ? 'Set to Inactive' : 'Set to Active'}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu> */}
            </>
          
          );
        },
      },
    ],
    []
  );

  return (
    <PageLayout
      title="Contributions"
      rightButton={{ text: 'Add EPF/ESI', path: 'create' }}
    >
      <ShadcnDataTable
        columns={columns}
        data={data}
        tableState={tableState}
      />
    </PageLayout>
  );
}