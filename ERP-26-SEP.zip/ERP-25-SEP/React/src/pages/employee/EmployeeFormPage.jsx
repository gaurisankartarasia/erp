//     <FormInput name={`${type}_address`} label="Address" rules={{ required: "Address is required" }} disabled={isDisabled} />
//     <FormInput name={`${type}_pin_code`} label="Pincode" rules={{ required: "Pincode is required" }} disabled={isDisabled} />
//     <FormSelect name={`${type}_state`} label="State" options={stateOptions} disabled={isDisabled} rules={{ required: "State is required" }} />
//     <FormSelect name={`${type}_district`} label="District" options={districtOptions} disabled={isDisabled} placeholder={!isDisabled ? "Select a state first" : undefined} rules={{ required: "District is required" }} />

//     return await fetchData(`/locations/states/${stateId}/districts`, "id", "district_name");

//             <FormInput name="father_name" label="Father's Name" rules={{ required: "Father's Name is required" }} />
//             <FormInput name="mother_name" label="Mother's Name" />

//             {maritalStatus === "married" && <FormInput name="spouse_name" label="Spouse's Name" rules={{ required: "Spouse's name is required" }} />}

import React, { useEffect, useCallback, useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, FormProvider } from "react-hook-form";
import FormLayout from "@/components/layouts/FormLayout";
import FormInput from "./custom/FormInput";
import FormSelect from "./custom/FormSelect";
import apiClient from "@/api/axiosConfig";
import { useMessageModal } from "@/hooks/useMessageModal";
import DocumentUploader from "@/components/common/forms/FormDocumentUpload";

const SectionHeader = ({ title }) => (
  <div className="col-span-4 mt-4 border-b pb-2">
    <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
  </div>
);

const AddressFields = ({ type, stateOptions, districtOptions, isDisabled }) => (
  <>
    <SectionHeader
      title={`${type.charAt(0).toUpperCase() + type.slice(1)} Address`}
    />
    <FormInput
      name={`${type}_address`}
      label="Address"
      rules={{ required: "Address is required" }}
      disabled={isDisabled}
    />
    <FormInput
      name={`${type}_pin_code`}
      label="Pincode"
      rules={{ required: "Pincode is required" }}
      disabled={isDisabled}
    />
    <FormSelect
      name={`${type}_state`}
      label="State"
      options={stateOptions}
      disabled={isDisabled}
      rules={{ required: "State is required" }}
    />
    <FormSelect
      name={`${type}_district`}
      label="District"
      options={districtOptions}
      disabled={isDisabled}
      placeholder={
        !isDisabled && districtOptions.length === 0
          ? "Select a state first"
          : "--Select an option--"
      }
      rules={{ required: "District is required" }}
    />
  </>
);

const EmployeeFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const message = useMessageModal();

  const methods = useForm({
    defaultValues: {
      user_type: "",
      name: "",
      email: "",
      mobile_no: "",
      dob: "",
      doj: "",
      designation: "",
      client: "",
      guardian_contact: "",
      gender: "",
      religion: "",
      father_name: "",
      mother_name: "",
      marital_status: "",
      spouse_name: "",
      qualification: "",
      extra_qualification: "",
      pan_no: "",
      bank_name: "",
      aadhar_no: "",
      branch_name: "",
      branch_id: "",
      esi_ip_no: "",
      ifsc_code: "",
      epf_uan_no: "",
      bank_ac_no: "",
      blood_group: "",
      gross_salary: "",
      dor: "",
      upload_image: null,
      upload_resume: null,
      present_address: "",
      present_district: "",
      present_state: "",
      present_pin_code: "",
      permanent_address: "",
      permanent_district: "",
      permanent_state: "",
      permanent_pin_code: "",
    },
  });

  const { handleSubmit, reset, watch, setValue, getValues } = methods;

  const [options, setOptions] = useState({
    designations: [],
    clients: [],
    states: [],
  });
  const [districts, setDistricts] = useState({ present: [], permanent: [] });
  const [isSameAddress, setIsSameAddress] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(!!id);
  const [employeeData, setEmployeeData] = useState(null);

  const presentStateId = watch("present_state");
  const permanentStateId = watch("permanent_state");
  const maritalStatus = watch("marital_status");

  const selectOptions = useMemo(
    () => ({
      user_type: [
        { value: "user", label: "User" },
        { value: "admin", label: "Admin" },
        { value: "master", label: "Master" },
      ],
      gender: [
        { value: "male", label: "Male" },
        { value: "female", label: "Female" },
        { value: "others", label: "Others" },
      ],
      religion: [
        { value: "Hindu", label: "Hindu" },
        { value: "Muslim", label: "Muslim" },
        { value: "Christian", label: "Christian" },
      ],
      marital_status: [
        { value: "single", label: "Single" },
        { value: "married", label: "Married" },
        { value: "divorced", label: "Divorced" },
        { value: "widowed", label: "Widowed" },
      ],
      blood_group: ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(
        (bg) => ({
          value: bg,
          label: bg,
        })
      ),
    }),
    []
  );

  const formatOptionsForSelect = useCallback((data, valueKey, labelKey) => {
    if (!Array.isArray(data)) return [];
    return data
      .filter((item) => item && item[valueKey] != null)
      .map((item) => ({
        value: String(item[valueKey]),
        label: item[labelKey],
      }));
  }, []);

  const fetchData = useCallback(
    async (endpoint, valueKey, labelKey) => {
      try {
        const response = await apiClient.get(endpoint);
        return formatOptionsForSelect(response.data.data, valueKey, labelKey);
      } catch (error) {
        message.error(`Failed to fetch options from ${endpoint}`);
        return [];
      }
    },
    [message, formatOptionsForSelect]
  );

  useEffect(() => {
    const fetchInitialOptions = async () => {
      try {
        const [designations, clients, states] = await Promise.all([
          fetchData("master/designations", "id", "designation_name"),
          fetchData("master/clients", "id", "projNm"),
          fetchData("/locations/states", "id", "state_name"),
        ]);
        setOptions({ designations, clients, states });
      } catch (error) {
        message.error("Failed to fetch initial options");
      }
    };
    fetchInitialOptions();
  }, [fetchData, message]);

  const fetchDistricts = useCallback(
    async (stateId) => {
      if (!stateId) return [];
      return await fetchData(
        `/locations/states/${stateId}/districts`,
        "id",
        "district_name"
      );
    },
    [fetchData]
  );

  useEffect(() => {
    if (!id) return;

    const fetchEmployee = async () => {
      setIsLoading(true);
      try {
        const response = await apiClient.get(`/employee/employees/${id}`);
        const data = response.data;

        setEmployeeData(data);

        const promises = [];

        if (data.present_state) {
          promises.push(
            fetchDistricts(data.present_state).then((districts) => ({
              type: "present",
              districts,
            }))
          );
        }

        if (
          data.permanent_state &&
          data.permanent_state !== data.present_state
        ) {
          promises.push(
            fetchDistricts(data.permanent_state).then((districts) => ({
              type: "permanent",
              districts,
            }))
          );
        }

        if (promises.length > 0) {
          const results = await Promise.all(promises);

          const newDistricts = { present: [], permanent: [] };
          results.forEach((result) => {
            newDistricts[result.type] = result.districts;
          });

          if (data.permanent_state === data.present_state) {
            newDistricts.permanent = newDistricts.present;
          }

          setDistricts(newDistricts);
        }

        const formData = {
          ...data,
          designation: String(data.designation || ""),
          client: String(data.client || ""),
          present_state: String(data.present_state || ""),
          present_district: String(data.present_district || ""),
          permanent_state: String(data.permanent_state || ""),
          permanent_district: String(data.permanent_district || ""),
          upload_image: null,
          upload_resume: null,
        };

        setTimeout(() => {
          reset(formData);
        }, 0);
      } catch (error) {
        message.error("Failed to fetch employee data");
        navigate("/employees");
      } finally {
        setIsLoading(false);
      }
    };

    fetchEmployee();
  }, [id, reset, message, navigate, fetchDistricts]);

  useEffect(() => {
    // Skip if we're in edit mode and still loading initial data
    if (id && isLoading) return;

    const fetchDistrictsForStates = async () => {
      const promises = [];

      if (presentStateId) {
        promises.push(
          fetchDistricts(presentStateId).then((districts) => ({
            type: "present",
            districts,
          }))
        );
      }

      if (permanentStateId && !isSameAddress) {
        promises.push(
          fetchDistricts(permanentStateId).then((districts) => ({
            type: "permanent",
            districts,
          }))
        );
      }

      if (promises.length > 0) {
        try {
          const results = await Promise.all(promises);

          setDistricts((prev) => {
            const newDistricts = { ...prev };
            results.forEach((result) => {
              newDistricts[result.type] = result.districts;
            });
            return newDistricts;
          });
        } catch (error) {
          message.error("Failed to fetch districts");
        }
      }
    };

    fetchDistrictsForStates();
  }, [
    presentStateId,
    permanentStateId,
    isSameAddress,
    fetchDistricts,
    message,
    id,
    isLoading,
  ]);

  useEffect(() => {
    if (isSameAddress) {
      const [presentAddress, presentPinCode, presentState, presentDistrict] =
        getValues([
          "present_address",
          "present_pin_code",
          "present_state",
          "present_district",
        ]);

      setValue("permanent_address", presentAddress);
      setValue("permanent_pin_code", presentPinCode);
      setValue("permanent_state", presentState);
      setValue("permanent_district", presentDistrict);

      setDistricts((prev) => ({
        ...prev,
        permanent: prev.present,
      }));
    }
  }, [isSameAddress, getValues, setValue]);

  useEffect(() => {
    if (isSameAddress && presentStateId) {
      const presentValues = getValues([
        "present_address",
        "present_pin_code",
        "present_district",
      ]);

      setValue("permanent_address", presentValues[0]);
      setValue("permanent_pin_code", presentValues[1]);
      setValue("permanent_state", presentStateId);
      setValue("permanent_district", presentValues[2]);
    }
  }, [isSameAddress, presentStateId, getValues, setValue]);

  const onSubmit = async (data) => {
    setIsSubmitting(true);

    try {
      const payload = new FormData();

      Object.keys(data).forEach((key) => {
        const value = data[key];

        if (value === null || value === undefined || value === "") {
          return;
        }

        if (key === "upload_image" || key === "upload_resume") {
          if (value instanceof FileList && value.length > 0) {
            payload.append(key, value[0]);
          } else if (value instanceof File) {
            payload.append(key, value);
          }
          return;
        }

        payload.append(key, String(value));
      });

      let response;
      if (id) {
        response = await apiClient.put(`/employee/edit/${id}`, payload, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        message.success("Employee updated successfully.");
      } else {
        response = await apiClient.post("/employee/register", payload, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        message.success("Employee registered successfully.");

        if (response.data.generatedPassword) {
          message.info(
            `Generated Password: ${response.data.generatedPassword}`
          );
        }
      }

      navigate("/employees");
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || "An unexpected error occurred.";
      message.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = useCallback(() => {
    navigate("/employees");
  }, [navigate]);

  const handleReset = useCallback(() => {
    reset();
    setDistricts({ present: [], permanent: [] });
    setIsSameAddress(false);
  }, [reset]);

  return (
    <FormProvider {...methods}>
      <FormLayout
        title={id ? "Edit Employee" : "Register Employee"}
        backPath="/employees"
        onSubmit={handleSubmit(onSubmit)}
        isSubmitting={isSubmitting}
        submitText={id ? "Update" : "Submit"}
        onCancel={handleCancel}
        onReset={handleReset}
        isLoading={isLoading}
      >
        <div className="col-span-2">
          <div className="grid grid-cols-4 gap-6">
            <FormSelect
              name="user_type"
              label="User Type"
              options={selectOptions.user_type}
              rules={{ required: "User type is required" }}
            />
            <FormInput
              name="name"
              label="Name"
              rules={{ required: "Name is required" }}
            />
            <FormInput
              name="mobile_no"
              label="Mobile No"
              maxLength={10}
              rules={{
                required: "Mobile No is required",
                minLength: {
                  value: 10,
                  message: "Mobile number must be 10 digits",
                },
                maxLength: {
                  value: 10,
                  message: "Mobile number must be 10 digits",
                },
              }}
            />
            <FormInput
              name="dob"
              label="DOB"
              type="date"
              rules={{ required: "Date of Birth is required" }}
            />
            <FormInput
              name="doj"
              label="DOJ"
              type="date"
              rules={{ required: "Date of Joining is required" }}
            />
            <FormSelect
              name="designation"
              label="Designation"
              options={options.designations}
              rules={{ required: "Designation is required" }}
            />
            <FormSelect
              name="client"
              label="Client Location"
              options={options.clients}
              rules={{ required: "Client Location is required" }}
            />
            <FormInput
              name="email"
              label="Email Id"
              rules={{
                required: "Email is required",
                pattern: {
                  value: /^\S+@\S+$/i,
                  message: "Invalid email address",
                },
              }}
            />
            <FormInput
              name="father_name"
              label="Father's Name"
              rules={{ required: "Father's Name is required" }}
            />
            <FormInput name="mother_name" label="Mother's Name" />
            <FormInput
              name="guardian_contact"
              label="Guardian Contact"
              rules={{ required: "Guardian Contact is required" }}
            />
            <FormSelect
              name="gender"
              label="Gender"
              options={selectOptions.gender}
              rules={{ required: "Gender is required" }}
            />
            <FormSelect
              name="religion"
              label="Religion"
              options={selectOptions.religion}
            />
            <FormSelect
              name="marital_status"
              label="Marital Status"
              options={selectOptions.marital_status}
              rules={{ required: "Marital Status is required" }}
            />
            {maritalStatus === "married" && (
              <FormInput
                name="spouse_name"
                label="Spouse's Name"
                rules={{ required: "Spouse's name is required" }}
              />
            )}
            <FormSelect
              name="blood_group"
              label="Blood Group"
              options={selectOptions.blood_group}
            />
            <FormInput name="qualification" label="Qualification" />
            <FormInput name="extra_qualification" label="Extra Qualification" />
            <FormInput
              name="pan_no"
              label="PAN Number"
              rules={{ required: "PAN is required" }}
            />
            <FormInput
              name="aadhar_no"
              label="Aadhar Number"
              rules={{ required: "Aadhar is required" }}
            />
            <FormInput name="epf_uan_no" label="EPF UAN Number" />
            <FormInput name="esi_ip_no" label="ESI IP Number" />
            <FormInput
              name="bank_name"
              label="Bank Name"
              rules={{ required: "Bank name is required" }}
            />
            <FormInput
              name="bank_ac_no"
              label="Bank Account Number"
              rules={{ required: "Account no. is required" }}
            />
            <FormInput
              name="branch_name"
              label="Branch Name"
              rules={{ required: "Branch name is required" }}
            />
            <FormInput
              name="ifsc_code"
              label="IFSC Code"
              rules={{ required: "IFSC code is required" }}
            />
            <FormInput
              name="branch_id"
              label="Branch Id"
              rules={{ required: "Branch Id is required" }}
            />

            <AddressFields
              type="present"
              stateOptions={options.states}
              districtOptions={districts.present}
            />

            <div className="col-span-4 flex items-center gap-2">
              <input
                type="checkbox"
                id="sameAddress"
                checked={isSameAddress}
                onChange={(e) => setIsSameAddress(e.target.checked)}
                className="h-4 w-4 rounded"
              />
              <label htmlFor="sameAddress" className="text-sm font-medium">
                Permanent Address is same as Present Address
              </label>
            </div>

            <AddressFields
              type="permanent"
              stateOptions={options.states}
              districtOptions={
                isSameAddress ? districts.present : districts.permanent
              }
              isDisabled={isSameAddress}
            />

            <FormInput name="gross_salary" label="Gross Salary" type="number" />
            <FormInput name="dor" label="Date of Resignation" type="date" />

            <DocumentUploader
              name="upload_image"
              label="Upload Image"
              allowedTypes={[
                "image/jpg",
                "image/jpeg",
                "image/png",
                "image/webp",
              ]}
              maxSizeMB={2}
            />
            <DocumentUploader
              name="upload_resume"
              label="Upload Resume"
              allowedTypes={["application/pdf"]}
              maxSizeMB={2}
            />
          </div>
        </div>
      </FormLayout>
    </FormProvider>
  );
};

export default EmployeeFormPage;
