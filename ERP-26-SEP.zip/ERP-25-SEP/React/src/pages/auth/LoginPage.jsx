// import React, { useState } from "react";
// import { Button } from "@/components/ui/button";
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardHeader,
//   CardTitle,
// } from "@/components/ui/card";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import useAuth from "@/hooks/useAuth";
// import logo from "@/assets/logo.png"

// const LoginForm = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const { login } = useAuth();

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       await login(email, password);
//     } catch (error) {
//       console.error("Login failed:", error.response?.data || error.message);
//     }
//   };

//   return (
//    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
//   <div className="flex items-center justify-center p-6 bg-primary/50">
//     <img
//       src={logo}
//       alt="Login Illustration"
//       className="max-w-sm w-full"
//     />
//   </div>

//   <div className="flex items-center justify-center p-6 bg-white">
//     <div className="w-full max-w-md">
//       <Card className="border-none bg-transparent shadow-none">
//         <CardHeader className="text-center">
//           <CardTitle className="text-2xl">Login to your account</CardTitle>
//           <CardDescription>
//             Enter your email below to login to your account
//           </CardDescription>
//         </CardHeader>
//         <CardContent>
//           <form onSubmit={handleSubmit}>
//             <div className="flex flex-col gap-6">
//               <div className="grid gap-3">
//                 <Label htmlFor="email">Email</Label>
//                 <Input
//                   id="email"
//                   name="email"
//                   type="email"
//                   placeholder="m@example.com"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                   required
//                 />
//               </div>
//               <div className="grid gap-3">
//                 <div className="flex items-center">
//                   <Label htmlFor="password">Password</Label>
                
//                 </div>
//                 <Input
//                   id="password"
//                   name="password"
//                   type="password"
//                   value={password}
//                   onChange={(e) => setPassword(e.target.value)}
//                   required
//                 />

//               </div>
//               <Button type="submit" className="w-full">
//                 Login
//               </Button>
//             </div>
//           </form>
//         </CardContent>
//       </Card>
//     </div>
//   </div>
// </div>

//   );
// };

// export default LoginForm;


import React from "react";
import { useForm, FormProvider } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import useAuth from "@/hooks/useAuth";
import logo from "@/assets/logo.png";
import FormInput from "@/pages/employee/custom/FormInput";

const LoginForm = () => {
  const methods = useForm({
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const { handleSubmit } = methods;
  const { login } = useAuth();

  const onSubmit = async (data) => {
    try {
      await login(data.email, data.password);
    } catch (error) {
      console.error("Login failed:", error.response?.data || error.message);
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      <div className="flex items-center justify-center p-6 bg-primary/50" >
        <img src={logo} alt="Login Illustration" className="max-w-sm w-full" />
      </div>

      <div className="flex items-center justify-center p-6 bg-white">
        <div className="w-full max-w-md">
          <Card className="border-none bg-transparent shadow-none">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Login</CardTitle>
              <CardDescription>
                Enter your credentials below to login to your account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormProvider {...methods}>
                <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
                  <FormInput
                    name="email"
                    label="Email"
                    type="email"
                    placeholder="m@example.com"
                    required
                    rules={{
                      required: "Email is required",
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        message: "Enter a valid email address",
                      },
                    }}
                  />

                  <FormInput
                    name="password"
                    label="Password"
                    type="password"
                    placeholder="••••••••"
                    required
                    rules={{
                      required: "Password is required",
                      minLength: { value: 6, message: "Minimum 6 characters" },
                    }}
                  />

                  <Button type="submit" className="w-full">
                    Login
                  </Button>
                </form>
              </FormProvider>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
