import {
  MdOutlineDashboard,
  MdOutlineTune,
  MdOutlineBusiness,
  MdOutlineApartment,
  MdOutlineBadge,
  MdOutlineAccountBalanceWallet,
  MdOutlineLayers,
  MdOutlineCategory,
  MdOutlinePersonAddAlt,
  MdOutlineStorefront,
  MdOutlineTrendingUp,
  MdOutlineSchema,
  MdOutlineSummarize,
  MdOutlineTaskAlt,
  MdOutlineFormatListBulleted,
  MdOutlineHistory,
  MdOutlineAssignmentInd,
  MdOutlinePayments,
  MdOutlinePolicy,
  MdOutlineAccountTree,
  MdOutlineCurrencyRupee,
  MdOutlineEventBusy,
  MdOutlineClass,
  MdOutlineDateRange,
  MdOutlineSend,
  MdOutlineReceiptLong,
  MdOutlineGroup,
  MdOutlineAdminPanelSettings,
} from "react-icons/md";

// import { permissions } from "@/utils/permissions";

export const navItems = [
  {
    href: "/",
    icon: MdOutlineDashboard,
    label: "Dashboard",
    permission: null,
  },
  {
    href: "/page-permissions",
    icon: MdOutlineAdminPanelSettings,
    label: "Page Permissions",
    permission: null,
  },
 
  {
    label: "Master",
    icon: MdOutlineTune,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/clients",
        icon: MdOutlineBusiness,
        label: "Manage Client",
        permission: null,
      },
      {
        href: "/company-profile",
        icon: MdOutlineApartment,
        label: "Company Profile",
        permission: null,
      },
      {
        href: "/designations",
        icon: MdOutlineBadge,
        label: "Manage Designations",
        permission: null,
      },
      {
        href: "/contributions",
        icon: MdOutlineAccountBalanceWallet,
        label: "Manage EPF/ESI",
        permission: null,
      },
      {
        href: "/manage-unit",
        icon: MdOutlineLayers,
        label: "Manage Unit",
        permission: null,
      },
      {
        href: "/manage-item",
        icon: MdOutlineCategory,
        label: "Manage Item",
        permission: null,
      },
      {
        href: "/master/vacancies",
        icon: MdOutlinePersonAddAlt,
        label: "Manage Vacancy",
        permission: null,
      },
      {
        href: "/master/vendors",
        icon: MdOutlineStorefront,
        label: "Manage Vendor",
        permission: null,
      },
       {
    href: "/employees",
    icon: MdOutlineGroup,
    label: "Manage Employees",
    permission: null,
    
  },
    ],
  },
     {
    icon: MdOutlineGroup,
    label: "Workflow",
    permission: null,
     isSubmenu: true,
     subItems: [
      {
            
    href: "/supplierexpenses",
    icon: MdOutlineGroup,
    label: "Vendor Expenses Entry",
    permission: null,
    
  
      }
     ]
  },
  {
    label: "Increments",
    icon: MdOutlineTrendingUp,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/incrementschemes",
        icon: MdOutlineSchema,
        label: "Increment Schemes",
        permission: null,
      },
      {
        href: "/increment-reports",
        icon: MdOutlineSummarize,
        label: "Increment Reports",
        permission: null,
      },
    ],
  },
  {
    label: "Tasks",
    icon: MdOutlineTaskAlt,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/tasks",
        icon: MdOutlineFormatListBulleted,
        label: "Tasks",
        permission: null,
      },
      {
        href: "/tasks/history",
        icon: MdOutlineHistory,
        label: "Tasks History",
        permission: null,
      },
      {
        href: "/tasks/all-employees",
        icon: MdOutlineAssignmentInd,
        label: "All Employee Tasks",
        permission: null,
      },
    ],
  },
  {
    label: "Payroll",
    icon: MdOutlinePayments,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/salary-components",
        icon: MdOutlinePolicy,
        label: "Salary Policy",
        permission: null,
      },
      {
        href: "/salary-stucture",
        icon: MdOutlineAccountTree,
        label: "Salary Structure",
        permission: null,
      },
      {
        href: "/salary-payroll",
        icon: MdOutlineCurrencyRupee,
        label: "Generate Salary",
        permission: null,
      },
    ],
  },
  {
    label: "Leaves",
    icon: MdOutlineEventBusy,
    permission: null,
    isSubmenu: true,
    subItems: [
      {
        href: "/leave-types",
        icon: MdOutlineClass,
        label: "Leave Types",
        permission: null,
      },
      {
        href: "/manage-leaves",
        icon: MdOutlineDateRange,
        label: "Manage Leaves",
        permission: null,
      },
      {
        href: "/request-leave",
        icon: MdOutlineSend,
        label: "Request Leave",
        permission: null,
      },
    ],
  },
  {
    href: "/log",
    icon: MdOutlineReceiptLong,
    label: "Activity Log",
    permission: null,
  },
];